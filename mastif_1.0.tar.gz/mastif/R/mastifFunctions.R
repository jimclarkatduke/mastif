
mastIDmatrix <- function(treeData, seedData, genus, 
                         specNames = NULL, seedNames = NULL, 
                         censMin = NULL, ngen = 4){
  
  # possible seed ID errors: seedNames counted where seedNames of species 
  #    is missing. A '1' in R matrix indicates a 
  # must supply either 'genus' or both 'specNames' and 'seedNames'
  # ngen: no. of characters to match in genus
  
  CENS <- F
  
  specIn <- specNames
  seedIn <- seedNames
  
  plotT <- treeData$plot <- as.character(treeData$plot)
  plotS <- seedData$plot <- as.character(seedData$plot)
  treeData$species <- as.character(treeData$species)
  
  if(is.null(specNames)){
    trows  <- which( startsWith( treeData$species, substr(genus,1,4) ) )
    specNames <- sort(unique(treeData$species[trows]))
  }else{
    trows <- which(treeData$species %in% specNames)
  }
  if(length(trows) == 0)stop('specNames not found in treeData')
  
  if(is.null(seedNames)){
    scols  <- which( startsWith( colnames(seedData), substr(genus,1,4) ) )
  }else{
    scols <- which(colnames(seedData) %in% seedNames)
  }
  if(length(scols) == 0)stop('seedNames not found in seedData')
  
  snames <- colnames(seedData)[scols]
  
  tplots <- plotT[trows]
  ws     <- which( seedData[, scols, drop=F] > 0, arr.ind=T )
  splots <- plotS[seedData$plot[ws[,1]]]
  
  allPlots <- sort(unique( plotT ) )
  
  tdata <- treeData[trows,]
  sdata <- seedData[plotS %in% allPlots,c('plot','trap',snames)]
  
  # possible errors where seed type is missing
  spec <- sort(unique(tdata$species))
  specBySeed <- matrix(0, length(spec), length(snames))
  rownames(specBySeed) <- spec
  colnames(specBySeed) <- snames
  
  if(!is.null(censMin)){
    CENS <- T
    scens <- colnames(censMin)[colnames(censMin) %in% seedNames]
    pcens <- columnSplit(rownames(censMin),'-')[,1]
  }
  
  UN <- F
  gu <- grep('UNKN', snames)
  if(length(gu) > 0)UN <- T
  uncol <- rep(0, length(spec))
  names(uncol) <- spec
  
  for(j in 1:length(allPlots)){
    
    ws <- which( sdata$plot == allPlots[j])
    wt <- which( tdata$plot == allPlots[j])
    sj <- colSums( sdata[ws, snames, drop=F], na.rm=T )
    sj <- names( sj[sj > 0] )
      
    tj  <- names( table(tdata$species[wt]) )
    win <- which(!tj %in% sj)                          #species not in seedNames
    if(length(win) > 0)specBySeed[ tj[win],sj ] <- 1
    if(CENS){
      wc <- which( pcens == allPlots[j])
      cj <- colSums( censMin[wc, scens, drop=F], na.rm=T )
      cj <- names( cj[cj > 0] )
      wic <- which(!tj %in% cj)       
      if(length(wic) > 0)specBySeed[ tj[wic],cj ] <- 1
    }
    if(UN)uncol[tj] <- 1
  }
  
  wj <- match(rownames(specBySeed), colnames(specBySeed))
  wf <- which(is.finite(wj))
  specBySeed[ cbind(wf,wj[wf]) ] <- 1
  if(UN)specBySeed[,gu] <- uncol
  
  # missing seedNames
  wc <- colnames(specBySeed)[colSums(specBySeed) == 0]
  if(length(wc) > 0){
    wmiss <- colnames(specBySeed)[wc]
    specBySeed <- specBySeed[,!colnames(specBySeed) %in% wc, drop=F]
    sdata <- sdata[,!colnames(sdata) %in% wc, drop=F]
    snames <- colnames(specBySeed)
  }
  
  # missing specNames, seedNames
  wc <- rownames(specBySeed)[rowSums(specBySeed) == 0]
  if(length(wc) > 0)specBySeed[wc,] <- 1 
  
  specNames <- rownames(specBySeed)
  seedNames <- colnames(specBySeed)
  
  wm <- which(!seedIn %in% seedNames)
  if(length(wm) > 0){
    sa <- paste0(seedIn[wm], collapse = ', ')
    cat( paste('\nseedNames could not be used:', sa, '\n') )
    seedNames <- seedNames[!seedNames %in% sa]
  }
  wm <- which(!specIn %in% specNames)
  if(length(wm) > 0){
    sa <- paste0(specIn[wm], collapse = ', ')
    cat( paste('\nspecNames could not be used:', sa, '\n') )
    specNames <- specNames[!specNames %in% sa]
  }
  
  specBySeed <- specBySeed[drop=F,specNames,seedNames]
  
  list(R = specBySeed, specNames = specNames,
       seedNames = seedNames, seedData = sdata)
}


mastPriors <- function(file, specNames, code, genus = 'NULL'){
  
  # if not found in 'code' column can use 'genus', if supplied
  # if only 'genus', then a single vector returned
  # code columns in priorParameters.txt are 'code...'
  
  ns <- length(specNames)
  
  if( endsWith(file, '.txt') )
     priorVals <- read.table( file, header=T, stringsAsFactors = F)
  if( endsWith(file, '.csv') )
    priorVals <- read.csv( file, header=T, stringsAsFactors = F)
  
  ccols <- grep('code',colnames(priorVals))
  wcol  <- which(colnames(priorVals) == code)
  mcols <- ccols[!ccols == wcol]
  if(length(mcols) > 0)priorVals <- priorVals[,-mcols]
  
  if( code == 'genus'){
    wr <- which(priorVals[,'genus'] == genus & is.na(priorVals[,'code4']))
    prr <- priorVals[drop=F, wr,]
    rownames(prr) <- prr$genus
    return(prr[,-ccols, drop=F])
  }
  
  prr <- priorVals[ 1:ns, ]
  
  wrow <- match(specNames, priorVals[,code])
  wf   <- which(is.finite(wrow))
  if( length(wf) > 0){
    prr[wf,]   <- priorVals[wrow[wf],]
  }
  wn <- which(!is.finite(wrow))   # use genus for missing
#  wg <- match(genus, priorVals[,'genus'])
  
  
  # gn <- prr$genus[wf][1]
  if(length(wn) > 0){
    wr <- which(priorVals[,'genus'] == genus & is.na(priorVals[,'code4']))
    if(length(wr) > 0){
      prr[wn,] <-  priorVals[drop=F, wr,] 
      prr[wn, code] <- specNames[wn]
    }else{
      wd <- which(priorVals$genus == 'default')
      prr[wn,] <- priorVals[drop=F, wd,] 
      prr[wn, code] <- specNames[wn]
      prr[, 'genus'] <- genus
    }
  }
  rownames(prr) <- specNames
  prr
}

buildSeedByPlot <- function(sdata, snames){
  
  plot  <- as.character(sdata$plot)
  plots <- sort(unique(plot))
  
  snames <- snames[snames %in% colnames(sdata)]
  ntype  <- length(snames)
  nseed  <- nrow(sdata)
  
  if(ntype == 0)return(numeric(0))
  
  seedCount <- as.matrix(sdata[,snames])
  #  colnames(seedCount) <- snames
  
  wm <- match(as.character(sdata$plot),plots)
  ii <- rep(wm, ntype)
  jj <- rep(1:ntype, each=nseed)
  totalSeed <- t( .myBy(as.vector(seedCount),ii,jj,fun='sum') )
  colnames(totalSeed) <- plots
  rownames(totalSeed) <- paste('seeds_',snames, sep='')
  
  totalSeed
}

buildSpecByPlot <- function(cnames, mat, plot){
  
  if(is.matrix(mat)){
    wg <- which(!cnames %in% rownames(mat))
    if(length(wg) > 0){
      mm <- matrix(0, length(wg), ncol(mat) )
      rownames(mm) <- cnames[wg]
      mat <- rbind(mat, mm)
    }
    
    if(!plot %in% colnames(mat)){
      mat <- cbind(mat, 0)
      colnames(mat)[ncol(mat)] <- plot
    }
    mat[cnames, plot] <- 1
    
  }else{
    mat <- matrix(1, length(cnames), ncol=1)
    rownames(mat) <- cnames
    colnames(mat)  <- plot
  }
  mat
}

phenClimate <- function(pfile, mpath, cvar='tmin', treeData,
                        FUN = 'min'){
  
  # mpath - path to climate file
  # pfile - phenology file
  
  specNames <- sort(unique( as.character(treeData$species))) 
  
  pdata <- read.table( pfile, header=T)
  cfile  <- paste(mpath, cvar, '.csv', sep='')
  tyears <- treeData$year
  tplots <- as.character(treeData$plot)
  xvar   <- matrix(NA, nrow(treeData), 3)
  
  ptime <- pdata[drop=F, specNames %in% pdata$species,]
  
  if(nrow(ptime) > 0){
    
    for(m in 1:length(specNames)){
      
      wr <- which(ptime$species == specNames[m])
      if(length(wr) == 0)next
      
      for(i in wr){
        
        ti <- mastClimate( file = cfile, plots = tplots, 
                           years = tyears+ptime$year[i], 
                           months = ptime$startMo[i]:ptime$endMo[i], FUN = FUN)
        if(i == wr[1]){
          tvar <- ti
        }else{
          for(k in 1:3){
            tvar[,k] <- apply( cbind(tvar[,k],ti[,k]), 1, FUN)
          }
        }
      }
      
      wtree <- which(treeData$species == specNames[m])
      xvar[wtree,] <- tvar[wtree,]
    }
  }
  colnames(xvar) <- c('Phen', 'PhenSiteMean', 'PhenAnomaly')
  colnames(xvar) <- paste(cvar, colnames(xvar), sep='')
  xvar
}

mastClimate <- function( file, plots, years, months, FUN = 'mean', 
                         vname = character(0)){
  
  # return covariate for a vector of plots and years
  # vname variable name
  # plots and years are vectors of the same length
  # months is a vector in (1, 12)
  
  fform <- integer(0)
  
  tform <- grep('.csv',file)
  if(length(tform) == 0)ffrom <- grep('.txt', file)
  
  if(length(fform) == 0 & length(tform) == 0)
    stop('file must be .csv or .txt format')

  if(length(tform) > 0)data <- read.csv(file, header = T, row.names=1)
  if(length(fform) > 0)data <- read.table(file, header = T, row.names=1)
  
  colnames(data) <- .replaceString(colnames(data),'X','')
  rownames(data) <- .fixNames(rownames(data), all=T, MODE='character')$fixed
  
  plots <- .fixNames(plots, all=T, MODE='character')$fixed
  
  # small number of plots, but many points
  
  allPlots <- sort(unique(plots))
  
  tmp <- columnSplit(colnames(data), '_')
  yr  <- as.numeric( tmp[,1] )
  mo  <- as.numeric( tmp[,2] )
  
  yd <- sort(unique(yr))
  
  wy <- match(yr, yd)
  wm <- match(mo, 1:12)
  
  xx <- numeric(0)
  
  for(j in 1:length(allPlots)){
    dj   <- data[allPlots[j],] 
    if(is.list(dj))dj <- unlist(dj)
    mmat <- matrix(NA, length(yd), 12)
    mmat[ cbind(wy, wm) ] <- dj
    mvec <- suppressWarnings(
      apply(mmat[,months, drop=F], 1, FUN, na.rm=T)
    )
    xx   <- cbind(xx, mvec)
  }
  colnames(xx) <- allPlots
  xx[!is.finite(xx)] <- NA
  
  plotMean <- matrix( colMeans(xx, na.rm=T), nrow(xx), ncol(xx), byrow=T)
  plotAnom <- xx - plotMean
  
  wy  <- match(years, yd)
  wp  <- match(plots, colnames(xx))
  wfy <- which( is.finite(wy) & is.finite(wp) )
  
  if(length(wfy) < length(wy)){
    miss <- unique( columnPaste(plots[-wfy], years[-wfy], '_') )
    pmiss <- paste0( miss, collapse=', ')
    warning( paste('\nMissing plot_years in covariate file:\n', pmiss) )
  }
  
  noYr <- sort(unique(years[!is.finite(wy)]))
  noPl <- sort(unique(years[!is.finite(wp)]))
  
  tmp <- rep(NA, length(years))

  mu <- ann <- tmp
  tmp[wfy] <- xx[ cbind(wy[wfy], wp[wfy]) ]
  
  miss <- which(!is.finite(tmp))
  if(length(miss) > 0)
    warning('Missing plot_years in covariate file\n')
  mu[wfy]  <- plotMean[ cbind(wy[wfy], wp[wfy]) ]
  ann[wfy] <- plotAnom[ cbind(wy[wfy], wp[wfy]) ]
    
  tmp <- matrix(tmp,ncol=1)
  mu  <- matrix(mu,ncol=1)
  ann <- matrix(ann,ncol=1)
  
  tc  <- paste0(num2Month(months), collapse='')
  colnames(tmp) <- tc
  
  xm <- signif(cbind(tmp, mu, ann), 3)
  colnames(xm) <- paste(vname, tc, c('','SiteMean','Anom'), sep='')

  xm
}

num2Month <- function(monthNum){
  
  mNames   <- c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug',
                'Sep','Oct','Nov','Dec')
  mNames[monthNum]
}
month2Num <- function(monthName){
  
  match(monthName, num2Month(1:12) )
}

lowerFirstLetter <- function(xx){
  s <- unlist(strsplit(xx, " "))
  s <- paste(tolower(substring(s, 1, 1)), substring(s, 2),
             sep = "", collapse = " ")
  unlist(strsplit(s, " "))
}

upperFirstLetter <- function(xx){
  s <- unlist(strsplit(xx, " "))
  s <- paste(toupper(substring(s, 1, 1)), substring(s, 2),
             sep = "", collapse = " ")
  unlist(strsplit(s, " "))
}

getSigFig <- function(x){
  length(gregexpr("[[:digit:]]", as.character(x))[[1]])
}


combineSpecies <- function(specVec, specNames, combineSpecs){
  
  if(is.null(combineSpecs))
    return( list(specNames = specNames, species = specVec) )
  
  if(!is.character(specVec))specVec <- as.character(specVec)
  
  if(!is.null(combineSpecs)){
    wf <- which(combineSpecs[,'from'] %in% as.character(specVec))
    if(length(wf) > 0){
      specs <- as.character(specVec)
      for(m in wf){
        ws <- which(specs == combineSpecs[m,'from'])
        specs[ws] <- combineSpecs[m,'to']
      }
      specVec <- as.factor(specs)
    }
    specNames <- sort(unique(as.character(specVec)))
  }
  list(specNames = specNames, species = specVec)
}

combineSeedNames <- function(sdata, seedNames, combine=NULL){
  
  if(is.null(combine))
    return( list(seedNames = seedNames, seedData = sdata) )
  
  cc <- combine
  
  c1 <- matrix( paste(cc,'_min',sep=''), ncol=2)
  c2 <- matrix( paste(cc,'_max',sep=''), ncol=2)
  
  combine <- rbind(cc, c1, c2)
  
  ww <- which(seedNames %in% combine[,'from'])
  if(length(ww) == 0 | is.null(combine))
    return(list(seedNames = seedNames, seedData = sdata))
  
  mm <- match(seedNames[ww], combine[,'from'])
  
  for(k in 1:length(mm)){
    fromk <- combine[mm[k],'from']
    tok   <- combine[mm[k],'to']
    seedNames[ww[k]] <- tok
    if(tok %in% colnames(sdata)){
      sdata[ ,tok ] <- sdata[ ,tok ] +
        sdata[ ,fromk ]
    }else{
      colnames(sdata)[colnames(sdata) == fromk] <- tok
    }
  }
  
  wm <- which(colnames(sdata) %in% combine[,'from'])
  if(length(wm) > 0)sdata <- sdata[,-wm]
  wm <- which(seedNames %in% combine[,'from'])
  if(length(wm) > 0)if(length(wm) > 0)seedNames <- seedNames[-wm]

  seedNames <- seedNames[!duplicated(seedNames)]

  list(seedNames = seedNames, seedData = sdata)
}

################################


.trimRows <- function(xmat1, xmat2, xcol, STOP=F){
  
  # xmat1 will have rows trimmed to include xmat2, no row matching
  
  kword <- character(0)
  
  x1 <- xmat1[,xcol]
  x2 <- xmat2[,xcol]
  if(is.factor(x1) | is.factor(x2)){
    x1 <- as.character(x1)
    x2 <- as.character(x2)
  }
  
  wm <- match(x1, x2)
  wf <- which(is.finite(wm))
  if(length(wf) < length(wm)){
    if(STOP){
      stop(paste('duplicates in', xcol))
    }else{
      kword <- paste('Values have been trimmed in ', xcol,'.',sep='')
  #    cat( paste('\nNote: ', kword, '\n', sep='') )
      xmat1 <- xmat1[wf,]
    }
  }
  list(mat1 = xmat1, words = kword)
}

cleanSeedData <- function(sdata, xytrap, seedNames){
  
  words <- character(0)
  sdata$plot <- as.character(sdata$plot)
  sdata$trap <- as.character(sdata$trap)
  
  if(!'area' %in% colnames(sdata)){
    sdata$area <- 1
    kword <- 'area is missing from seedData.'
    warning(kword)
    words <- paste(words, kword )
  }
  if( is.character(sdata$area) ){
    kword <- 'seedData$area was coerced to numeric.'
    warning( paste('\nNote: ', kword, '\n', sep='') )
    words <- paste(words, kword)
    sdata$area <- as.numeric(sdata$area)
  }
  if(!'active' %in% colnames(sdata)){
    kword <- 'An $active column was added to seedData.'
    cat( paste("\nNote: ", kword, sep="") )
    sdata$active <- 1
  }
  if( is.character(sdata$active) ){
    kword <- 'seedData$active coerced to numeric.'
    warning( paste('\nNote: ', kword, '\n', sep='') )
    words <- paste(words, kword)
    sdata$active <- as.numeric(sdata$active)
  }
  if(max(sdata$active, na.rm=T) > 1 | min(sdata$active, na.rm=T) < 0){
    kword <- 'Some seedData$active are outside (0, 1).'
    warning( paste('\nNote: ', kword, '\n', sep='') )
    words <- paste(words, kword)
  }
  
  wm <- match(colnames(sdata), seedNames)
  wf <- which(is.finite(wm))
  colnames(sdata)[wf] <- .fixNames(colnames(sdata)[wf], all=T, MODE='character')$fixed
  seedNames <- .fixNames(seedNames, all=T, MODE='character')$fixed
  
  #missing trap years
  
  #censored columns
  seedNamesAll <- seedNames
  m1 <- grep('_min',colnames(sdata))
  if(length(m1) > 0)seedNamesAll <- c( seedNamesAll, colnames(sdata)[m1] )
  m2 <- grep('_max',colnames(sdata))
  if(length(m2) > 0)seedNamesAll <- c( seedNamesAll, colnames(sdata)[m2] )
  
  nseed <- length(seedNamesAll)
  
  sdata  <- sdata[order(sdata$plot, sdata$trap, sdata$year),]
  trapID <- columnPaste(sdata$plot, sdata$trap)
  id     <- sort(unique(trapID))
  snew   <- numeric(0)
  
  for(k in 1:length(id)){
    
    wk <- which(trapID == id[k])
    pk <- sdata$plot[wk[1]]
    ak <- range(sdata$year[sdata$plot == pk])
    ak <- ak[1]:max(ak)
    yk <- sdata$year[wk]
    if( (max(ak) - min(ak) + 1) == length(yk) ){
      smat <- sdata[wk,c('plot','trap','year','area','active',seedNamesAll)]
    }else{
      sk <- min(ak):max(ak)
      nk <- length(sk)
      
      kmat <- data.frame(plot = rep(sdata$plot[wk[1]],nk),
                         trap = rep(sdata$trap[wk[1]],nk),
                         year = sk, area = rep(sdata$area[wk[1]],nk))
      cmat <- matrix(NA, nk, 1+nseed)
      colnames(cmat) <- c('active', seedNamesAll)
      smat <- as.matrix(sdata[wk,c('active', seedNamesAll)])
      cmat[match(yk,sk),] <- smat
      smat <- cbind(kmat, cmat)
    }
    snew <- rbind(snew, smat)
  }
  
  sdata <- snew
  
  ccols <- c('plot','trap','year','area','active',seedNamesAll)
  wm <- which(!ccols %in% colnames(sdata))
  if(length(wm) > 0)
    stop(paste0('\nNMissing columns from seedData:\n', ccols[wm], collapse=', '))
  
  ccols <- c('plot','trap','x','y')
  wm <- which(!ccols %in% colnames(xytrap))
  if(length(wm) > 0)
    stop(paste0('\nMissing columns from xytrap:\n', ccols[wm], collapse=', '))
  
  wna <- which(is.na(sdata$active) | sdata$active == 0)
  if(length(wna) > 0){
    kword <- 'Some active values are undefined in seedData.'
    cat( paste('\nNote: ', kword, '\n', sep='') )
    words <- paste(words, kword)
    sdata$active[wna] <- .1
  }
  wna <- which(is.na(sdata$area) | sdata$area == 0)
  if(length(wna) > 0)
    stop('\nSome area values undefined or zero in seedData\n')
  
  sdata  <- .fixNamesVector( c('plot','trap'), sdata, MODE='character')
  xytrap <- .fixNamesVector( c('plot','trap'), xytrap, MODE='character')
 # colnames(sdata) <- .fixNames(colnames(sdata), all=T)$fixed
  if(is.character(sdata$year))sdata$year <- as.numeric(sdata$year)
   
  sdata <- sdata[,c('plot','trap','year','area','active',seedNamesAll)]
  sdata$trapID  <- columnPaste(sdata$plot,sdata$trap)
  sdata$plotYr  <- columnPaste(sdata$plot,sdata$year)
  xytrap$trapID <- columnPaste(xytrap$plot,xytrap$trap)
  sdata$trapID  <- columnPaste(sdata$plot,sdata$trap)
  
  if(is.factor(sdata$year))sdata$year <- factor2integer(sdata$year)
  
  xytrap <- .cleanRows(xytrap, 'trapID')
  xytrap <- xytrap[xytrap$trapID %in% sdata$trapID,]
  
  list(sdata = sdata, xytrap = xytrap, words = words)
}

cleanTreeData <- function(tdata, xytree, specNames){
  
  words <- character(0)
  
  ccols <- c('plot','tree','species','year','diam')
  wm <- which(!ccols %in% colnames(tdata))
  if(length(wm) > 0)
    stop(paste0('\nMissing columns from treeData:\n', ccols[wm], collapse=', '))
  
  tdata  <- .fixNamesVector( c('plot','tree','species'), tdata, MODE='character')
  if(is.character(tdata$year))tdata$year <- as.numeric(tdata$year)
  
  if(is.null(xytree)){       # bogus tree locations if missing
    kword <- ' xytree is missing from inputs.'
    warning(kword)
    words <- paste(words, kword )
    
    tid <- columnPaste(tdata$plot, tdata$tree)
    tid <- sort(unique(tid))
    pt  <- columnSplit(tid, '-')
    xytree <- data.frame(plot = pt[,1], tree = pt[,2], x = 0, y = 0)
  }
  xytree  <- .fixNamesVector( c('plot','tree'), xytree, MODE='character')
  
  tdata <- tdata[as.character(tdata$species) %in% specNames,]
  tdata$treeID  <- columnPaste(tdata$plot, tdata$tree)
  xytree$treeID <- columnPaste(xytree$plot, xytree$tree)
  xytree <- xytree[as.character(xytree$treeID) %in% as.character(tdata$treeID),]
  
  mm <- match( as.character(xytree$treeID), as.character(tdata$treeID) )
  xytree$species <- tdata$species[mm]
  
  ccols <- c('plot','tree','x','y')
  wm <- which(!ccols %in% colnames(xytree))
  if(length(wm) > 0)
    stop(paste0('\nMissing columns from xytree:\n', ccols[wm], collapse=', '))
  
  tdata$plotYr  <- columnPaste(tdata$plot, tdata$year)
  
  tmp <- .trimRows(xytree, tdata, 'treeID')
  xytree <-  tmp$mat1
  words <- paste(words, tmp$words)
  
  if(!'species' %in% colnames(xytree)){
    wm <- match(xytree$treeID, tdata$treeID)
    xytree$species <- tdata$species[wm]
  }
  
  if( is.character(tdata$diam) ){
    kword <- ' treeData$diam coerced to numeric.'
    warning( paste('\nNote: ', kword, '\n', sep='') )
    words <- paste(words, kword)
    tdata$diam <- as.numeric(tdata$diam)
  }
  
  if(is.factor(tdata$year))tdata$year <- factor2integer(tdata$year)
  
  xytree <- .cleanRows(xytree, 'treeID')
  xytree <- .trimRows(xytree, tdata, 'treeID')[[1]]
  tdata  <- .trimRows(tdata, xytree, 'treeID')[[1]]
  
  list(tdata = tdata, xytree = xytree, specNames = specNames,
       words = words)
}


cleanInputs <- function(inputs, beforeFirst = 4,
                        afterLast = 4, p = 0){
  
  # only retain seed trap data from one yr before start of tree census
  SEEDDATA <- T
  SEEDCENSOR <- F   # censored counts with 'seedNames_min', 'seedNames_max'
  censMin <- censMax <- NULL
  minDiam <- 0
  words <- character(0)
  
  if('minDiam' %in% names(inputs))minDiam <- inputs$minDiam[1]
  
  tdata  <- inputs$treeData
  sdata  <- inputs$seedData
  xytree <- inputs$xytree
  xytrap <- inputs$xytrap
  combineSpecs <- inputs$combineSpecs
  combineSeeds <- inputs$combineSeeds
  
  tdata$plot <- .fixNames(tdata$plot, all=T, MODE='character')$fixed
  sdata$plot <- .fixNames(sdata$plot, all=T, MODE='character')$fixed
  xytree$plot <- .fixNames(xytree$plot, all=T, MODE='character')$fixed
  xytrap$plot <- .fixNames(xytrap$plot, all=T, MODE='character')$fixed
  
  plotInput <- sort(unique(c(tdata$plot,sdata$plot)))
  pname <- .fixNames(plotInput,all=T, MODE='character')$fixed
  names(plotInput) <- pname
  
  specNames <- .fixNames(inputs$specNames, all=T, MODE='character')$fixed
  
  if(length(which(duplicated(c(specNames)))) > 0)stop('duplicate specNames')
  
  if(is.null(sdata))SEEDDATA <- F
  
  
  tmp <- combineSpecies(tdata$species, specNames, combineSpecs)
  tdata$species <- tmp$species
  specNames     <- tmp$specNames
  
  tdata <- tdata[as.character(tdata$species) %in% specNames,]
  tdata$tree <- .fixNames(tdata$tree, all=T, MODE='character')$fixed
  xytree$plot <- .fixNames(xytree$plot, all=T, MODE='character')$fixed
  
  if(SEEDDATA){
    
    sdata$plot  <- .fixNames(sdata$plot, all=T, MODE='character')$fixed
    xytrap$plot <- .fixNames(xytrap$plot, all=T, MODE='character')$fixed
    
    
    tmp <- combineSeedNames(sdata, seedNames, combineSeeds)
    sdata     <- tmp$seedData
    seedNames <- tmp$seedNames
    nseed     <- length(seedNames)

    seedPlots <- sort(unique(sdata$plot))
    treePlots <- sort(unique(tdata$plot))
    
    #only plots with both traps and trees
    psave <- intersect(seedPlots, treePlots)
    if(length(psave) == 0)stop('tree and seed data not from same plots')
    sdata <- sdata[sdata$plot %in% psave,]
    tdata <- tdata[tdata$plot %in% psave,]
    xytree <- xytree[xytree$plot %in% psave,]
    xytrap <- xytrap[xytrap$plot %in% psave,]
    
    #censored counts?
    seedNames <- inputs$seedNames
    
    ntype <- length(seedNames)
    scens <- .multivarChainNames( c('min', 'max'), seedNames )
    wcens <- which(scens %in% colnames(sdata))   # data input as censored
    mcols <- integer(0)
    if(length(wcens) > 0){  # repair names, but leave '_min', '_max'
      m1cols <- grep('_min',colnames(sdata))
      ncc <- .replaceString(colnames(sdata)[m1cols],'_min','')
      mc <- .fixNames(ncc, all=T, MODE='character')$fixed
      colnames(sdata)[m1cols] <- paste(mc,'_min',sep='')
      
      m2cols <- grep('_max',colnames(sdata))
      ncc <- .replaceString(colnames(sdata)[m2cols],'_max','')
      mc <- .fixNames(ncc, all=T, MODE='character')$fixed
      colnames(sdata)[m2cols] <- paste(mc,'_max',sep='')
      mcols <- c(m1cols, m2cols)
      
      seedNames <- .fixNames(seedNames, all=T, MODE='character')$fixed
    }
    
    wcc <- c(1:ncol(sdata))
    if(length(mcols) > 0)wcc <- wcc[-mcols]
    colnames(sdata)[wcc] <- .fixNames(colnames(sdata)[wcc], all=T, 
                                 MODE='character')$fixed
    
    tmp <- cleanSeedData(sdata, xytrap, seedNames)
    sdata  <- tmp$sdata
    xytrap <- tmp$xytrap
    words  <- paste(words, tmp$words)
    
    tid <- columnPaste(sdata$plot,sdata$trap)
    tid <- columnPaste(tid, sdata$year)
    rownames(sdata) <- tid
    
    if(length(wcens) > 0){
      
      SEEDCENSOR <- T
      
  #    scens <- .multivarChainNames( c('min', 'max'), seedNames )
      scens <- paste(seedNames, '_min', sep='')
      tcens <- paste(seedNames, '_max', sep='')
      wcens <- which(scens %in% colnames(sdata))   # data input as censored
      scens <- scens[wcens]
      wcens <- which(tcens %in% colnames(sdata))   # data input as censored
      tcens <- tcens[wcens]
      
      
      cnot <- seedNames[seedNames %in% colnames(sdata) &
                          !seedNames %in% scens &
                          !seedNames %in% tcens]          # not censored
      
      stypes <- columnSplit(scens,'_min')
      ttypes <- columnSplit(tcens,'_max')
      stypes <- sort(unique(c(stypes, ttypes)))
      
      slo <- matrix(0, nrow(sdata), length(stypes))
      colnames(slo) <- stypes
      shi <- slo + Inf
      snew <- slo
      
      cnn <- paste(stypes,'_min',sep='')
      s1c <- stypes[cnn %in% scens]
      if(length(s1c) > 0){
        s2c <- cnn[cnn %in% scens]
        slo[,s1c] <- as.matrix(sdata[,s2c])
        snew <- slo
      }
      
      cnn <- paste(stypes,'_max',sep='')
      s1c <- stypes[cnn %in% scens]
      if(length(s1c) > 0){
        s2c <- cnn[cnn %in% scens]
        shi[,s1c] <- as.matrix(sdata[,s2c])
      }
      wf <- which(is.finite(shi))
      if(length(wf) > 0){
        snew[wf] <- round(c(slo[wf] + shi[wf])/2)
      }
      
   #   if(length(cnot) > 0){
   #     snew <- cbind(sdata[,cnot,drop=F],snew)
   #   }
      
   #   scols <- colnames(sdata)[colnames(sdata) %in% 
   #                              c('plot','trap','year','active','area')]
      sdata[,colnames(snew)] <- snew
  #    sdata <- cbind(sdata[,scols], snew)
      
      # censor index
      rlo <- rowSums(slo)
      rhi <- rowSums(shi - slo)
      
      wcens <- which(rlo > 0 & rhi > 0)
      
      censMin <- cbind(wcens, slo[wcens,,drop=F])
      censMax <- cbind(wcens, shi[wcens,,drop=F])
      colnames(censMin)[1] <- colnames(censMax)[1] <- 'srow'
      
      sdata$plot <- .fixNames(sdata$plot, all=T, MODE='character')$fixed
      srr <- columnPaste(sdata$plot, sdata$trap)
      srr <- columnPaste(srr,sdata$year)
      rownames(sdata) <- srr
      
      rownames(censMin) <- rownames(censMax) <- rownames(sdata)[wcens]
      
      colnames(censMin) <- colnames(censMax) <- 
        .fixNames(colnames(censMin), all=T, MODE='character')$fixed
    }
    
    # censor inactive traps
    
    seedNames <- .fixNames(seedNames, all=T, MODE='character')$fixed
    
    ww <- which(!seedNames %in% colnames(sdata))
    if(length(ww) > 0)seedNames <- seedNames[-ww]
    
    cna <- suppressWarnings(apply( sdata[,seedNames,drop=F], 1, max, na.rm=T))
    sdata$active[cna < 0] <- .5  # NAs will be -Inf
    srow <- which(sdata$active < 1)
    
    if(length(srow) > 0){
      
      cmin <- cbind(srow, sdata[srow,seedNames, drop=F])
      cmin[is.na(cmin)] <- 0
      if(length(censMin) == 0){
        censMin <- cmin
        censMax <- cmin*0 + Inf
      }else{
        wnew <- which(!colnames(cmin) %in% colnames(censMin))
        if(length(wnew) > 0){
          newmat <- matrix(0, nrow(censMin), length(wnew))
          colnames(newmat) <- colnames(cmin)[wnew]
          censMin <- cbind(censMin, newmat)
          newmat <- newmat + Inf
          censMax <- cbind(censMax, newmat)
        }
        wnew <- which(!colnames(censMin) %in% colnames(cmin))  # repeat?
        snn <- seedNames[seedNames %in% colnames(censMin)]
        snn <- c('srow', snn)
        cmax <- cmin
        cmax[,-1] <- cmax[,-1] + Inf
        
        censMin <- rbind(censMin[, snn], cmin[,snn])
        censMax <- rbind(censMax[, snn], cmax[,snn])
      }
    }
    sdata[is.na(sdata)] <- 0
    sdata$trapID <- columnPaste(sdata$plot, sdata$trap)
  }
  
  tmp <- cleanTreeData(tdata, xytree, specNames)
  tdata     <- tmp$tdata
  xytree    <- tmp$xytree
  specNames <- tmp$specNames
  words     <- paste(words, tmp$words)
  # subset data
  
  plots  <- sort(unique(tdata$plot))
  
  if(SEEDDATA){
    wseed <- which(sdata$plot %in% plots)
    sdata  <- sdata[wseed,]
    xytrap <- xytrap[xytrap$plot %in% plots,]
  }
  
  # check coordinates
  ntt     <- table(xytree$plot)
  utt     <- tapply(xytree$x, xytree$plot, range)
  plots   <- .fixNames(names(utt))$fixed
  metersX <- matrix( round(unlist(utt)), ncol=2, byrow=T )
  colnames(metersX) <- c('minX', 'maxX')
  dx <- apply(metersX,1,diff)

  metersY <- matrix( round(unlist(tapply(xytree$y, xytree$plot, range))), ncol=2,
                        byrow=T )
  colnames(metersY) <- c('minY', 'maxY')
  dy <- apply(metersY,1,diff)

  ha <- round(apply(metersX,1,diff)*apply(metersY,1,diff)/10000, 2)
  metersX <- cbind(metersX, dx)
  metersY <- cbind(metersY, dy)
  
  mmm <- cbind(metersX, metersY)
  rownames(mmm) <- plots
  mmm <- cbind(ntt[plots],mmm)
  colnames(mmm)[1] <- 'trees'
  
  if(max(ha) > 100)cat('\nNote: plot area from xytree > 100 ha? See below:')
  cat('\n\nSpatial range for trees (dx, dy) and area: \n')
  print(cbind(mmm))
  
  if(SEEDDATA){
    
    ntt     <- table(xytrap$plot)
    metersX <- matrix( round(unlist(tapply(xytrap$x, xytrap$plot, range))), ncol=2,
                       byrow=T )
    colnames(metersX) <- c('minX', 'maxX')
    dx <- apply(metersX,1,diff)
    
    metersY <- matrix( round(unlist(tapply(xytrap$y, xytrap$plot, range))), ncol=2,
                       byrow=T )
    colnames(metersY) <- c('minY', 'maxY')
    dy <- apply(metersY,1,diff)
    
    ha <- round( apply(metersX,1,diff)*apply(metersY,1,diff)/10000, 2 )
    metersX <- cbind(metersX, dx)
    metersY <- cbind(metersY, dy)
    
    mmm <- cbind(metersX, metersY)
    
    rownames(mmm) <- plots
    mmm <- cbind(ntt[plots],mmm)
    colnames(mmm)[1] <- 'traps'
    
    if(max(ha) > 100)cat('\nNote: plot area from xytrap > 100 ha? See below:')
    if(min(ha) < .01)cat('\nNote: plot area from xytrap < 1/100 ha? See below:')
    cat('\n\nSpatial range for trap data in meters and plot area: \n')
    print(mmm)
  }
  
  # diameter
  rdiam <- range(tdata$diam,na.rm=T)
  if(rdiam[1] <= 0){
    ww <- which(tdata$diam <= 0)
    if(length(ww) > 0)tdata <- tdata[-ww,]
    kword <- ' Removed diameters <= 0.'
    cat( paste('\nNote: ', kword, '\n', sep='') )
    words <- paste(words, kword)
  }
  if(rdiam[2] > 500)cat('\nNote: some diameters > 5 m')
  
  
  wna <- which(is.na(tdata$diam))
  if(length(wna) > 0){
    mm <- paste0( unique(tdata$treeID[wna]), collapse=', ')
    tdata <- tdata[-wna,]
    kword <- paste(' Removed treeData with missing diam:\n ', mm,sep='')
    cat('\nNote: ', kword,'\n')
    words <- paste(words, kword)
  }
  
  
  wna <- which(tdata$diam > minDiam)
  if(length(wna) == 0){
    stop(paste('\nno trees > minDiam:\n ',minDiam,sep=''))
  }
  

  tdata  <- .trimRows(tdata, xytree, 'treeID')[[1]]
  xytree <- .trimRows(xytree, tdata, 'treeID')[[1]]
  
  if('repr' %in% names(tdata)){
    rr <- suppressWarnings( range(tdata$repr,na.rm=T) )
    if(rr[1] == 1){
      kword <- ' All trees declared to be reproductive.'
      warning(paste('\nNote: ', kword, '\n', sep='') )
      words <- paste( words, kword )
    }
    if(rr[2] == 0){
      kword <- ' All trees declared to be immature.'
      warning(paste('\nNote: ', kword, '\n', sep='') )
      words <- paste( words, kword )
      tdata$repr[tdata$diam < minDiam] <- NA
    }
  }
  
  if(SEEDDATA){
    tmp <- .trimRows(sdata, xytrap, 'trapID')
    sdata <- tmp$mat1
    words <- paste(words, tmp$words)
  }
  
  plots <- sort(unique(as.character(tdata$plot)))
  
 # extend tdata$year
  
  for(j in 1:length(plots)){
    
    ts <- unique(tdata$year[as.character(tdata$plot) == plots[j]])
    rs <- ts
    if(SEEDDATA)rs <- unique(sdata$year[as.character(sdata$plot) == plots[j]])
    
    rs <- rs[rs <= (max(ts) + afterLast)]
    rs <- rs[rs >= (min(ts) - beforeFirst)]
    ts <- ts[ts %in% rs]                    # change for tree obs outside seed obs yrs
    
    pyr <- (min(rs)-p):(max(rs)+p)
    
    if(SEEDDATA){
      wj <- which(as.character(sdata$plot) == plots[j] & !sdata$year %in% pyr)
      if(length(wj) > 0)sdata <- sdata[-wj,]
    }
    wi <- which(as.character(tdata$plot) == plots[j])
    wj <- which(as.character(tdata$plot) == plots[j] & !tdata$year %in% pyr)
    
    if(length(wj) > 0){
      if(length(wi) == length(wj)){       #census does not fall in a seed trap interval
        yi <- sort(unique(tdata$year[wj]))
        dd <- outer(X = yi, Y = pyr, function(X,Y) (X - Y)^2) #closest trap yr
        dy <- pyr[ apply(dd, 1, which.min) ]
        di <- match(tdata$year[wj], yi)
        tdata$year[wj] <- dy[di]
        wj <- which(as.character(tdata$plot) == plots[j] & !tdata$year %in% pyr)
      }
      if(length(wj) > 0)tdata <- tdata[-wj,]
    }
  }
  
  specNames <- sort(unique(tdata$species))
  plots     <- sort(unique(as.character(tdata$plot)))
  
#  treeID <- sort(unique(tdata$treeID))
  
  # duplicated tree years
  ty <- with(tdata, table(treeID, year) )
  
  if(max(ty) > 1){
    wm <- which(ty > 1,arr.ind=T)
    cw <- unique(rownames(wm))
    cy <- paste0( cw , collapse=', ')
    kword <- paste( ' Removed treeData with duplicate years:\n', cy )
    cat(paste('\nNote: ', kword, '\n', sep='') )
    words <- paste( words, kword )
    words <- paste(words, kword)
    tdata <- tdata[!as.character(tdata$treeID) %in% cw,]
  }
  
  # after tdata$year extended by p, beforeFirst, afterLast, 
  # remove traps beyond range(tdata$year) by plot
  # don't remove trap years between range(tdata$year), they will be interpolated
  
  tmp <- .trimRows(xytree, tdata, 'treeID')
  xytree <- tmp$mat1
  words  <- paste(words, tmp$words)
  
  sdata <- trimPlotYr(tdata, sdata, beforeFirst, afterLast, p)
  
  years <- range( tdata$year ) 
  if(SEEDDATA)years <- range(c(years, sdata$year))
  years <- min(years):max(years)
  
  # too rare
  tid     <- tdata[!duplicated(tdata$treeID),]
  specTab <- table(tid$species)
  wna     <- which(specTab < 5)
  
  if(length(wna) > 0){               # species too rare
    
    bad   <- names(specTab)[wna]
    ww    <- which(!tdata$species %in% bad)
    tdata <- tdata[ww,]
    
    tmp <- .trimRows(xytree, tdata, 'treeID')
    xytree <- tmp[[1]]
    words  <- paste(words, tmp[[2]])
    
    tdata <- .trimRows(tdata, xytree, 'treeID')$mat1
   
    if(nrow(tdata) < 5)stop('too few trees')
    
    rn    <- paste0(names(specTab)[wna],collapse=', ')
    specNames <- specNames[!specNames %in% names(specTab)[wna]]
    nspec <- length(specNames)
    cat('\nNote: too rare, removed:\n')
    print( rn )
    
    if(SEEDDATA){
      
      badFruit <- which(colnames(sdata) %in% paste(bad, 'fruit', sep=''))
      badCones <- which(colnames(sdata) %in% paste(bad, 'cones', sep=''))
      
      bad <- c(bad, colnames(sdata)[c(badFruit, badCones)])
      
      wz <- which(bad %in% colnames(sdata))
      if(length(wz) > 0){
        for(b in wz){
          wb <- which(colnames(sdata) == bad[b])
          sdata <- sdata[,-wb]
          if(SEEDCENSOR){
            wb <- which(colnames(censMin) == bad[b])
            censMin <- censMin[,-wb]
            censMax <- censMax[,-wb]
          }
        }
        seedNames <- seedNames[!seedNames %in% bad]
      }
    }
    
    ptab <- table(tdata$plot)
    w0   <- which(ptab == 0)
    
    if(length(w0) > 0){
      pmiss <- names(ptab)[w0]
      wm <- which(as.character(xytree$plot) %in% pmiss)
      if(length(wm) > 0)xytree <- xytree[-wm,]
      
      if(SEEDDATA){
        wm <- which(as.character(sdata$plot) %in% pmiss)
        if(length(wm) > 0)sdata <- sdata[-wm,]
        
        wm <- which(as.character(xytrap$plot) %in% pmiss)
        if(length(wm) > 0)xytrap <- xytrap[-wm,]
      }
      plots  <- plots[!plots %in% pmiss]
    }
  }
  
  # remove plots where there are no trees
  plotRm <- character(0)
  
  for(j in plots){
    tj <- which(as.character(xytree$plot) == j)
    t2 <- which(as.character(tdata$plot) == j)
    if(length(tj) == 0 | length(t2) == 0){
      plotRm <- c(plotRm,j)
      kword <- paste(' Plot',j,'is absent from xytree or treeData')
      cat('\nNote:', kword, '/n')
      words <- paste(words, kword)
      next
    }
  }
  
  if(length(plotRm) > 0){
    plots  <- plots[!plots %in% plotRm]
    wr     <- which(tdata$plot %in% plotRm)
    if(length(wr) > 0)tdata  <- tdata[-wr,]
    wr     <- which(xytree$plot %in% plotRm)
    if(length(wr) > 0)xytree  <- xytree[-wr,]
    if(SEEDDATA){
      wr     <- which(sdata$plot %in% plotRm)
      if(length(wr) > 0)sdata  <- sdata[-wr,]
      wr     <- which(xytrap$plot %in% plotRm)
      if(length(wr) > 0)xytrap <- xytrap[-wr,]
    }
  }
  
  # retain trees in plot-years that have seed traps
  
  plotYears <- sort(unique(as.character(tdata$plotYr)))
  
  
  
  
  if(SEEDDATA){
    sdata     <- sdata[sdata$plot %in% plots,]
    sdata$plotYr <- columnPaste(sdata$plot, sdata$year)
    xytrap    <- xytrap[xytrap$plot %in% plots,]
    plotYears <- sort(unique(c(as.character(sdata$plotYr), 
                               as.character(tdata$plotYr))))
    sdata$plotyr <- match( sdata$plotYr, plotYears )
  }
  tdata$plotyr <- match( tdata$plotYr, plotYears )
  
  xytree    <- xytree[xytree$treeID %in% tdata$treeID,]
  specNames <- sort(unique(as.character(tdata$species)))
  
  plots <- sort(unique(as.character(tdata$plot)))
  
  # seedNames, specNames
  
  if(SEEDDATA){
    gg <- grep('UNKN',seedNames)
    if(length(gg) > 0){
      kword <- paste0( ' The unknown seed type is ',seedNames[gg],'.',sep=' ')
      cat( paste('\nNote: ', kword, '\n', sep='' ) )
      words <- paste(words, kword)
    }
    if(length(gg) > 1)
      stop( 'Only one seedName can have "UNKN" in name')
    
    ww <- which(!specNames %in% seedNames)
    if(length(ww) > 0){
      if(length(gg) == 0){
        kword <- ' There is no "UNKN" in seedNames'
        cat( '\nNote: ', kword, '\n' )
        words <- paste(words, kword)
      }
    }
    
    ww <- which(!seedNames %in% specNames)
    
    if(length(ww) > 0){
      
      wg <- which(!ww %in% gg)
      
      if(length(wg) > 0){
        
        missName <- seedNames[ww[wg]]
        mname    <- paste0(missName, collapse=', ')
        kword <- paste(' seedNames that are not in specNames and not "UNKN":\n', mname)
        
        cat( paste('\n', kword, '\n', sep='') )
        words <- paste(words, kword, '.', sep='')
        
        # appended specName?
        ispec <- character(0)
        for(i in 1:length(specNames)){
          iss <- grep(specNames[i], missName)
          if(length(iss) > 0)ispec <- c(ispec, specNames[i])
        }
        
        # if not, add to UNKN class
        mcol <- grep(missName[1], colnames(sdata))
        
        if(length(gg) > 0){   # there is an UNKN type
          if(length(mcol) > 0 & length(ispec) == 0){
            if(length(missName) > 1){
              for(k in 1:length(missName)){
                mcol <- c(mcol, grep(missName[k], colnames(sdata)))
              }
            }
            sdata[,seedNames[gg]] <- sdata[,seedNames[gg]] + sdata[,mcol]
            sdata <- sdata[,-mcol]
            kword <- paste0(' Moved ', missName, ' to "UNKN" class',
                            collapse=', ')
            cat( paste('\n', kword, '\n', sep='') )
            words <- paste(words, kword)
          }
        }else{
          sdata <- sdata[,-mcol]  #there is no UNKN type
     #     seedNames <- seedNames[!seedNames %in% missName]
        }
        
        if(length(ispec) == 0)seedNames <- seedNames[-ww[wg]]
      }
    }
    sdata  <- sdata[order(sdata$plot,sdata$trap,sdata$year),]
    xytrap <- xytrap[order(xytrap$plot, xytrap$trap),]
    
    # all factors
   # tmp <- which( sapply(xytrap, is.character) )
   # for(k in tmp)xytrap[[k]] <- as.factor(xytrap[[k]])
    
  #  tmp <- which( sapply(sdata, is.character) )
  #  for(k in tmp)sdata[[k]] <- as.factor(sdata[[k]])
    
    inputs$seedData  <- sdata
    inputs$xytrap    <- xytrap
    inputs$seedNames <- seedNames
    
    if(SEEDCENSOR | length(censMin) > 0){
      wm <- match(rownames(censMin), rownames(sdata))
      censMin <- censMin[is.finite(wm),]
      censMax <- censMax[is.finite(wm),]
      
      wm <- match(rownames(censMin), rownames(sdata))
   #   wf <- which(is.finite(wm))
      censMin[,1] <- wm
      censMax[,1] <- wm
      
      wc <- c(1, which( colnames(censMin) %in% colnames(sdata) ) )
      censMin <- censMin[,wc]
      censMax <- censMax[,wc]
    }
  }
  
  ord <- order( as.character(tdata$plot), 
                as.character(tdata$tree), tdata$year) 
  tdata  <- tdata[ord,]
  ord <- order( as.character(xytree$plot), 
                as.character(xytree$tree)) 
  xytree <- xytree[ord,]
  
  if(is.null(tdata$obs))tdata$obs <- 1
  
  # all factors
  tmp <- which( sapply(tdata, is.character) )
  tmp <- names(tmp)[!names(tmp) %in% c('plot','tree','treeID','plotYr')]
  if(length(tmp) > 0)for(k in tmp)tdata[[k]] <- as.factor(tdata[[k]])
  
 # tmp <- which( sapply(xytree, is.character) )
 # tmp <- names(tmp)[!names(tmp) %in% c('plot','tree','species','treeID','plotYr')]
 # if(length(tmp) > 0)for(k in tmp)xytree[[k]] <- as.factor(xytree[[k]])
  
  inputs$treeData  <- tdata
  inputs$xytree    <- xytree
  inputs$specNames <- specNames
  inputs$plotInput <- plotInput
  inputs$inwords  <- words
 # if(SEEDCENSOR){
    inputs$censMin <- censMin
    inputs$censMax <- censMax
 # }
  inputs
}
 
trimPlotYr <- function(tdata, sdata, beforeFirst, afterLast, p){
  
  tmp  <- table(tdata$plot, tdata$year)
  tmp[tmp > 1] <- 1
  tmat <- tmp*matrix(as.numeric(colnames(tmp)), nrow(tmp), ncol(tmp), byrow=T)
  tmat[tmat == 0] <- NA
  mm   <- apply(tmp*tmat, 1, range, na.rm=T)
  mm[1,] <- mm[1,] - max(c(beforeFirst, p))
  mm[2,] <- mm[2,] + max(c(afterLast, p))
  ty   <- character(0)
  for(j in 1:ncol(mm)){
    jy <- paste(colnames(mm)[j],mm[1,j]:mm[2,j],sep='-')
    ty <- c(ty, jy)
  }
  ww <- which(!sdata$plotYr %in% ty)
  if(length(ww) > 0){
    sdata <- sdata[-ww,]
  }
  sdata
}

################################

mastFillCensus <- function(inputs, beforeFirst = 15,
                           afterLast = 15, p = 0){
  
  # fill census with seed trap years, interpolated diameter
  # beforeFirst - assumed present for no. of years before tree first observed
  # afterLast   - no. yr after last observed
  # p       - if AR(p > 0) model, fills p yr before and after tree observed
  
 # if(!is.null(attr(inputs$treeData,'plag'))){
 #   ap <- attr(inputs$treeData,'plag')
 #   if(ap == p){
 #     return(inputs)
 #   }else{
 #     ss <- paste('treeData constructed for AR(',ap,
 #                 ') model, this one is  AR(',p,')',sep='')
 #     stop('treeData constructed for different AR(p) model')
 #   }
 # }
  
  words <- character(0)
  SEEDCENSOR <- F
  SEEDDATA   <- T
  if(!'seedData' %in% names(inputs))SEEDDATA <- F
  
  AR <- F
  if(p > 0){
    AR <- T
    kword <- paste(' This is an AR(', p, ') model', sep='')
    words <- paste(words, kword)
    cat( '\n', kword, '\n' )
  }
  
  inputs$seedData$plot <- .fixNames(inputs$seedData$plot, all=T, 'character')$fixed
  inputs$treeData$plot <- .fixNames(inputs$treeData$plot, all=T, 'character')$fixed
  
  ss <- tapply(inputs$treeData$year, 
               list(plot = inputs$treeData$plot), range, na.rm=T)
  sn <- names(ss)
  censusYr <- matrix( unlist(ss), ncol=2, byrow=T )
  rownames(censusYr) <- sn
  
  ss <- tapply(inputs$seedData$year, 
               list(plot = inputs$seedData$plot),range)
  sn <- names(ss)
  trapYr <- matrix( unlist(ss), ncol=2, byrow=T )
  rownames(trapYr) <- sn
  
  inputs <- cleanInputs(inputs, beforeFirst=10, afterLast=10, p)
  specNames <- inputs$specNames
  seedNames <- inputs$seedNames  
  tdata  <- inputs$treeData   
  sdata  <- inputs$seedData  
  xytree <- inputs$xytree     
  xytrap <- inputs$xytrap
  censMin <- inputs$censMin
  censMax <- inputs$censMax
  words   <- c(words, inputs$inwords)
  
  if(!is.null(censMin))SEEDCENSOR <- T
  
  plots <- sort(unique( as.character(tdata$plot) ))
  plots <- .fixNames(plots, all=T)$fixed
  nplot <- length(plots)
  
  sdata$obs <- 1
  
  if( !'obs' %in% colnames(tdata) ){  # observation period for traps
    tdata$obs <- 0
    for(j in 1:nplot){
      sjj <- sdata[as.character(sdata$plot) == plots[j],]
      pyr <- min(sjj$year):max(sjj$year)
      wtt <- which(as.character(tdata$plot) == plots[j] & 
                     tdata$year %in% pyr)
      tdata$obs[wtt] <- 1
    }
  }
  
  years <- range( tdata$year[tdata$obs == 1] )
  
  
  if(SEEDDATA)years <- range( c(years, sdata$year) )
  
  years <- years[1]:years[2]
  allYears <- (min(years) - p):(max(years) + p)

  tdata$plotTreeYr <- columnPaste(tdata$treeID,tdata$year,sep='_')
  sdata$plotTrapYr <- columnPaste(sdata$trapID,sdata$year,sep='_')
  
  vtypes <- getVarType(colnames(tdata), tdata, i=tdata$treeID, j = tdata$year)
  
  if('repr' %in% names(tdata))vtypes$repr = 'ij'
  if('repMu' %in% names(tdata))vtypes$repMu = 'ij'
  if('repSd' %in% names(tdata))vtypes$repSd = 'ij'
  
  if('fecMin' %in% names(tdata)){
    vtypes$fecMin = 'ij'
    fecMin <- tdata$fecMin
    names(fecMin) <- tdata$plotTreeYr
  }
  if('fecMax' %in% names(tdata)){
    vtypes$fecMax = 'ij'
    fecMax <- tdata$fecMax
    names(fecMax) <- tdata$plotTreeYr
  }
  
  wnull <- which(is.null(vtypes))
  if(length(wnull) > 0){
    for(k in 1:length(wnull)) vtypes[[k]] <- 'ij'
  }
  
  treeIDs <- sort( unique(as.character(tdata$treeID)) )
  trapIDs <- sort( unique(as.character(sdata$trapID)) )
  plots   <- sort( unique(as.character(tdata$plot)) )
  nplot   <- length(plots)
  nyr     <- length(years)
    
  ww <- which(!as.character(sdata$plotYr) %in% 
                as.character(tdata$plotYr) ) #traps without tree data
  
  if(length(ww) > 0 | AR){
    
    yrSeq <- years
    if(AR)yrSeq <- allYears
    ijFull <- numeric(0)
    nyr    <- length(yrSeq)
    
    ijIndex <- cbind( match(as.character(tdata$treeID), treeIDs),
                      match(tdata$year, yrSeq) )
    
  #  before <- max(c(beforeFirst, p))
  #  after  <- max(c(afterLast, p))
    
    for(j in 1:nplot){
      
  #    wt <- which(as.character(tdata$plot) == plots[j] & tdata$obs == 1)
      
      wt <- which(as.character(tdata$plot) == plots[j])
      ws <- which(as.character(sdata$plot) == plots[j])
      
      tj <- tdata[wt,]
      sj <- sdata[ws,]
      
      rt <- range(tj$year)
      rs <- range(sj$year)
      
      pr <- match( range( c(rt, rs) ), yrSeq ) 
      
      tID <- as.character(tj$treeID)
      jID <- sort(unique(tID))
      
      ii  <- match( as.character(tID), jID)
      tii <- match(as.character(jID), treeIDs)
      
      pindex <- cbind( ii, match(tj$year, yrSeq) )
   #   ttt <- table(pindex[,1],pindex[,2])          # individual trees
   #   tjj <- as.numeric(colnames(ttt))
   #   tii <- as.numeric(rownames(ttt))
   #   ttt[ttt > 1] <- 1
      
   #   imat <- omat <- ttt*matrix(tjj, nrow(ttt), ncol(ttt), byrow=T) 
      
      imat <- matrix(0, length(jID), length(yrSeq))
      imat[pindex] <- pindex[,2]
      
      imat[imat == 0] <- NA
      mini <- apply(imat,1,min,na.rm=T) - beforeFirst
      mini[mini < pr[1]] <- pr[1]
      mini <- mini - p
      mini[mini < 1] <- 1
      
      maxi <- apply(imat,1,max,na.rm=T) + afterLast
      maxi[maxi > pr[2]] <- pr[2]
      maxi <- maxi + p
      maxi[maxi > nyr] <- nyr
      
      for(i in 1:length(mini)){
        ik <- c(mini[i]:maxi[i])
        ik <- cbind(tii[i],ik)
        ijFull <- rbind(ijFull, ik)
      }
    }
    
    tdata$times <- match(tdata$year, allYears)
    sdata$times <- match(sdata$year, allYears)
    
    vtypes    <- getVarType(colnames(tdata), tdata, ijIndex[,1], ijIndex[,2]) 
    vtypes$obs <- 'ij'
    vtypes$times <- 'j'
    vtypes$diam <- 'ij'
    
    jtimes <- 1:nyr
    tpy <- as.character(tdata$plotTreeYr)
    
    if('fecMax' %in% names(tdata)){
      fecMax <- tdata$fecMax
      names(fecMax) <- tdata$plotTreeYr
    }
    if('fecMin' %in% names(tdata)){
      fecMin <- tdata$fecMin
      names(fecMin) <- tdata$plotTreeYr
    }
    
   # tdata$obs <- as.factor(tdata$obs)
    
    tmp <- fillMissing(vtypes, tdata, icol = 'treeID', jcol = 'times', 
                       jtimes = jtimes, ijIndex = ijIndex, ijFull = ijFull)
    tdata      <- tmp$data
    tdata$year <- allYears[ tdata$times ]
    tdata$obs  <- as.numeric(as.character(tdata$obs))
    tdata$obs[is.na(tdata$obs)] <- 0
    tdata$plotYr     <- as.character( columnPaste(tdata$plot,tdata$year) )
    tdata$treeID     <- as.character(tdata$treeID)
  #  tdata$species    <- as.character(tdata$species)
    tdata$plot       <- as.character(tdata$plot)
    tdata$tree       <- as.character(tdata$tree)
    tdata$plotTreeYr <- columnPaste(tdata$treeID,tdata$year)
    
    xytree <- .trimRows(xytree, tdata, 'treeID')[[1]]   # trees having too few years
    
    for(j in 1:nplot){
      kj <- as.character(tdata$plot) == plots[j]
      wj <- which(kj)
      yr <- (trapYr[plots[j],1]):(trapYr[plots[j],2])
      tdata$obs[wj] <- 0
      tdata$obs[kj & tdata$year %in% yr] <- 1
    }
    
    tdata$repr[is.na(tdata$plotTreeYr)] <- NA
    
    sdata <- trimPlotYr(tdata, sdata, beforeFirst, afterLast, p)
    if(SEEDCENSOR){
      censMin <- censMin[rownames(censMin) %in% rownames(sdata),]
      censMax <- censMax[rownames(censMax) %in% rownames(sdata),]
      censMin[,1] <- censMax[,1] <- match(rownames(censMin), rownames(sdata))
    }
      
    plotYears <- sort(unique(c(as.character(tdata$plotYr), 
                               as.character(sdata$plotYr))))
    tdata$plotyr <- match( as.character(tdata$plotYr), plotYears )
    sdata$plotyr <- match( as.character(sdata$plotYr), plotYears )
    
    tdata$plotTreeYr <- columnPaste(tdata$treeID, tdata$year, '_')
    
    w0 <- which(tdata$obs == 0)
    if('repr' %in% names(tdata))tdata$repr[w0] <- NA
    if('repMu' %in% names(tdata))tdata$repMu[w0] <- NA
    
    if('fecMin' %in% names(tdata)){
      tdata$fecMin[w0] <- NA
      wm <- match(names(fecMin),tdata$plotTreeYr)
      wf <- which(is.finite(wm))
      tdata$fecMin <- NA
      tdata$fecMin[wm[wf]] <- fecMin[wf]
    }
    if('fecMax' %in% names(tdata)){
      tdata$fecMax[w0] <- NA
      wm <- match(names(fecMax),tdata$plotTreeYr)
      wf <- which(is.finite(wm))
      tdata$fecMax <- NA
      tdata$fecMax[wm[wf]] <- fecMax[wf]
    }
  }
  
  allYears <- sort(unique(tdata$year))
  
  tdata$times <- match(tdata$year, allYears)
  sdata$times <- match(sdata$year, allYears)
  
 # tdata$plotTreeYr <- as.factor(tdata$plotTreeYr)
 # sdata$plotTrapYr <- as.factor(sdata$plotTrapYr)
  
  attr(tdata, 'plag') <- p
  
  inputs$treeData  <- tdata
  inputs$seedData  <- sdata
  inputs$xytree    <- xytree
  inputs$xytrap    <- xytrap
  inputs$specNames <- specNames
  inputs$seedNames <- seedNames
  inputs$inwords   <- words
  
  inputs
}

  
vec2mat <- function(xx, ROW=F){
  
  #if(ROW) make row vector
  
  if(is.matrix(xx))return(xx)
  
  cc <- names(xx)
  xx <- matrix(xx)
  rownames(xx) <- cc
  if(!ROW)xx <- t(xx)
  xx
}


.cleanRows <- function(xmat, xcol, STOP=F){
  
  ww <- which(duplicated(xmat[,xcol]))
  if(length(ww) == 0)return(xmat)
  
  if(STOP)stop(paste('duplicates in', xcol))
  
  tvec <- xmat[ww,xcol]
  if(length(ww) > 1)tvec <- paste0(tvec,collapse=', ')
  
  cat(paste('\nNote: removed duplicates in', xcol, ':\n', tvec) )
  
  xmat[-ww,]
}

gen4code <- function(xx, nn=4){
  
  #shorten genus name in genusSpecies string to nn characters
  
  FAC  <- F
  if(is.factor(xx))FAC <- T
  xx   <- as.character(xx)
  fc   <- sapply(gregexpr("[A-Z]",xx),'[',1)
  wf   <- which(fc > 5)
  if(length(wf) > 0){
    gen <- substr(xx[wf],1,4)
    spp <- substr(xx[wf],fc[wf],1000)
    xx[wf] <- columnPaste(gen,spp,'')
  }
  if(FAC)xx <- as.factor(xx)
  xx
}

combineMastData <- function(inputs, newlist=NULL, regions=NULL){
  
  # inputs and newlist both have inputs
  
  if(is.null(newlist)){
    
    inputs$treeData  <- inputs$treeData[inputs$treeData$region %in% regions,]
    inputs$specNames <- inputs$specNames[inputs$specNames %in% inputs$treeData$species]
    plots            <- sort(unique(as.character(inputs$treeData$plot)))
    inputs$seedData  <- inputs$seedData[inputs$seedData$plot %in% plots,]
    inputs$xytree    <- inputs$xytree[inputs$xytree$plot %in% plots,]
    inputs$xytrap    <- inputs$xytrap[inputs$xytrap$plot %in% plots,]
    
    ssum <- colSums( as.matrix(inputs$seedData[,inputs$seedNames]) )
    stmp <- inputs$seedData[,!colnames(inputs$seedData) %in% inputs$seedNames]
    
    inputs$seedData <- data.frame( cbind(stmp), inputs$seedData[,names(ssum)[ssum > 0]] )
    inputs$seedNames <- names(ssum)[ssum > 0]
    
    inputs$treeData <- cleanFactors(inputs$treeData)
    inputs$seedData <- cleanFactors(inputs$seedData)
    inputs$xytree <- cleanFactors(inputs$xytree)
    inputs$xytrap <- cleanFactors(inputs$xytrap)
    
    return(inputs)
    
  }
  
  newlist$treeData  <- newlist$treeData[newlist$treeData$region %in% regions,]
  plots             <- sort(unique(as.character(newlist$treeData$plot)))
  newlist$seedData  <- newlist$seedData[newlist$seedData$plot %in% plots,]
  newlist$xytree    <- newlist$xytree[newlist$xytree$plot %in% plots,]
  newlist$xytrap    <- newlist$xytrap[newlist$xytrap$plot %in% plots,]
  newlist$specNames <- newlist$specNames[newlist$specNames %in% newlist$treeData$species]
  
  treeData <- merge(inputs$treeData, newlist$treeData, by=colnames(inputs$treeData), all=T)
  treeData <- treeData[!duplicated(treeData),]
  xytree   <- merge(inputs$xytree, newlist$xytree, by=colnames(inputs$xytree), all=T)
  xytrap   <- merge(inputs$xytrap, newlist$xytrap, by=colnames(inputs$xytrap), all=T)
  
  
  sd1 <- inputs$seedData[,!names(inputs$seedData) %in% inputs$seedNames]
  sd2 <- newlist$seedData[,!names(newlist$seedData) %in% newlist$seedNames]
  
  
  w1 <- rownames(inputs$seedData)
  w2 <- rownames(newlist$seedData)
  w0 <- sort(unique(c(w1,w2)))
  
  sall <- sort(unique( c(inputs$seedNames, newlist$seedNames) ))
  
  scount <- matrix(0,length(w0),length(sall))
  rownames(scount) <- w0
  colnames(scount) <- sall
  
  for(k in 1:length(sall)){
    wi <- which(colnames(inputs$seedData) == sall[k])
    wn <- which(colnames(newlist$seedData) == sall[k])
    
    if(length(wi) == 1)scount[w1,sall[k]] <- scount[w1,sall[k]] + inputs$seedData[,wi]
    if(length(wn) == 1)scount[w1,sall[k]] <- scount[w2,sall[k]] + newlist$seedData[,wn]
  }
  scount <- scount[,colSums(scount) > 0]
  stmp   <- merge(sd1,sd2, by=colnames(sd1), all=T)
  
  plotTrapYr <- columnPaste(stmp$trapID,stmp$year)
  stmp <- stmp[!duplicated(plotTrapYr),]
  plotTrapYr <- columnPaste(stmp$trapID,stmp$year)
  
  rownames(stmp) <- plotTrapYr
  sc2 <- scount[rownames(stmp),]
  stmp <- cbind(stmp,sc2)
 # inputs$seedData <- stmp
  
  inputs$treeData  <- cleanFactors(treeData)
  inputs$seedData  <- cleanFactors(stmp)
  inputs$xytree    <- cleanFactors(xytree)
  inputs$xytrap    <- cleanFactors(xytrap)
  inputs$seedNames <- colnames(scount)
  inputs$specNames <- sort(unique(as.character(treeData$species)))
  
  inputs
}

rankNeighbors <- function(xy, xysite, dr = 5, nrank=10){
  
  # rmat is number of trees at distance (columns)
  # rows are rank: closest tree, 2nd closest, ...
  
  nsite  <- nrow(xysite)
  nrank  <- min( c(nsite, nrank) )
  breaks <- seq(0, 1000, by=dr)
  
  dj <- .distmat(xy[,'x'],xy[,'y'],xysite[,'x'], xysite[,'y']) 
  
  rr <- apply(dj, 2, order, decreasing=F)

  rmat <- matrix(NA, nrank, length(breaks)-1)
  rownames(rmat) <- paste('rank',c(1:nrank),sep='-')
  
  for(k in 1:nrank){
    
    loc <- cbind(rr[k,], 1:ncol(rr))
    tmp <- hist(dj[ loc ], breaks = breaks, plot=F)
    rmat[k,] <- tmp$density
  }
  rtot <- colSums(rmat,na.rm=T)
  rseq <- c(1:ncol(rmat))
  rseq[rtot == 0] <- 0
  rmat <- rmat[,1:max(rseq)]
  mh <- colSums(rmat)
  list(rmat = rmat, mh = mh, breaks = breaks[1:ncol(rmat)])
}


HMC <- function (ff, fMin, fMax, ep, L, tree, sdat, ug, 
                 mu, sg, zz, R, SAMPR, distance, 
                 obsRows, obsYr, seedNames){
  
  #Hamiltonian Markov chain steps
  
  getU <- function(q, U = T){   # yq = log(fec)
    
    # for Hamiltonian
    # if U == T, return U, if U == F, return dU/df
    nseed <- ncol(R)
    fq <- exp(q)
    fq[fq > fMax] <- fMax[fq > fMax]
    fq[fq < fMin] <- fMin[fq < fMin]
    
    if(SAMPR | nseed > 1){
      fq <- matrix(fq,length(fq),ncol=ncol(R))*R[drop=F,as.character(tree$specPlot),]
    }else{
      fq <- matrix(fq,ncol=1)
    }
    
    uvec <- ug[ attr(distance,'species') ]
    dmat <- t(uvec/pi/(uvec + t(distance)^2)^2)
    dmat[dmat < 1e-8] <- 0
    
    lambda <- kernYrRcpp(dmat, fq*zz, years = obsYr, seedyear = sdat$year,
                         treeyear = tree$year, seedrow = sdat$drow,
                         treecol = tree$dcol)
    ss <- as.matrix(sdat[,seedNames])
    lambda[lambda < 1e-6] <- 1e-6
    
    if(U){
      mmat  <- matrix(0,max(sdat$plotyr),1)
      sprob <- -ss*log(lambda) + activeArea*lambda
      ii    <- rep(sdat$plotyr, nseed)
      tmp   <- .myBy(as.vector(sprob), ii, ii*0+1, summat=mmat, fun='sum')
      tprob <- 1/sg*(q - mu)^2 + tmp[tree$plotyr]
      
      return( tprob ) 
    }
    
    kmat <- dmat[sdat$drow,tree$dcol]
    smat <- -ss/lambda + activeArea
    
    if(nseed == 1){
      svec <- ff*colSums( kmat*as.vector(smat) )
    }else{
      svec <- rep(0,length(q))
      for(m in 1:nseed){
        sv <-  colSums(kmat*as.vector(smat[,m]) )*fq[,m]
        svec <- svec + sv
      }
    }
    svec + (q - mu)/sg
  }
  
  
#  logmax <- log(maxFec)
  
  q <- log( ff )
  p <- currentP <- rnorm(length(q)) 
  
  activeArea <- sdat$area
  
  # half step for momentum 
  p <- p - ep*getU(q, U = F)/2
  
  # Alternate full steps for position and momentum
  wall <- 1:length(q)
  
  for (i in 1:L){
    q[wall] <- q[wall] + ep[wall]*p[wall]  
    if(i < L)p[wall] <- p[wall] - ep[wall]*getU(q, U = F)[wall] 
    wall <- which(q < log(fMax))
  }
  
  # half step for momentum end
  p <- p - ep*getU(q, U = F)/2
  
  # Negate momentum at end of trajectory to make proposal symmetric
  p <- -p
  
  # Evaluate potential and kinetic energies at start and end of trajectory
  currentU  <- getU(log( ff ), U = T) 
  proposedU <- getU(q, U = T)
  currentK  <- currentP^2/2 
  proposedK <- p^2/2
  
  # Accept or reject the state at end of trajectory, returning either 
  # the position at the end of the trajectory or the initial position
  sp <- currentU - proposedU + currentK - proposedK
  ii <- tree$plotyr
  
  pnow <- .myBy(sp*zz, ii, ii*0 + 1, fun='sum')
  
  a <- exp(pnow)
  wa <- which( runif(length(a)) < a)
  
  if(length(wa) > 0){
    wt <- which(tree$plotyr %in% wa & zz == 1)
    ff[wt] <- exp( q[wt] )
    ep[wt] <- ep[wt]*1.1
    ep[-wt] <- ep[-wt]*.9
  }else{
    ep <- ep*.9
  }
  
  list(fg = ff, epsilon = ep, accept = length(wa))
}

msarLagTemplate <- function(plag, data, icol, jcol, gcol, ocol){
  
  # index for sampling betaYr
  # data - data.frame created by msarSetup
  # icol - individual column (integer or name)
  # jcol - time column (integer)
  # gcol - group column (integer or name)
  # ocol - indicator for observed (1) or interpolated (0)
  
  ifac <- gfac <- F
  idata <- data[,icol]
  jdata <- data[,jcol]
  gdata <- data[,gcol]
  odata <- data[,ocol]
  
  if(is.character(idata))idata <- as.factor(idata)
  if(is.character(gdata))gdata <- as.factor(gdata)
  
  if(is.factor(idata)){
    ifac   <- T
    indivs <- attr(idata,'levels')
    idata  <- match( as.character(idata), indivs )
  }else{
    indivs <- sort(unique(idata))
  }
  if(is.factor(gdata)){
    gfac   <- T
    groups <- attr(gdata,'levels')
    gdata  <- match( as.character(gdata), groups )
  }else{
    groups <- sort(unique(gdata))
  }
                   
  times  <- sort(unique(jdata))
  ngroup <- length(groups)
  nyr    <- length(times)
  lagGroup <- vector('list',ngroup)
  names(lagGroup) <- groups
  
  lagMatrix <-  numeric(0)
  lagGroup  <- numeric(0)
  
  nall <- 0
  
  for(m in 1:ngroup){
    
    wm   <- which(gdata == m & odata == 1)  #obs states required
    lagm <- numeric(0)
    
    im <- idata[wm]
    tall <- sort(unique(im))
    
    orm <- order(im,jdata[wm])
    
    imk <- match(im,tall)
    tmat <- matrix(NA,length(tall),nyr)
    tmat[ cbind(imk,jdata[wm]) ] <- wm
    rownames(tmat) <- tall
    
    for(j in (plag+1):nyr){
      
      jname <- paste(tall,times[j],sep='-')
      tj    <- tmat[,j:(j-plag),drop=F]
      rownames(tj) <- jname
      lagm <- rbind(lagm,tj)
    }
    wm <- unique( which(is.na(lagm),arr.ind=T)[,1] )
    if(length(wm) > 0)lagm <- lagm[drop=F, -wm,]
  
    nall <- nall + nrow(lagm)
    
    colnames(lagm) <- paste('lag',c(0:plag),sep='-')
    lagm <- lagm[drop=F, order(lagm[,1]),]
    lagMatrix <- rbind(lagMatrix,lagm)
    lagGroup  <- c(lagGroup,rep(m,nrow(lagm)))
  }
  
  cat( paste('\nNumber of full observations with AR(', 
       plag, ') model\ is: ', sep='') )
  print( nall ) 
  
  if(nall < 20)stop('not enough observations for AR(p), try reducing p')
  
  #  lagGroup
  list(matrix = lagMatrix, group = lagGroup)
}

getVarType <- function(vnames, data, i, j){
  
  # 'i'  - individual variable
  # 'j'  - time variable
  # 'ij' - individual/time
  
  if(is.factor(i))i <- as.character(i)
  
  id <- sort(unique(i))
  ni <- length(id)
  yr <- sort(unique(j))
  ny <- length(yr)
  i <- match(i, id)
  j <- match(j, yr)
  
  vnew <- vector('list',length(vnames))
  names(vnew) <- vnames
  
  
  for(k in 1:length(vnames)){
    cj <- data[,vnames[k]]
    if(is.factor(cj))cj <- as.character(cj)
    mj <- matrix(NA, ni,ny)
    mj[ cbind(i, j) ] <- cj
    
    rr <- suppressWarnings( apply(mj,1,range,na.rm=T) )
    rc <- suppressWarnings( apply(mj,2,range,na.rm=T) )
    rowSame <- all(rr[1,] == rr[2,])
    colSame <- all(rc[1,] == rc[2,])
    if(is.na(rowSame))rowSame <- F
    if(is.na(colSame))colSame <- F
    if(!rowSame & !colSame)vnew[[k]] <- 'ij'
    if( rowSame &  colSame)vnew[[k]] <- 'i'
    if(!rowSame &  colSame)vnew[[k]] <- 'j'
    if( rowSame & !colSame)vnew[[k]] <- 'i'
  }
  vnew
}

msarSetup <- function(data, plag, icol, jcol, gcol = NULL,
                      minGroup=10){
  
  # icol - column names in data for individual index; integer or factor
  # jcol - column name in data for time index; integer
  # gcol - column name for group index; integer or factor
  # pcol - column name for group names (character)
  # gmat - matrix of individual columns to retain in output
  # plag - AR lag 
  # minGroup - minimum group size
  
  if(!is.data.frame(data))stop('data must be a data.frame')
  
  huge <- 1e+10
  
  data$obs <- 1
  
  if(is.factor(data[,icol]))data[,icol] <- droplevels(data[,icol])
  if(is.factor(data[,jcol]))data[,jcol] <- droplevels(data[,jcol])
  if(is.null(gcol)){
    gcol <- 'group'
    data$group <- rep(1,nrow(data))
  }else{
    if(is.factor(data[,gcol]))data[,gcol] <- droplevels(data[,gcol])
  }
  
  i <- as.character(data[,icol])
  j <- data[,jcol]
  g <- data[,gcol]
  
  io <- i
  if(is.factor(io))io <- as.character(io)
  oo <- apply(cbind(io,j),1,paste0,collapse='-')
  
  iall <- sort(unique(as.character(i)))
  jall <- c((min(j) - plag):(max(j) + plag))
  
  groups <- unique(g)
  
  baseMat <- base <- with(data, table(i, j) )
  base[base == 0] <- NA
  
  if( max(base,na.rm=T) > 1 )
    stop('must be a unique individual-time pair in data')
  
  ii <- match(i,iall)
  jj <- match(j,jall)  # original times
  ni <- length(iall)
  nj <- length(jall)
  
  #groups with sufficient times
  tmp <- table(g,jj)
  ntmp <- as.numeric(colnames(tmp))
  tmp[,ntmp < plag] <- 0
  tsum <- apply(tmp,1,max)

  cat('\nNote: no. trees with > plag years, by group:\n')
  print(tsum)
  
  wlow <- which(tsum < minGroup)
  if(length(wlow) > 0)cat( paste('\nsmall group: ',names(tsum)[wlow],'\n',sep='') )
  
  back  <- matrix(0,nrow(base),plag)
  
  expMat <- zmat <- cbind(back, baseMat, back) #i by j, with plag
  colnames(expMat) <- colnames(zmat) <- jall
  
  imat <- jmat <- matrix(NA,ni,nj)
  imat[ cbind(ii, jj) ] <- c(1:nrow(data))
  jmat[ cbind(ii, jj) ] <- j
  first <- apply(jmat,1,which.min)
  last  <- apply(jmat,1,which.max)
  
  emat <- imat*0
  
  for(k in 1:ni)emat[k, (first[k]-plag):(last[k]+plag) ] <- 1
  ijFull <- which(emat == 1, arr.ind=T)
  
  vtypes    <- getVarType(colnames(data), data, ii, jj) 
  vtypes$obs <- 'ij'
  
  tpy <- as.character(columnPaste(data$treeID,data$year))
  
  tmp <- fillMissing(vtypes, data, icol, jcol, 
                      jtimes = jall, ijIndex = cbind(ii,jj), ijFull = ijFull)
  data <- tmp$data
  naVars <- tmp$naVars
  tpn    <- as.character(columnPaste(data$treeID,data$year))
  data$obs[!tpn %in% tpy] <- 0
  rm(tpy,tpn)
  
  i <- match(data[,icol],iall)
  j <- match(data[,jcol],jall)
  g <- match(as.character(data[,gcol]),as.character(groups) )
  
  io <- data[,icol]
  if(is.factor(io))io <- as.character(io)
 # odd <- apply(cbind(io,data[,jcol]),1,paste0,collapse='-')
 # obs[odd %in% oo] <- 1
  
  data <- cbind(data,i,j,g)
  data <- data[order(data$i, data$j),]
  
  wideGroup <- apply(with(data, table(i,g)),1,which.max) 
  
  ngroup <- length(groups)
  betaYr <- round( matrix(rnorm(ngroup*plag,0,.1),ngroup,plag), 3)
  rownames(betaYr) <- groups
  colnames(betaYr) <- paste('lag',c(1:plag),sep='-')
  
  list(xdata = data, times = jall, yeGr = groups,
       groupByInd = wideGroup, betaYr = betaYr, plag = plag)
}

fillMissing <- function(variables, data, icol, jcol, jtimes,
                        ijIndex = NULL, ijFull=NULL){
  
  # ijIndex is location in i by j matrix
  # ijFull is location in i by j matrix that includes added obs
  # jtimes - integer
  
  
  if(!is.data.frame(data))data <- as.data.frame(data, stringsAsFactors = F)
  
  if(!'obs' %in% colnames(data))data$obs <- 1
  
 # icc <- which(sapply(data,is.character))
 # if(length(icc) > 0){
 #   for(k in icc)data[[k]] <- as.factor(data[[k]])
 # }
  
 # if(is.null(ijIndex)){
 #   ijIndex <- cbind(ii, jj)
 #   ii <- data[,icol]
 #   jj <- data[,jcol]
 #   if(is.factor(ii))ii <- as.character(ii)
 #   iall <- sort(unique(ii))
 #   ii   <- match(ii, iall)
 #   jj   <- match(jj, jtimes)
 # }else{
    ii <- ijIndex[,1]
    jj <- ijIndex[,2]
    iall <- sort(unique(ii))
 # }
  if(is.null(ijFull))ijFull <- ijIndex
  
  ny <- length(jtimes)
  ni <- max(iall)
  
  emat <- matrix(NA,ni, ny)
  newData <- vector('list',ncol(data))
  names(newData) <- names(data)
  ffact <- which( sapply(data, is.factor) )
  naVars <- character(0)
  
  
  for(k in 1:ncol(data)){           #expand to pre- and post-data
    
    jmat  <- matrix(NA,ni,ny,byrow=T)
    
    vtype <- variables[names(data)[k]]
    tinySlope <- .00001
    
    kvar <- data[,k]
    sigFig <- getSigFig(kvar[1])
    
    if(k %in% ffact)kvar <- as.character(kvar)
    jmat[ cbind(ii,jj) ]  <- kvar
    w0 <- which( is.na(jmat),arr.ind=T)
    w1 <- which(!is.na(jmat),arr.ind=T )
    
    if(vtype == 'i'){
      w1 <- w1[!duplicated(w1[,1]),]
      w2 <- w0
      w2[,2] <- w1[match(w2[,1],w1[,1]),2]
      jmat[ w0 ] <- jmat[ w2 ]
    }
    if(vtype == 'j'){
      if(colnames(data)[k] == jcol){
        jmat <- matrix(jtimes,ni,ny, byrow=T)
      }else{
        w1 <- w1[!duplicated(w1[,2]),]
        w2 <- w0
        w2[,1] <- w1[match(w2[,2],w1[,2]),1]
        jmat[ w0 ] <- jmat[ w2 ]
      }
    }
    if(vtype == 'ij'){            # use trend
      if( is.numeric(kvar) & !all(is.na(kvar)) ){
        rr   <- range(jmat,na.rm=T)
        INCREASING <- F
        if( colnames(data)[k] == 'diam'){
          tinySlope <- .005
          rr[1] <- rr[1] - .5
          rr[2] <- rr[2] + .5
          if(rr[1] < .1)rr[1] <- .1
          INCREASING <- T
        }
        if( colnames(data)[k] == 'repMu'){
          INCREASING <- T
          rr <- c(0,1)
        }
        if(rr[2] <= rr[1])rr[2] <- rr[1] + .01
        jmat <- .interpRows(jmat, INCREASING=INCREASING,minVal=rr[1],maxVal=rr[2],
                            defaultValue=NULL,tinySlope=tinySlope) 
      }else{
        naVars <- c(naVars, colnames(data)[k])
      }
    }
    
    ktmp <- jmat[ijFull]
    if( k %in% ffact ) ktmp <- as.factor(ktmp)

    newData[[k]] <- ktmp
  }
  
  xdata <- data.frame(newData, stringsAsFactors = F)
  rownames(xdata) <- NULL
  xdata <- xdata[order(xdata[,icol],xdata[,jcol]),]
  list(data = xdata, naVars = naVars)
}

.propZ <- function(znow, last0first1, matYr){
  
  # repr - known repr from tdata
  # random walk proposal
  
  new <- matYr + sample( c(-1:1), nrow(znow), replace=T)
  
  new[last0first1[,'all0'] == 1] <- 0
  new[last0first1[,'all1'] == 1] <- ncol(znow) + 1
  
  ww  <- which(new < last0first1[,1])
  new[ww] <- last0first1[ww,1]
  
  ww  <- which(new > last0first1[,2])
  new[ww] <- last0first1[ww,2]
  
  down <- which(new < matYr & new > 0)
  znow[ cbind(down,new[down]) ] <- 1   # advance 1 year
  
  up <- which(new > matYr & new < ncol(znow))
  znow[ cbind(up,matYr[up]) ] <- 0     # delay 1 year
  
  znow[last0first1[,'all0'] == 1, ] <- 0
  znow[last0first1[,'all1'] == 1, ] <- 1
  
  list(zmat = znow, matYr = new)
}

.setupYear <- function(yearEffect, tdata, years){
  
  specNames <- lagGroup <- NULL
  nyr <- length(years)
  
  yrnames <- names(yearEffect)
  mcol    <- unlist(yearEffect)
  mcol    <- mcol[names(mcol) %in% c('specGroups','plotGroups')]
  yeGroup <- tdata[,mcol]
  if(length(mcol) > 1){
    if(length(mcol) > 2)stop('only two groups available for yearEffects')
    cy <- cbind(as.character(yeGroup[,1]),as.character(yeGroup[,2]))
    yeGroup <- apply( cy, 1, paste0, collapse='-')
  }
  yeGr   <- sort(as.character(unique(yeGroup)))      
  ygr    <- match(yeGroup, yeGr)
  yyr    <- match(tdata$year,years)
  ngroup <- length(yeGr)
  tdata$group <- yeGroup
    
  yrIndex <- cbind(ygr, yyr)
  colnames(yrIndex) <- c('group','year')
  gy     <- apply( yrIndex, 1, paste0,collapse='-')
  gyall  <- sort(unique(gy))
  groupYr <- match(gy,gyall)
  yrIndex <- cbind(yrIndex,groupYr)
  rownames(yrIndex) <- gy
  
  betaYr <- .myBy(ygr*0+1, yrIndex[,'group'], yrIndex[,'year'], fun='sum')
  rownames(betaYr) <- yeGr
  colnames(betaYr) <- years
  
  
  rmax <- apply(betaYr,1,max)
  wr   <- which(rmax < 10)
  if(length(wr) > 0)cat('\nat least one year group has < 10 trees\n')
  
  # reference class removed if specGroups are species
  yeRef <- yeGr
  dash <- grep('-', yeGr)
  if(length(dash) > 0){
    yeRef <- matrix( unlist(strsplit(yeGr,'-')), ncol=2,byrow=T) 
    wr    <- match(yeRef[,1],specNames)
    yeRef <- yeGr[ !duplicated(wr)  ]
  }
  betaYr <- betaYr*0
  
 # lagGroup <- numeric(0)
  
#  if(AR){
#    lagGroup <- .lagSetup(ylist$p, ngroup, yrIndex, data, years, yeGr)
#    betaYr <- betaYr[,1:ylist$p,drop=F]*0
#    colnames(betaYr) <- colnames(lagm)[-1]
#  }
    
  list(betaYr = betaYr, yrRef = yeGr, yrIndex = yrIndex, yeGr = yeGr,
       tdata = tdata)
}

.lagSetup <- function(plag, ngroup, yrInd, tdata, yr, yeGr){
  
  # tdata must have treeID, year           
  
  nyr <- length(yr)
  lagGroup <- vector('list',ngroup)
  
  OBSCOL <- F
  if('obs' %in% colnames(tdata))OBSCOL <- T
  
  for(m in 1:ngroup){
    
    if(!OBSCOL){
      toc <- rep(1,nrow(yrInd))
    }else{
      toc <- tdata$obs
    }
    
    wm   <- which(yrInd[,'group'] == m & toc == 1)  #all states required
    lagm <- numeric(0)
    
    tall <- sort(unique(tdata$treeID[wm]))
    tmat <- matrix(NA,length(tall),nyr)
    ti   <- match(tdata$treeID[wm],tall)
    yi   <- match(tdata$year[wm],yr)
    tmat[ cbind(ti,yi) ] <- wm
    rownames(tmat) <- tall
    
    for(j in (plag+1):nyr){
      
      jname <- paste(tall,yr[j],sep='-')
      tj    <- tmat[,j:(j-plag)]
      rownames(tj) <- jname
      lagm <- rbind(lagm,tj)
    }
    wm <- unique( which(is.na(lagm),arr.ind=T)[,1] )
    if(length(wm) > 0)lagm <- lagm[-wm,]
    
    colnames(lagm) <- paste('lag',c(0:plag),sep='-')
    lagGroup[[m]] <- lagm
  }
  names(lagGroup) <- yeGr

  lagGroup
}

.boxCoeffsLabs <- function( boxPars, labels, colLabs = NULL, cex=1, 
                            xadj = 0){
  
  ncols <- length(labels)
  if(is.null(colLabs))colLabs <- rep('black',ncols)
  
  xaxp <- par('xaxp')
  da <- diff(xaxp[1:2])
 # at <- xadj + (da/ncols/2 + xaxp[1] + c(0:ncols)*da/(xaxp[3] + 1))[1:ncols]
  
  at <- (xaxp[1] + c(0:ncols)*da/ncols)[-1]
  at <- at - diff(at)[1]/2
  
  yends <- boxPars$stats[c(1,nrow(boxPars$stats)),]
  yfig  <- par('usr')[3:4]
  dy    <- diff(yfig)
  dends <- rbind(yfig[1] - yends[1,], yfig[2] - yends[2,])
  sides <- apply( abs(dends), 2, which.max)
  wt  <- which(sides == 1)
  if(length(wt) > 0)text(at[wt],yends[1,wt] - dy/20,labels[wt], 
                         offset = -.1,
                         col=colLabs[wt], pos=2, srt=90, cex = cex)
  wt  <- which(sides == 2)
  if(length(wt) > 0)text(at[wt],yends[2,wt] + dy/20,labels[wt], 
                         offset = -.1,
                         col=colLabs[wt], pos=4, srt=90, cex = cex)
}

summaryData <- function(tdata, sdata, seedNames, xytree, xytrap, 
                        plotDims=NULL, plotArea=NULL){
  
  plots <- as.character(sort(unique(tdata$plot)))
  nplot <- length(plots)
  years <- sort(unique(tdata$year))
  nyr   <- length(years)
  
  if(is.null(plotArea)){
    plotArea <- matrix( plotDims[,'area']/10000, nplot, nyr)
    colnames(plotArea) <- years
    rownames(plotArea) <- plots
  }
  
  ba    <- pi*(tdata$diam/2)^2
  
  summat <- matrix(0,nplot,nyr)
  
  ii <- match(as.character(tdata$plot),plots)
  jj <- match(tdata$year,years)
  tmp <- .myBy(ba,ii,jj,summat=summat,fun='sum')/10000  # m2 per plot
  colnames(tmp) <- years
  rownames(tmp) <- plots
  
  yr <- as.character( years[years %in% colnames(plotArea)] )
  
  baPlotYr <- round(tmp[,yr]/plotArea[drop=F,plots,yr],6)
  
  seedCount <- as.matrix(sdata[,seedNames,drop=F])
  
  ii <- match(as.character(sdata$plot),plots)
  jj <- match(sdata$year,years)
  ii <- rep(ii,length(seedNames))
  jj <- rep(jj,length(seedNames))
  aa <- rep(sdata$area,length(seedNames))
  tmp <- .myBy(as.vector(seedCount)/aa,ii,jj,summat = summat,fun='sum')
  colnames(tmp) <- years
  rownames(tmp) <- plots
  
  seedPerBA <- tmp[drop=F,plots,yr]/baPlotYr[drop=F,plots,yr]
  
  keep <- which(colSums(baPlotYr,na.rm=T) > 0)
  
  list(BA = baPlotYr[,keep,drop=F], seedPerBA = seedPerBA[,keep,drop=F])
}

getBins <- function(xx, nbin=15, pow=1){
  
  xrange <- range(xx, na.rm=T)
  bins <- unique( quantile(as.vector(xx[xx > 0]),seq(0,1,length=nbin)^pow) )
  bins <- c(0,bins)
  dbin <- diff(bins)
  
  bins[-1] <- bins[-1] - diff(bins)/2
  bins <- c(bins,max(bins)+1)
  db   <- diff(bins)
  w0   <- which(db < 1)
  
  if(length(w0) > 0)bins <- bins[-(w0+1)]
  sort(unique(bins))
}

.cov2Cor <- function(covmat, covInv = NULL){  
  
  # covariance matrix to correlation matrix
  # if covInv provided, return inverse correlation matrix
  
  d    <- nrow(covmat)
  di   <- diag(covmat)
  s    <- matrix(di,d,d)
  cc   <- covmat/sqrt(s*t(s))
  
  if(!is.null(covInv)){
    dc <- diag(sqrt(di))
    ci <- dc%*%covInv%*%dc
    return(ci)
  }
  cc
}


plotCoeffs <- function(beta, bchain, burnin, ng, specNames, specCol, cex=.8,
                       xlab=''){
  
  fnames  <- .coeffNames(rownames(beta))
  nspec   <- length(specNames)
  
  nint <- grep(':',colnames(bchain))
  intt <- c(1:ncol(bchain))
  intt <- c(1:ncol(bchain))
  if(length(nint) > 0)intt <- intt[-nint]
  
  bc <- bchain[burnin:ng,intt,drop=F]
  colnames(bc) <- .replaceString(colnames(bc),'species','')
  
  ylim <- quantile(bc, c(.1, .99))
  ylim[1] <- ylim[1] - .5*diff(ylim)
  ylim[2] <- ylim[2] + .5*diff(ylim)
  
  boxPars <- .boxCoeffs(bc, specNames, xaxt='n',
                        xlab = xlab, ylab='', ylim=ylim,
                        cols = specCol[specNames], addSpec = '')
  .boxCoeffsLabs( boxPars, specNames, specCol[specNames], cex=cex)
  
  if(length(nint) > 0){
    bc <- bchain[burnin:ng,nint,drop=F]
    colnames(bc) <- .replaceString(colnames(bc),'species','')
    scol <- rep(character(0), ncol(bc))
    
    bcc <- .boxCoeffs(bc, specNames, xlab = '', xaxt='n', 
                      ylim=quantile(bc, c(.01, .99)),
                      ylab=' ', cols = specCol[specNames], addSpec = '' )
    gg <- grep(':',fnames)
    cnames <- fnames[gg]
    cnames <- columnSplit(cnames,':', LASTONLY=T)
    cnames <- cnames[seq(1,length(cnames),by=nspec)]
    stats  <- bcc$stats
    snew   <- numeric(0)
    if(length(cnames) == 1){
      .plotLabel(cnames,'bottomleft', cex=.8)
    }else{
      for(k in 1:length(cnames)){
        skk <- stats[,grep(cnames[k], colnames(stats), fixed=T), drop=F]
        mins <- apply(skk,1,min)
        maxs <- apply(skk,1,max)
        sk  <- skk[,1]*0
        sk[1] <- mins[1]
        sk[length(sk)] <- maxs[length(sk)]
        snew <- cbind(snew,sk)
      }
      colnames(snew) <- cnames
      bcc$stats <- snew
      .boxCoeffsLabs( bcc, cnames, cex=cex)
    }
  }
}


.mastPlot2File <- function( output, plotPars ){
  
  parfile <- 'plotPars'
  if(is.null(plotPars))plotPars <- list()
  
  RMD <- plotPars$RMD
  if(RMD == 'pdf'){
    RMD <- 'pandoc'
    plotPars$MAPS <- F
  }
  
  if(!RMD %in% c('html','pandoc','pdf'))plotPars$RMD  <- 'html'
  
  
  rfile   <- 'tmp.r'
  file.create(rfile)
  fileConn <- file(rfile)
  rtext <- '.mastPlot(output, plotPars)'
  
  writeLines(rtext, con = fileConn)
  close(fileConn)
  
  knitr::spin(rfile)
  file.remove( rfile )
  
  tmp <- readLines('tmp.md')
  rmdOut <- file('mastifOutput.Rmd', "w")
  
 # tmp <- .replaceString(tmp, '## ', '')
  tmp <- .replaceString(tmp,".mastPlot(output, plotPars)","")
  
  capline <- grep('## ',tmp)
  newCaps <- .replaceString(tmp[capline],'## ','')

  caption <- grep('plot of chunk', tmp)
  cwords  <- tmp[caption - 3]
  cwords  <- .replaceString(cwords, ' ','')
  
  fnum <- c(1:length(caption))
 # fcap <- paste('![Figure ',fnum,']',sep='')
  
  for(m in 1:length(caption)){
    tmp[caption[m]]  <- .replaceString(tmp[caption[m]], 'plot of chunk unnamed-chunk-1',
                                       newCaps[m])
  }
  comment <- grep('##',tmp)
  tmp <- tmp[-comment]
  tick <- grep('`',tmp)
  tmp <- tmp[-tick]
  
  day <- paste('date: ', date(), '\n', sep='')
  
  doc <- "output: 'html_document'\n"
  if(RMD == 'pandoc')doc <- "output: pdf_document\n"
  
  ptab <- paste("\n   print( knitr::kable(tj, knitr.kable.NA = '', caption = caps[wj, 2], format = '",
                RMD,"') )\n", sep='')
  
  #write new lines to rmdOut file
  cat("---\n", file = rmdOut)
  cat("title: 'mastif report'\n", file = rmdOut)
  cat(day, file = rmdOut)
  cat(doc, file = rmdOut)
  cat("---\n", file = rmdOut)
  
  cat("\n```{r, results = 'asis', echo = F}\n", file = rmdOut)
  cat("\ntfiles <- list.files('tables', full.names=T)",file = rmdOut)
  cat("\ntfiles <- tfiles[!tfiles %in% c('tables/words.txt', 'tables/captions.txt')]",
      file = rmdOut)
  cat("\ncaps  <- read.table('tables/captions.txt', as.is = T, header=F)", 
      file = rmdOut)
  
  cat("\nwords <- read.table('tables/words.txt', header=F)", file = rmdOut)
  cat("\ncolnames(words) <- NULL", file = rmdOut)
  cat("\ncat( paste0(unlist(words), collapse=' ') )\n", file=rmdOut)

  
  cat("\nfor(j in 1:length(tfiles)){\n",file = rmdOut)
  cat("\n   wj <- which(caps[,1] == tfiles[j])", file = rmdOut)
  cat("\n   tj <- read.table(tfiles[j], header=T)",file = rmdOut)
 # cat("\n   print( knitr::kable(tj, caption = caps[wj, 2], format = 'html') )\n",
 #         file = rmdOut)
  cat(ptab,file = rmdOut)
  cat("\n}\n",file = rmdOut)
  cat("```\n", file = rmdOut)
  
  
  #write all lines from rmdOut file
  for(i in 1:length(tmp)){
    cat(tmp[i], "\n", file = rmdOut, sep = "\t")
  }
  close(rmdOut)
  
  
 # file.remove('tmp.md', showWarnings = F)
}

mastPlot <- function(output, plotPars = NULL){
  
  # RMD - generate Rmarkdown
  
  if(!is.null(plotPars)){
    if('RMD' %in% names(plotPars)){
      .mastPlot2File( output, plotPars )
      return()
    }
  }
  .mastPlot( output, plotPars )
}
  
.mastPlot <- function(output, plotPars){
    
  SAVEPLOTS <- KNOWNBA <- SEEDCENSOR <- F
  YR <- AR <- RANDOM <- TV <- SAMPR <- PREDICT <- SPACETIME <- F
  
  RMD <- NULL
  CONSOLE <- T
  caption <- character(0)
  
  data <- treeData <- priorUgibbs <- fecPred <- plotDims <- 
    plotHaByYr <- plotArea <- keepIter <- aUgibbs <- alphaMu <- NULL
  
  seedNames <- specNames <- R <- formulaFec <- formulaRep <- xfec <- xrep <-
    tdata <- seedData <- xytree <- xytrap <- distall <- ng <- burnin <- nplot <-
    ntree <- ntrap <- nyr <- maxFec <- bfec <- brep <- upar <- rgibbs <- 
    betaFec <- betaRep <- rMu <- rSe <- usigma <- fecMu <- fecSe <- matrMu <- 
    seedPred <- inputs <- chains <- parameters <- predictions <- 
    upars <- dpars <- trueValues <- betaYrMu <- betaYrSe <-  
    sgibbs <- ugibbs <- omegaE <- predPlots <- betaYrRand <- 
    betaYrRandSE <- prediction <- eigenMu <- facLevels <- specPlots <- NULL
  randGroups <- formulaRan <- rnGroups <- reIndex <- xrandCols <- NULL  
  specGroups <- plotGroups <- yrIndex <- randomEffect <- yearEffect <- NULL
  pacfMat <- pacfSe <- pacsMat <- pacsSe <- obsRows <- NULL
  modelYears <- seedPredGrid <- treePredGrid <- NULL
  notFit <- character(0)
  censMin <- censMax <- NULL
  
  ugibbs <- matrix(0)
  
  outFolder <- 'mastPlots'
  yeGr <- NULL
  plotsPerPage <- 4
  MAPS <- T
  
  for(k in 1:length(output))assign( names(output)[k], output[[k]] )
  for(k in 1:length(inputs))assign( names(inputs)[k], inputs[[k]] )
  for(k in 1:length(chains))assign( names(chains)[k], chains[[k]] )
  for(k in 1:length(parameters))assign( names(parameters)[k], parameters[[k]] )
  for(k in 1:length(prediction))assign( names(prediction)[k], prediction[[k]] )
  if('arList' %in% names(data)){
    for(k in 1:length(data$arList))
      assign( names(data$arList)[k], data$arList[[k]] )
    AR <- T
    plag <- ncol(data$arList$betaYr)
  }
  if(!is.null(plotPars)){
    for(k in 1:length(plotPars))assign( names(plotPars)[k], plotPars[[k]] )
    if( 'trueValues' %in% names(plotPars)  ){
      TV <- T
      for(k in 1:length(trueValues))
        assign( names(trueValues)[k], trueValues[[k]] )
    }
  }
  if('trueValues' %in% names(inputs)){
    TV <- T
    for(k in 1:length(inputs$trueValues))
      assign( names(inputs$trueValues)[k], inputs$trueValues[[k]] )
  }
  notFit    <- output$data$setupData$notFit
  maxFec    <- output$inputs$maxFec
  specNames <- output$inputs$specNames
  seedNames <- output$inputs$seedNames
  if('rgibbs' %in% names(output$chains))SAMPR <- T
  if('randomEffect' %in% names(output$inputs)){
    RANDOM <- T
    for(k in 1:length(randomEffect))
      assign( names(randomEffect)[k], randomEffect[[k]] )
    agibbs <- .orderChain(agibbs, specNames)
  }
  if('yearEffect' %in% names(output$inputs)){
    YR <- T
    yrIndex <- output$data$setupYear$yrIndex
    if(is.null(yrIndex))yrIndex <- output$inputs$yrIndex
    if('p' %in% names(output$inputs$yearEffect)){
      if(output$inputs$yearEffect$p > 0){
        AR <- T
        YR <- F
      }
    }
    yeGr <- as.character(output$data$setupYear$yeGr)
    if(is.null(yeGr))yeGr <- output$data$setupData$yeGr
    bygibbsR <- .orderChain(bygibbsR, yeGr)
    ugibbs   <- .orderChain(ugibbs, specNames)
  }
  if(!YR)yeGr <- as.character(output$data$setupData$yeGr)
  ngroup <- length(yeGr)
  
  # }
  
  ngLab <- ng
  burnLab <- burnin
  if( 'keepIter' %in% names(inputs) ){
    burnin <- ceiling( burnin*keepIter/ng )
    ng <- keepIter
  }
  nspec <- length(specNames)
  
  if(!is.null(RMD))SAVEPLOTS <- CONSOLE <- F
  if(SAVEPLOTS)CONSOLE <- F
  
  if(SAVEPLOTS){
    tt <- paste('\nPlots saved to ',outFolder,'/\n',sep='')
    cat(tt)
  }
  
  if(AR)YR <- F
  if(!is.null(censMin) & !is.null(censMax))SEEDCENSOR <- T
  
  xmean <- output$data$setupData$xmean  # to unstandardize xfec, xrep
  xsd   <- output$data$setupData$xsd
  
  tdata <- output$inputs$treeData
  sdata <- output$inputs$seedData
  
  xfecu2s <- output$data$setupData$xfecu2
  xrepu2s <- output$data$setupData$xrepu2s
  
  xfecs2u <- output$data$setupData$xfecs2u
  xreps2u <- output$data$setupData$xreps2u
  
  fnames  <- .coeffNames(rownames(betaFec))
  rnames  <- .coeffNames(rownames(betaRep))
  
  xfec <- output$data$setupData$xfec
  xrep <- output$data$setupData$xrep
  Qf   <- ncol(xfec)/nspec
  Qr   <- ncol(xrep)/nspec
  
  
  ###############
  rm(treeData)
  ##############
  
  outTables <- 'tables/table_'
  if(file.exists('tables')){
    fi <- list.files('tables', full.names=T)
    for(j in 1:length(fi)){
      file.remove(fi[j])
    }
  }else{
    dir.create('tables')
  }
    
  captions <- character(0)
  
  sumOut <- summary.mastif( output, verbose = F )
  ww <- which(!names(sumOut) == 'words')
  for(k in ww){
    xk <- sumOut[[k]]
    ok <- paste( outTables, names(sumOut)[k], '.txt', sep='')
    
    cap <- attr(xk, 'caption')
    if(is.null(cap))cap <- 'tcap'
    write.table(xk, quote=F, file = ok, row.names=T) 
    
    captions <- rbind(captions, cbind(ok, cap) )
    
  }
  words <- paste0( sumOut$words, collapse = '. ')
  words <- .replaceString(words, '\n', '')
  write.table(captions, file='tables/captions.txt', row.names=F, col.names=F)
  write.table(sumOut$words, file='tables/words.txt', row.names=F, col.names=F)
  
  
  if(is.null(yeGr))yeGr <- 'all'
  
  nspec  <- length(specNames)
  ntype  <- length(seedNames)
  years  <- sort(unique(tdata$year))
  nyr    <- length(years)
  ngroup <- length(yeGr)
  plots  <- sort(unique(as.character(tdata$plot)))
  nplot  <- length(plots)
  
  tmp1 <- as.character(tdata$plot)
  tmp2 <- tdata$year
  if(!is.null(seedPredGrid)){
    PREDICT <- T
    tmp1 <- c(tmp1, as.character(seedPredGrid$plot))
    tmp2 <- c(tmp2, seedPredGrid$year)
  }
  
  plotYrTable <- table(plot = tmp1, year = tmp2)
  rm(tmp1)
  rm(tmp2)
  
  
  cfun <- colorRampPalette( c('#66c2a5','#fc8d62','#8da0cb') )
  specCol <- cfun(nspec)
  names(specCol) <- specNames
  cols <- specCol
  
  
  gfun <- colorRampPalette( c("#8DD3C7", "#BEBADA", "#FB8072",
                              "#80B1D3", "#FDB462") )
  groupCol <- gfun(ngroup)
  names(groupCol) <- yeGr
  
 # if(ngroup == 1 & ncol(ugibbs) > 1){
 #   groupCol <- gfun(ncol(ugibbs))
 #   names(groupCol) <- colnames(ugibbs)
 # }
  
  gfun <- colorRampPalette( c("forestgreen","#8DD3C7", "#BEBADA", "#FB8072",
                              "#80B1D3", "#FDB462", "brown") )
  plotCol <- gfun(nplot)
  names(plotCol) <- plots
  
  if(SAVEPLOTS){
    ff <- file.exists(outFolder)
    if(!ff)dir.create(outFolder)
  }
  
  if(KNOWNBA){
    
    # empirical summary
    tmp <- summaryData(tdata, sdata, seedNames, xytree, xytrap, plotDims, 
                       plotArea)
    
    BA <- as.matrix( tmp$BA[drop=F,plots,] )
    seedPerBA  <- as.matrix( tmp$seedPerBA[drop=F,plots,] )
    BA[!is.finite(BA)] <- NA
    seedPerBA[!is.finite(seedPerBA)] <- NA
    
    pyr <- as.character(years[years %in% colnames(BA) & 
                                years %in% colnames(seedPerBA)])
    
    if(is.null(RMD)) graphics.off()
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'dataSummary.pdf') )
    
    par(bty='n', mfrow=c(1,1),mar=c(5,5,3,3),oma=c(2,2,1,2), cex=1.2)
    
    xlim <- range(BA[,pyr],na.rm=T)
    xlim[2] <- 1.1*xlim[2]
    ylim <- range(seedPerBA[,pyr],na.rm=T)
    ylim[2] <- ylim[2]*1.2
    
    xlab <- expression( paste('BA (',plain(m)^2, plain(ha)^-1,')' ) )
    ylab <- expression( paste('Seeds (', plain(m)^-2, 'BA ', plain(yr)^-1,')') )
    zlab <- expression( paste(bar(y) %+-% plain(sd), ' (for non-zero values)') )
    
    plot(NULL,xlim=xlim,ylim=sqrt(ylim),yaxt='n', xlab=xlab, ylab=ylab, yaxt='n')
    
    tt   <- sqrtSeq(1.2*sqrt(ylim[2]))
    at   <- tt$at
    labs <- tt$labs
    axis(2, at = at, labels = labs)
    
    syr <- seedPerBA[,pyr,drop=F]
    qs <- quantile(syr[syr > 0],probs = pnorm(c(-1,0,1)),na.rm=T)
    abline(h=sqrt(qs),lty=2,lwd=1)
    abline(h=sqrt(qs[2]),lwd=1)
    
    for(j in 1:nrow(BA)){
      points(BA[j,pyr],sqrt(syr[j,]),
             col=.getColor(plotCol[rownames(BA)[j]],.5),pch=16)
      b1 <- BA[j,pyr]
      xj <- .1*diff(xlim) + quantile(b1[b1 > 0], .7, na.rm=T)
      yj <- 1.2*max(sqrt(syr[j,]), na.rm=T)
      if(xj > xlim[2])xj <- xlim[2]*.95
      if(yj > ylim[2])yj <- ylim[2]*.95
      if(yj < diff(sqrt(ylim))/5)yj <- yj + diff(sqrt(ylim))/5
      text(xj,yj, rownames(BA)[j],srt=45, col=plotCol[rownames(BA)[j]])
    }
    mtext('Quantial for non-zeros',outer=T,side=4, line=-2)
    mtext('mean (solid), 68% (dashed)',outer=T,side=4, line=-1)
    
    if(CONSOLE)
      readline('seeds vs BA by yr-- return to continue ')
    if(SAVEPLOTS)dev.off( )
  }
  
  ########### MCMC chains
  
  if(is.null(RMD)) graphics.off()
  
  refVals <- NULL
  
 # if(TV)refVals <- inputs$trueValues$betaRep
  words <- .chainPlot(brep, burnin, 'maturation', ngLab, burnLab,
             refVals = refVals, CONSOLE, RMD, SAVEPLOTS, outFolder)
 # if(is.null(RMD))caption <- c(caption, words)
  
#  if(TV)  refVals <- inputs$trueValues$betaFec
  
  bfecFit   <- bfec[,!colnames(bfec) %in% notFit, drop=F]
  words <- .chainPlot(bfecFit, burnin, 'fecundity', ngLab, burnLab, 
             refVals = refVals, CONSOLE, RMD, SAVEPLOTS, outFolder)
 # if(is.null(RMD))caption <- c(caption, words)
  
  if(TV)refVals <- inputs$trueValues$upar
  words <- .chainPlot(ugibbs, burnin, 'dispersal parameter u',
                      ngLab, burnLab, refVals = refVals, CONSOLE, 
                      RMD, SAVEPLOTS, outFolder)
 # if(is.null(RMD))caption <- c(caption, words)
  
  if(nspec > 1){
    words <- .chainPlot(priorUgibbs, burnin, 'dispersal mean and variance', 
                        ngLab, burnLab,
                        refVals = NULL, CONSOLE, RMD, SAVEPLOTS, outFolder)
 #   if(is.null(RMD))caption <- c(caption, words)
  }
  
  words <- .chainPlot(sgibbs, burnin, 'variance sigma', ngLab, burnLab,
                      refVals = NULL, CONSOLE, RMD, 
             SAVEPLOTS, outFolder)
 # if(is.null(RMD))caption <- c(caption, words)
  
  if(SAMPR){
    
    mg   <- rgibbs
    posR <- attr(rMu,'posR')
    rff  <- NULL
    
    tmp <- columnSplit(colnames(mg),'_')
    seedCols <- tmp[,1]
    
    wdash <- grep('-',tmp[1,2])
    if(length(wdash) > 0){
      tmp  <- columnSplit(tmp[,2],'-')
      specCols <- tmp[,1]
      plotCols <- tmp[,2]
      np <- length(plots)
    }else{
      specCols <- tmp[,2]
      plotCols <- NULL
      np <- 1
    }
    
    for(j in 1:np){
      if(!is.null(plotCols)){
        wj <- which(plotCols == plots[j])
        if(length(wj) == 0)next
        rj <- range(mg[,wj])
        if(rj[1] == 1 | rj[2] == 0)next
      }else{
        wj <- 1:ncol(mg)
      }
      
      label <- paste('M matrix', plots[j])
      
      if(TV){
        tt <- columnSplit(colnames(mg)[wj])
        rff <- inputs$trueValues$R[ cbind(tt[,2],tt[,1]) ]
      }
      
      words <- .chainPlot(mg[,wj,drop=F], burnin, label, 
                          ngLab, burnLab,ylim=c(0,1),
                 refVals = rff, CONSOLE, RMD, SAVEPLOTS, outFolder)
  #    if(is.null(RMD))caption <- c(caption, words)
    }
    
    if(is.null(RMD)) graphics.off()
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'Mpars.pdf') )
    
    espec <- sort(unique(specCols))
    
    par(mfrow=c(length(espec),1), bty='n', mar=c(.5,4,.5,3), oma=c(4,3,2,4))
    tlab <- ''
    
    plotColors <- plotCol[plotCols]
    
    for(j in 1:nspec){
      
      cj <- which(specCols  == specNames[j])
      if(length(cj) == 0)next
      
      unkn <- grep('UNKN',colnames(mg)[cj])
      if(length(unkn) > 0){
        cj <- c(cj[-unkn],cj[unkn])
      }
      
      cols <- plotColors[cj]
      
      boxPars <- .boxCoeffs(mg[burnin:ng,cj,drop=F], specNames[j], xlab = tlab,
                            ylab=specNames[j], addSpec='', ylim=c(0,1),
                            cols = cols, yaxt='n')
      wt <- c(match(seedCols[cj], seedNames), 1000)
      wt[length(wt)] <- wt[length(wt)] + 1
      wt <- which(diff(wt) != 0)
      abline(v=wt+.5,col='grey')
      text(wt-.1,.5,seedCols[cj[wt]], srt=90, cex=.8)
      
      abline(h=1,col='grey', lwd=1)
      axis(2, at=c(0,1), las=2)
      tlab <- ''
    }
    
    mtext('Fraction from these species...', side=2, line=.4, outer=T, cex=1.2)
    mtext('...to these seed types', side=3, line=.4, outer=T, cex=1.2)
    
    ncol <- round(length(plots)/4) + 1
    
    cornerLegend('bottomright', plots, text.col = plotCol[plots],
                 cex=.9, bty='n', ncol=ncol)
    
    if(CONSOLE)
      readline('species -> seed type -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- paste( 'Contribution of each species to seedNames' )
      message( words )
      caption <- c(caption, words)
    }
    
  ########################
  
    #inverse probability species h| seedtype m
    
    fec <- output$prediction$fecPred
    
    nsim <- 40
    ksim <- sample(c(burnin:ng), nsim, replace=T)
    
    npairs <- columnSplit(colnames(rgibbs),'_')[,c(2,1)]
    
    rmat <- sprob <- sprob2 <- parameters$rMu*0
    
    for(m in 1:length(plots)){
      
      wj <- grep( paste('-',plots[m],sep=''), colnames(rgibbs))
      
      if(length(wj) <= 1)next
      mm <- rgibbs[,wj,drop=F]
      mp <- npairs[wj,]
      
      wm <- which(fec$plot == plots[m])
      ff <- fec$fecEstMu[wm]
      ss <- fec$fecEstSe[wm] + .00001
      mt <- fec$matrEst[wm]
      
      rrow <- grep(plots[m],rownames(rmat))
      
      for(k in 1:nsim){
        
        rmat <- rmat*0
        rmat[npairs[wj,]] <- mm[ksim[k],]
        rmm  <- rmat[drop=F,rrow,]
        
        fk <- .tnorm(length(ff), 0, maxFec, ff, ss)*mt
        ii <- match(fec$species[wm],specNames)
        tf <- tapply(ff, ii, FUN=sum)
        tf <- tf/sum(tf)
        names(tf) <- paste(specNames[as.numeric(names(tf))],plots[m],sep='-')
        tmat <- rmm*0
        tmat[names(tf),] <- rep(tf, ncol(tmat))
        
        sf <- rmm*tmat/matrix( colSums(rmm*tmat),nrow(rmm), ncol(rmm), byrow=T )
        sf[is.na(sf)] <- 0
        sprob[rrow,] <- sprob[rrow,] + sf
        sprob2[rrow,] <- sprob2[rrow,] + sf^2
      }
    }
    seed2SpecMu <- sprob/nsim
    sse <- sprob2/nsim - seed2SpecMu^2
    sse[sse < 1e-30] <- 0
    seed2SpecSe <- sqrt( sse )
    
    if(max(seed2SpecSe, na.rm=T) > 1e-20){
      
      if(SAVEPLOTS)pdf( file=.outFile(outFolder,'undiffSeed.pdf') )
      
      kplots <- character(0)
      
      for(m in 1:length(plots)){
        rrow <- grep(plots[m],rownames(seed2SpecMu))
        smm  <- seed2SpecMu[rrow,]
        wk   <-  which(smm > 1e-20 & smm < 1, arr.ind=T)
        if(length(wk) == 0)next
        kplots <- c(kplots,plots[m])
      }
      
      tt <- .getPlotLayout(length(kplots))
      par(mfrow=tt$mfrow, bty='n', mar=c(3,3,1,1), oma=c(3,3,3,4))
      aspec <- character(0)
      
      ucol <- grep('UNKN', colnames(seed2SpecMu))
      
      ISPLOT <- F
      
      for(m in 1:length(kplots)){
        
        rrow <- grep(kplots[m],rownames(seed2SpecMu))
        smm  <- seed2SpecMu[rrow,]
        emm  <- seed2SpecSe[rrow,]
        wk   <-  which(smm > 1e-20 & smm < 1, arr.ind=T)
        if(length(wk) == 0)next
        
        wk <- wk[wk[,2] == ucol,]
        if(length(wk) == 0)next
        
        ISPLOT <- T
        
        cspec <- columnSplit(rownames(wk),'-')[,1]
        aspec <- c(aspec,cspec)
        colm <- specCol[cspec]
        tmp  <- barplot(smm[wk], beside=T, col=.getColor(colm,.5), 
                        border=colm, ylim=c(0,1),yaxt='n', lwd=2)
        labels <- F
        if(m %in% tt$left)labels=c(0,1)
        axis(2, c(0,1), labels=labels)
        segments(tmp, smm[wk], tmp, smm[wk] + 1.96*emm[wk], lwd = 1.5, col=colm)
        segments(tmp-.1, smm[wk] + 1.96*emm[wk], tmp+.1, smm[wk] + 1.96*emm[wk],
                 lwd=1.5, col=colm)
        .plotLabel(kplots[m], 'topright', above=T)
      }
      
      if(ISPLOT){
        mtext('...from these species', side=1, line=.4, outer=T, cex=1.2)
        mtext('Fraction of unknown seed type...', side=2, line=.4, outer=T, cex=1.2)
        
        aspec <- sort(unique(aspec))
        
        cornerLegend('bottomright', aspec, text.col = specCol[aspec],
                     cex=1.1, bty='n', ncol=1)
        
        if(CONSOLE)
          readline('Species to undiff seed -- return to continue ')
        if(SAVEPLOTS)dev.off( )
        
        if(is.null(RMD)){
          graphics.off()
        }else{
          words <- paste( 'Contribution of each species to undifferentiated type' )
          message( words )
          caption <- c(caption, words)
        }
      }else{
        dev.off()
      }
    }
  }
  
  ##############################
  if(RANDOM){
    
    aMu <- parameters$aMu
    
    att <- aMu*0
    wc <- 1
    if(length(aMu) > 1){
      diag(att) <- 1
      wc <- which(att == 1)
    }
    
    vaa <- agibbs[,wc,drop=F]
    vrr <- apply(vaa,2,sd)
    if( max(vrr) > 1e-5 ){
      
      words <- .chainPlot(aUgibbs[,wc,drop=F], burnin, 
                          'random effects variance', 
                          ngLab, burnLab,
                 refVals = NULL, CONSOLE, RMD, SAVEPLOTS, outFolder)
      caption <- c(caption, words)
    }
    if(is.null(RMD)) graphics.off()
  }
  
  
  ########### coefficients
  
  if(SAVEPLOTS)pdf( file=.outFile(outFolder,'fecundityCoeffs.pdf') )
  
  # standardized betas
  bfecStnd <- bfec%*%t(xfecu2s)
  brepStnd <- brep%*%t(xrepu2s)
  colnames(brepStnd) <- colnames(brep)
  
  if(nspec == 1){
              
    par(mfrow=c(1,2), mar=c(5,4,2,1), bty='n')
    tmp <- .boxplotQuant( brepStnd[drop=F,burnin:ng,], add = F, xaxt = 'n',
                          xlim = NULL, ylab='Standard deviations', 
                          outline=F, col=.getColor('black', .2), 
                          border='black', lty=1, boxfill=NULL )
    
    axis(1, at = c(1:nrow(betaRep)), labels=rnames, las = 2)
    abline(h=0, col='grey', lwd=2, cex.axis=.6)
    title('a) Maturation')
    if(TV)abline(h=inputs$trueValues$betaRep, lwd=2, lty=2, col='grey')
    
    tmp <- .boxplotQuant( bfecStnd[drop=F,burnin:ng,!colnames(bfecStnd) %in% notFit], 
                          add = F, xaxt = 'n',
                          xlim = NULL, ylab='', 
                          outline=F, col=.getColor('black', .2), 
                          border='black', lty=1, boxfill=NULL )
    axis(1, at = c(1:nrow(betaFec)), labels=fnames, las = 2)
    abline(h=0, col='grey', lty=2)
    title('b) Fecundity')
    if(TV){
      abline(h=inputs$trueValues$betaFec, lwd=2, lty=2, col='grey')
      text(2,inputs$trueValues$betaFec[1] + 2,'true values')
    }
    
  }else{
    
    par(mfrow=c(2,2), mar=c(1,3,1,.2), bty='n', oma=c(2,2,1,1))

    plotCoeffs(betaRep, brepStnd, burnin, ng, specNames, specCol, cex=.8,
               xlab = 'Maturation')
    plotCoeffs(betaFec, bfecStnd, burnin, ng, specNames, specCol, cex=.8,
               xlab = 'Fecundity')
    mtext('Standardardized estimates',side=2, outer=T)
  }
  
  if(CONSOLE)
    readline('fecundity, maturation -- return to continue ')
  if(SAVEPLOTS)dev.off( )
  
  if(is.null(RMD)){
    graphics.off()
  }else{
    words <- paste( 'Posterior estimates for maturation and fecundity parameters' )
    message( words )
    caption <- c(caption, words)
  }
  
  ############ maturation, fecundity
  
  if(SAVEPLOTS)pdf( file=.outFile(outFolder,'maturation.pdf') )
  
  mfrow <- c(nspec,2)
  par(mfrow=mfrow, bty='n', mar=c(3,3,1,1),  oma=c(1,1,1,1.1))
  
  ymax <- quantile(fecPred$fecPredMu[obsRows],.99)
  tt   <- sqrtSeq(sqrt(ymax))
  at   <- tt$at
  labs <- tt$labs
  xlim <- c(0, max(tdata$diam, na.rm=T))
  
  nsim <- 1000
  lseq <- seq(0, 1, length=500)
  
  
  for(j in 1:nspec){
    
    fspec  <- fecPred[obsRows,]
    tspec  <- tdata[obsRows,]
    xrspec <- xrep[obsRows,]
    xfspec <- xfec[obsRows,]
    
    fss <- as.character(fspec$species)
    
    pspec  <- tspec$plot[fss == specNames[j]]
    xrspec <- xrspec[fss == specNames[j],]
    xfspec <- xfspec[fss == specNames[j],]
    mspec  <- fspec$matrEst[fss == specNames[j]]
    dspec  <- tspec$diam[fss == specNames[j]]
    
    pspec <- as.character(pspec)
    pall  <- sort(unique(pspec))
    
    dq   <- round( quantile(dspec, lseq), 1)
    dq   <- unique(dq)
    
    ttt  <- nn2(dspec, dq, k = 1)[[1]]
    www  <- which(duplicated(ttt))
    if(length(www) > 0)ttt <- ttt[-www]
    
    ntt  <- length(ttt)                          # tree yr
    ksamp <- sample(nrow(brep),nsim,replace=T)   # MCMC row
    bcols <- colnames(brep)
    fcols <- colnames(bfec)
    if(nspec > 1){
      bcols <- bcols[ grep(specNames[j], bcols) ]
      fcols <- fcols[ grep(specNames[j], fcols) ]
    }
    
    ddcol <- grep('diam',bcols)
    fdcol <- grep('diam',fcols)
    
    xtt <- xrspec[ttt,bcols]            # standardized
    ftt <- xfspec[ttt,fcols]
    
    xtmu <- matrix(colMeans(ftt), nrow(ftt), ncol(ftt), byrow=T)
    gcol <- grep('diam',colnames(ftt))
    
    
    
    ftt[,-gcol] <- xtmu[,-gcol]        # diam columns not centered
      
    rk <- mk <- sk   <- matrix(NA, ntt, nsim)
    
    for(k in 1:nsim){
  #    rk[,k] <- pnorm( xtt%*%t( brepStnd[ksamp[k],bcols, drop=F] ) )
      
      ss <- sqrt( sgibbs[ksamp[k],1] )
      bf <- bfecStnd[ksamp[k],fcols, drop=F] 
      
      if(RANDOM){                             # check standardized
        br <- rmvnormRcpp(1, aMu[1,]*0, aMu)
        names(br) <- colnames(aMu)
        br <- br[colnames(aMu) %in% fcols]
        bf[,names(br)] <- bf[,names(br)] + br
      }
      
      mk[,k] <- pnorm( xtt%*%t( brepStnd[ksamp[k],bcols, drop=F] ) )
      muk <- ftt%*%t( bf )
  #    rk[,k] <- exp( muk + (ss^2)/2 )*mk[,k]
      sk[,k] <- exp( muk + rnorm(ntt, 0, ss) )*mk[,k]
  #    sk[,k] <- exp( muk )*mk[,k]
      
    }
    mr <- apply( mk, 1, quantile, c(.5, .05, .95) )
 #   qr <- apply( sqrt(rk), 1, quantile, c(.5, .05, .95) )
    sr <- apply( sqrt(sk), 1, quantile, c(.5, .05, .95) )
    
    
 #   qr <- sqrt(apply( rk, 1, quantile, c(.5, .05, .95) ))
    sr <- sqrt(apply( sk, 1, quantile, c(.5, .05, .95) ))
    
    
    plot(NULL, xlim=xlim,ylim=c(0,1),xlab='',
         ylab='')
    wp <- match(as.character(pspec),plots)
    
    fj <- mspec
    wj <- which(fj < .001 | fj > .999)
    fj[wj] <- jitter(fj[wj],.15)
    points(dspec,fj, pch=16, col='white', cex=1)
    points(dspec,fj, pch=16, col=.getColor(plotCol[wp],.4),
           cex=.7)
    
    .shadeInterval( dspec[ttt], t(mr[2:3,]) , col=
                      .getColor('tan', .1) )
    lines(dspec[ttt], mr[1,], col='white', lwd=5)
    lines(dspec[ttt], mr[1,], col='brown', lwd=2)
    

    jplot <- plots[plots %in% pspec]
    legend('bottomright',jplot,text.col=plotCol[jplot],bty='n')
    
    if(j == 1)title('Maturation')
    
    pspec <- tspec$plot[tspec$species == specNames[j]]
    fspec <- fecPred[obsRows,]
    wfp   <- which(fspec$species == specNames[j])
    fspec <- fspec$fecEstMu[wfp]*fspec$matrEst[wfp]
    pspec <- as.character(pspec)
    pall  <- sort(unique(pspec))
    
    plot(NULL, xlim=xlim, ylim=range(at), xlab='', ylab='', yaxt='n')
    axis(2, at = at, labels = labs)
    
    .shadeInterval( dspec[ttt], t(sr[2:3,]) , col=
                      .getColor('tan', .01) )
    
    wp <- match(as.character(pspec),plots)
    points(dspec,sqrt(fspec), pch=16, col='white', cex=1)
    points(dspec,sqrt(fspec), pch=16, col=.getColor(plotCol[wp],.4),
           cex=.7)
    
    lines(dspec[ttt], sr[1,], col='white', lwd=6)
    lines(dspec[ttt], sr[1,], lwd=2)
    
    if(nspec > 1).plotLabel(specNames[j])
    if(j == 1)title('Fecundity')
  }
  mtext('Diameter (cm)', side=1, line=0, outer=T)
  mtext('Probability', side=2, line=0, outer=T)
  
  if(CONSOLE)
    readline('maturation, fecundity by diameter -- return to continue ')
  if(SAVEPLOTS)dev.off( )
  
  if(is.null(RMD)){
    graphics.off()
  }else{
    words <- paste( 'Predictive distribution for maturation, fecundity from posterior (shaded intervals) and latent states (dots) ' )
    message( words )
    caption <- c(caption, words)
  }
  
  ############ dispersal
  
  udat <- ugibbs[burnin:ng,,drop=F]
  
    cols <- specCol[specNames]
  
  upars <- parameters$upars
  
  
  if(ncol(udat) > 1){
    
    if( is.null(rownames(upars)) )rownames(upars) <- 'mean'
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'dispersalCoeffs.pdf') )
    
    ncc <- ncol(udat)
    sideMar <- min( c(3, 3 + 10/ncc) )
    
    par(mfrow=c(1,1), mar=c(3,5,5,4), bty='n', oma=c(2,sideMar,1,sideMar))
    
    ylim <- range(udat)
    ylim[1] <- .75*ylim[1]
    ylim[2] <- 1.25*ylim[2]
    
    ylab1 <- expression( paste(hat(u),' (', plain(m)^2, ')') )
    ylab2 <- expression( paste('Kernel mean ', bar(d), ' (m)') )
    
    tmp <- .boxplotQuant( udat, xaxt='n', add = F, xlim = NULL, 
                          ylab=ylab1, ylim = ylim, boxwex=.6,
                          outline=F, col=.getColor(cols,.3), 
                          border=cols, xaxt='n',lty=1, boxfill=NULL )
    abline(h=upars['mean',3:4], lty=2, lwd=2, col='grey')
    .boxCoeffsLabs( tmp, names(cols), cols, cex=.8)
    
    rr <- range( pi*sqrt(udat)/2 )
    rm <- -1
    by <- 10
    if(diff(rr) < 20){
      by <- 5
      rm <- 0
    }
    if(diff(rr) < 10){
      by <- 2
      rr[1] <- rr[1] - 1
      rr[2] <- rr[2] + 1
    }
    
    rr <- round(rr, rm)
    rr <- seq(rr[1],rr[2], by=by)
    
    axis(4, at = (2*rr/pi)^2, labels = rr )
    mtext(ylab2, 4, line=0, outer=T)
    abline(v=par('usr')[1:2])
    
    if(CONSOLE)
      readline('dispersal by group -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- paste( 'Posterior estimates for dispersal parameters' )
      message( words )
      caption <- c(caption, words)
    }
  }
  
  if(is.null(RMD)) graphics.off()
  
  if(SAVEPLOTS)pdf( file=.outFile(outFolder,'seedShadow.pdf') )
  
  par(mfrow=c(1,1), bty='n')
  
  xfec  <- data$setupData$xfec
  
  qd     <- .75
  
  dcol   <- grep('diam',colnames(xfec))
  
  diam60 <- xfec[,dcol]
  diam60 <- diam60[diam60 != 0]
  diam60 <- quantile(diam60, qd)
  
  dtcol <- grep('diam',colnames(tdata))
  lab60 <- tdata[,dtcol]
  lab60 <- lab60[lab60 != 0]
  lab60 <- quantile(lab60, qd)
  lab60 <- signif(lab60,1)
  
  # each group at mean for other predictors
  xbar   <- numeric(0)
  rnames <- character(0)
  ucol   <- numeric(0)
  
  for(j in 1:nspec){
    
    wj   <- which(tdata$species == specNames[j])
    xmu  <- colMeans(xfec[drop=F,wj,])
    
    w0 <- which(xmu != 0)       #insert diameter value
    w0 <- intersect(w0, dcol)
    xmu[w0] <- diam60
    
    xbar <- rbind(xbar, xmu)
    rnames <- c(rnames, specNames[j])
  }
  
  rownames(xbar) <- rnames
  
  nsim <- 2000
  ns  <- 100
  buffer <- 15
  
  
  dpars <- parameters$dpars
  
  mm <- 6*max(dpars)
  if(nspec > 1)mm <- 6*max(dpars['mean',])
  
  dseq <- 10^seq(0,log10(mm),length=ns) - 1
  dseq <- matrix( dseq, ns, nsim)
  
  
  ij <- sample(burnin:ng, nsim, replace=T)
  
  
  ssList <- numeric(0)
  maxy   <- 0
  
  bf <- bfecStnd[ij,colnames(xbar)]
  
  if(RANDOM){
    br <- rmvnormRcpp(nrow(bf), aMu[1,]*0, aMu)
    colnames(br) <- colnames(aMu)
 #   br <- br[colnames(aMu) %in% bcols]
    bf[,colnames(br)] <- bf[,colnames(br)] + br
  }
  ff <-  bf%*%t(xbar)
  
#  ff[ff > log(maxFec)] <- log(maxFec)
  maxy <- numeric(0)
  
  kss <- 1:(ns-buffer)
  keepSeq <- c(rev(kss), kss) 
  dss  <- c(-rev(dseq[kss,1]),dseq[kss,1])
  
  for(k in 1:nspec){
    
    uj <- ugibbs[ij,k]
    sj <- sgibbs[ij,'sigma']
    
    kj <- uj/pi/(uj + dseq^2)^2
    kj <- kj*matrix(exp(ff[,k] + sj/2), ns, nsim, byrow=T)
    kj[!is.finite(kj)] <- NA
    qj <- t( apply(kj, 1, quantile, c(.5, .05, .95), na.rm=T ) )
    
    for(m in 1:3)qj[,m] <- runmed(qj[,m], k = buffer, endrule='constant')
    maxy <- c(maxy, max( qj[,1] ))
    
    ssList <- append(ssList, list( qj[keepSeq,] ) )
  }
  
  maxy[maxy > 1e+10] <- 1e+10
  maxy[maxy < 1e-10] <- 1e-10
  names(ssList) <- rownames(xbar)
  
  par(bty='n', mar=c(5,5,1,1))
  
  labSeeds <- expression( paste('Seeds (', plain(m)^-2, ')') )
  
  if(nspec > 1){
    rmax <- diff( range(log10(maxy)) )
  }else{
    rmax <- log10(maxy)
  }
  SQRT <- F
  if( rmax > 3 ){
    SQRT <- T
    smax <- sqrt(max(maxy))
    plot(NULL, xlim=range(dss), ylim=c(0,smax),
         xlab='Distance (m)', ylab = labSeeds, yaxt='n')
    tt   <- sqrtSeq(1.2*smax)
    at   <- tt$at
    labs <- tt$labs
    axis(2, at = at, labels = labs)
    
  }else{
    plot(NULL, xlim=range(dss), ylim=c(0,1.2*max(maxy)),
         xlab='Distance (m)', ylab = labSeeds)
  }
  
  for(k in 1:length(ssList)){
    if(maxy[k] <= 1e-10 | maxy[k] >= 1e+10)next
    ss <- ssList[[k]][,2:3]
    
    if(SQRT)ss <- sqrt(ss)
    .shadeInterval( dss, ss , col=
                      .getColor(cols[names(cols)[k]], .2) )
  }
  mc <- numeric(0)
  for(k in 1:length(ssList)){
    ss <- ssList[[k]][,1]
    if( max(ss,na.rm=T) >= 1e+10)next
    if(SQRT)ss <- sqrt(ss)
    lines(dss, ss, col='white',lwd=6)
    lines(dss, ss, col=cols[names(cols)[k]], lwd=2)
    mc <- c(mc, max(ssList[[k]][,1]))
  }
  
  if(nspec > 1){
    ord <- order(mc, decreasing=T)
    legend('topright',names(cols)[ord],
           text.col=cols[names(cols)[ord]], bty='n')
  }
  legend('topleft', paste(lab60,' cm diameter tree',sep=''), bty='n')
  
  if(CONSOLE)
    readline('seed shadow -- return to continue ')
  if(SAVEPLOTS)dev.off( )
  
  if(is.null(RMD)){
    graphics.off()
  }else{
    words <- paste( 'Seed shadow predictions for a ', lab60,' cm diameter tree',sep='')
    message( words )
    caption <- c(caption, words)
  }
  
  ########### random coefficients
  
  if(RANDOM){
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'randomCoeffs.pdf') )
    
    xrandCols  <- output$data$setupRandom$xrandCols
    formulaRan <- output$data$setupRandom$formulaRan
    
    betaFec <- output$parameters$betaFec[,1, drop=F]
    names(xrandCols) <- rownames(output$parameters$betaFec)[xrandCols]
    alphaUMu <- parameters$alphaUMu
    intercept <- paste('species',specNames,sep='')
    if(nspec == 1)intercept <- '(Intercept)'
    slopes    <- names(xrandCols)[!names(xrandCols) %in% intercept]
    
    npp <- length(slopes)/length(intercept)
    
    npp <- 1
    
    mfrow <- c(1,1)
    if(npp > 1)mfrow <- c(2,2)
    
    par(mfrow=mfrow, bty='n', mar=c(4,4,1,1), cex=1.2)
    
    icol <- match(intercept, colnames(alphaMu))
    icol <- icol[is.finite(icol)]
    intercept <- intercept[is.finite(icol)]
    
    xlim <- range(betaFec[icol,] + alphaMu[,icol])
    
    if(length(slopes) == 0){
      
      rlim <- range(alphaUMu)
      breaks <- seq(rlim[1]-.1, rlim[2]+.1,length=20)
      hvals <- xvals <- numeric(0)
      for(s in 1:length(specNames)){
        ra <- alphaUMu[,icol[s]]
        ra <- ra[ra != 0]
        tmp <- hist(ra, plot=F, breaks = breaks)
        hvals <- cbind(hvals,tmp$density)
        xvals <- cbind(xvals,tmp$mids)
      }
      ylim <- range(hvals, na.rm=T)
      xl <- range(betaFec[colnames(alphaUMu),1],na.rm=T) + range(rlim, na.rm=T)
      xl[1] <- xl[1] - 1
      xl[2] <- xl[2] + 1
      
      plot(NA,xlim=xl,ylim = ylim, xlab='log fecundity (fixed plus random)', ylab='frequency')
      for(s in 1:length(specNames)){
        ws <- range( which(hvals[,s] > 0) )
        ss <- ws[1]:ws[2]
        xs <- betaFec[icol[s],1] + xvals[ss,1]
        xs <- c(xs[1],xs,xs[length(xs)])
        ys <- c(0, hvals[ss,s], 0)
        lines( xs, ys,type='s',col=specCol[s], lwd=2)
        lines( xs, xs*0,col=specCol[s], lwd=2)
      }
    }else{
      
      ww <- grep(':', slopes)
      
      if(length(ww) > 0){
        slopeLab <- columnSplit(slopes, ':')[,2]
     #   slopeLab  <- matrix( unlist( strsplit( slopes, ':')), ncol=2,byrow=T)[,2]
      }else{
        slopeLab <- slopes
      }
      jcol <- match(slopes, colnames(alphaMu))
      ylim <- range(betaFec[jcol,1] + alphaMu[,jcol])
      
      if(length(icol) == 1)jcol <- jcol[1]
      
      slab <- unique(slopeLab)
      jcol <- jcol[slopeLab == slab[1]]
      
      plot(betaFec[icol,1],betaFec[jcol,1],col=.getColor(specCol,.7), 
           xlim=xlim, ylim=ylim, cex=.8, xlab='Intercept',ylab=slopeLab[1])
      abline(h = 0, lwd=2, lty=2, col='grey')
      abline(v = 0, lwd=2, lty=2, col='grey')
      
      for(s in 1:length(specNames)){
        points(betaFec[icol[s],1] + alphaMu[,icol[s]],
               betaFec[jcol[s],1] + alphaMu[,jcol[s]],
               col=.getColor(specCol[s],.3), pch=16, cex=1)
      }
    }
    legend('topright', specNames, text.col = specCol,bty='n')
    
    if(CONSOLE)
      readline('fixed plus random effects -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'Posterior estimates of fixed plus random effects'
      message( words )
      caption <- c(caption, words)
    }
  }
  
  ########### predicted seed counts, true fecundity
  
  if(SAVEPLOTS)pdf( file=.outFile(outFolder,'seedPrediction.pdf') )
  
  obsRowSeed <- inputs$obsRowSeed
  
  xs <- rowSums(sdata[obsRowSeed,seedNames,drop=F])
  pcols <- grep('predMean',colnames(seedPred))      # by seed trap
  ecols <- grep('estMean',colnames(seedPred))
  
  ys <- seedPred[,pcols]
  zs <- seedPred[,ecols]
  
  ww <- which(is.finite(xs))
  xs <- xs[ww]
  ys <- ys[ww]
  zs <- zs[ww]
  
  ylim <- quantile(c(ys, zs), c(0,.98),na.rm=T)
  xlim <- range(xs,na.rm=T) + 1
  
  mfrow <- c(1,2)
  title <- 'a) From posterior distribution'
  
  if(TV)mfrow <- c(2,2)
  if(SEEDCENSOR)mfrow <- c(2,2)
  
  par(mfrow=mfrow, mar=c(4,4,2,1), bty='l')
  
  bins <- getBins(xs, nbin=10, pow=.4)
  nbin <- length(bins)
  
  opt <- list(log=F, xlabel='Observed', bins = bins,
              nbin=nbin, ylabel='Predicted', col='forestgreen', 
              ylimit = ylim, xlimit = xlim, SQRT=T)
  tmp <- .plotObsPred(xs, ys, opt = opt)
  .plotLabel(title, above=T, cex=1)
  abline(0, 1, lwd=2, col='white')
  abline(0,1,lty=2)
  if(SEEDCENSOR){
    cs <- sqrt(seedPred[rownames(censMin),pcols])
    xl <- rowSums(censMin[,-1, drop=F])
    xh <- rowSums(censMax[,-1, drop=F])
    xh[xh > xlim[2]] <- xlim[2]
    opt <- list(log=F, xlabel='Censored interval', bins = bins,
                nbin=nbin, ylabel=' ', col='white', ptcol='white',
                ylimit = ylim, xlimit = xlim, SQRT=T)
    tmp <- .plotObsPred(xs, ys, opt = opt)
    segments(xl, cs, xh, cs, col=.getColor('black',.1))
    abline(0, 1, lwd=2, col='white')
    abline(0,1,lty=2)
    .plotLabel('b) Censored observations', above=T, cex=1)
  }
  
  lab <- 'b) From fecundity estimate'
  if(SEEDCENSOR)lab <- 'c) From fecundity estimate'
    
  opt <- list(log=F, xlabel='Observed', bins = bins, atx = tmp$atx, labx = tmp$labx,
              aty = tmp$aty, laby = tmp$laby,
              ylabel='', col='forestgreen', ylimit=ylim, xlimit = xlim,
              nbin=nbin, SQRT=T)
  tmp <- .plotObsPred(xs, zs, opt = opt)
  .plotLabel(lab, above=T, cex=.8)
  abline(0, 1, lwd=2, col='white')
  abline(0,1,lty=2)
  
  cwords <- 'prediction'

  if(SEEDCENSOR){
    cs <- sqrt(seedPred[rownames(censMin),ecols])
    xl <- rowSums(censMin[,-1, drop=F])
    xh <- rowSums(censMax[,-1, drop=F])
    xh[xh > xlim[2]] <- xlim[2]
    opt <- list(log=F, xlabel='Censored interval', bins = bins,
                nbin=nbin, ylabel=' ', col='white', ptcol='white',
                ylimit = ylim, xlimit = xlim, SQRT=T)
    tmp <- .plotObsPred(xs, ys, opt = opt)
    segments(xl, cs, xh, cs, col=.getColor('black',.1))
    .plotLabel('d) Censored from fecundity estimate', above=T, cex=.9)
    abline(0, 1, lwd=2, col='white')
    abline(0,1,lty=2)
  }
  
  if(TV){
    
    ford <- as.character(tdata$plotTreeYr)
    
    xs <- inputs$trueValues$fec[ford]
    ys <- prediction$fecPred$fecEstMu
    ylim <- quantile(ys[ys > 1],c(.02,1))
    ylim[1] <- max(c(ylim[1],1))
    
    ws <- which(xs > 0 & ys > 0)
    xlim <- quantile(xs[ws],c(.02,.99))
    
    bins <- getBins(xs, pow = .2)
    nbin <- length(bins)
    
    opt <- list(xlimit = xlim, ylimit = ylim, bins = bins,
                nbin=nbin, log=F, xlabel='True values', 
                ylabel='Estimates', col='darkgreen', SQRT=T)
    .plotObsPred(xs, ys, opt = opt)
    .plotLabel('c) Fecundity prediction', above=T, cex=.8)
    abline(0, 1, lwd=2, col='white')
    abline(0,1,lty=2)
    
    xs <- inputs$trueValues$repr[ford]
    ys <- prediction$fecPred$matrEst
    
    tmp <- boxplot( ys ~ xs, plot=F)
    
    ss  <- apply( fecPred[,8:9], 2, quantile, pnorm(c(-1.96,-1,0,1,1.96)), na.rm=T ) 
    qs <- unlist( by(ys, INDICES=xs, FUN=quantile, 
                     pnorm(c(-1.96,-1,0,1,1.96))) )
    tmp$stats <- matrix(qs, 5, 2)
    bxp(tmp, add = F, yaxt = 'n',  varwidth=T, xlab='True values',
        ylim=c(0,1), ylab='', boxwex=.5,
        outline=F, col=.getColor('black', .2), 
        border='black', lty=1, boxfill=NULL)
    axis(2, at=c(0,1))
    .plotLabel('d) Maturation prediction', above=T, cex=.8)
  }
  
  if(CONSOLE)
    readline( paste(cwords, '-- return to continue') )
  if(SAVEPLOTS)dev.off( )
  
  if(is.null(RMD)){
    graphics.off()
  }else{
    words <- 'Prediction from the posterior distribition'
    message( words )
    caption <- c(caption, words)
  }
  
  # true parameter values
  
  if(TV){
    
    brepTrue <- inputs$trueValues$betaRep
    bfecTrue <- inputs$trueValues$betaFec
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'trueParameters.pdf') )
    
    par(mfrow=c(2,1),bty='n', mar=c(3,3,3,4), oma=c(2,2,1,1))
    betaFec <- as.matrix(output$parameters$betaFec[,1:4])
    betaRep <- as.matrix(output$parameters$betaRep[,1:4])
    
    sc  <- grep('diam',rownames(betaRep))
    col <- rep('black', nrow(betaRep))
    col[-sc] <- 'gray'
    slp <- c(mean(inputs$trueValues$betaRep[sc,1]), mean(betaRep[sc,1]) )
    
  #  bfstand <- xfecu2s%*%betaFec[,1]
  #  bftrue  <- xfecu2s%*%inputs$trueValues$betaFec
    
    plot( brepTrue, betaRep[,1], ylim = range(betaRep), xlab='', 
          ylab=' ', pch=3, col = col)
    abline(0, 1, lwd=2, lty=2, col=.getColor('black',.4))
    suppressWarnings(
      arrows( inputs$trueValues$betaRep, betaRep[,3], 
              inputs$trueValues$betaRep, betaRep[,4], lwd=2,
              angle=90, length=.05, col=col, code=3)
    )
    text(slp[1],slp[2], 'Slopes', pos=2)
    .plotLabel('a) Maturation parameters', above=T, cex=1)
    
    
    sc  <- grep('diam',rownames(betaFec))
    col <- rep('black', length(betaFec))
    col[-sc] <- 'gray'
    slp <- c(mean(inputs$trueValues$betaFec[sc,1]), mean(betaFec[sc,1]) )
    
    plot( bfecTrue, betaFec[,1], ylim=range(betaFec), 
          xlab='', ylab='', pch=3, col=col)
    abline(0,1, lwd=2, lty=2, col=.getColor('black',.4))
    suppressWarnings(
      arrows( inputs$trueValues$betaFec, betaFec[,3], 
              inputs$trueValues$betaFec, betaFec[,4], lwd=2,
              angle=90, length=.05, code=3, col=col)
    )
    text(slp[1],slp[2], 'Slopes', pos=2)
    .plotLabel('b) Fecundity parameters', above=T, cex=1)
    mtext('True values', side=1, line=0, outer=T)
    mtext('Estimates', side=2, line=0, outer=T)
    
    if(CONSOLE)
      readline('parameter recovery -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'Posterior estimates compared with true values'
      message( words )
      caption <- c(caption, words)
    }

  }
  
  ############# predicted maps
  
  if(MAPS){
    
    treeSymbol <- output$prediction$fecPred$fecEstMu
    if(is.null(treeSymbol))treeSymbol <- treeData$diam
    
    if(is.null(RMD)) graphics.off()
    
    mpp <- 1:length(plots)
    
    plotDims <- as.matrix(plotDims)
    
    for(m in mpp){
      
      xlim <- plotDims[plots[m],c('xmin','xmax')]
      ylim <- plotDims[plots[m],c('ymin','ymax')]
      
      dx <- diff(xlim)
      dy <- diff(ylim)
      ratio <- dx/dy
      
      pyr <- plotYrTable[plots[m],]
      pyr <- as.numeric( colnames(plotYrTable)[pyr > 0] )
      
      mfrow <- c(2, 2)
      if( max(c(dx,dy)) > 100){
        if(ratio > 2) mfrow <- c(2,1)
        if(ratio < .5)mfrow <- c(1,2)
      }
      
      if(!is.null(RMD))mfrow <- c(1,1)
      
      nperPage <- prod(mfrow)
      
      yrm <- years[years %in% pyr]
      ny  <- length(yrm)
      
      k   <- 0
      add <- F
      o   <- 1:nperPage
      o   <- o[o <= nyr]
      
      seedMax <- as.matrix( sdata[sdata$plot == plots[m] & sdata$year %in% yrm ,seedNames] )
      if(is.matrix(seedMax)){
        if(nrow(seedMax) == 0){
          seedMax <- rbind(seedMax,0)
        }
        seedMax <- rowSums(seedMax, na.rm=T)
      }
      
      seedMax <- max(seedMax, na.rm=T) + 1
      
      while( max(o) <=  nyr & length(o) > 0 ){
        
        if(length(o) < 5 & is.null(RMD))mfrow <- c(2,2)
        
        yr <- yrm[o]
        yr <- yr[is.finite(yr)]
        if(length(yr) == 0)break
        
        if(is.null(RMD)) graphics.off()
        
        file <- paste('map_',plots[m],'_',yr[1],'.pdf',sep='')
        
        if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
        
        mapList <- output
        mapList$treeSymbol <- treeSymbol
        mapList$mapPlot <- plots[m]
        mapList$xlim <- xlim
        mapList$ylim <- ylim
        mapList$PREDICT <- T
        mapList$mapYears <- yr
        mapList$treeScale <- 1.3
        mapList$trapScale <- 1
        mapList$mfrow <- mfrow
        mapList$seedMax <- seedMax
        mapList$plotScale <- 1
        mapList$COLORSCALE <- F
        mapList$LEGEND <- T
        mapList$RMD <- RMD
 
        add <- mastMap(mapList)
        
        if(add)scaleBar('m', value = 20, yadj=.07)
        
        if(CONSOLE)
          readline('predicted fecundity, seed data maps -- return to continue ')
        if(SAVEPLOTS)dev.off( )
        if(is.null(RMD)){
          graphics.off()
        }else{
          words <- paste('Prediction map for plot', plots[m],
                         'in year', yr)
          message( words )
          caption <- c(caption, words)
        }
        
        o <- o + nperPage
        o <- o[o <= nyr]
        
        if(length(o) == 0){
          break
        }
        
        if(!add)next
      }  
    }
  }
  
  ################# year effects
  
  if( 'betaYrMu' %in% names(parameters) ){
    
    if(is.null(RMD)) graphics.off()
    
    file <- paste('yearEffect.pdf',sep='')
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    
    #  YR <- T
    if('lagGroup' %in% names(inputs))AR <- T
    
    betaYrMu <- parameters$betaYrMu
    betaYrSe <- parameters$betaYrSe
    
    if(nrow(betaYrMu) == 1 & length(specNames) == 1)
      rownames(betaYrMu) <- rownames(betaYrSe) <- yeGr[1]
    
    if('betaYrRand' %in% names(parameters)){  #combine fixed and random
      
      betaYrRand   <- parameters$betaYrRand
      betaYrRandSE <- parameters$betaYrRandSE
      betaYrRandSE[is.na(betaYrRandSE)] <- 0
      bmu <- bsd <- betaYrRand*0
      
      if(!AR){
        ttab <- table( yeGr[yrIndex[,'group']], tdata$year )
      }else{
        ttab <- betaYrRand
      }
      ttab[ttab != 0] <- 1
      
      for(k in 1:nrow(betaYrRand)){
        bmu[k,] <- betaYrMu + betaYrRand[k,]
        bsd[k,] <- sqrt(betaYrSe^2 + betaYrRandSE[k,]^2)
        bmu[k,] <- bmu[k,]*ttab[rownames(betaYrRand)[k],]
        bsd[k,] <- bsd[k,]*ttab[rownames(betaYrRand)[k],]
      }
      betaYrMu <- bmu
      betaYrSe <- bsd
      betaYrSe[is.na(betaYrSe)] <- 0
    }
    
    
    if(AR){
      par(mfrow=c(1,2),bty='n', mar=c(5,4,2,1))
      xlab <- 'lag (yr)'
      yr <- c(1:plag)
      mr <- .5
    }
    
    
    xtt <- seq(1900,2100,by=5)                #reference xtick
    
    par(mfrow=c(1,1),bty='n', mar=c(4,4,2,5), mai=c(1,1,1,1.1))
    if(AR){
      yr <- xtick <- 1:plag
      xlab <- 'lag (yr)'
    }
    if(YR & !AR){
      yr <- xtick <- years
      xlab <- ''
      if(length(yr) > 10)xtick <- xtick[xtick %in% xtt]
    }
    mr  <- max(betaYrMu + betaYrSe, na.rm=T)
    
    
    ylim = c(-2*mr,mr)
    
    plot(NULL, xlim = range(yr), ylim = ylim, xlab = xlab, 
         ylab = 'log fecundity', xaxt='n')
    axis(1, xtick)
    abline(h = 0, lty=2, col='grey', lwd=2)
    #   abline(v = xtick, lty=2, col='grey', lwd=2)
    leg <- character(0); col <- numeric(0)
    
    if(!AR & !YR){
      loHi <- cbind( betaYrMu[1,] - 1*betaYrSe[1,],
                     betaYrMu[1,] + 1*betaYrSe[1,])
      .shadeInterval(yr,loHi,col='black',PLOT=T,add=T, trans = .3)
      lines(yr, betaYrMu[1,], col=.getColor('white',.7), lwd=5)
      lines(yr, betaYrMu[1,], col='grey', lwd=2)
    }
    col <- numeric(0)
    
    if(!is.null(betaYrRand)){
      betaYrRand   <- betaYrRand[drop=F,yeGr,]
      betaYrRandSE <- betaYrRandSE[drop=F,yeGr,]
    }
    
    for(j in 1:ngroup){
      nj <- yeGr[j]
      wj <- which(is.finite(betaYrMu[nj,]) & betaYrMu[nj,] != 0) 
      #   if(length(wj) < 3)next
      loHi <- cbind( betaYrMu[nj,wj] - 1*betaYrSe[nj,wj],
                     betaYrMu[nj,wj] + 1*betaYrSe[nj,wj])
      .shadeInterval(yr[wj],loHi,col=groupCol[nj],PLOT=T,add=T, trans = .3)
    }
    
    for(j in 1:ngroup){
      nj <- yeGr[j]
      wj <- which(is.finite(betaYrMu[nj,]) & betaYrMu[nj,] != 0) 
      #   if(length(wj) < 3)next
      lines(yr[wj], betaYrMu[nj,wj], col=.getColor('white',.7), lwd=5)
      lines(yr[wj], betaYrMu[nj,wj], col=groupCol[nj], lwd=2)
    }
    if(ngroup > 1)cornerLegend('topright', yeGr, text.col = groupCol[yeGr],
                               cex=.8, bty='n')
    if(AR){
      title('AR coefficients',adj=0, font.main=1, font.lab=1,
            cex.main=.9)
      
      if(CONSOLE)
        readline('lag effect groups -- return to continue ')
      if(SAVEPLOTS)dev.off()
      if(is.null(RMD)){
        graphics.off()
      }else{
        words <- 'Posterior estimates of lag effects, by random group'
        message( words )
        caption <- c(caption, words)
      }
      
      file <- paste('countByYr.pdf',sep='')
      if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    }
    
    if(YR)title('Year effects, +/- 1 se',adj=0, font.main=1, font.lab=1,
                cex.main=.9)
    
    s2p <- as.matrix( sdata[,seedNames] )
    nseed <- length(seedNames)
    
    if(!AR)par(new = T)
    ymax <- 2*max(sqrt(s2p), na.rm=T)
    plot(jitter(sdata[,'year']),sqrt( s2p[,1]), cex=.8, axes=F,
         xlab='Year', ylim=c(0,ymax), ylab=NA, pch=16, 
         col=.getColor('black',.3))
    if(nseed > 1){
      for(j in 2:nseed){
        points(jitter(sdata[,'year']),sqrt( s2p[,j]), cex=.6, 
               pch=16, col=.getColor('black',.3))
      }
    }
    ii <- match(sdata$year,years)
    ii <- rep(ii, ncol(s2p))
    jj <- rep(1, length=length(s2p))
    ssum <- .myBy(as.vector( sqrt(s2p) ), ii, jj, 
                  summat = matrix(0, length(years), 1), fun='sum')
    nsum <- .myBy(as.vector( s2p*0 + 1 ), ii, jj, 
                  summat = matrix(0, length(years), 1), fun='sum')
    
    sall <- ssum/nsum
    lines(years, sall, lwd=5, col='white')
    lines(years, sall, lwd=2, col='black')
    
    side <- 4
    if(AR)side <- 2
    
    at <- c(0:100)^2
    at <- at[at < ymax]
    
    axis( side = side, at=at, labels=at )
    mtext(side = side, line = 3, 'seed count')
    
    if(CONSOLE)
      readline('year effect groups -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'Posterior estimate of year effects, by random group'
      message( words )
      caption <- c(caption, words)
    }
    
    if('plotGroups' %in% names(yearEffect)){  # by region
      
      if(is.null(RMD)) graphics.off()
      
      file <- 'yearEffectByRegion.pdf'
      if(AR)file <- 'lagEffectByRegion.pdf'
      
      if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
      
      yeGr <- output$data$setupYear$yeGr
      if(is.null(yeGr))yeGr <- as.character(output$data$setupData$yeGr)
      region <- yearEffect$plotGroups
      spec   <- yearEffect$specGroups
      #   if(!'specGroups' %in% names(yearEffect))spec   <- character(0)
      #   if(!'plotGroups' %in% names(yearEffect))region <- character(0)
      
      wd <- grep('-',yeGr)
      if(length(wd) > 0){
        spec   <- columnSplit(yeGr,sep='-')[,1]
        region <- columnSplit(yeGr,sep='-')[,2]
      }else{
        if(length(spec) > 0)spec <- yeGr
        if(length(region) > 0)region <- yeGr
      }
      regs <- unique(region)
      nreg <- length(regs)
      
      if(nreg == 0){
        regs <- spec
        nreg <- length(spec)
      }
      
      par(mfrow=c(nreg,1), bty='n', mar=c(2,2,.1,2), oma=c(2,3,1,1))  
      
      for(k in 1:nreg){
        
        wk <- which(region == regs[k])
        
        plot(NULL, xlim = range(yr), ylim = c(-1,1), xlab = xlab, 
             ylab = '', xaxt='n',yaxt='n')
        if(k == nreg)axis(1, xtick)
        axis(2,c(-2,0,2))
        abline(h = 0, lty=2, col='grey', lwd=2)
        #   abline(v = xtick, lty=2, col='grey', lwd=2)
        
        wll <- numeric(0)
        
        for(j in wk){
          nj <- yeGr[j]
          wj <- which(is.finite(betaYrMu[nj,]) & betaYrMu[nj,] != 0)
          #     if(length(wj) < 3)next
          wll <- c(wll,j)
          loHi <- cbind( betaYrMu[nj,wj] - 1*betaYrSe[nj,wj],
                         betaYrMu[nj,wj] + 1*betaYrSe[nj,wj])
          .shadeInterval(yr[wj],loHi,col=groupCol[nj],PLOT=T,add=T, trans = .3)
        }
        
        for(j in wk){
          nj <- yeGr[j]
          wj <- which(is.finite(betaYrMu[nj,]) & betaYrMu[nj,] != 0)
          if(length(wj) < 3)next
          lines(yr[wj], betaYrMu[nj,wj], col=.getColor('white',.7), lwd=5)
          lines(yr[wj], betaYrMu[nj,wj], col=groupCol[nj], lwd=2)
        }
        legend('bottomleft', yeGr[wll], text.col = groupCol[yeGr[wll]],
               cex=1.2, bty='n')
        .plotLabel(region[j],'topleft')
        
        
        if(AR){
          mtext('Lag',side=1,line=1,outer=T)
        }else{
          mtext('Year',side=1,line=1,outer=T)
        }
        mtext('log fecundity',side=2,line=1,outer=T)
      }
      
      if(CONSOLE)
        readline('year effect groups -- return to continue ')
      if(SAVEPLOTS)dev.off( )
      if(is.null(RMD)){
        graphics.off()
      }else{
        words <- 'Posterior estimate of year effects, by group'
        message( words )
        caption <- c(caption, words)
      }
    }
  }
  
  ############# pacf
  
  nyy <- ceiling(nyr*.6)
  if(nyy > 10)nyy <- 10
  
  if(nyr > 3 & sum(pacfMat,na.rm=T) != 0){
    
    if(is.null(RMD)) graphics.off()
    
    file <- paste('pacf.pdf',sep='')
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    
    par(mfrow=c(1,2),bty='n', mar=c(3,2,1,.5), oma=c(2,3,1,1))
    
    mr  <- .9
    ylim <- range(pacfMat[,-1],na.rm=T)
    ylim <- range( c(ylim, pacsMat[-1]), na.rm=T )
    
    plot(NULL, xlim = c(1,nyy), ylim = ylim, xaxt = 'n',
         xlab = '', ylab = '')
    axis(1, at=c(1:nyy))
    abline(h = 0, lty=2, col='grey', lwd=2)
    leg <- character(0); col <- numeric(0)
    lag <- c(0:(nyr-1))
    
    if(yeGr[1] %in% specNames & specNames[1] %in% rownames(pacfMat)){
      pacfMat <- pacfMat[drop=F,specNames,]
      cols <- specCol[specNames]
      leg  <- specNames
    }else{
      cols <- groupCol
      leg <- rownames(pacfMat)
    }
    
    pacCol <- gfun(nrow(pacfMat))
    names(pacCol) <- rownames(pacfMat)
    
    for(j in 1:nrow(pacfMat)){
      
      wj <- which( is.finite(pacfMat[j,]))
      wj <- wj[-1]                   # omit lag zero
      nj <- length(wj)
      if(nj < 2)next
      
      ac <- pacfMat[j,wj]
      
      lines(lag[wj], ac, col=pacCol[j], lwd=2)
      loHi <- cbind( ac - 1.96*pacfSe[j,wj],
                     ac + 1.96*pacfSe[j,wj])
      .shadeInterval(lag[wj],loHi,col=pacCol[j],PLOT=T,add=T, 
                     trans = .2)
      
      up <- which(loHi[,1] > 0)
      up <- up[up > 1]
      points(lag[wj[up]],ac[up],cex=1.3,pch=16,col=.getColor(pacCol[j],.5))
      
      up <- up[up < 10]
      up <- paste0( up[up > 2], collapse=', ')
      ll <- rownames(pacfMat)[j]
      leg <- c(leg,ll)
      col <- c(col,j)
    }
    if(length(leg) > 1)legend('topright', leg, text.col = pacCol, 
                              bty='n', cex=.6)
    .plotLabel('a) log Fecundity', location='topleft',above=T, cex=.9)
    
    xlim <-  c(1,nyy)
    plot(NULL, xlim = xlim, ylim = ylim, xaxt = 'n', yaxt='n',
         xlab = '', ylab = '')
    axis(1, at=c(1:nyy))
    axis(2, labels=F)
    abline(h=0, lty=2,lwd=2, col='grey')
    leg <- character(0); col <- numeric(0)
    lag <- c(0:nyy)
    
    wj <- which(pacsMat != 0)
    nj <- length(wj)
    if(nj > 2){
      
      ac <- pacsMat[wj]
      lines(lag[wj], ac, col=1, lwd=2)
      segments( lag[wj], ac*0, lag[wj], ac)
    }
    .plotLabel('b) Seed counts', location='topleft', above=T, cex=.9)
    mtext('Lag (yr)', side=1, outer=T)
    mtext('PACF', side=2, outer=T, line=1)
    
    if(CONSOLE)
      readline('partial ACF -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'Partial ACF'
      message( words )
      caption <- c(caption, words)
    }
  }
  
  
  if('plotGroups' %in% names(yearEffect) & sum(pacfMat,na.rm=T) != 0){  
    # by species/plot
    
    file <- paste('yearEffectByGroup.pdf',sep='')
    
    if(is.null(RMD)) graphics.off()
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    
    
    mfrow <- .getPlotLayout(nspec)
    par(mfrow=mfrow$mfrow, bty='n', mar=c(1,1,1,1), oma=c(3,3,1,3))  
    
    preg <- columnSplit(rownames(pacfMat),'-')
    
    for(k in 1:nspec){
      
      wk <- which(preg[,1] == specNames[k])
      
      ylab <- xlab <- F
      if(k %in% mfrow$left)ylab=T
      if(k %in% mfrow$bottom)xlab=T
      
      plot(NULL, xlim = c(1,nyy), ylim = ylim, xaxt = 'n', yaxt='n',
           xlab = '', ylab = '')
      axis(1, at=c(1:nyy), labels=xlab)
      axis(2,labels=ylab)
      abline(h = 0, lty=2, col='grey', lwd=2)
      leg <- character(0); col <- numeric(0)
      lag <- c(0:(nyr-1))
      
      for(j in wk){
        wj <- which( is.finite(pacfMat[j,]))
        wj <- wj[-1]                   # omit lag zero
        nj <- length(wj)
        if(nj < 2)next
        
        ac <- pacfMat[j,wj]
        
        lines(lag[wj], ac, col=plotCol[preg[j,2]], lwd=2)
        loHi <- cbind( ac - 1.96*pacfSe[j,wj],
                       ac + 1.96*pacfSe[j,wj])
        .shadeInterval(lag[wj],loHi,col=plotCol[preg[j,2]],PLOT=T,add=T, 
                       trans = .4)
        
        up <- which(loHi[,1] > 0)
        up <- up[up > 1]
        points(lag[wj[up]],ac[up],cex=1.3,pch=16,
               col=.getColor(plotCol[preg[j,2]],.5))
        
        up <- up[up < 10]
        up <- paste0( up[up > 2], collapse=', ')
        ll <- rownames(pacfMat)[j]
        #    leg <- c(leg,ll)
        #    col <- c(col,j)
      }
      .plotLabel(specNames[k],'topright') 
    }
    if( nspec == prod(mfrow$mfrow) ){
      cornerLegend('bottomright',plots,bty='n',text.col=plotCol[plots], cex=.9)
    }else{
      plot(NULL, xlim=xlim, ylim=ylim, xlab='', ylab='', axes=F)
      legend('topleft',plots,bty='n',text.col=plotCol[plots], cex=1.2)
    }
    mtext('Lag (yr)',side=1,line=1,outer=T)
    mtext('PACF',side=2,line=1,outer=T)
    
    if(CONSOLE)
      readline('partial ACF -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'Partial ACF'
      message( words )
      caption <- c(caption, words)
    }
  }
  
  
  ############# eigenvalues AR
  
  if(AR){
    
    if(is.null(RMD)) graphics.off()
    
    file <- paste('eigenAR.pdf',sep='')
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    
    par(bty='n', mai=c(1,1,1,1),mar=c(5,5,1,1), mfrow=c(1,1))
    
    ename <-rownames(eigenMu)
    ename <- rep(ename,each=ncol(eigenMu))
    text.col <- rep(groupCol[yeGr],each=ncol(eigenMu))
    
    xlab <- expression( paste( plain(Re),' ',lambda ))
    ylab <- expression( paste( plain(Im),' ',lambda ))
    
    xseq <- seq(-1,1,length=100)
    yseq <- sqrt(1 - xseq^2)
    plot(eigenMu,xlim=c(-1.2,1.2),ylim=c(-1.1,1.1), 
         cex=.1,xlab=xlab,ylab=ylab)
    lines(xseq,yseq,lwd=2,col='grey',lt=2)
    lines(xseq,-yseq,lwd=2,col='grey',lt=2)
    lines(c(0,0),c(-1,1),col='grey',lt=2)
    lines(c(-1,1),c(0,0),col='grey',lt=2)
    text(Re(eigenMu),Im(eigenMu),ename, cex=.9, col=text.col)
    
    if(CONSOLE)
      readline('ACF eigenvalues -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'ACF eigenvalues'
      message( words )
      caption <- c(caption, words)
    }
  }
  
  ############# fecundity and seed prediction
  
  tyears <- years  <- sort(unique(sdata$year))
  tplots <- pplots <- sort(unique(as.character(sdata$plot)))
  if(AR)tyears <- sort(unique(tdata$year))
  
  if(PREDICT & length(inputs$predList$years) > 1){
    
    file <- paste('prediction.pdf',sep='')
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    
    pyears <- sort(unique(c(fecPred$year,seedPredGrid$year)))
    pplots <- sort(unique(as.character(seedPredGrid$plot)))
    tyears <- sort(unique(c(years,pyears,tyears)))
    tplots <- sort(unique(c(plots,pplots)))
    
    # prediction grid closest to traps
    
    pcol <- grep('meanM2',colnames(seedPredGrid))
    scol <- grep('seM2',colnames(seedPredGrid))
    
    kcol <- c("trapID","plot","year","trap","plotYr","plotyr",
              "drow","area","active")
    spred <- numeric(0)
    
    for(j in 1:length(pplots)){
      
      xyt <- xytrap[xytrap$plot == pplots[j],]
      
      sp <- seedPredGrid[seedPredGrid$plot == pplots[j],]
      so <- sdata[sdata$plot == pplots[j],]
      if(nrow(so) == 0)next
      sxy <- xyt[match(so$trapID,xyt$trapID),c('x','y')]
      
      spi <- as.character( columnPaste(sp$trapID,sp$year) )
      soo <- as.character( columnPaste(so$trapID,so$year) )
      spi <- match(soo,spi)
      wf  <- which(is.finite(spi))
      
      spp <- sp[spi[wf],pcol,drop=F]
      countPerM2 <- rowSums(so[wf,seedNames,drop=F])/so$area[wf]
      predPerM2  <- rowSums(spp)
      
      sall  <- cbind(so[wf,],spp,countPerM2,predPerM2)
      spred <- rbind(spred,sall)
    }
    
    #error by year
    rmse <- sqrt( (spred$countPerM2 - spred$predPerM2)^2 )
    aerr <- spred$countPerM2 - spred$predPerM2
    
    xlim <- range(spred$year,na.rm=T)
    
    maxMod <- NULL
    if(!is.null(modelYears))maxMod <- max(modelYears)
    
    pplots <- as.character(sort(unique(spred$plot)))
    
    mfrow <- .getPlotLayout(length(pplots))$mfrow
    opt <- list(log=F, xlabel='Year', POINTS=F, 
                ylabel='Residual', col='brown', add=T)
    
    par(mfrow=mfrow,bty='n', mar=c(3,3,1,1), oma=c(2,2,0,2))
    
    xseq <- c(0,2^c(0:15))[-2]
    
    ylabel <- expression( paste('Count (', plain(m)^-2,')') )
    zlabel <- expression( bar(y) %+-% plain(sd) )
    
    for(j in 1:length(pplots)){
      
      wj    <- which(spred$plot == pplots[j])
      obs   <- spred$year[wj]
      yMean <- spred$predPerM2[wj]
      yObs  <- spred$countPerM2[wj]
      
      if( max(yMean, na.rm=T) == 0 | length(yMean) < 3 )next
      
      tj <- by(yMean, obs, quantile, probs=pnorm(c(0,-1,1)), na.rm=T)
      cj <- names(tj)
      tj <- matrix( unlist(tj), ncol=3, byrow=T )
      rownames(tj) <- cj
      tj <- sqrt(tj)     
      ww <- which(is.finite(tj[,1]))
      yj <- as.numeric(rownames(tj))
      
      omu <- by(yObs, obs, quantile, probs=pnorm(c(0,-1,1)), na.rm=T)
      cj <- names(omu)
      oj <- matrix( unlist(omu), ncol=3, byrow=T )
      rownames(oj) <- cj
      oj <- sqrt(oj)     # not for residuals
      
      smax <- max( c(tj,oj,5) )
      tt   <- sqrtSeq(smax)
      at   <- tt$at
      labs <- tt$labs
      
      #  xlim <- range(obs,na.rm=T)
      ylim <- range(at)
      
      plot(NULL,xlim=xlim,ylim=ylim, ylab='', xlab='',yaxt='n')
      axis(2,at=at, labels = labs)
      
      if(!is.null(maxMod)){
        rect(maxMod+.5,ylim[1],xlim[2]+.5,ylim[2],col='wheat', border='wheat')
      }
      
      .shadeInterval(yj,loHi=tj[ww,2:3], col=.getColor('grey', .8))
      abline(h=0,lty=2,lwd=4,col='white')
      
      .shadeInterval(yj,loHi=oj[ww,2:3], col=.getColor('green', .3))
      
      lines(yj, tj[ww,1], col='white', lwd=8)
      lines(yj, tj[ww,1], lwd=3)
      lines(yj, oj[ww,1], col=.getColor('white',.5), lwd=8)
      lines(yj, oj[ww,1], col=.getColor('forestgreen',.7),lwd=3)
      
      points(jitter(obs),sqrt(yObs),pch=16,col=.getColor('forestgreen',.2))
      
      .plotLabel(tplots[j],'topleft')
    }
    mtext('Year',side=1,line=0,outer=T, cex=1.4)
    mtext(ylabel,side=2,line=0,outer=T, cex=1.4)
    mtext(zlabel,side=4,line=0,outer=T, cex=1.4)
    
    if(CONSOLE)
      readline('observed (green), predicted (black), shaded forecast (if modelYears) -- return to continue ')
    if(SAVEPLOTS)dev.off( )
    if(is.null(RMD)){
      graphics.off()
    }else{
      words <- 'Observed (green), predicted (black), shaded forecast (if modelYears)'
      message( words )
      caption <- c(caption, words)
    }
  }    
  
  yfun    <- colorRampPalette( c('tan', 'brown','turquoise','steelblue') )
  yearCol <- yfun(nyr)
  names(yearCol) <- tyears
  
  ########## tree correlations over years
  
  if(is.null(RMD)) graphics.off()
  
  file <- paste('treeCor.pdf',sep='')
  
  if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
  
  breaks <- seq(-1.1,1.1,by=.1)
  ylim <- c(0,5)
  nplot <- length(plots)
  
  ppt <- character(0)
  
  for(j in 1:nplot){
    
    wjk <- tdata$dcol[ tdata$plot == plots[j] ]
    njk <- length(unique(wjk))
    if(njk < 2)next
    ojk <- omegaE[wjk,wjk]
    ojk[is.na(ojk)] <- 0
    if(max(ojk) == 0)next
    
    ppt <- c(ppt,plots[j])
  }
  
  npp <- length(ppt)
  
  mfrow <- .getPlotLayout(npp)
  par(mfrow=mfrow$mfrow, mar=c(1,1,1,2), oma=c(3,3,1,1), bty='n')
  
  for(j in 1:npp){
    
    jk <- 0
    sk <- character(0)
    ek <- numeric(0)
    
    for(k in 1:nspec){
      
      wjk <- tdata$dcol[ tdata$species == specNames[k] &
                           tdata$plot == ppt[j] ]
      njk <- length(unique(wjk))
      if(njk < 2)next
      
      wjk <- sort(unique(wjk))
      ojk <- omegaE[wjk,wjk]
      
      ojk[is.na(ojk)] <- 0
      oj <- ojk
      diag(oj) <- 0
      rs <- which( rowSums(oj) == 0 )
      diag(oj) <- diag(ojk)
      if(length(rs) > 0)oj <- oj[-rs,-rs]
      
      oj[oj > .95] <- .95
      oj[oj < -.95] <- -.95
      
      diag(oj) <- 1
      
      if(length(oj) < 2)next
      jk <- jk + 1
      sk <- c(sk,specNames[k])
      
      oj <- oj[lower.tri(ojk)]
      ovec <- hist(oj, breaks = breaks, plot=F)$density
      
      tmp <- .getPoly(breaks[-1],ovec)
      if(jk == 1){
        plot(tmp[1,], tmp[2,],type='s',lwd=2,
             col=.getColor(specCol[specNames[k]],.3),
             xlab='', ylab='', ylim=ylim, xaxt='n', yaxt='n')
        axis(1, at=c(-1,0,1), labels=c(-1,0,1))
        axis(2, labels=T)
      }
      
      tmp <- .getPoly(breaks[-1],ovec)
      polygon( tmp[1,], tmp[2,], col=.getColor(specCol[specNames[k]],.3), lwd=2, 
               border=specCol[specNames[k]])
    }
    if(length(sk) == 0)next
    .plotLabel(ppt[j],'topleft')
    legend('topright',sk,text.col=specCol[sk],bty='n')
  }
  
  if(jk > 0){
    mtext('Correlation', side=1, outer=T, line=1)
    mtext('Density', side=2, outer=T, line=1)
  }
  
  if(CONSOLE)
    readline('tree correlation in time -- return to continue ')
  if(SAVEPLOTS)dev.off( )
  if(is.null(RMD)){
    graphics.off()
  }else{
    words <- 'Correlations between trees, over time'
    message( words )
    caption <- c(caption, words)
  }
  
  ################# spatio-temporal correlation
  
  if(SPACETIME){
    
    # trees/sites ordered by similarity at zero lag
    
    mvs <- suppressWarnings(
      meanVarianceScore(output, Q = pnorm(c(0, -1, 1)), nsim=1, LAGMAT = T,
                        ktree = 30, maxSite = 30, CLOSE = F)
    )
    
    treeCov <- mvs$lagCanopy
    trapCov <- mvs$lagGround
    nkk <- length(treeCov)
    plotk <- names(treeCov)
    
    if(is.null(RMD)) graphics.off()
    
    if(nkk > 0){
      
      col2 <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582",
                                 "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE",
                                 "#4393C3", "#2166AC", "#053061"))
      for(k in 1:nkk){
        
        wpt <- which(names(treeCov) == plotk[k])
        wpc <- which(names(trapCov) == plotk[k])
        
        if(length(wpt) == 0 | length(wpc) == 0)next
        
        tvar <- treeCov[[wpt]]
        cvar <- trapCov[[wpc]]
        
        if(length(tvar) < 2 | length(cvar) < 2) next
        
        tmp  <- columnSplit(colnames(tvar),'_')
        
        klag <- as.numeric(tmp[,ncol(tmp)])
        tvar[tvar < -1] <- 0
        tvar[tvar > 1] <- 0
        
        if(nrow(tvar) < 2)next
        
        km <- max(klag)
        if(km > 5)km <- 5
        
        
        file <- paste('spaceTime',plotk[k],'.pdf',sep='')
        if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
        
        
        par(mfrow=c(2,km+1), mar=c(2,1,1,1), oma=c(2,1,2,1), bty='n',xpd=T)
        
        order  <- 'hclust'
        
        for(i in 0:km){
          
          wl <- which(klag == i)
          stree <- tvar[,wl]
          
          if(i > 0){
            order <- 'original'
            colnames(stree) <- rownames(stree)
            stree <- stree[rnames,rnames]
          }
          
          tmp <- corrplot(stree, is.corr=T, method='color', col=rev(col2(200)),
                          tl.pos='n', cl.length=3, cl.lim=c(-1,1), type='lower',
                          order=order, cl.pos='n')
          rnames <- rownames(tmp)
          tlab <- paste('lag',i)
          title(main = list(tlab, cex = 1.5,
                            font = 1), line = -2, adj=1)
          if(i == 0)title(main = list("Canopy", cex = 1.5,
                                      font = 3))
        }
        
        
        tmp  <- columnSplit(colnames(cvar),'_')
        klag <- as.numeric(tmp[,ncol(tmp)])
        cvar[cvar < -1] <- 0
        cvar[cvar > 1] <- 0
        
        order  <- 'hclust'
        
        for(i in 0:km){
          wl <- which(klag == i)
          if(length(wl) == 0)next
          stree <- cvar[,wl]
          
          if(ncol(stree) < nrow(stree)){
            sc <- columnSplit(colnames(stree),'_')[,1]
            w0 <- which(!rownames(stree) %in% sc)
            c1 <- c(1:(w0-1))
            c2 <- c((w0+1):ncol(stree))
            c1 <- c1[c1 > 0]
            c2 <- c2[c2 < nrow(stree) & c2 > w0]
            stree <- cbind( stree[,c1], 0, stree[,c2] )
            colnames(stree)[w0] <- paste(rownames(stree)[w0],i,sep='_')
          }
          
          if(i > 0){
            order <- 'original'
            colnames(stree) <- rownames(stree)
            stree <- stree[rnames,rnames]
          }
          
          tmp <- corrplot(stree, is.corr=T, method='color', col=rev(col2(200)),
                          tl.pos='n', cl.length=3, cl.lim=c(-1,1), type='lower',
                          cl.pos='n')
          rnames <- rownames(tmp)
          if(i == 0)title(main = list("Forest floor", cex = 1.5,
                                      font = 3))
        }
        mtext(plotk[k], 1, outer=T, line=0)
        
        
        if(CONSOLE)
          readline('tree-time (above), space-time (below) -- return to continue ')
        if(SAVEPLOTS)dev.off()
        if(is.null(RMD)){
          graphics.off()
        }else{
          words <- 'Tree-time (above), space-time (below)'
          message( words )
          caption <- c(caption, words)
        }
      }
    }
    
    ############## score by scale
    
    darea <- 100
    
    mvs <- suppressWarnings(
      meanVarianceScore(output, Q = pnorm(c(0, -1, 1)), ktree = 20, 
                        nsim=100, LAGMAT = T, CLOSE = T)
    )
    
    if(is.null(RMD)) graphics.off()
    
    
    scoreT <- scoreS <- scoreTse <- scoreSse <- numeric(0)
    pname  <- character(0)
    
    for(k in 1:length(plots)){
      
      wt <- which(names(mvs$scoreTree) == plots[k])
      ws <- which(names(mvs$scoreSeed) == plots[k])
      
      if(length(wt) == 0 | length(ws) == 0)next
      
      dtree <- mvs$scoreTree[[wt]]
      dseed <- mvs$scoreSeed[[ws]]
      dtreeSE <- mvs$scoreTreeSe[[wt]]
      dseedSE <- mvs$scoreSeedSe[[ws]]
      
      if(length(dtree) > 2 & length(dseed) > 2){
        scoreT <- append(scoreT, list(dtree))
        scoreS <- append(scoreS, list(dseed))
        scoreTse <- append(scoreTse, list(dtree))
        scoreSse <- append(scoreSse, list(dseed))
        
        pname  <- c(pname,plots[k])
      }
    }
    
    names(scoreT) <- names(scoreS) <- names(scoreTse) <- 
      names(scoreSse) <- pname
  
    
    pk <- names(scoreT)[k]
    dss <- scoreT
    ylab  <- 'Number of hosts'
    title <- 'Canopy'
    file  <- 'resourceScoreCanopy.pdf'
    carea <- 1
    q <- seq(0, 1, length=15)^1
    cols <- .getColor('black',q)
    
    npp <- length(scoreT)
    
    if(npp > 0){
      
      for(j in 1:2){
        
        if(j == 2){
          dss <- scoreS
          file <- 'resourceScoreGround.pdf'
          yy <- as.numeric(rownames(dk))
          ylab <- 'Distance (m)'
          title <- 'Forest floor'
        }
        
        zscale <- range(sapply(dss, range, na.rm=T))
        cseq   <- seq(zscale[1], zscale[2], length=30)
        
        xscale <- max(sapply(dss, ncol))
        yscale <- max(sapply(dss, nrow))
        if(yscale < 100)yscale <- 100
        if(j == 2 & yscale < 20)yscale <- 20
        
        xlim <- log(1 + c(0, xscale))
        ylim <- log(1 + c(0, yscale+10))
        
        if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
        
        mff <- .getPlotLayout(length(dss))
        
        par(mfrow=mff$mfrow, bty='l',mar=c(4,3,.1,.1), oma=c(4,4,1,1))
        
        for(k in 1:npp){
          
          dk <- dss[[k]]
          xx <- columnSplit(colnames(dk),'_')[,2]
          xx <- as.numeric(xx)
          yy <- c(1:nrow(dk))
          
          if(j == 2){
            aa <- as.numeric(rownames(dk))
            yy <- (pi*aa^2)/10000
          }
          
          levels <- quantile(dk, q )
          levels <- sort(unique(levels))
          
          ytick <- c(1, 5, c(1:5)*10 )
          lx <- log(xx + 1)
          ly <- log(yy + 1)
          ltick <- log(ytick + 1) 
          
          if(j == 1)ylim[1] <- ly[1]/2
          if(j == 2)ylim[1] <- diff(ly[1:2])/2
          
          plot(NA, axes = F, xlim=xlim, ylim=ylim, xlab='', ylab='')
          contour(lx, ly, t(dk), levels=levels, col=cols, labels='', add=T,
                  axes=F)
          .filled.contour(lx, ly, t(dk), levels=levels, col=cols)
          
          if(length(yy) > 10){
            #     yy <- c(0,yy)
            #     ly <- c(0,ly)
            bb <- ceiling(length(yy)/10)
            ss <- seq(1, length(yy), by=bb)
            ytick <- ytick[ss]
            ltick <- ltick[ss]
          }
          
          xlabs <- ylabs <- F
          
          if(k %in% mff$bottom)xlabs <- xx
          
          if(j == 2){
            ytick <- c(100, 1000, 10000, 50000, 100000)/10000
            ltick <- log(ytick + 1)
          }
          
          if(k %in% mff$left){
            ylabs <- ytick
            if(j == 2)ylabs <- c('100 m2', '1000 m2', '1 ha', '5 ha','10 ha')
          }
          
          axis(1, at=lx, labels=xlabs)
          axis(2, at=ltick, labels=ylabs)
          
          .plotLabel(names(dss)[k],'topright')
        }
        mtext('Years', 1, outer=T, line=1)
        mtext(ylab, 2, outer=T, line=1)
        
        endLabs <- signif(range(dk),1)
        
        clist <- list( kplot=1, ytick=NULL, text.col = 'black',
                       cols=cols, labside='right', text.col=col,
                       bg='grey', endLabels=endLabs) 
        cornerScale( clist )
        
        if(CONSOLE)
          readline('score by scale -- return to continue ')
        if(SAVEPLOTS)dev.off()
        if(is.null(RMD)){
          graphics.off()
        }else{
          words <- 'Score by scale'
          message( words )
          caption <- c(caption, words)
        }
      }
      
      # plot comparison
      
      nhost <- 5
      nhy   <- 2
      tmat  <- matrix(NA, npp, 3)
      colnames(tmat) <- c('mu','lo','hi')
      rownames(tmat) <- names(scoreT)
      smat <- tmat
      
      for(k in 1:npp){
        
        nn  <- nhost
        dkk <- scoreT[[k]]
        if(nn > nrow(dkk))nn <- nrow(dkk)
        skk <- scoreTse[[k]]
        mu  <- dkk[nn,nhy-1]
        ss  <- skk[nn,nhy-1]
        tmat[k,] <- c(mu, mu + ss*c(-1,1))
        
        nn  <- nhost
        dkk <- scoreS[[k]]
        if(nn > nrow(dkk))nn <- nrow(dkk)
        skk <- scoreSse[[k]]
        mu  <- dkk[nn,nhy-1]
        ss  <- skk[nn,nhy-1]
        smat[k,] <- c(mu, mu + ss*c(-1,1))
      }
      
      file <- 'scoreByPlot.pdf'
      if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
      
      par(mfrow=c(1,1), mar=c(4,4,2,2), bty='n',xpd=F)
      xlim <- range(tmat) + c(-.1,.2)
      ylim <- range(smat) + c(-.1,.2)
      
      ylab <- paste('Forest floor, ', nhost*darea,'m2')
      xlab <- paste('Canopy score,',nhost,'host trees')
      
      plot(NA, xlim=xlim, ylim=ylim, xlab=xlab,
           ylab = ylab)
      points(tmat[,1],smat[,1])
      segments(tmat[,1], smat[,2], tmat[,1], smat[,3])
      segments(tmat[,2], smat[,1], tmat[,3], smat[,1])
      text(tmat[,1]+.1, smat[,1]+.1,names(mvs$scoreTree), pos=4)
      abline(0,1,col='grey',lwd=2,lty=2)
      .plotLabel(paste(nhy,' yr'), 'bottomright')
      
      if(CONSOLE)
        readline('score by plot -- return to continue ')
      if(SAVEPLOTS)dev.off()
      if(is.null(RMD)){
        graphics.off()
      }else{
        words <- 'Score by plot'
        message( words )
        caption <- c(caption, words)
      }
      
    }
    
    ################ entropy
    
    entropy <- mvs$entropy
    
    if(!is.null(entropy)){
      
      if(nrow(entropy) > 4){
        
        if(is.null(RMD)) graphics.off()
        
        file <- 'entropy.pdf'
        if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
        
        par(mfrow=c(1,2), mar=c(4,4,1,.5), oma=c(1,1,1,1), bty='n',xpd=F)
        
        entropy[!is.finite(entropy)] <- NA
        
        xl <- range(entropy[,1], na.rm=T )
        dx <- .3*diff(xl)
        xl[2] <- xl[2] + dx
        yl <- range(entropy[,1])
        
        we <- grep('tree-tree',rownames(entropy))
        wr <- grep('site-site',rownames(entropy))
        rnames <- unlist( strsplit(rownames(entropy)[we],'_tree-tree') )
        
        xl <- range(entropy[we,1], na.rm=T ) + c(-1,1)
        dx <- .3*diff(xl)
        xl[2] <- xl[2] + dx
        yl <- range(entropy[wr,1], na.rm=T) + c(-1,1)
        
        
        plot(entropy[we,1],entropy[wr,1], xlim=xl, ylim=yl, xlab='', 
             ylab='Forest floor entropy', cex=.01, yaxt='n')
        axis(2, line=1)
        abline(0,1,lty=2)
        
        par(new=F,xpd=T)
        text(entropy[we,1],entropy[wr,1],rnames)
        mtext('Canopy entropy',1,outer=T,line=-1)
        .plotLabel('a) Spatial', above=T)
        
        we <- grep('tree-lag',rownames(entropy))
        wr <- grep('site-lag',rownames(entropy))
        rnames <- unlist( strsplit(rownames(entropy)[we],'_tree-lag') )
        
        xl <- range(entropy[we,1], na.rm=T ) + c(-1,1)
        dx <- .3*diff(xl)
        xl[2] <- xl[2] + dx
        yl <- range(entropy[wr,1], na.rm=T) + c(-1,1)
        
        plot(entropy[we,1],entropy[wr,1], xlim=xl, ylim=yl, xlab='', ylab='', 
             cex=.01, yaxt='n')
        axis(2, line=1)
        # abline(0,1,lty=2)
        
        par(new=F,xpd=T)
        text(entropy[we,1],entropy[wr,1],rnames)
        .plotLabel('b) Temporal', above=T)
        
        par(new=T,xpd=F)
        
        if(CONSOLE)
          readline('entropy -- return to continue ')
        if(SAVEPLOTS)dev.off()
        if(is.null(RMD)){
          graphics.off()
        }else{
          words <- 'Entropy'
          message( words )
          caption <- c(caption, words)
        }
      }
    }
  }
  invisible(caption)
}
 
corrLabs <- function(xvar, nsite=5){
  
  tname <- columnSplit(rownames(xvar),'-')[,2]
  tall  <- unique(tname)
  if(length(tall) > nsite){
    ttab <- table(tname)
    most <- names(ttab)[order(ttab,decreasing=T)]
    tall <- most[1:nsite]
  }
  ws   <- which(tname %in% tall)
  xvar <- xvar[ws,ws]
  
  ttmp  <- columnSplit(rownames(xvar),'-')
  tline <- which( diff(rev(as.numeric(ttmp[,3]))) != -1 )
  tname <- unique(ttmp[,2])
  
  vx <- rbind(ncol(xvar) - tline+.5, ncol(xvar) - tline+.5)
  vy <- rbind(.5, tline-.5)
  hx <- rbind(.5, ncol(xvar)-tline+.5)
  hy <- rbind(tline-.5, tline-.5)
  
  tx <- c(ncol(xvar),hx[2,])
  dx <- -diff(tx)/2
  dx <- c(dx,dx[length(dx)])
  tx <- tx - dx*.7
  ty <- c(vy[2,],ncol(xvar)) - dx*.4
  
  list(vx = vx, vy = vy, hx = hx, hy = hy, tx = tx, ty = ty,
       xvar = xvar, tname = tname, tline = tline)
}


t2tr <- function(TV, R){
  
  # TV = nT x nT tree-time covariance
  # R  = nT X R seed type matrix
  
  rvec <- matrix(t(R),ncol=1)
  
  RR <- crossprod(t(rvec))    # R x R blocks in RnT x RnT matrix
  
  ti <- rep(1:ncol(TV), each=ncol(R))
  TT <- TV[ti,]
  TT <- TT[,ti]
  TR <- TT*RR
  
}

getCvol <- function(Fmat, Smat, tree, seed, rCons){
  
  # rCons - species by seed preference or seed mass
  # nrep = 1, because x,y currently fixed
  # on a per-tree and per-location basis
  
  yr <- sort(unique(tree$year))
  
  Rvec <- rCons[tree$species,1]
  Fmat <- t( t(Fmat)*Rvec )
  
  # total
  
  Tv   <- cov(Fmat)
  w0    <- which(diag(Tv) == 0)
  if(length(w0) > 0){
    Fmat <- Fmat[,-w0]
    Tv <- cov(jitter(Fmat))
    tree <- tree[-w0,]
  }
  FF     <- mean(Fmat)
  entT   <- nrow(Tv)/2*(1 + log(2*pi)) + determinant(Tv)$modulus/2
  
  C   <- cov(Smat)
  w0  <- which(diag(C) == 0)
  if(length(w0) > 0){
    Smat <- Smat[,-w0]
    C <- cov(jitter(Smat))
    seed <- seed[-w0,]
  }
  M    <- mean(Smat)
  entC <- nrow(C)/2*(1 + log(2*pi)) + determinant(C)$modulus/2
  rownames(C) <- colnames(C) <- columnPaste(seed$trapID,seed$year)
  
  entT <- entT/nrow(Tv)
  entC <- entC/nrow(C)
  
  # per year
  
  ec <- et <- yri <- numeric(0)
  
  for(k in 1:length(yr)){
    
    wt <- which(tree$year == yr[k])
    ws <- which(seed$year == yr[k])
    
    if(length(wt) < 3 | length(ws) < 3)next
    
    Tk    <- cov(Fmat[,wt])
    w0    <- which(diag(Tk) == 0)
    if(length(w0) > 0)Tk <- Tk[-w0,-w0]
    entTk <- nrow(Tk)/2*(1 + log(2*pi)) + determinant(Tk)$modulus/2
    
    Ck    <- cov(Smat[,ws])
    w0    <- which(diag(Ck) == 0)
    if(length(w0) > 0)Ck <- Ck[-w0,-w0]
    entCk <- nrow(Ck)/2*(1 + log(2*pi)) + determinant(Ck)$modulus/2
    
    entCk <- entCk/nrow(Ck)    #per dimension
    entTk <- entTk/nrow(Tk)
    
    ec  <- c(ec,entCk)
    et  <- c(et,entTk)
    yri <- c(yri,yr[k])
  }
  
  eyr <- rbind(et,ec)
  colnames(eyr) <- yri

  ent <- cbind( rbind(sum(FF),sum(M)),rbind(entT,entC) , eyr)
  colnames(ent)[1:2] <- c('mean_seeds','E_per_dim')
  rownames(ent) <- c('T','C')
  
  list(Tvar = Tv, Cvar = C, ent = ent)
}

.getPoly <- function(x,y){
  dx <- diff(x)
  xx <- c(x[1] - dx[1]/2, x[-1] - dx/2)
  xx <- rep(xx,each=2)
  yy <- rep(y,each=2)
  yy <- c(0,yy,0)
  xx <- c(xx,xx[length(xx)],xx[length(xx)])
  rbind(xx,yy)
}


.chainPlot <- function(mat, burnin, label, ngLab = NULL, burnLab = NULL,
                       refVals = NULL, CONSOLE, RMD,
                       SAVEPLOTS=F, outFolder='', ylim = NULL){
  
  words <- character(0)
  
  if(is.null(ngLab))ngLab <- ng
  if(is.null(burnLab))burnLab <- burnin
  
  if(!is.null(refVals)){
    if(length(refVals) == 1 & ncol(mat) > 1)refVals <- rep(refVals, ncol(mat))
  }
  
  cseq <- 1:nrow(mat)
  if(length(cseq) > 2000)cseq <- round(seq(1,length(cseq),length=1000))
  
  if(SAVEPLOTS){
    fileName <- .replaceString(label,',','')
    fileName <- .replaceString(label,' ','')
    fileName <- paste(fileName,'.pdf',sep='')
    pdf( file=.outFile(outFolder,fileName) )
  }
  
  cnames <- .coeffNames( colnames(mat) )
  colnames(mat) <- cnames
  
  npp <- length(cnames)
  if(npp > 25)npp <- 25
  
  mfrow <- .getPlotLayout(npp)
  par(mfrow=mfrow$mfrow, bty='n', mar=c(2,2,2,2), oma=c(2,3,1,1)) 
  
  cex <- 1/(1 + mfrow$mfrow[2])^.1
  
  ng <- nrow(mat)
  
  cseq <- 1:ng
  burnline <- burnin
  ss   <- burnin:ng
  if(nrow(mat) > 1000){
    cseq <- seq(1,ng,length=1000)
    burnline <- burnin/ng*1000
    ss <- cseq[ cseq > burnin ]
  }
  
  NEWY <- F
  if(is.null(ylim))NEWY <- T
  
  naa <- 0
  
  for(j in 1:ncol(mat)){
    
    if(j %in% c(25, 50)){
      naa <- naa + 1
      if(CONSOLE){
        lab <- paste(label, ' -- return to continue')
        readline(lab)
      }
      if(SAVEPLOTS) {
        dev.off( )
      }
      if(!is.null(RMD)){
        words <- paste( 'MCMC chains for', label, 'with 95% coverage' )
        message( words )
      }
      if(SAVEPLOTS){
        fileName <- .replaceString(label,',','')
        fileName <- .replaceString(label,' ','')
        fileName <- paste(fileName,'_',letters[naa],'.pdf',sep='')
        pdf( file=.outFile(outFolder,fileName) )
      }
      npp <- ncol(mat) - j
      if(npp > 25)npp <- 25
      mfrow <- .getPlotLayout(npp)
      par(mfrow=mfrow$mfrow, bty='n', mar=c(2,2,2,2), oma=c(2,3,1,1)) 

    }
    
    xlabels <- F
    
    if(j %in% mfrow$bottom)xlabels <- T
    
    mj <- mat[,j]
    
    if(NEWY){
      ylim <- range(mj)
      if(!is.null(refVals) & NEWY){
        ylim <- range(c(refVals[j], mj))
        expd <- diff(ylim)
        ylim <- ylim + c(-1, 1)*.5*expd
      }
    }
    
    plot(mj[cseq], type='l', ylim = ylim, xaxt='n', xlab='', ylab='')
    if(xlabels){
      axis(1, at = c(0, burnline, 1000), labels = c(0, burnLab, ngLab))
    }else{
      axis(1, at = c(0, burnline, 1000), labels = F)
    }
    
    q <- quantile( mj[ss], c(.025, .5, .975) )
    for(k in 1:3){
      segments(burnline, q[k], 1000, q[k], col='white',lwd=1)
      segments(burnline, q[k], 1000, q[k], lty=2)
    }
    segments(burnline, q[1], burnline, q[3], col='white',lwd=1)
    segments(burnline, q[1], burnline, q[3], lty=2)
    if(!is.null(refVals))abline(h = refVals[j], col='blue')
    .plotLabel(cnames[j], above=T, cex=cex)
  }
  mtext('Iteration', outer=T, side=1, line=1)
  mtext('Parameter value', outer=T, side=2, line=1)
    
  if(CONSOLE){
    lab <- paste(label, ' -- return to continue')
    readline(lab)
  }
  if(SAVEPLOTS) {
    dev.off( )
  }
  if(!is.null(RMD)){
    words <- paste( 'MCMC chains for', label, 'with 95% coverage' )
    message( words )
  }
  invisible(words)
}
 
.outFile <- function(outFolder=character(0),file){
  paste(outFolder,file,sep='/')
}

.plotLabel <- function(label,location='topleft',cex=1.3,font=1,
                       above=F,below=F,bg=NULL){
  
  if(above){
    adj <- 0
    if(location == 'topright')adj=1
    title(label,adj=adj, font.main = font, font.lab =font, cex.main=cex)
    return()
  }
  if(below){
    adj <- 0
    if(location == 'bottomright')adj=1
    mtext(label,side=1,adj=adj, outer=F,font.main = font, font.lab =font,cex=cex)
    return()
  }
  
  if(is.null(bg)){
    tmp <- legend(location,legend=' ',bty='n')
  } else {
    tmp <- legend(location,legend=label,bg=bg,border=bg,text.col=bg,bty='o')
  }
  
  xt <- tmp$rect$left # + tmp$rect$w
  yt <- tmp$text$y
  
  pos <- 4
  tmp <- grep('right',location)
  if(length(tmp) > 0)pos <- 2
  
  XX <- par()$xlog
  YY <- par()$ylog
  
  if(XX)xt <- 10^xt
  if(YY)yt <- 10^yt
  
  text(xt,yt,label,cex=cex,font=font,pos=pos)
}

.boxCoeffs <- function(chain, snames, xlab = "", ylab='Coefficient',
                       addSpec = 'species', ylim=NULL, cols = NULL,
                       xaxt = 's', yaxt = 's'){
  
  nspec  <- length(snames)
  cnames <- colnames(chain)
  xn     <- character(0)
  vnames <- numeric(0)
  iname  <- character(0)
  gnames <- paste(addSpec,snames,sep='')

  for(j in 1:nspec){
    ij     <- which(cnames == gnames[j])
    if(length(ij) > 0)iname <- 'intercept'
    wj     <- grep(gnames[j],cnames)
    if(length(wj) > 0)vnames <- rbind(vnames, wj)
    wk <- grep(':',cnames[wj])
    if(length(wk) > 0){
      xn <- matrix( unlist( strsplit(cnames[wj[wk]],':')),
                    ncol=2, byrow=T)[,2]
    }
  }
    
  rownames(vnames) <- snames[vnames[,1]]
  colnames(vnames) <- c(iname,xn)
  nv <- ncol(vnames)
  
  nss <- nrow(vnames)
  
  atvals <- c(1:nss)/(nss + 1)
  atvals <- atvals - mean(atvals)
  sseq   <- c(1:nv)
  xlim   <- c(.5, nv +.5)
  
  if(is.null(ylim)){
    ylim <- range(chain)
    ylim[1] <- ylim[1] - diff(ylim)*.25
  }
  
  add <- F
  if(is.null(cols))cols <- seq(1:nss)
  
  xlabel <- ''
  
  stats <- numeric(0)
  
  for(j in 1:nv){
    
    jcol <- vnames[,j]
    if(j > 1)add <- T
    chainj <- chain[,jcol, drop=F]
    mj     <- mean(chainj)
    sj     <- sd(chainj)
    chainj <- chainj #/sj
    
    if(j == nv)xlabel <- xlab
    
    colj <- cols[j]
    
    if(any(colnames(chainj) %in% snames))colj <- cols[colnames(chainj)]
    
    wi <- grep(':',colnames(chainj))
    if(length(wi) > 0){
      tt <- columnSplit(colnames(chainj)[wi],':')[,1]
      colj <- cols[tt]
    }
    
    boxPars <- .boxplotQuant( chainj, xaxt=xaxt, add = add,
                          at = atvals + j, xlim = xlim,
                          outline=F, ylim=ylim,
                          col=.getColor(colj, .5), 
                          border=colj, lty=1,
                          ylab = ylab, yaxt = yaxt)
    stats <- cbind(stats,boxPars$stats)
 #   text(j,ylim[1],colnames(vnames)[j],pos=3)
  }
  .plotLabel(xlab,'topleft',above=T)
 # legend('topright',snames, text.col=1:nspec, bty='n')
  abline(h = c(0), lwd=1, col=.getColor('grey',.6))
  boxPars$stats <- stats
  invisible(boxPars)
}

.coeffNames <- function(cvec){
  
  # clean names  for coefficients
  
  fnames  <- .replaceString(cvec, '(Intercept)', 'intercept' )
  fnames  <- .replaceString(fnames, 'I(', '' )
  fnames  <- .replaceString(fnames, '))', ')' )
  fnames  <- .replaceString(fnames, 'species','')
  fnames  <- .replaceString(fnames, '^2)','^2')
  fnames
}


.fixNamesVector <- function(vnames, data, MODE='keep'){
  
  wgg <- match(vnames,names(data))
  
  for(k in wgg){
    data[[k]] <- .fixNames(data[[k]], all=T, MODE)$fixed
  }
  data
}

.fixNames <- function(cvec, all=F, MODE='keep'){
  
  # MODE == 'character', 'factor', or 'keep' (return same mode)
  
  cdup <- numeric(0)
  
  FACT <- F
  if(is.factor(cvec)){
    FACT <- T
    cvec <- as.character(cvec)
  }
  if(is.numeric(cvec)){
    cvec <- as.character(cvec)
    wdot <- grep('.',cvec)
    if(length(wdot) > 0)cvec <- .replaceString(cvec,'.','dot')
  }
  if(all) cvec <- .replaceString(cvec, '_','')
  cvec <- .replaceString(cvec, '-','')
  cvec <- .replaceString(cvec, ' ','')
  cvec <- .replaceString(cvec, "'","")
 # cvec <- .replaceString(cvec, ".","dot")
  cvec <- .replaceString(cvec, '"','')
  if( (FACT | MODE == 'factor') & MODE != 'character' ){
    cvec <- as.factor(cvec)
    droplevels(cvec)
  }
  
  cvec <- .replaceString(cvec, 'acerPenn', 'acerPens')
  
  wd <- which(duplicated(cvec))
  if(length(wd) > 0)cdup <- wd
    
  list(fixed = cvec, dups = cdup)
}

.setupR <- function(sdata, tdata, seedNames, specNames, unknown='UNKN'){
  
  SAMPR <- T
  UCOLS <- F
  
  wun <- grep('UNKN', seedNames)
  if(length(wun) > 1){
    stop("can only have one seedNames with 'UNKN' class")
  }
  if(length(wun) == 1)UCOLS <- T
    
  if(!'specPlot' %in% colnames(tdata))
    tdata$specPlot <- columnPaste(tdata$species,tdata$plot)
  
  if( length(seedNames) == 1 )SAMPR <- F
  
  plots  <- sort(unique(as.character(tdata$plot)))
  priorR <- numeric(0)
  
  for(j in 1:length(plots)){
    
    wj   <- which(tdata$plot == plots[j])
    jtab <- table(tdata$species[wj])
    jtab <- jtab[jtab > 0]
    
    ws   <- which(sdata$plot == plots[j])
    stab <- colSums(sdata[drop=F,ws,seedNames], na.rm=T)
    sname <- names(stab)
    unkn <- grep('UNKN', sname)
    UNKN <- sname[unkn]
    
    #   stab <- stab/sum(stab)
    
    jvec <- matrix(jtab)
    JJ   <- crossprod(t(jvec)) + diag(.01, length(jvec))
    rr <- crossprod(matrix(stab, nrow=1),t(jvec))%*%solve( JJ )
    rownames(rr) <- names(stab)
    colnames(rr) <- names(jtab)
    rr <- t(rr)
    
    if(length(rr) == 1){
      rr[1] <- 1
      rownames(rr) <- paste(names(jtab), plots[j],sep='-')
      priorR <- rbind(priorR,rr)
    }else{
      
      for(m in 1:nrow(rr)){
        
        # no seeds counted
        if(sum(rr[m,]) == 0){ 
          if(length(UNKN) > 0){
            rr[m,UNKN] <- 1
          }
          next
        }
        
        # counted as a different species
        OTHER <- F
        wm <- which( rr[m,] > 0 )
        wk <- which( !names(wm) %in% c(rownames(rr), UNKN) )
        keep <- character(0)
        if(length(wk) > 0){
          keep  <- names(wm[wk])
          OTHER <- T
        }
        
        # to unknown class
        if(UCOLS){
          wm <- which(!colnames(rr) %in% c(rownames(rr)[m],UNKN, keep) )
          if(length(wm) > 0)rr[m,wm] <- 0
        }
        
        # to same class
        wm <- which(colnames(rr) == rownames(rr)[m])
        if(length(wm) > 0){
          if(OTHER)rr[m,wm] <- rr[m,wm]*10
          if(UCOLS & OTHER)rr[m,unkn] <- rr[m,unkn]*10
        }
      }
      rownames(rr) <- paste(names(jtab), plots[j],sep='-')
      rr <- sweep(rr, 1, rowSums(rr), '/')
      priorR <- rbind(priorR,rr)
    }
  }
  
  priorR[!is.finite(priorR)] <- 0
  
  seedCount <- as.matrix(sdata[,seedNames,drop=F])

  tt <- columnSplit(rownames(priorR),'-')
  
  attr(priorR,'species') <- tt[,1]
  attr(priorR,'plot')    <- tt[,2]
  
  ws <- which(rowSums(priorR) == 0)
  if(length(ws) > 0){
    rr <- mastIDmatrix(tdata, sdata, 
                       specNames = specNames, seedNames = seedNames)$R
    if(ncol(rr) > 1)rr <- sweep(rr, 1, rowSums(rr), '/')
    priorR[ws,colnames(rr)] <- rr[attr(priorR,'species')[ws],]
  }
  
  priorRwt <- priorR*10
  
  posR <- which(!priorR %in% c(0, 1))
  
  if( all(priorR %in% c(0, 1)) )SAMPR <- F
  
  return( list(SAMPR = SAMPR, R = priorR, priorR = priorR, priorRwt = priorRwt,
               seedCount = seedCount, posR = posR, tdata = tdata) )
}

setupZ <- function(tdata, ntree, years, minDiam, maxDiam, maxFec){
  
  minD <- specPriorVector(minDiam, tdata)
  maxD <- specPriorVector(maxDiam, tdata)
  maxF <- specPriorVector(maxFec, tdata)
  
 # if(is.na(minDiam) | minDiam == 0)minDiam <- 1
  nyr <- length(years)
  
  # initialize repro
  tdata$repr[tdata$repr < .5] <- 0
  tdata$repr[tdata$repr >= .5] <- 1
  iy   <- match(tdata$year, years)
  tdata$repr[tdata$diam < minD & is.na(tdata$repr)] <- 0
  tdata$repr[tdata$diam > maxD & is.na(tdata$repr)] <- 1
  zknown <- dmat <- matrix(NA, max(tdata$dcol), length(years))
  zknown[ cbind(tdata$dcol, iy) ] <- tdata$repr
  dmat[ cbind(tdata$dcol, iy) ]   <- tdata$diam
  
  tmp <- .getRepro(zknown, dmat, minD, maxD)
  last0first1 <- tmp$last0first1
  zmat  <- tmp$rmat
  matYr <- tmp$matYr
  
  tmp <- .propZ(zmat, last0first1, matYr)
  zmat <- tmp$zmat
  matYr <- tmp$matYr
  
  # attributes for zmat
  tt <- matrix(NA, ntree, nyr)
  tt[ cbind(tdata$dcol, iy) ] <- tdata$treeID
  tt <- rowMeans(tt,na.rm=T)
  tt <- sort(unique(as.character(tdata$treeID)))[tt]
  pt <- matrix( unlist( strsplit(tt, '-') ), ncol=2, byrow=T)
  
  attr(zmat,'plot') <- pt[,1]
  attr(zmat,'treeID') <- tt
  
  tyindex <- cbind(tdata$dcol, iy)  #tree-yr index
  z    <- zmat[ tyindex ]
  
  
  if( is.null(tdata$fecMax) ){
    tdata$fecMax <- 1 + (maxF - 1)*z
    tdata$fecMin <- z
  }
  fmin <- z + 1e-4
  fmax <- 1 + z*maxF
  
  fmin[is.finite(tdata$fecMin)] <- ((z+1e-4)*tdata$fecMin)[is.finite(tdata$fecMin)]
  fmax[is.finite(tdata$fecMax)] <- ((z+1e-4)*tdata$fecMax)[is.finite(tdata$fecMax)]
  
  fmin[fmin < 1e-4] <- 1e-4
  fmax[fmax < 1] <- 1
  tdata$fecMax <- fmax
  tdata$fecMin <- fmin
  
  list(z = z, zmat = zmat, matYr = matYr, 
       last0first1 = last0first1, tdata = tdata)
}

getPredGrid <- function(predList, tdata, sdata, xytree, xytrap, group, 
                        specNames, plotDims){
  
  mapMeters  <- predList$mapMeters
  mapPlot    <- predList$plots
  mapYear    <- predList$years
  
  if(is.null(mapMeters)){
    mapMeters <- 5
    cat('\nMissing mapMeters for prediction grid set to 5 m\n')
  }
  
  plotYrComb <- table( tdata$plot, tdata$year )
  plotYrComb <- plotYrComb[drop=F,rownames(plotYrComb) %in% mapPlot,]
  plotYrComb <- plotYrComb[,colnames(plotYrComb) %in% mapYear, drop=F ]
  npred      <- nrow(plotYrComb)
  
  if(sum(plotYrComb) == 0){
    cat('\n\nPlot-years in predList missing from data:\n')
    print( paste(predList$plot,': ', predList$year, sep='') )
    cat('\n\n')
    return( list(seedPred = NULL, distPred = NULL) )
  }
  
  if(length(mapMeters) == 1 & npred > 1)mapMeters <- rep( mapMeters, npred )
  
  seedPred <- numeric(0)
  drowj <- drowTot <- 0
  
  distPred <- grp <- spp <- numeric(0)
  treeid   <- trapid <- numeric(0)
  
  gridSize <- rep(0, npred)
  names(gridSize) <- rownames(plotYrComb)
  
  for(j in 1:npred){
    
    wj <- which(plotYrComb[j,] > 0)
    pj <- rownames(plotYrComb)[j]
    wy <- as.numeric(colnames(plotYrComb)[wj])
  
    jplot <- as.matrix( plotDims[rownames(plotDims) == pj,] )
    
    jx <- c(jplot['xmin',1] - mapMeters[j]/2,
            jplot['xmax',1] + mapMeters[j]/2)
    jy <- c(jplot['ymin',1] - mapMeters[j]/2,
            jplot['ymax',1] + mapMeters[j]/2)
    
    sx <- seq(jx[1],jx[2],by=mapMeters[j])
    sy <- seq(jy[1],jy[2],by=mapMeters[j])
    
    jgrid <- expand.grid(x = sx, y = sy)
    gridSize[j] <- nrow(jgrid)
    
    yrj   <- rep( wy, nrow(jgrid) )
    
    jseq  <- rep(1:nrow(jgrid), each=length(wy) )
    jgrid <- jgrid[ jseq ,]
    
    dgrid   <- drowTot + jseq
    drowTot <- max(dgrid)
    trapID  <- paste(pj,'-g',dgrid,sep='')
    
    dj  <- data.frame(trapID = trapID, year = yrj, jgrid, drow=0, dgrid = dgrid)
    dj$plot  <- pj
    
    #includes trap years from data
    wmatch <- which(sdata$plot %in% pj)
    id     <- as.character(unique( sdata$trapID[wmatch] ) )
    sdd    <- sdata[match(id,sdata$trapID),]
    
    xy  <- xytrap[match(sdd$trapID,xytrap$trapID),c('x','y')]
  #  ii  <- rep( c(1:length(wy)), each=nrow(xy))
    jj  <- rep( c(1:nrow(sdd)), each=length(wy))
    yrj <- rep( wy, nrow(sdd) )
    drAll  <- sort(unique(sdd$drow))
    dgrid  <- drowTot + c(1:length(drAll))
    dgrid  <- dgrid[ match(sdd$drow[jj],drAll) ]
    drowTot <- max(dgrid)
    
    tj <- data.frame(trapID = sdd$trapID[jj], year = yrj, 
                     x = xy[jj,'x'], y = xy[jj,'y'],
                     drow = sdd$drow[jj], dgrid=dgrid, plot = sdd$plot[jj])
    dj <- rbind(dj,tj)
    
    seedPred <- rbind(seedPred, dj)
    
    # needed for column names and upar groups
    tj      <- which(as.character(xytree$plot) == pj)
    xy1     <- xytree[tj,]
    treeid  <- c(treeid,xytree$treeID[tj])
    
    grr <- match( xytree$treeID[tj], tdata$treeID )
    grp <- c(grp, group[grr])
    
    spp <- c(spp, as.character(xytree$species[tj]))
    
    wk    <- which(!duplicated(dj$dgrid))
    tid   <- as.character(dj$trapID[wk])
    kgrid <- dj[wk,c('x','y')]
    
    trapid <- c(trapid, tid )
    da     <- .distmat(xy1[,'x'],xy1[,'y'],kgrid[,'x'],kgrid[,'y']) 
    colnames(da) <- xy1$treeID
    rownames(da) <- tid
    distPred     <- .blockDiag(distPred,da)
  }
  
  plotYrComb <- cbind(plotYrComb, mapMeters, gridSize)
  seedPred$active  <- seedPred$area <- 1 # note for 1 m2
 # attr(distPred, 'group')  <- grp
  attr(distPred,'species') <- spp
  
  distPred[distPred == 0] <- 100000
  distPred <- round(distPred,1)
  
  seedPred$drow <- match(as.character(seedPred$trapID), rownames(distPred))
  
  rownames(seedPred) <- NULL
  
  cat("\nPrediction grid size: ")
  cat("If too large, increase predList$mapMeters:\n")
  print( plotYrComb[, c('mapMeters','gridSize')] )
  
  list(seedPred = seedPred, distPred = distPred)
}

cleanFactors <- function(x){
  
  #fix factor levels
  
  scode <- names(x[ which(sapply( x, is.factor )) ])
  if(length(scode) > 0){
    for(j in 1:length(scode)) {
  #    x[,scode[j]] <- .fixNames(x[,scode[j]])$fixed
      x[,scode[j]] <- droplevels(x[,scode[j]])
    }
  }
  x
}
  
firstClean <- function(tdata, sdata, xytree, xytrap,
                       specNames, seedNames, minDiam){
  
  facLevels <- character(0)
  
  if('repr' %in% names(tdata)){
    wf <- which(is.finite(tdata$repr))
    tdata$repMu <- rep(.5, nrow(tdata))
    tdata$repSd <- rep(1, nrow(tdata))
    if(length(wf) > 0){
      tdata$repMu[wf] <- tdata$repr[wf]
      tdata$repSd[wf] <- .1
    }
    rr <- range(tdata$repr,na.rm=T)
    
    if(rr[1] == 1)warning('every tree declared to be reproductive')
    if(rr[2] == 0){
      warning('every tree declared to be immature')
      tdata$repr[tdata$diam < minDiam] <- NA
    }
  }
  
  rdiam <- range(tdata$diam,na.rm=T)
  if(rdiam[1] <= 0)stop('some diameters <= 0')
  if(rdiam[2] > 500)warning('some diameters > 5 m')
  
  if(!'active' %in% names(sdata))sdata$active <- 1
  
  #coerce characters
  if( is.character(sdata$area) ){
    warning('\nseedData$area coerced to numeric\n')
    sdata$area <- as.numeric(sdata$area)
  }
  if( is.character(sdata$active) ){
    warning('\nseedData$active coerced to numeric\n')
    sdata$active <- as.numeric(sdata$active)
  }
  if(max(sdata$active, na.rm=T) > 1 | min(sdata$active, na.rm=T) < 0){
    warning('\nseedData$active outside (0, 1)\n')
  }
  if( is.character(tdata$diam) ){
    warning('\ntdata$diam coerced to numeric\n')
    tdata$diam <- as.numeric(tdata$diam)
  }
  
  tdata  <- .fixNamesVector(vnames=c('plot','tree','species'), 
                           data = tdata, MODE='factor')
  xytree <- .fixNamesVector(vnames=c('plot','tree'), 
                           data = xytree, MODE='factor')
  sdata <- .fixNamesVector(vnames=c('plot','trap'), 
                            data = sdata, MODE='factor')
  xytrap <- .fixNamesVector(vnames=c('plot','trap'), 
                            data = xytrap, MODE='factor')
  
  
  #colnames(tdata) <- .fixNames(colnames(tdata), all=T)$fixed
  colnames(sdata) <- .fixNames(colnames(sdata), all=T)$fixed
  tdata$species   <- .fixNames(tdata$species, all=T)$fixed
  specNames <- .fixNames(specNames, all=T)$fixed
  seedNames <- .fixNames(seedNames, all=T)$fixed
  
  wf <- which( sapply(tdata, is.factor) )
  wf <- wf[!names(wf) %in% c( 'plot', 'tree', 'species')]
  if(length(wf) > 0){
    for(k in wf){
      names(tdata)[k] <- .fixNames( names(tdata)[k], all=T )$fixed
      kl <- .fixNames( levels(tdata[[k]]), all=T )$fixed
      facLevels <- append(facLevels, list( kl ) )
      tdata[[k]] <- .fixNames(tdata[[k]], all=T)$fixed
    }
    names(facLevels) <- names(wf)
  }
  wf <- which( sapply(sdata, is.factor) )
  if(length(wf) > 0)for(k in wf)sdata[[k]] <- .fixNames(sdata[[k]], all=T)$fixed
  wf <- which( sapply(xytree, is.factor) )
  if(length(wf) > 0)for(k in wf)xytree[[k]] <- .fixNames(xytree[[k]], all=T)$fixed
  wf <- which( sapply(xytrap, is.factor) )
  if(length(wf) > 0)for(k in wf)xytrap[[k]] <- .fixNames(xytrap[[k]], all=T)$fixed
  
  plots <- sort(unique(as.character(tdata$plot)))
  years <- sort(unique(tdata$year))
  
  xytrap$trapID <- columnPaste(xytrap$plot,xytrap$trap)
  sdata$trapID  <- columnPaste(sdata$plot,sdata$trap)
  xytree$treeID <- columnPaste(xytree$plot,xytree$tree)
  tdata$treeID  <- columnPaste(tdata$plot,tdata$tree)
  
  xytree <- .cleanRows(xytree, 'treeID')
  xytrap <- .cleanRows(xytrap, 'trapID')
  
  ww <- which(!tdata$treeID %in% xytree$treeID)
  if(length(ww) > 0)tdata <- tdata[-ww,]
  
  ww <- which(!sdata$trapID %in% xytrap$trapID)
  if(length(ww) > 0)sdata <- sdata[-ww,]
  
  tdata  <- cleanFactors(tdata)
  sdata  <- cleanFactors(sdata)
  xytree <- cleanFactors(xytree)
  xytrap <- cleanFactors(xytrap)
  
  ty <- with(tdata, table(treeID, year) )
  
  if(max(ty) > 1){
    wm <- which(ty > 1,arr.ind=T)
    cw <- unique(rownames(wm))
    cy <- paste0( cw , collapse=', ')
    cat( paste( '\nremoved trees with duplicate years:\n', cy ) )
    tdata <- tdata[!as.character(tdata$treeID) %in% cw,]
    years <- sort(unique(c(tdata$year,sdata$year)))
  }
  
  tdata    <- tdata[as.character(tdata$plot) %in% plots & 
                      tdata$year %in% years,]
  sdata <- sdata[as.character(sdata$plot) %in% plots & 
                         sdata$year %in% years,]
  xytree   <- xytree[as.character(xytree$plot) %in% plots,]
  xytrap   <- xytrap[as.character(xytrap$plot) %in% plots,]
  tdata$plot  <- droplevels(tdata$plot)
  sdata$plot  <- droplevels(sdata$plot)
  xytree$plot <- droplevels(xytree$plot)
  xytrap$plot <- droplevels(xytrap$plot)
  
  # fix names
  tdata$species <- as.factor( .fixNames(as.character(tdata$species), all=T)$fixed )
  tdata$species <- droplevels( tdata$species )
  
  specNew <- .fixNames(specNames, all=T)$fixed
  seedNew <- .fixNames(seedNames, all=T)$fixed
  
  ww <- which(!specNames %in% specNew)
  if(length(ww) > 0){
    ts <- as.character(tdata$species)
    for(k in 1:length(ww)){
       ts[ ts == specNames[ww[k]] ] <- specNew[ww[k]]
    }
    tdata$species <- as.factor(ts)
    tdata$species <- droplevels( tdata$species )
    specNames <- sort( unique( specNew ) )
  }
  
  ww <- which(!seedNames %in% seedNew)
  if(length(ww) > 0){
    
    mm <- match(seedNames[ww], colnames(sdata))
    sdata <- sdata[,-mm]
    seedNames <- sort( unique( seedNew ) )
  }
           
  colnames(sdata) <- .fixNames(colnames(sdata), all=T)$fixed
  if('species' %in% colnames(xytree))
    xytree$species <- as.factor( .fixNames(as.character(xytree$species), all=T)$fixed )
  
  
  if(!'diam' %in% colnames(tdata))stop("include 'diam' column in treeData")
  
  tdata <- tdata[tdata$year %in% sdata$year,]
  
  tdata <- tdata[,!names(tdata) %in% c('treeID','plotYr')]
  sdata <- sdata[,!names(sdata) %in% c('trapID','plotYr')]
  
  list(tdata = tdata, sdata = sdata, xytree = xytree, xytrap = xytrap,
       specNames = specNames, seedNames = seedNames, plots = plots, 
       years = years, facLevels = facLevels)
}

.setupRandom <- function(randomEffect, tdata, xfec, xFecNames, specNames){
  
  tdata$species <- as.factor(tdata$species)
  
  nspec      <- length(specNames)
  formulaRan <- randomEffect$formulaRan
  if(nspec > 1)formulaRan <- .specFormula(randomEffect$formulaRan)
  xx        <- .getDesign(formulaRan, tdata)$x
  if(nspec > 1)xx <- xx[,grep('species',colnames(xx)),drop=F]  # CHECK for 1 spp
  
  xrandCols  <- match(colnames(xx),colnames(xfec))
  
  if( !is.finite(min(xrandCols)) )
    stop('there are variables in formulaRan that are missing from formulaFec')
  
  Qrand      <- length(xrandCols)
  reI        <- as.character(tdata[,randomEffect$randGroups])
  rnGroups   <- sort(unique(reI))
  reIndex    <- match(reI, rnGroups)
  reGroups   <- sort(unique(reIndex))
  nRand      <- length(reGroups)
  Arand      <- priorVA <- diag(1, Qrand)
  dfA        <- ceiling( Qrand + sqrt(nRand) )
  alphaRand  <- matrix(0, nRand, Qrand)
  colnames(alphaRand) <- xFecNames[xrandCols]
  rownames(alphaRand) <- rnGroups
  
 # formulaRan <- .specFormula(randomEffect$formulaRan, NOINTERCEPT=T)
 # xunstand   <- model.matrix(formulaRan,tdata)
  
  XX <- crossprod(xx)
  diag(XX) <- diag(XX) + .00000001
  xrands2u <- solve(XX)%*%crossprod(xx,xfec[,xrandCols]) 
  xrands2u[abs(xrands2u) < 1e-8] <- 0
  
  list(formulaRan = formulaRan, xrandCols = xrandCols, Qrand = Qrand,
       rnGroups = rnGroups, reIndex = reIndex, reGroups = reGroups, 
       Arand = Arand, dfA = dfA, alphaRand = alphaRand, priorVA = priorVA,
       xrands2u = xrands2u)
}

getPlotDims <- function(xytree, xytrap){
  
  plots <- sort( unique(as.character(xytree$plot) ) )
  npp   <- length(plots)
  
  pdims <- numeric(0)
  
  for(j in 1:npp){
    
    jx <- range( c(xytree$x[xytree$plot == plots[j]],
                   xytrap$x[xytrap$plot == plots[j]]) )
    jy <- range( c(xytree$y[xytree$plot == plots[j]],
                   xytrap$y[xytrap$plot == plots[j]]) )
    jx[1] <- floor( jx[1] - 1 )
    jx[2] <- ceiling( jx[2] + 1 )
    jy[1] <- floor( jy[1] - 1 )
    jy[2] <- ceiling( jy[2] + 1 )
    
    area <- diff(jx)*diff(jy)/10000
    
    pdims <- rbind( pdims, c(jx, jy, area) )
  }
  colnames(pdims) <- c('xmin','xmax','ymin','ymax','area')
  rownames(pdims) <- plots
  pdims
}
  
.orderChain <- function(xchain, snames){
  
  if(!snames[1] %in% colnames(xchain))return(xchain)
  
  ns <- length(snames)
  
  mnames <- .coeffNames(colnames(xchain))
  first  <- mnames[1:ns]
  tmp    <- grep('_',first)
  
  if(length(tmp) > 0){
    first <- matrix( unlist(strsplit(first,'_')),ncol=2,byrow=T)[,2]
  }
  
  orr    <- match(snames,first)
  if(is.na(orr[1]))return(xchain)
  
  newChain <- xchain*0
  
  k <- orr
  m <- 1:ns
  while(max(k) <= ncol(xchain)){
    
    newChain[,m] <- xchain[,k]
    colnames(newChain)[m] <- colnames(xchain)[k]
    
    m <- m + ns
    k <- k + ns
    
  }
  newChain
}


factor2integer <- function(fvec){
  as.numeric(as.character(fvec))
}

formit <- function(form, nspec){
  
  if(nspec > 1){
    fc   <- as.formula( .replaceString( as.character(form), 'species *','') )
    form <- .specFormula(fc)
  }
  .fixFormula(form)
}

.fixFormula <- function(form){
  
  # remove I(log()) from formula
  
  fchar <- as.character(form)[2]
  tmp   <- gregexpr('I(log(', fchar, fixed=T)[[1]]
  
  if(tmp[1] < 0)return(form)
  
  if(length(tmp) > 0){
    
    while(tmp[1] > 0){
      tmp   <- gregexpr('I(log(', fchar, fixed=T)[[1]]
      end <- gregexpr(')', fchar, fixed=T)[[1]]
      we <- end[ min(which(end > tmp[1])) ]
      substr(fchar, we, we) <- " "
      substr(fchar, tmp[1], (tmp[1] + attr(tmp,'match.length')[1]) ) <- "  log("
      fchar <- .replaceString(fchar,'  ',' ')
      fchar <- .replaceString(fchar,' )',')')
      tmp   <- gregexpr('I(log(', fchar, fixed=T)[[1]]
    }
  }
  as.formula( paste('~ ', fchar) )
}

mastif <- function(inputs, formulaFec=NULL, formulaRep=NULL, 
                   ng = NULL, burnin = NULL, predList = NULL, 
                   yearEffect = NULL, randomEffect = NULL, 
                   modelYears = NULL, plotDims = NULL){   
  data  <-  NULL
  
  if( class(inputs) == 'mastif' ){
    
    inputs$inputs$ng <- ng
    inputs$inputs$burnin <- burnin
    
    parameters <- inputs$parameters
    priorTable <- inputs$inputs$priorTable
    
    data   <- inputs$data
    if( !is.null(modelYears) ){
      inputs$inputs$tdataOut <- inputs$prediction$tdataOut
      inputs$inputs$sdataOut <- inputs$prediction$sdataOut
    }
    inputs <- inputs$inputs
    inputs$parameters <- parameters
    inputs$priorTable <- priorTable
    class(inputs) <- 'mastif'
  }

  if(is.null(ng))stop("supply no. MCMC steps, 'ng'")
  if(is.null(burnin))stop("supply 'burnin'")
  
  .mast(inputs, data, formulaFec, formulaRep, predList, yearEffect, 
        randomEffect, modelYears, ng, burnin) 
}
   
.mast <- function(inputs, data, formulaFec, formulaRep, predList, yearEffect,
                  randomEffect, modelYears, ng, burnin){
  
  upar <- xytree <- xytrap <- specNames <- treeData <- seedData <-
    seedNames <- arList <- times <- xmean <- xfecCols <- xrepCols <-
    groupByInd <- dfA <- xrands2u <- lagGroup <- lagMatrix <- xfecs2u <-
    xreps2u <- Qrand <- xfecU <- xrepU <- seedMass <- seedsPerCone <- 
    plotDims <- plotArea <- tdataOut <- sdataOut <- specPlots <- 
    plotNames <- distall <- NULL
  censMin <- censMax <- NULL
  SEEDCENSOR <- CONES <- F
  
  keepIter <- 3000
  
  words <- inwords <- character(0)
  
  priorList <- priorTable <- NULL

  priorDist <- 25; priorVDist <- 10; maxDist <- 40; minDist <- 4
  minDiam <- 10; maxDiam <- 40; sigmaMu <- 1
 
  plag    <- 0; maxFec   <- 1e+8; priorVtau <- 6
  ug <- priorTauWt <- NULL
  alphaRand <- Arand <- priorB <- priorIVB <- betaPrior <- NULL
  RANDOM <- YR <- AR <- ARSETUP <- SEEDCENSOR <- F
  PREDSEED <- T
  if(is.null(predList))PREDSEED <- F
  betaYr <- betaLag <- yeGr <- plots <- years <- NULL
  facLevels <- character(0)
  ngroup <- 1
  
  nng <- ng
  
  if( class(inputs) == 'mastif' ){
    
    ARSETUP <- T
    
    ww <- c(1:length(inputs))

    if(!is.null(formulaFec))ww <- ww[ names(inputs)  != 'formulaFec' ] 
    if(!is.null(formulaRep))ww <- ww[ names(inputs)  != 'formulaRep' ] 
    
    ww <- which(!names(inputs) %in% c('inputs','chains','fit',
                                      'burnin', 'ng', 'predList'))
    
    for(k in ww)assign( names(inputs)[k], inputs[[k]] )
    tdata <- treeData
    
    for(k in 1:length(data$setupData)){
      assign( names(data$setupData)[k], data$setupData[[k]] )
    }
    if('arList' %in% names(data)){
      for(k in 1:length(data$arList))
        assign( names(data$arList)[k], data$arList[[k]] )
      AR <- T
    }
    if('setupRandom' %in% names(data)){
      for(k in 1:length(data$setupRandom))
        assign( names(data$setupRandom)[k], data$setupRandom[[k]] )
      RANDOM <- T
    }
    if('setupYear' %in% names(data)){
      for(k in 1:length(data$setupYear)){
        if(names(data$setupYear)[k] == 'yrIndex')next
        assign( names(data$setupYear)[k], data$setupYear[[k]] )
      }
      YR <- T
    }
    ug <- inputs$parameters$upars[,1]
    
    
    if(length(ug) > 1)ug <- ug[!names(ug) %in% c('mean','var')]
    
    upar <- ug
    years <- sort(unique(tdata$year))
    nyr <- years
    if(!is.null(predList)){
      predList$years <- predList$years[predList$years %in% years]
      if('plots' %in% names(predList))
        predList$plots <- .fixNames(predList$plots, all=T)$fixed
    }
    yrIndex <- yrIndex[,!duplicated(colnames(yrIndex))]
    
    seedTable   <- inputs$seedByPlot
    matYr       <- inputs$matYr 
    last0first1 <- inputs$last0first1
    
  }else{ 

    if(!is.null(yearEffect)){
      if('p' %in% names(yearEffect))
        plag <- yearEffect$p
    }
    
    priorR <- mastIDmatrix( inputs$treeData, inputs$seedData, 
                            specNames = inputs$specNames,
                            seedNames = inputs$seedNames,
                            censMin = inputs$censMin)$R
    if(is.matrix(priorR)){
      inputs$specNames <- specNames <- rownames(priorR)
      inputs$seedNames <- seedNames <- colnames(priorR)
    }

    inputs <- mastFillCensus(inputs, p = plag)  
    for(k in 1:length(inputs))assign( names(inputs)[k], inputs[[k]] )
    
    if(!is.null(censMin))SEEDCENSOR <- T
    
    words <- c(words, inwords)
    years <- range(c(treeData$year,seedData$year))
    years <- years[1]:years[2]
  }
  
  plots <- .fixNames( sort(unique(as.character(treeData$plot))), all=T)$fixed
  
  if(!is.null(randomEffect)){
    randomEffect$formulaRan <- .fixFormula(randomEffect$formulaRan)
    if('randGroups' %in% names(randomEffect)){
      if(randomEffect$randGroups == 'tree')randomEffect$randGroups <- 'treeID'
      randGroups <- randomEffect$randGroups
    }
  }
  if(!is.null(predList)){
    PREDSEED <- T
    if(!'plots' %in% names(predList))stop('predList must include plots')
    predList$plots <- .fixNames(predList$plots, all=T)$fixed
    predList$plots <- predList$plots[predList$plots %in% plots]
    if(length(predList$plots) == 0)
      stop('Prediction plots do not occur in treeData')
    if(!'mapGrid' %in% names(predList))predList$mapGrid <- 5
  }
  if(!is.null(yearEffect)){
  #  plotGroups <- yearEffect$plotGroups
  #  specGroups <- yearEffect$specGroups
    YR <- T
    if('p' %in% names(yearEffect)){
      plag <- yearEffect$p
    }
  }
  
  if(plag > 0){
    AR <- T
    YR <- F
  }
  
  
  ng <- nng
  plots <- sort(unique(as.character(treeData$plot)))
  
  tmp <- checkPlotDims(plots, years, xytree, xytrap, plotDims, plotArea)
  plotDims <- tmp$plotDims
  plotArea <- tmp$plotArea
  
  sigmaWt <- sqrt(nrow(treeData))
  
  nspec <- length(specNames)

    
  if(!is.null(priorList)){
    
    if(length(priorList) > 1){ #priors by species
      
      for(k in 1:length(priorList)){
        wk <- which(names(priorList[[k]]) == 'priorDist')
        if(length(wk) == 1)priorDist <- unlist(priorList[[k]][wk]) 
        wk <- which(names(priorList[[k]]) == 'priorVDist')
        if(length(wk) == 1)priorVDist <- unlist(priorList[[k]][wk])
        wk <- which(names(priorList[[k]]) == 'minDist')
        if(length(wk) == 1)minDist <- unlist(priorList[[k]][wk])
        wk <- which(names(priorList[[k]]) == 'maxDist')
        if(length(wk) == 1)maxDist <- unlist(priorList[[k]][wk])
        wk <- which(names(priorList[[k]]) == 'minDiam')
        if(length(wk) == 1)minDiam <- unlist(priorList[[k]][wk])
        wk <- which(names(priorList[[k]]) == 'maxDiam')
        if(length(wk) == 1)maxDiam <- unlist(priorList[[k]][wk])
        wk <- which(names(priorList[[k]]) == 'maxF')
        if(length(wk) == 1)maxFec <- unlist(priorList[[k]][wk])
      }
    }
  }
  
  pcols <- c("priorDist","priorVDist","minDist","maxDist","minDiam",
             "maxDiam","maxFec")
  
  if(is.null(priorTable)){
    priorTable <- matrix(NA, length(specNames), length(pcols))
    colnames(priorTable) <- pcols
    rownames(priorTable) <- specNames
    for(k in 1:length(pcols)){
      priorTable[,pcols[k]] <- get( pcols[k][1] )
    }
  }else{
    pm <- which(!pcols %in% colnames(priorTable))
    if(length(pm) > 0){
      for(k in pm){
        priorTable <- cbind(priorTable, get( pcols[k][1] ))
        colnames(priorTable)[k] <- pcols[k]
      }
    }
  }
  
    
  priorU  <- round( (2*priorTable[,'priorDist']/pi)^2 )
  priorVU <- round( (2/pi)^2*priorTable[,'priorVDist']^2 )
  maxU    <- round( (2*priorTable[,'maxDist']/pi)^2 )
  minU    <- round( (2*priorTable[,'minDist']/pi)^2 )
  
  
  priorTable <- cbind(priorTable,priorU, priorVU, maxU, minU)
  
 # priorTable <- rbind(minDiam, maxDiam, maxFec, priorDist, priorVDist,
 #                     minDist, maxDist)
 # rownames(priorTable) <- c('minDiam', 'maxDiam', 'maxF', 'priorDist', 
 #                           'priorVDist', 'minDist', 'maxDist')
 # colnames(priorTable) <- 'Value'
  

  umean <- mean(priorTable[,'priorU'])
  propU <- mean(priorTable[,'priorU'])/100
  uvar  <- mean(priorTable[,'priorVU'])
  if(is.null(ug))ug <- mean(priorTable[,'priorU'])

  for(k in 1:ncol(priorTable)){
    pk <- priorTable[,k]
    names(pk) <- rownames(priorTable)
    assign(colnames(priorTable)[k], pk)
  }
  ug   <- priorU
  maxF <- max(maxFec)
  
  if(is.null(priorTauWt))priorTauWt <- nrow(treeData)
  tau1 <- priorTauWt
  tau2 <- priorVU*(tau1 - 1)
  
  if(!is.null(betaPrior)){
    if(!is.null(yearEffect) | !is.null(randomEffect))
    plag <- yearEffect$p
  }
  
  formulaFec <- formit(formulaFec, nspec)
  formulaRep <- formit(formulaRep, nspec)
  
  if( !is.null(modelYears) ){
    
    inputs$modelYears <- modelYears
    
    wtree <- which(treeData$year %in% modelYears)
    wtrap <- which(seedData$year %in% modelYears)
    
    tdataOut <- treeData[-wtree,]
    sdataOut <- seedData[-wtrap,]
    sdataOut$seedM2  <- round(rowSums( as.matrix(sdataOut[,seedNames]) )/
                                sdataOut$area,1)
    
    xy <- xytrap[ match(sdataOut$trapID, xytrap$trapID),c('x','y')]
    sdataOut <- cbind(xy, sdataOut)
  }
  
  tdata <- treeData
  sdata <- seedData
  

  
  
  ##################
  rm(treeData)
  rm(seedData)
  ##################
 
  if( !ARSETUP ){ 
    
    tmp <- .setupData(formulaFec, formulaRep, tdata, sdata,
                      xytree, xytrap, specNames, seedNames, AR, YR, yearEffect, 
                      minDiam, maxDiam)
    for(k in 1:length(tmp))assign( names(tmp)[k], tmp[[k]] ) 
    yeGr   <- as.character(yeGr)
    ngroup <- length(yeGr)
   # yrIndex[,'group'] <- match(tdata$group, yeGr)
    
    setupData <- tmp[ !names(tmp) %in% 
                        c("tdata","sdata","seedNames","specNames",
                                   "xytree","xytrap") ]
    
    data      <- append(data, list(setupData = setupData))
    
    years <- range(tdata$year)
    years <- years[1]:years[2]
    
    # enough seed?
    seedTable <- buildSeedByPlot(sdata, seedNames)
    
    if(length(censMin) > 0){
      ctmp <- censMin
      ctmp$plot <- sdata$plot[censMin$srow]
      censTable <- buildSeedByPlot(ctmp, seedNames)
      rownames(censTable) <- .replaceString(rownames(censTable),'seeds','min')
      
      wk <- which(!colnames(seedTable) %in% colnames(censTable))
      if(length(wk) > 0){
        
        moreCols <- matrix(0, nrow(censTable), length(wk))
        colnames(moreCols) <- colnames(seedTable)[wk]
        censTable <- cbind(censTable, moreCols)
        seedTable <- rbind(seedTable, censTable[drop=F,,colnames(seedTable)])
        attr(seedTable,'caption') <- 'min_ rows give sum of minimum values for censored traps'
      }
    }
    
    
    cat('\nSeed count by plots having trees:\n')
    print(seedTable)
    if(sum(seedTable) < 10)stop('not enough seeds')

    if(AR){
      data      <- append(data, list(arList = arList))
      for(k in 1:length(arList))assign( names(arList)[k], arList[[k]] ) 
      nyrAR    <- length(times)
      
      groupYr  <- yrIndex[,'group'] # for AR, group and groupYr identical
      yrIndex  <- cbind(yrIndex,groupYr)
      preYr    <- years[-c(1:plag)]

      # check order:
      # plot(tdata$dcol,yrIndex$group)      
      # points(1:ntree, groupByInd, col=2, cex=.6)
      # points(tdata$dcol[lagMatrix[,1]],lagGroup,col=3,cex=.3) # must be > p yr
      # plot(tdata$dcol[match(tdata$treeID,colnames(distall))], cex=.2)
      
    }

    if(YR){
  #    yrTmp <- yrIndex
  #    tmp <- .setupYear(yearEffect, tdata, years)
  #    for(k in 1:length(tmp))assign( names(tmp)[k], tmp[[k]] ) 
      setupYear <- list(yeGr = yeGr, yrIndex = yrIndex)
      
      
      data     <- append(data, list(setupYear = setupYear))
      
      
      betaYr <- matrix(0, ngroup, length(years))
      rownames(betaYr) <- yeGr
      colnames(betaYr) <- years
      
      group <- match( as.character(tdata$groupName), yeGr )
      
      tdata$group <- yrIndex[,'group'] <- group
      
    #  wn <- which(!colnames(yrTmp) %in% colnames(tmp$yrIndex))
    #  if(length(wn) > 0)yrIndex <- cbind(yrTmp[,wn],tmp$yrIndex)
      
      betaYrR  <- betaYr
      betaYrF  <- betaYrR[drop=F,1,]
    }
  } ################
  
  if(!'dcol' %in% colnames(yrIndex)){
    dcol    <- tdata$dcol
    yrIndex <- cbind(yrIndex,dcol)
  }
  if(is.null(upar))upar <- ug
  
  if( is.list(yrIndex) )yrIndex <- as.matrix(yrIndex)
  
  nseed <- nrow(sdata)
  nplot <- length(plots)
  n     <- nrow(xfec)
  ntobs <- table(tdata$plot)
  nsobs <- table(sdata$plot)
  ttab  <- table(tdata$plot, tdata$year)
  wtab  <- which(ttab > 0, arr.ind=T) 
  ntree  <- nrow(xytree)
  ntrap  <- nrow(xytrap)
  obsYr  <- sort(unique(tdata$year[tdata$obs == 1]))
  nyr    <- length(years)
  
  if(!is.null(modelYears))      
    obsYr <- intersect(obsYr,modelYears)  #also, plotYears? yrIndex?
  
  obsTimes <- match(obsYr,years)
  
  RANDYR <- F
  spp <- match( as.character(tdata$species), specNames )
  yrIndex <- cbind(yrIndex, spp)

  tdata     <- cleanFactors(tdata)
 # plotYears <- attr(tdata$plotYr, 'levels' )
  plotYears <- sort(unique(tdata$plotYr))
  
  nacc   <- length(years)
  nspec  <- length(specNames)
  
  yrIndex <- yrIndex[,!duplicated(colnames(yrIndex))]
  
  UNSTAND <- T
  if(length(xmean) == 0)UNSTAND <- F
  
  Qfec <- ncol(xfec)
  Qrep <- ncol(xrep)
  xFecNames <- colnames(xfec)
  xRepNames <- colnames(xrep)
  
  nSpecPlot <- max(yrIndex[,'specPlot'])
  
  npacf   <- ceiling(nacc/2)
  pacfMat <- matrix(0, nSpecPlot, npacf)
  rownames(pacfMat) <- as.character(specPlots)
  colnames(pacfMat) <- paste('lag',0:(npacf-1),sep='-')

  pacf2  <- pacfMat
  acfMat <- pacfMat
  pacN   <- pacfMat
  
  if(YR | AR){
    muyr <- rep(0,nrow(tdata))
    if(ngroup > 1)RANDYR <- T
  }
  
  if( !ARSETUP ){        
    # random effects
    rnGroups <- reIndex <- reGroups <- priorVA <- NULL
    alphaRand <- Arand <- NULL
    if( !is.null(randomEffect) ){
      RANDOM     <- T
      tmp <- .setupRandom(randomEffect, tdata, xfec, xFecNames, specNames) 
      for(k in 1:length(tmp))assign( names(tmp)[k], tmp[[k]] ) 
      data <- append(data, list(setupRandom = tmp))
      if(length(Arand) == 1)ONEA <- T
    }
  }        
  if(is.null(yeGr))yeGr <- specNames[1]
 
  priorU  <- mean( priorU )
  priorVU <- mean( priorVU )
  
  if(nspec == 1){
    maxU    <- max( maxU )
    minU    <- min( minU )
    priorDist  <- priorDist[1]
    priorVDist <- priorVDist[1]
    maxDist    <- maxDist[1]
    minDist    <- minDist[1]
  }else{
    ug <- ug[specNames]
    minU <- minU[specNames]
    maxU <- maxU[specNames]
    minDiam <- minDiam[specNames]
    maxDiam <- maxDiam[specNames]
    maxFec  <- maxFec[specNames]
  }
  
  
  obsRows <- which(tdata$obs == 1)
  
  ONEF <- ONER <- ONEA <- F     
  if(ncol(xfec) == 1)ONEF <- T  # intercept only
  if(ncol(xrep) == 1)ONER <- T  # intercept only
  
  seedPredGrid <- distPred <- NULL
  nseedPred <- 0
  
  rownames(yrIndex) <- NULL
  
  # species to seed type
  
  tmp <- .setupR(sdata, tdata, seedNames, specNames)
  R         <- tmp$R
  priorR    <- tmp$priorR
  priorRwt  <- tmp$priorRwt
  SAMPR     <- tmp$SAMPR
  seedCount <- tmp$seedCount
  posR      <- tmp$posR
  tdata     <- tmp$tdata
  
  if(PREDSEED){
    
   # if(AR)predList$years <- years         # may not be desireable 
    
    if(is.character(predList$years)) predList$years <- 
                            as.numeric(predList$years)
    
    tmp <- getPredGrid(predList, tdata, sdata, xytree, xytrap, 
                       group = yrIndex[,'group'], specNames, plotDims)
    
    sdatPred  <- tmp$seedPred
    distPred  <- tmp$distPred
    nseedPred <- nrow(sdatPred)
    if( !is.null(nseedPred) ){ 
      treeRows <- which( as.character(tdata$plot) %in% predList$plots &
                           tdata$year %in% predList$years )
      rowt <- match( as.character(tdata$plotTreeYr[treeRows]), 
                     as.character(tdata$plotTreeYr) )
      predDcol <- match( tdata$treeID[treeRows], colnames(distPred) )
      tdatPred <- data.frame( treeID = tdata$treeID[treeRows], row = rowt, 
                              dcol = predDcol, 
                              species = tdata$species[treeRows],
                              specPlot = tdata$specPlot[treeRows],
                              plotTreeYr = tdata$plotTreeYr[treeRows],
                              year = tdata$year[treeRows])
    }else{
      PREDSEED <- F
    }
  }
    
  ti <- match(colnames(distall),as.character(tdata$treeID))
 # attr(distall, 'group') <- yrIndex[ti,'group'] 
  
  if(YR){
    cnames  <- paste('yr',1:nyr,sep='-')
    sygibbs <- matrix(0,ng, nyr)
    colnames(sygibbs) <- cnames        # variance, random years
  }
  
  if(AR)Alag   <- diag(.1, plag, plag)
  
  if( ARSETUP ){
    iy   <- match(tdata$year, years)
    zmat <- matrix(NA, max(tdata$dcol), length(years))
    zmat[ cbind(tdata$dcol, iy) ] <- tdata$lastRepr
    z <- tdata$lastRepr
  }else{
    tmp <- setupZ(tdata, ntree, years, minDiam, maxDiam, maxFec)
    z           <- tmp$z
    zmat        <- tmp$zmat
    matYr       <- tmp$matYr 
    last0first1 <- tmp$last0first1
    tdata       <- tmp$tdata       # fecMin, fecMax included
  }
  
  fecMin <- tdata$fecMin
  fecMax <- tdata$fecMax
  
  
  tdata$species <- as.character(tdata$species)
  
  MISS <- F
  missSeed <- which(is.na(seedCount),arr.ind=T)
  if(length(missSeed) > 0){
    MISS <- T
    sdata[,seedNames][missSeed] <- 0
  }
  
  fstart <- rep(NA, nrow(tdata))
  
  if('coneCount' %in% colnames(tdata)){
    ccone <- grep('coneCount', colnames(tdata))
    if( sum(tdata[,ccone], na.rm=T) > 0){
      if(is.null(seedsPerCone)){
        warning('cannot use treeData$coneCount without inputs$seedsPerCone, assumed = 1')
        seedsPerCone <- matrix(1, nspec, 1)
        rownames(seedsPerCone) <- .fixNames(specNames, MODE='character')$fixed
      }
      CONES <- T
      if(!'coneFraction' %in% colnames(tdata)){
        kwords <- "\nNote: missing column _coneFraction_, assumed = 1\n"
        words <- c(words, kwords)
        tdata$coneFraction <- .99
      }
      seedsPerCone    <- ceiling(seedsPerCone)
      tdata$coneCount <- ceiling(tdata$coneCount)
      tdata$coneCount[is.na(tdata$coneFraction)] <- NA
      fm <- tdata$coneCount*seedsPerCone[tdata$species,]
      ff <- tdata$coneFraction
      wf <- is.finite(fm)
      mf <- which(wf)
      fstart[mf] <- fm[mf]/ff[mf]
      tdata$fecMin[(tdata$fecMin < fm) & wf] <- fm[(tdata$fecMin < fm) & wf] - .001
      tdata$fecMin[(tdata$fecMin < .001)] <- .001
      tdata$fecMin[fm == 0] <- .001
      
      tdata$fecMax[mf] <- 2*fstart[mf]
      tdata$fecMax[tdata$fecMax < 1] <- 1
      w0 <- which(fm == 0 & tdata$repr == 0)
      tdata$fecMax[w0] <- 1
      w0 <- which(fm == 0 & tdata$repr == 1)
      tdata$fecMax[w0] <- 10
    }
  }
  
  # initial maturation fecundity
  
  
  if('lastRepr' %in% names(tdata)){
    z <- tdata$lastRepr
    zmat[ yrIndex[,c('dcol','year')] ] <- z
  }
  if('lastFec' %in% names(tdata)){
    fg <- tdata$lastFec
  }else{
    tmp <- .initEM(last0first1, yeGr, distall, priorU[1],tdata, sdata, 
                   specNames, seedNames, R, 
                   SAMPR, years, plotYears, z, xfec, zobs=tdata$repr,
                   fstart)
    fg <- tmp
  }
 # fg[fg > (maxFec - 1)] <- maxFec - 1
 # fecMax[fecMax > maxF] <- maxF
  
  propF <- fg/10
  propF[propF < .0001] <- .0001
 # propF[propF > .1*maxF] <- .1*maxF
  
  # reg variance
  sg <- sigmaMu
  s1 <- sigmaWt
  s2 <- sigmaMu*(s1 - 1)
  
  bgFec <- matrix(0, Qfec, 1)
  bgRep <- matrix(0, Qrep, 1)
  rownames(bgFec) <- xFecNames
  rownames(bgRep) <- xRepNames
  
  if(!is.null(betaPrior)){
    betaPrior <- .getBetaPrior(betaPrior, bgFec, bgRep, specNames)
  }
  
  ngroup <- length(yeGr)
  
  obsRowSeed <- which(sdata$year %in% obsYr)
  fitCols <- 1:Qfec
  notFit <- match(notFit,colnames(xfec))
  if(length(notFit) > 0)fitCols <- fitCols[-notFit]
  
  
  .updateBeta <- .wrapperBeta(priorB, priorIVB, SAMPR, obsRows, obsYr, obsRowSeed,
                              tdata, xfecCols, xrepCols, last0first1, ntree, nyr, 
                              betaPrior, years, distall, YR, AR, yrIndex,
                              RANDOM, reIndex, xrandCols, RANDYR,
                              fitCols)
  
  .updateU <- .wrapperU(distall, tdata, minU, maxU, priorU, priorVU,
                        seedNames, nspec, obsRows, obsRowSeed, obsYr, 
                        tau1, tau2, SAMPR, RANDYR)
  
  predYr  <- sort( unique(tdata$year[tdata$obs == 1]) )
  
  tcols <- c('specPlot','species','dcol','year','plotYr','plotyr','obs')
  if(AR)tcols <- c(tcols,'times')
  if(CONES)tcols <- c(tcols,'coneCount', 'coneFraction')

  
  updateProp <- c( 1:1000, seq(1001, 10000, by=100) )
  updateProp <- updateProp[updateProp < .9*ng]
  
  .updateFecundity <- .wrapperStates( maxFec, SAMPR, RANDOM, obsTimes, plotYears, 
                                      sdata, tdat = tdata[,tcols], seedNames,
                                      last0first1, distall, YR, AR,
                                      obsRows, obsYr, predYr, obsRowSeed,
                                      ntree, years, nyr, xrandCols, reIndex, 
                                      yrIndex, plag, groupByInd, RANDYR, updateProp,
                                      seedsPerCone)
  
  ikeep <- 1:ng
  if(ng < keepIter)keepIter <- ng
  if(keepIter < ng){
    ikeep <- round(seq(1, ng, length.out=keepIter))
    ikeep <- ikeep[!duplicated(ikeep)]
  }
  nkeep <- length(ikeep)
  
  bfgibbs  <- matrix(0, nkeep, Qfec); colnames(bfgibbs) <- xFecNames
  brgibbs  <- matrix(0, nkeep, Qrep); colnames(brgibbs) <- xRepNames
  bygibbsF <- bygibbsR <- NULL
  
 

  ugibbs <- matrix(0, nkeep, nspec)
  sgibbs <- matrix(0, nkeep, 3)
  colnames(ugibbs) <- specNames
  colnames(sgibbs) <- c('sigma','rmspe','deviance')
  
  ncols <- nyr
  if(AR){
    ncols <- plag
    cnames <- paste('lag',c(1:plag),sep='-')
  }
  
  betaYrF  <- betaYrR <- matrix(0, 1, ncols)
  if( YR ) sgYr <- rep(1, ncols)
  if(YR | AR){
    betaYrF  <- matrix(0, 1, ncols)
    betaYrR  <- matrix(0, ngroup, ncols)
    rownames(betaYrR) <- yeGr
    colnames(betaYrF) <- colnames(betaYrR) <- cnames
    bygibbsF <- matrix(NA, nkeep, length(betaYrF))
    bygibbsR <- matrix(0, nkeep, length(betaYrR))
    colnames(bygibbsF) <- colnames(betaYrF)
    colnames(bygibbsR) <- .multivarChainNames(yeGr, colnames(betaYrR))
    bygibbsN <- bygibbsR
  }
  if(AR){
    Gmat  <- rbind(0, cbind( diag(plag-1), 0 ) )
    eigenMat <- eigen1 <- eigen2 <- betaYrR*0
  }
  if(nspec > 1){
    priorUgibbs <- matrix(0,nkeep,2)
    colnames(priorUgibbs) <- c('mean','var')
  }
  
  if(RANDOM){
    agibbs <- matrix(NA, nkeep, length(Arand))
    colnames(agibbs) <- .multivarChainNames(xFecNames[xrandCols],
                                            xFecNames[xrandCols])
    aUgibbs <- agibbs
    asum <- asum2 <- aUsum <- aUsum2 <- alphaRand*0
  }
  
  colnames(brgibbs) <- xRepNames
  
  if(SAMPR){
    rgibbs <- matrix(0, nkeep, length(R))
    colnames(rgibbs) <- .multivarChainNames(rownames(R), colnames(R) )
    rgibbs <- rgibbs[,posR]
  }
  
  accept <- rep(0, length(plotYears))
  
  cat('\nMCMC\n')
  
  ug[1:nspec] <- .tnorm( nspec, minU, maxU, ug, 5)
  
  pars  <- list(fg = fg, fecMin = tdata$fecMin, fecMax = tdata$fecMax, 
                ug = ug, umean = umean, uvar = uvar,
                sg = sg, bgFec = bgFec, bgRep = bgRep,
                betaYrR = betaYrR*0, betaYrF = betaYrF, alphaRand = alphaRand, 
                Arand = Arand, R = R)
  
  mufec <- xfec%*%bgFec
  muyr  <- muran <- mufec*0
  
  # draw from probit
  wlo <- rep(-Inf, length(z))
  whi <- rep(Inf, length(z))
  whi[z == 0] <- 0
  wlo[z == 1] <- 0
  w <- .tnorm(length(z), wlo, whi, tdata$repMu, 1)
  
  tmp <- .updateBeta(pars, xfec, xrep, w, z, zmat, matYr, muyr)
  bgFec <- pars$bgFec <- tmp$bgFec
  bgRep <- pars$bgRep <- tmp$bgRep
  
  tmp <- .updateU(pars, z, propU, sdata)
  ug    <- pars$ug    <- tmp$ug
  umean <- pars$umean <- tmp$umean
  uvar  <- pars$uvar  <- tmp$uvar
  propU <- tmp$propU
  
  # tree correlation
  nSpecPlot <- max(yrIndex[,'specPlot'])
  fmat <- matrix(0,ntree,nyr)
  
  wwi <-  match( unique(tdata$dcol),tdata$dcol )
  rownames(fmat) <- tdata$treeID[ wwi ]
  
  if(is.null(seedMass)){
    seedMass <- matrix(1,length(specNames),1)
    rownames(seedMass) <- specNames
  }
  
  if(MISS){
    lm <- .getLambda(tdata[obsRows,c('specPlot','year','dcol')],
                     sdata[obsRowSeed,c('year','drow')],
                     AA=1, ug, fg[obsRows]*z[obsRows], R, 
                     SAMPR, distall, obsYr, PERAREA=F, SPECPRED=F)
    sdata[obsRowSeed,seedNames][missSeed] <- round(lm[missSeed])
  }
  
  omegaE <- omegaN <- matrix(0,ntree,ntree)
  
  if(PREDSEED){  #predict species, not seedNames
    specPredSum <- specPredSum2 <- matrix(0, nseedPred, nspec)
    colnames(specPredSum) <- specNames
  }
  
  gupdate <- c(5, 10, 15, 20, 25, 50, 100, 200, 500, 800, 1200,2000)  
  g1      <- 1
  yupdate <- sort( sample(burnin:ng, 50, replace=T) )
  yupdate <- unique(yupdate)
  pupdate <- burnin:ng
  if(length(pupdate) > 1000)pupdate <- 
    unique( round( seq(burnin, ng, length=100) ))
  
  SvarEst  <- SvarPred <- matrix(0,length(pupdate),length(obsRowSeed))
  colnames(SvarEst)    <- rownames(sdata)[obsRowSeed]
  specSum <- specSum2  <- matrix(0,length(obsRowSeed),nspec)
  colnames(specSum)    <- colnames(specSum2) <- specNames
  rownames(specSum)    <- rownames(specSum2) <- rownames(sdata)[obsRowSeed]
  
  ntoty <- rmspe <- deviance <- 0
  ntot  <- 0
  zest <- zpred <- fest <- fest2 <- fpred <- fpred2 <- fg*0 # fecundity 
  sumDev <- ndev <- 0   #for DIC

 # maxFLog <- log(maxFec)
  
  activeArea <- sdata$area
  
  nPlotYr <- max(tdata$plotyr)
  acceptRate <- nPlotYr/5
  
  if(SEEDCENSOR){ #locations of censored seed counts
    censMin <- as.matrix(censMin)
    censMax <- as.matrix(censMax)
    censIndex <- which(censMax[,-1, drop=F] > censMin[,-1, drop=F], arr.ind=T)
    censIndex <- sort(unique(censIndex[,1]))
  }
  
  # known immature
  zdmat <- matrix(1, ntree, nyr)                    # this needs ztrue!
  w0    <- which(tdata$diam < minDiam[tdata$species] | tdata$repr == 0)
                   
  zdmat[ yrIndex[w0,c('dcol','year')] ] <- 0
  rpred <- zdmat*0
  
  pbar <- txtProgressBar(min=1,max=ng,style=1)
  
  logScoreStates <- logScoreFull <- obsRowSeed*0
  
  nprob <- 0
  
  fg[fg > fecMax] <- fecMax[fg > fecMax]
  
  epsilon <- (log(fg) + log(fecMax + 1 - fg))/100000
  
  gk <- 0
  
  for(g in 1:ng){ 
    
    if(g %in% ikeep)gk <- gk + 1
    if(gk > ng)break
    
    pars$fg <- fg
    yg      <- log(fg)      
    mufec   <- xfec%*%bgFec
    
    if(RANDOM){
      yg <- yg - mufec
      if(YR){
        yg <- yg - betaYrF[yrIndex[,'year']] 
        if(RANDYR)yg <- yg - betaYrR[yrIndex[,c('group','year')]] 
      }
      if(AR)yg <- yg - muyr
      
      wrow <- obsRows[z[obsRows] == 1]
      
      tmp <- .updateAlphaRand(ntree, yg[wrow], xfec[drop=F,wrow,], sg, 
                              reIndex[wrow], reGroups,
                              xrandCols, Arand, priorVA, dfA, minmax = 1)
      Arand       <- pars$Arand <- tmp$Arand
      alphaRand   <- pars$alphaRand <- tmp$alphaRand
      ArandU      <- xrands2u%*%tmp$Arand%*%t(xrands2u)
      alphaRandU  <- tmp$alphaRand%*%t(xrands2u)
      
      if(g %in% ikeep){
        agibbs[gk,]  <- as.vector(Arand)   
        aUgibbs[gk,] <- as.vector(ArandU)
      }
      muran <- xfec[,xrandCols]*alphaRand[reIndex,]
      if(length(Arand) > 1)muran <- rowSums( muran )
    }
    
    if(YR){
      yg <- log(fg) - mufec
      if(RANDOM)yg <- yg - muran
      
      tmp      <- .updateBetaYr(yg, z, sg, sgYr, betaYrF, betaYrR, yrIndex, yeGr,
                                RANDYR, tdata$obs)
      betaYrF  <- pars$betaYrF <- tmp$betaYrF
      betaYrR  <- pars$betaYrR <- tmp$betaYrR
      sgYr     <- pars$sgYr    <- tmp$sgYr
      wfinite  <- tmp$wfinite
      
      if(g %in% ikeep){
        bygibbsF[gk,] <- betaYrF
        bygibbsR[gk,] <- betaYrR
        bygibbsN[gk,wfinite] <-  1
        sygibbs[gk,]  <- sgYr
      }
      muyr <- betaYrF[yrIndex[,'year']] 
      if(RANDYR) muyr <- muyr + betaYrR[ yrIndex[,c('group','year')] ]
    }
    
    if(AR){
      yg <- log(fg) 
      mu <- mufec
      if(RANDOM)mu <- mu + muran
      
      tmp <- .updateBetaAR_RE(betaYrF, betaYrR, Alag, yg, mu, z, 
                              lagGroup, lagMatrix, plag, ngroup, sg)
      betaYrF <- pars$betaYrF <- tmp$betaYrF
      betaYrR <- pars$betaYrR <- tmp$betaYrR
      wfinite <- which(betaYrR != 0)
      Alag    <- tmp$Alag
      muyr <- tmp$ylag
      if(g %in% ikeep){
        bygibbsF[gk,] <- betaYrF
        bygibbsR[gk,] <- betaYrR
        bygibbsN[gk,wfinite] <-  1
      }
    }
    
    wlo <- 10*(z - 1)
    whi <- 10*z
    w   <- .tnorm(length(z), wlo, whi, xrep%*%bgRep, 1)
    
    tmp <- .updateBeta(pars, xfec, xrep, w, z, zmat, matYr, muyr)
    bgFec <- pars$bgFec <- tmp$bgFec
    bgRep <- pars$bgRep <- tmp$bgRep
    
    tmp <- .updateU(pars, z, propU, sdata)
    ug    <- pars$ug    <- tmp$ug
    umean <- pars$umean <- tmp$umean
    uvar  <- pars$uvar  <- tmp$uvar
    propU <- tmp$propU

    tmp <- .updateFecundity(g, pars, xfec, xrep, propF, z, zmat, matYr, muyr,
                            epsilon = epsilon, pHMC = .03)

   # if(is.na(max(tmp$fg)))stop('fecundity error')
    
    fg    <- pars$fg <- tmp$fg
    pars$fecMin <- tmp$fecMin
    pars$fecMax <- tmp$fecMax
    z     <- tmp$z
    zmat  <- tmp$zmat
    matYr <- tmp$matYr
    propF <- tmp$propF
    epsilon <- tmp$epsilon

    muf <- xfec%*%bgFec
    if(YR | AR)muf <- muf + muyr
    if(RANDOM)muf  <- muf + muran
    
    sg <- pars$sg <- .updateVariance(log(fg[obsRows][z[obsRows] == 1]), 
                                     muf[obsRows][z[obsRows] == 1], s1, s2)
    if(sg > 20)sg <- pars$sg <- 20
    
    if(SAMPR){
      tmp  <- .updateR(ug, fg[obsRows]*z[obsRows], SAMPR, distall, 
                     sdata, seedNames, tdata[obsRows,c('specPlot','year','dcol')], 
                     R, priorR, priorRwt, obsYr, posR, plots)
      pars$R <- R <- tmp
      if(g %in% ikeep)rgibbs[gk,]  <- R[posR]
    }
   
    # prediction
 
    rpred[ yrIndex[,c('dcol','year')] ] <- rnorm(nrow(tdata),xrep%*%bgRep)
    
    Fpred <- pnorm(rpred)
    Fpred[rpred == 0] <- 0
    dvals <- matrix( runif(ntree, 0, 1), ntree, nyr)
    Fpred[Fpred > dvals] <- 1
    Fpred[zdmat == 0] <- 0
    Fpred[Fpred < 1] <- 0
    
  #  zw <- Fpred[yrIndex[,c('dcol','year')] ]
    
    zw <- rnorm(nrow(tdata),xrep%*%bgRep)
    zw[zw <= 0] <- 0
    zw[zw > 0]  <- 1
    
    flo <- fhi <- zw*0
    flo[zw == 0] <- -9.21034
    fhi[zw == 1] <- log(pars$fecMax[zw == 1])
    
    ymu <- .tnorm( length(muf), flo, fhi, muf, sqrt(sg) )
    fmu <- exp( ymu )                          # mean prediction
 
    # save unstandardized
    bfSave <- bgFec
    brSave <- bgRep
    
    if(UNSTAND){
      if(length(xfecs2u) > 0)bfSave <- xfecs2u%*%bgFec  
      if(length(xreps2u) > 0)brSave <- xreps2u%*%bgRep
    }
  
    
    if(g %in% ikeep){
      bfgibbs[gk,] <- bfSave
      brgibbs[gk,] <- brSave
      ugibbs[gk,]  <- ug
    }
    
    if( nspec > 1 )priorUgibbs[gk,] <- c(umean,uvar)
    
    if(g %in% gupdate & gk > 10){
      gi <- (gk - 10):gk
   #   g1 <- gk
      if(length(ug) > 1){
        propU  <- apply(ugibbs[gi,],2,sd) + .0001
      }else{
        propU <- sd(ugibbs[gi,]) + .0001
      }
    }
    
    if(SEEDCENSOR){
      lf <- .getLambda(tdata[obsRows,c('specPlot','year','dcol')],
                       sdata[censMin[,1],c('year','drow')],
                       activeArea[censMin[,1]], ug, fg[obsRows]*z[obsRows], R, 
                       SAMPR, distall, obsYr, PERAREA=F)  # per trap
      lf[lf < 1e-9] <- 1e-9
      
      ttt <- rtpois( lo = censMin[,-1, drop=F], hi = censMax[,-1, drop=F], mu = lf )
      sdata[ censMin[,1], colnames(ttt) ] <- ttt
    }
    
    if(g %in% pupdate){
      
      nprob <- nprob + 1
      
      # estimated fecundity per m2
      
      fz <- fg[obsRows]*z[obsRows]
      lm <- .getLambda(tdata[obsRows,c('specPlot','year','dcol')],
                       sdata[obsRowSeed,c('year','drow')],
                       AA=1, ug, fz, R, 
                       SAMPR, distall, obsYr, PERAREA=T, SPECPRED=T)  # per m^2
      lm[lm < 1e-9] <- 1e-9
      pm    <- matrix( rpois(length(lm), lm), nrow(lm), ncol(lm) )
      specSum  <- specSum + pm
      specSum2 <- specSum2 + pm^2
      
      #estimated fecundity per trap
      lf <- .getLambda(tdata[obsRows,c('specPlot','year','dcol')],
                       sdata[obsRowSeed,c('year','drow')],
                       activeArea[obsRowSeed], ug, fz, R, 
                       SAMPR, distall, obsYr, PERAREA=F)  # per trap
      lf[lf < 1e-9] <- 1e-9
      pf    <- matrix( rpois(length(lf), lf), nrow(lf), ncol(lf) )
      
      if(MISS){
        sdata[obsRowSeed,seedNames][missSeed] <- pf[missSeed]
      }
      
      SvarEst[nprob,] <- rowSums(pf)

      # predicted fecundity per trap
      la    <- .getLambda(tdata[obsRows,c('specPlot','year','dcol')], 
                          sdata[obsRowSeed,c('year','drow')],
                          AA=activeArea[obsRowSeed], ug, fmu[obsRows]*zw[obsRows], 
                          R, SAMPR, distall, obsYr, PERAREA=F)     # per trap
      la[la < 1e-9] <- 1e-9
      pg    <- matrix( rpois(length(la), la), nrow(lf), ncol(la) )
      
      resid <- (seedCount[obsRowSeed,] - pg)^2
      if(SEEDCENSOR)resid[censMin[,1],][censIndex] <- 0
      
      rmspe <- sqrt( mean( resid, na.rm=T ) )
      
      SvarPred[nprob,] <- rowSums(pg)
      
      # deviance from predicted fecundity
      dev   <- dpois(seedCount[obsRowSeed,], la, log=T)

      if(SEEDCENSOR){
        pr <- dtpois(censMin[,-1], censMax[,-1], la[censMin[,1],], index = censIndex) 
        dev[censIndex] <- log( pr[censIndex] )
      }
      deviance <- -2*sum( dev )
      
      sumDev <- sumDev - deviance
      ndev <- ndev + 1
      
      # score from predicted fecundity
      
      logScoreStates <- logScoreStates - dpois(seedCount[obsRowSeed,], lf, log=T)
      logScoreFull   <- logScoreFull - dev
      
      
      if(PREDSEED){
        ls <- .getLambda(tdatPred[,c('specPlot','year','dcol')], 
                         sdatPred[,c('year','drow')], AA = 1,
                         ug, fmu[tdatPred[,'row']]*zw[tdatPred[,'row']], R, 
                         SAMPR, distPred, predList$years, PERAREA=T,
                         SPECPRED=T)   # per m^2
        ls <- ls + 1e-9
        ps <- matrix( rpois(nseedPred*ncol(ls), ls), nseedPred, nspec )
        
        
        ##################
    #    lss <- rowSums(ls)
    #     scc <- tapply(rowSums(seedCount), list(plot=sdata$plot, year = sdata$year), sum)
    #    spp <- tapply(lss, list(plot=sdatPred$plot,year=sdatPred$year),sum)
    #    fff <- tapply(fmu, list(plot=tdata$plot, year=tdata$year), sum)
        
     #   pl <- 'DUKEHW'
     #   plot(colnames(spp),spp[pl,],type='l')
     #   lines(colnames(scc), scc[pl,]*100,col=3)
     #   lines(colnames(fff),fff[pl,]/100,col=2)
        
        ###############
        
        specPredSum  <- specPredSum + ps
        specPredSum2 <- specPredSum2 + ps^2
      }
    }
    
    if(g %in% ikeep)sgibbs[gk,]  <- c(sg, rmspe, deviance)
    
    if(g %in% yupdate){
      
      ntoty  <- ntoty + 1
      
      # by group
      if(AR){
        for(j in 1:ngroup){
          Gmat[1,] <- betaYrF + betaYrR[j,]
          eigenMat[j,] <- eigen(Gmat)$values
        }
        eigen1 <- eigen1 + eigenMat
        eigen2 <- eigen2 + eigenMat^2
      }
      
      fecRes <- fg
      yRes <- yg
      yRes <- yRes - mean(yRes)           #tree autocorrelation
      
        
      for(m in 1:nSpecPlot){
        
        fmat <- fmat*0
        
        wm   <- which(yrIndex[,'specPlot'] == m & tdata$obs == 1 & fg > 1)
        dm   <- tdata$dcol[wm]
        ym   <- yrIndex[wm,'year']
        dr   <- unique(dm)
        if(length(dr) < 2)next
        
        fmat[ cbind(dm,ym) ] <- fecRes[wm]
        fm  <- fmat[unique(dm),unique(ym)]
        
        # between trees
        ff <- suppressWarnings( cor(t(fm), use="pairwise.complete.obs") ) 
        wf <- which(is.finite(ff))
        
        omegaE[dr,dr][wf] <- omegaE[dr,dr][wf] + ff[wf]
        omegaN[dr,dr][wf] <- omegaN[dr,dr][wf] + 1
        
        acm <- acfEmp(yRes[wm], tdata$dcol[wm], yrIndex[wm,'year'])
        wfin <- which(is.finite(acm))
        wfin <- wfin[wfin <= npacf]
        if(length(wfin) == 0)next
        
        pa <- try( pacf(acm[wfin]), T )
        
        if( !inherits(pa,'try-error') ){
          pacfMat[m,wfin] <- pacfMat[m,wfin] + pa
          pacf2[m,wfin]   <- pacf2[m,wfin] + pa^2
          acfMat[m,wfin] <- acm[wfin]
          pacN[m,wfin] <- pacN[m,wfin] + 1
        }
      }
    }
     
    if(g >= burnin){
      
      ntot <- ntot + 1
      
      zest  <- zest + z
      fz    <- fg*z
      fest  <- fest + fz  # only add to mature 
      fest2 <- fest2 + fz^2
      
      zpred  <- zpred + zw
      fz     <- fmu*zw
      fpred  <- fpred + fz
      fpred2 <- fpred2 + fz^2
      
      if(RANDOM){
        asum <- asum + alphaRand
        asum2 <- asum2 + alphaRand^2
        aUsum <- aUsum + alphaRandU
        aUsum2 <- aUsum2 + alphaRandU^2
      }
    }
    
    setTxtProgressBar(pbar,g)
  } ###########################################################
   
  # to re-initialize
  tdata$lastFec  <- fg
  tdata$lastRepr <- z
  tdata$fecMin   <- pars$fecMin
  tdata$fecMax   <- pars$fecMax
  
  # fecundity
  matrEst  <- zest/ntot
  matrPred <- zpred/ntot
  
  fecEstMu <- fest/zest     #  same order at tdata
  fecEstSe <- fest2/zest - fecEstMu^2
  fecEstSe[fecEstSe < 0] <- 0
  fecEstSe <- sqrt(fecEstSe)
  
  fecPredMu <- fpred/zpred     #  pred|z = 1
  fecPredSe <- fpred2/zpred - fecPredMu^2
  fecPredSe[fecPredSe < 0] <- 0
  fecPredSe <- sqrt(fecPredSe)
  
  fecPred <- tdata[,c('plot','treeID','species','year','diam','dcol')]
  if(YR | AR){
    ygr <- yrIndex
    colnames(ygr) <- paste('ind_',colnames(ygr),sep='')
    fecPred <- cbind(fecPred, ygr)
  }
  mpm <- round( cbind(matrEst, matrPred), 3)
  
  fpm <- cbind(fecEstMu, fecEstSe, fecPredMu, fecPredSe)
  fpm[is.na(fpm)] <- 0
  fpm <- round(fpm,1)
  
  
  fecPred <- cbind(fecPred, mpm, fpm)
  
  scols <- c('plot','year','trapID','drow','area')
  countPerTrap <- rowSums(sdata[obsRowSeed,seedNames,drop=F])

  seedEst <- cbind( colMeans(SvarEst), apply(SvarEst, 2, sd) )
  colnames(seedEst) <- c('estMeanTrap', 'estSeTrap')
  seedPred <- cbind( colMeans(SvarPred), apply(SvarPred, 2, sd) )
  colnames(seedPred) <- c('predMeanTrap', 'predSeTrap')
  
  seedSpecMu <- specSum/nprob
  seedSpecSe <- specSum2/nprob - seedSpecMu^2
  seedSpecSe[seedSpecSe < 0] <- 0
  seedSpecSe <- sqrt(seedSpecSe)
  
  seedPred <- data.frame( cbind( sdata[obsRowSeed,scols], countPerTrap,
                                 signif(seedEst, 3),signif(seedPred, 3)) )
  m1 <- paste(specNames,'meanM2',sep='_')
  m2 <- paste(specNames,'sdM2',sep='_')
  m2Mu <- seedSpecMu[,specNames,drop=F]
  m2Se <- sqrt( seedSpecSe[,specNames,drop=F]^2 ) 
  colnames(m2Mu) <- m1
  colnames(m2Se) <- m2
  seedPred <- cbind(seedPred, signif(m2Mu, 3), signif(m2Se,3))
  
  nss <- length(obsRowSeed)

  MM <- F
  if(!all(seedMass == 1))MM <- T
  
  if( MM ){
    mss <- matrix(seedMass[specNames,],nss,nspec,byrow=T)
    massMu <- seedSpecMu[,specNames,drop=F]*mss
    massSe <- sqrt( seedSpecSe[,specNames,drop=F]^2*mss^2 ) 
    m1 <- paste(colnames(massMu),'meanGmM2',sep='_')
    m2 <- paste(colnames(massSe),'sdGmM2',sep='_')
    colnames(massMu) <- m1
    colnames(massSe) <- m2
    seedPred <- cbind(seedPred, signif(massMu, 3), signif(massSe,3))
  }
  
  
  if(PREDSEED){
    scols <- c('plot','trapID','year','x','y','drow','dgrid','area','active')
    specMu <- specPredSum/nprob
    specSe <- sqrt(specPredSum2/nprob - specMu^2)
    colnames(specMu) <- paste(colnames(specMu),'_meanM2',sep='')
    colnames(specSe) <- paste(colnames(specSe),'_sdM2',sep='')
    
    preds <- signif(cbind(specMu, specSe), 3)
    
    seedPredGrid <- data.frame( cbind( sdatPred[,scols], preds ) )
    treePredGrid <- cbind(tdatPred, fecPred[tdatPred$row,])
  #  seedPredGrid$plot <- as.factor(seedPredGrid$plot)
  #  treePredGrid$plot <- as.factor(treePredGrid$plot)
    
    
    # out-of-sample
    if(!is.null(modelYears)){
      
      sdataOut$plotTrapYr <- columnPaste(sdataOut$trapID,sdataOut$year)
      sdataOut$fore <- sdataOut$year - max(modelYears)

      tdataOut$plotTreeYr <- columnPaste(tdataOut$treeID,tdataOut$year)
      treePredGrid$plotTreeYr <- columnPaste(treePredGrid$treeID,treePredGrid$year)
      
      fec <- matrix(NA,nrow(tdataOut),4)
      colnames(fec) <- colnames(fpm)
      ww <- which(tdataOut$plotTreeYr %in% treePredGrid$plotTreeYr)
      qq <- match(tdataOut$plotTreeYr[ww], treePredGrid$plotTreeYr)
      fec[ww,] <- fpm[qq,]
      tdataOut <- cbind(tdataOut,fec)
    }
  }
  
#  kg <- burnin:ng
  
  kg <- which(ikeep >= burnin & ikeep <= ng)
  
  betaFec <- .chain2tab(bfgibbs[kg,])
  betaRep <- .chain2tab(brgibbs[kg,])
  
  # seed, fecundity acf
  seedRes <- t( t(seedCount) - colMeans(seedCount, na.rm=T) )
  ww <- colSums(seedCount, na.rm=T)
  seedRes <- seedRes[,ww > 0,drop=F]
  
  ii <- rep(sdata$drow,ncol(seedRes))
  yy <- match(sdata$year,years)
  jj <- rep(yy, ncol(seedRes))
  
  acm  <- acfEmp(as.vector(seedRes), ii, jj)
  wfin <- which(is.finite(acm))
  pacsMat <- acm*0
  pacsMat[wfin] <- pacf(acm[wfin])
  
  acfMat  <- acfMat/ntoty
  pacfMat <- pacfMat/pacN
  pacfSe  <- pacf2/pacN - pacfMat^2
  
  omegaE <- omegaE/omegaN
  
  ################ years/lags
  
  if(YR | AR){
    ncol <- nyr
    ccol <- years
    if(AR){
      ncol <- plag
      ccol <- colnames(bygibbsF)
    }
    betaYrMu <- matrix( colMeans(bygibbsF[drop=F, kg,], na.rm=T), nrow(betaYrF), ncol )
    betaYrSe <- matrix( apply(bygibbsF[drop=F, kg,], 2, sd, na.rm=T), nrow(betaYrF), ncol )
    colnames(betaYrMu) <- colnames(betaYrSe) <- ccol
    betaYrRand <- betaYrRandSE <- betaYrMu*0
    if(RANDYR){
      brsum <- matrix( colSums(bygibbsR[kg,], na.rm=T), 
                       nrow(betaYrR), ncol )
      brn <- matrix( colSums(bygibbsN[kg,], na.rm=T), 
                     nrow(betaYrR), ncol )
      betaYrRand <- brsum/brn
      brn2 <- matrix( colSums(bygibbsR[kg,]^2, na.rm=T), 
                      nrow(betaYrR), ncol )
      ser <- sqrt( brn2/brn - betaYrRand^2 )
      betaYrRandSE <- ser
      betaYrRand[!is.finite(betaYrRand)] <- 0
      rownames(betaYrRand) <- rownames(betaYrRandSE) <- yeGr
      colnames(betaYrRand) <- colnames(betaYrRandSE) <- ccol
    }
  }
  
  ################ REs
  
  if(RANDOM){
    alphaMu <- asum/ntot
    av    <- asum2/ntot - alphaMu^2
    av[av < 0] <- 0
    alphaSe <- sqrt(av)
    
    alphaUMu <- aUsum/ntot
    av    <- aUsum2/ntot - alphaUMu^2
    av[av < 0] <- 0
    alphaUSe <- sqrt(av)
    
    if(ONEA){
      aMu <- mean(agibbs[kg,])
      aSe <- sd(agibbs[kg,])
      aUMu <- mean(agibbs[kg,])
      aUSe <- sd(agibbs[kg,])
    }else{
      colnames(alphaMu) <- colnames(alphaSe) <- 
        colnames(alphaUMu) <- colnames(alphaUSe) <- xFecNames[xrandCols]
      rownames(alphaMu) <- rownames(alphaSe) <- 
        rownames(alphaUMu) <- rownames(alphaUSe) <- as.character()
      aMu <- matrix( apply(agibbs[drop=F,kg,], 2, mean), Qrand, Qrand )
      aSe <- matrix( apply(agibbs[drop=F,kg,], 2, sd), Qrand, Qrand )
      aUMu <- matrix( apply(aUgibbs[drop=F,kg,], 2, mean), Qrand, Qrand )
      aUSe <- matrix( apply(aUgibbs[drop=F,kg,], 2, sd), Qrand, Qrand )
      colnames(aMu) <- rownames(aMu) <- colnames(aSe) <- rownames(aSe) <-
        colnames(aUMu) <- rownames(aUMu) <- colnames(aUSe) <- rownames(aUSe) <-
        colnames(alphaMu)
      names(xrandCols) <- xFecNames[xrandCols]
    }
  }
  
  mmu <- 1
  if(SAMPR){
    
    tmu <- apply(rgibbs[kg,], 2, mean)
    tse <- apply(rgibbs[kg,], 2, sd)
    
    mmu <- mse <- priorR*0
    mmu[posR] <- tmu
    mse[posR] <- tse
    
    mmu[mmu == 0 & priorR == 1] <- 1
    
    attr(mmu,'posR') <- attr(mse,'posR') <- posR
    
    colnames(mmu) <- colnames(mse) <- seedNames
    rownames(mmu) <- rownames(mse) <- rownames(R)
  }
  
  #################### dispersal
  
  dgibbs <- pi*sqrt(ugibbs)/2
  upars <- .chain2tab(ugibbs[kg,,drop=F])[,c(1:4)]
  dpars <- .chain2tab(dgibbs[kg,,drop=F])[,c(1:4)]
  
  if( nspec > 1){
    
    uByGroup <- colMeans(ugibbs[drop=F, kg,])
    dByGroup <- colMeans(dgibbs[drop=F, kg,])
    priorDgibbs <- pi*sqrt(priorUgibbs[drop=F, kg,])/2
    
    uall <- .chain2tab(priorUgibbs[kg,,drop=F])[,c(1:4)]
    dall <- .chain2tab(priorDgibbs[,,drop=F])[,c(1:4)]
    
    upars <- rbind(upars,uall)
    dpars <- rbind(dpars,dall)
    
  }else{
    upars <- .chain2tab(ugibbs[kg,,drop=F])[,c(1:4)]
    uByGroup <- mean(ugibbs[kg,])
    
    dpars <- .chain2tab(dgibbs[kg,,drop=F])[,c(1:4)]
    dByGroup <- mean(dgibbs[kg,])
  }

  su <- .chain2tab(sgibbs[kg,])[,c(1:4)]
  
  # coefficients are saved unstandardized 
  
  if(UNSTAND){
    xfec <- xfecU
    xrep <- xrepU
  }
  
  zp <- pnorm(xrep%*%betaRep[,1])
  
  fp <- xfec%*%matrix(betaFec[,1], ncol=1) 
  if(YR){
    byr <- betaYrMu[ yrIndex[,'year'] ] 
    if(RANDYR)byr <- byr + betaYrRand[ yrIndex[,c('group','year')] ]
    byr[is.na(byr)] <- 0
    fp <- fp + byr
  }
  
  ############### AR
  
  if(AR){

    eigenMu <- eigen1/ntoty
    eigenSe <- sqrt( eigen2/ntoty - eigenMu^2 )
    
    yg   <- log(fecPred$fecPredMu)      
    yg[!is.finite(yg)] <- 0
    ylag <- yg*0
    mu   <- fp
    
    nl <- nrow(lagMatrix)
    
    zlag <- matrix(zp[lagMatrix[,-1]],nl,plag)
    zlag[zlag < .5] <- 0
    zlag[zlag > 0] <- 1
    xm <- matrix( yg[ lagMatrix[,-1]],nl,plag)*zlag
    ylag[lagMatrix[,1]] <- xm%*%t(betaYrMu)
    
    # random effects
    if(RANDYR){
      for(m in 1:ngroup){
        tg <- which(lagGroup == m)
        if(length(tg) == 0)next
        ylag[lagMatrix[tg,1]] <- xm[tg,]%*%betaYrRand[m,]
      }
    }
    ylag[!is.finite(ylag)] <- 0
    fp <- mu + ylag
  }
  
  ################ fit
  
  fp <- exp(fp)
  
  meanDev <- sumDev/ndev

  la <- .getLambda(tdata[obsRows,c('specPlot','year','dcol')], 
                   sdata[obsRowSeed,c('year','drow')], activeArea[obsRowSeed],
                   uByGroup, as.vector(fp[obsRows])*as.vector(zp[obsRows]), 
                   mmu, SAMPR, distall, obsYr, PERAREA=F)
  la <- la + 1e-9
  pd  <- meanDev - 2*sum(dpois(seedCount, la, log=T))
  DIC <- pd + meanDev
  
  RMSPE <- mean(sgibbs[kg,'rmspe'])
  
  logScoreStates <- logScoreStates/nprob
  logScoreFull   <- logScoreFull/nprob
  
  fit <- list( DIC = round(DIC), scoreStates = mean(logScoreStates),
               predictScore = round( mean(logScoreFull) ), 
               RMSPE = signif(RMSPE,3) )
  
  inputs$treeData   <- tdata
  inputs$seedData   <- sdata
  inputs$formulaFec <- formulaFec
  inputs$formulaRep <- formulaRep
  inputs$upar       <- ug
  inputs$ng         <- ng
  inputs$burnin     <- burnin
  inputs$keepIter   <- keepIter
  inputs$plotDims   <- plotDims
  inputs$plotArea   <- plotArea
  inputs$specNames  <- specNames
  inputs$seedNames  <- seedNames
  inputs$priorR     <- priorR
  inputs$priorRwt   <- inputs$priorRwt
  inputs$xytree     <- xytree
  inputs$xytrap     <- xytrap
  inputs$yrIndex    <- yrIndex
  inputs$obsRowSeed <- obsRowSeed
  inputs$obsRows    <- obsRows
  inputs$maxFec     <- maxFec
  inputs$summary    <- words
  inputs$priorTable <- priorTable
  inputs$seedByPlot <- seedTable
  inputs$matYr      <- matYr 
  inputs$last0first1 <- last0first1
  if(SEEDCENSOR)inputs$censIndex <- censIndex
  if(!is.null(plotDims))inputs$plotDims <- plotDims
  if(!is.null(seedMass))inputs$seedMass <- seedMass
  if(!is.null(yearEffect) & !'yearEffect' %in% names(inputs))
               inputs$yearEffect <- yearEffect

  chains <- list(bfec = .orderChain(bfgibbs, specNames), 
                 brep = .orderChain(brgibbs, specNames), 
                 ugibbs = ugibbs, sgibbs = sgibbs)
  parameters <- list( betaFec = betaFec,  
                      betaRep = betaRep,
                      sigma = su, acfMat = acfMat, 
                      upars = upars, dpars = dpars,
                      pacfMat = pacfMat,
                      pacfSe = pacfSe, pacsMat = pacsMat, omegaE = omegaE,
                      omegaN = omegaN)
  
  if(SAMPR){
    chains <- append(chains, list(rgibbs = rgibbs))
    parameters <- append(parameters, list(rMu = signif(mmu,3), 
                                          rSe = signif(mse,3)))
  }
  fecPred$obs <- tdata$obs
  prediction  <-  list( fecPred = fecPred, seedPred = seedPred)
  if(nspec > 1)chains <- append(chains, list(priorUgibbs = priorUgibbs))
  if(YR){
    chains <- append(chains, list(sygibbs = sygibbs))
  }
  if(AR){
    parameters <- append(parameters, 
                         list(eigenMu = eigenMu, eigenSe = eigenSe))
    prediction <- append(prediction, 
                         list(tdataOut = tdataOut, sdataOut = sdataOut))
  }
  if(AR | YR){
    if(yeGr[1] %in% specNames){
      tmp <- .orderChain(bygibbsR, specNames)
    }
    
    chains     <- append(chains, list(bygibbsF = bygibbsF, bygibbsR = bygibbsR) )
    parameters <- append(parameters, list(betaYrMu = signif(betaYrMu, 3),
                                          betaYrSe = signif(betaYrSe, 3)))
    
    if(RANDYR)parameters <- append(parameters, 
                                   list(betaYrRand = signif(betaYrRand,3),
                                        betaYrRandSE = signif(betaYrRandSE,3)))
  }
  if(PREDSEED) {
    prediction <- append(prediction, 
                         list(seedPredGrid = seedPredGrid,
                              treePredGrid = treePredGrid) )
    if(!'predList' %in% names(inputs))inputs <- append(inputs, list(predList = predList))
  }
  if(RANDOM){
    inputs$randomEffect <- randomEffect
    chains     <- append(chains, list(agibbs = .orderChain(agibbs, specNames),
                                      aUgibbs = .orderChain(aUgibbs, specNames)) )
    parameters <- append(parameters, 
                         list(alphaMu = alphaMu, alphaSe = alphaSe,
                              aMu = aMu, aSe = aSe, 
                              alphaUMu = alphaUMu, alphaUSe = alphaUSe,
                              aUMu = aUMu, aUSe = aUSe) )
  }
  data$setupData$distall <- distall
  
  chains     <- chains[ sort( names(chains) )]
  inputs     <- inputs[ sort( names(inputs) )]
  data       <- data[ sort(names(data)) ]
  inputs$ng  <- ng
  inputs$burnin <- burnin
  inputs$obsYr  <- table(tdata$plot[tdata$obs == 1], tdata$year[tdata$obs == 1])
  parameters <- parameters[ sort( names(parameters) )]
  
  out <- list(inputs = inputs, chains = chains, data = data, fit = fit, 
              parameters = parameters, prediction = prediction )
  
  class(out) <- 'mastif'
  out
} 
  
.chain2tab <- function(chain){
  
  mu <- colMeans(chain)    #standardized
  
  SE <- apply(chain,2,sd)
  CI <- apply(chain,2,quantile,c(.025,.975))
  splus <- rep(' ', length=length(SE))
  splus[CI[1,] > 0 | CI[2,] < 0] <- '*'
  
  tab <- cbind( mu, SE, t(CI))
  tab <- signif(tab, 3)
  colnames(tab) <- c('estimate','SE','CI_025','CI_975')
  tab <- as.data.frame(tab)
  tab$sig95 <- splus
  attr(tab, 'note') <- '* indicates that zero is outside the 95% CI'
  
  tab
}
  
meanVarianceScore <- function(output, ktree = 30, maxSite = 100,
                              LAGMAT=F, Q = c(.5, .025, .975), nsim = 1,
                              CLOSE=F){
  
  # ktree   - no. trees visited
  # maxSite - no. m2 visited
  # cyr     - no. years
  # CLOSE = T: sample small neighborhoods (selected to be close)
  # CLOSE = F: random neighborhoods
  
  lagCanopy <- lagGround <- NULL
  
 # sdata   <- output$inputs$seedData
 # tdata   <- output$inputs$treeData

  xytrap  <- output$inputs$xytrap
  xytree  <- output$inputs$xytree
  specNames <- output$inputs$specNames
  seedNames <- output$inputs$seedNames
  seedMass  <- output$inputs$seedMass
  # yrIndex   <- output$data$setupData$yrIndex
  plots   <- sort(unique( as.character(output$prediction$fecPred$plot) ))
  years   <- sort(unique(output$prediction$seedPred$year))
  nplot     <- length(plots)

#  ntree     <- nrow(xytree)
  ntrap     <- nrow(xytrap)
  obsYr     <- colSums(output$inputs$obsYr)
  obsYr     <- as.numeric(names(obsYr)[obsYr > 0])
  years     <- obsYr
  nyr       <- length(years)
  plotDims  <- output$inputs$plotDims
  predList  <- output$inputs$predList
  
  fecPred      <- output$prediction$fecPred
  seedPred     <- output$prediction$seedPred
  seedPredGrid <- output$prediction$seedPredGrid
  
  if(!'x' %in% colnames(seedPred)){
    xytrap <- output$inputs$xytrap
    mm <- match( as.character(seedPred$trapID), as.character(xytrap$trapID) )
    seedPred$x <- xytrap$x[mm]
    seedPred$y <- xytrap$y[mm]
  }
  
  treeID <- sort(unique(as.character(fecPred$treeID)))
  ntree  <- length(treeID)
  fecPred$dcol <- match(as.character(fecPred$treeID),treeID) #DIFFERENT FROM TDATA$DCOL
  
  fmat <- matrix(0, ntree, nyr)
  colnames(fmat) <- obsYr
 # rownames(fmat) <- tdata$treeID[ match( unique(tdata$dcol),tdata$dcol ) ]
  rownames(fmat) <- treeID
  
  if(is.null(seedMass)){
    seedMass <- matrix(1,length(specNames),1)
    rownames(seedMass) <- specNames
  }
  
  scoreT <- scoreS <- deltaT <- deltaS <- numeric(0)
  scoreTse <- scoreSse <- deltaTse <- deltaSse <- numeric(0)
  treeCor <- trapCor <- numeric(0)
  entropy <- domain <- numeric(0)
  resourceScore <- resourceMean <- totalVar <- numeric(0)
  win <- floor(nyr/2)
  if(win > 10)win <- 10
  
  GRID <- SMASS <- F
  
 # trapID <- as.character(seedPred$trapID)
  sid <- columnPaste(seedPred$x, seedPred$y, 'U')
  seedPred$trapID <- columnPaste(seedPred$plot, sid)
  allTraps   <- unique(seedPred$trapID)
 # seedPred$x <- xytrap$x[match(trapID,xytrap$trapID)]
 # seedPred$y <- xytrap$y[match(trapID,xytrap$trapID)]
  meanCols <- grep('_meanGmM2', colnames(seedPred))
  if(length(meanCols) == 0){
    meanCols <- grep('_meanM2', colnames(seedPred))
    rs       <- columnSplit(colnames(seedPred)[meanCols],'_meanM2')[,1]
    ws       <- which(rs %in% specNames)
    rs       <- rs[ws]
    meanCols <- meanCols[ws]
    rSeedMat <- seedPred[,meanCols,drop=F]*
                matrix(seedMass[rs,1],nrow(seedPred),length(rs),byrow=T)
    colnames(rSeedMat) <- paste(specNames,'_meanGmM2',sep='')
    seedPred <- cbind(seedPred, rSeedMat)
  }
    
  sgrid <- seedPred
  GRID  <- F
  
  #replace with prediction grid if all years predicted
  
  if( !is.null(seedPredGrid) ){
    
    predPlots <- predList$plots
    predYears <- predList$years
    
    oldGrid  <- seedPred
    newGrid  <- numeric(0)
    wcol     <- which(colnames(seedPred) %in% colnames(seedPredGrid))
    massCols <- grep('_meanGmM2', colnames(seedPred))
    areaCols <- grep('_meanM2', colnames(seedPredGrid))
    gcol <- unique(c(colnames(seedPred)[wcol],colnames(seedPredGrid)[areaCols]))
    
    pcols <- c("plot","year","trapID", "drow","area","active", "x","y")  
    
  #  if(length(massCols) == 0){  #uses the seedMass provided in original analysis
      for(m in 1:nplot){  
        
        wn <- which(seedPred$plot %in% plots[m])
        wm <- which(seedPredGrid$plot %in% plots[m])
        myr <- sort(unique(seedPred$year[wn]))           #all obs years in pred grid?
        pyr <- sort(unique(seedPredGrid$year[wm]))
        AYR <- all(myr %in% pyr)
        
        if( AYR & length(wm) > 0 ){
          
          mgrid <- seedPredGrid[wm,gcol]
          mcols <- grep('_meanM2', colnames(mgrid))
          
    #      acc   <- seedPredGrid[wm, areaCols, drop=F]
    #      mgrid <- cbind(mgrid, acc)
          
          rs    <- columnSplit(colnames(mgrid)[mcols],'_meanM2')[,1]
          rSeedMat <- mgrid[,mcols,drop=F]*
            matrix(seedMass[rs,1],nrow(mgrid),length(rs),byrow=T)
          colnames(rSeedMat) <- paste(specNames,'_meanGmM2',sep='')
          mgrid <- cbind(mgrid[,-mcols], rSeedMat)
          
          newGrid <- rbind(newGrid, mgrid)
          if(length(oldGrid) > 0){
            wo <- which(oldGrid$plot %in% plots[m])
            if(length(wo) > 0)oldGrid <- oldGrid[-wo,]
          }
        }
      }
   # }
    
    if(length(newGrid) > 0){
      rownames(oldGrid) <- NULL
      poo   <- match(pcols, colnames(oldGrid))
      pnn   <- match(pcols, colnames(newGrid))
      poo <- poo[is.finite(poo)]
      pnn <- pnn[is.finite(pnn)]
      mn  <- grep('_meanGmM2', colnames(newGrid))
      mc  <- grep('_meanGmM2', colnames(oldGrid))
      sgrid <- rbind(newGrid[,c(pnn,mn)],oldGrid[,c(poo, mc)])
    }
    GRID  <- T
  }
  
  meanCols <- grep('_meanGmM2', colnames(sgrid))
 
  trapID  <- as.character(sgrid$trapID)
  allTrap <- sort(unique(trapID))
  ntrap   <- length(allTrap)
  smat <- matrix(0, ntrap, nyr)
  rownames(smat) <- allTrap
    
  colnames(smat) <- obsYr
  meanNames <- c('trees_PerTree','sites_PerSite','trees_PerYr', 'sites_PerYr')
  eNames <- c('tree-tree','site-site','tree-lag','site-lag')
  scoreNames <- c('gmTree','gmM2',eNames)
  
  kk   <- 0
  if(nsim > 1){
    pbar <- txtProgressBar(min=1,max=nplot*nsim,style=1)
    cat('\nScore\n')
  }
  
  fecAll <- seedAll <- numeric(0)   #mass basis
  totalScore <- numeric(0)
  
  if(win > 1){
    
    rjtree <- rjtrap <- rjall <- character(0)
    
    darea <- 100
    ddist <- round( sqrt(darea), 0)
    rseq  <- c(0, seq(10, 2000, by = ddist))
    
    for(m in 1:nplot){
      
      wp <- fecPred$plot == plots[m]
      wo <- fecPred$obs == 1
      wm <- fecPred$matrEst > .3
      wy <- fecPred$year %in% obsYr
      
      wk <- wp&wo&wm&wy
      wc <- which(wk)
      
      if(length(wc) == 0)next
      
      yrm <- sort(unique(c(fecPred$year[wp],sgrid$year[sgrid$plot == plots[m]])))
      yrm <- yrm[yrm %in% obsYr]
      
   #   dm   <- tdata$dcol[wc]
      dm <- fecPred$dcol[wc]
      
      dr   <- unique(dm)             # unique trees
      
      if(length(dr) <= 1)next
      
      
      ym   <- fecPred$year[wc]
      ym   <- match(ym,obsYr)
      
      ytab  <- table(fecPred$year[wc])
      ykeep <- as.numeric(names(ytab))[ytab > 0]
      ckeep <- match(ykeep, obsYr)
      
      emat <- rmat <- vmat <- matrix(0, nsim, 4)
      cmat <- matrix(0, nsim, 6)
      size <- matrix(0, nsim, 5)
      
      #   ctree <- length(dr)
      tseq  <- c(1:length(dr))
      
      scols <- paste('0_',c(0:win),sep='')
      
      ssmat <- matrix(0, length(rseq), length(scols))
      colnames(ssmat) <- scols
      rownames(ssmat) <- rseq
      
      tdmat <- matrix(0, length(tseq),length(scols))
      colnames(tdmat) <- scols
      rownames(tdmat) <- tseq
      
      sdmat <- nsdmat <- ssmat <- nstmat <- ssmat*0
      tdmat <- ntdmat <- ttmat <- nttmat <- tdmat*0
      
      sdmat2 <- ssmat2 <- ssmat*0
      tdmat2 <- ttmat2 <- tdmat*0
      
      rjtree <- c(rjtree,plots[m])
      
      fmat <- fmat*0
      
      yall <- sort(unique(fecPred$year[wc]))
      nyrk <- length(yall)
      
      tkeep <- ckeep
      
      fmat[ cbind(dm,ym) ] <- fecPred$fecEstMu[wc]
      rkeep <- which(rowSums(fmat) > .99)
      fm  <- fmat[drop=F,rkeep,tkeep]
      sm   <- fecPred$species[match(rownames(fm),
                                    as.character(fecPred$treeID)) ]
      sm   <- as.character( sm )
      rvec <- seedMass[sm, 1]
      
   #   spec <- fecPred$species[ match(rownames(fmat),as.character(fecPred$treeID)) ]
   #   spec <- as.character(spec)spec
      
      fr <- fm*rvec
      rownames(fr) <- columnPaste(rownames(fr),names(rvec),'_')
      
      
      fecAll <- append(fecAll, list(fr))    # all fecund trees, mass basis
      names(fecAll)[length(fecAll)] <- plots[m]
      
      totTT  <- totTT2 <- totSS <- totSS2 <- 0
      ntt <- nss <- 0
      
      for(k in 1:nsim){
        
        kk <- kk + 1
        if(nsim > 1)setTxtProgressBar(pbar, kk)
        
        entTtree <- entTseed <- entYtree <-  entYseed <- rtot <- rTtree <- 
          rTseed <- rYtree <- rYseed <- Tk <- Ts <- Yk <- Ys <- carea <- 
          varTk <- varTs <- varYk <- varYs <- NA
        
        fcor <- NULL

        if(length(dr) > 1){   # canopy 
          
          rkeep <- 1:nrow(fm)
          fk <- fm*rvec       #CHANGED TO MASS
          if(length(rkeep) > ktree)rkeep <- sample(rkeep, ktree)
     #     fk    <- fm[drop=F,rkeep,tkeep]
          fk    <- fm[drop=F,rkeep,]
          
      #    fm <- fmat
          
          if(length(fk) > 2 & length(tkeep) > 2){
            
            nyrk <- ncol(fk)
            ntrk <- nrow(fk)
            
        #    sm   <- tdata$species[ match(rownames(fm),tdata$treeID) ]

            
            if(k == 1){
              fcor <- makeCrossCov( tmat = fk, win = win, MATRIX=T, COR=T )[[1]]
              fcor[!is.finite(fcor)] <- 0
            }
            
            if(LAGMAT){
              
              ff <- sample(nrow(fk))
              
              tt <- makeCrossCov( tmat = fk[drop=F,ff,], win = win, MATRIX=T, COR=F )
              mcov <- tt$lagCov
              
              if(length(mcov) > 1){
                
                tmu  <- tt$lagMean
                tmean <- mean(tmu[,1])
                
                  ############################# total space-time covariance
                  
                  ml     <- as.numeric( columnSplit(colnames(mcov),'_')[,2] )   
                  maxLag <- 1 + max(ml)
                  
                  hh <- grep('_-', colnames(mcov))
                  totCov <- mcov[drop=F,,-hh]
                  nn <- cbind(rownames(totCov), paste(rownames(totCov),'_0',sep=''))
                  totVar <- totCov[nn]*maxLag # each variance repeated for each lag (2nd-order stat.)
                  totCov[nn] <- 0
                  scov   <- sum(totCov*2)       # covariance twice
                  totVar <- sum(totVar) + scov
                  totMu  <- sum(tmu[,1])
                  totScore <- log(totMu) - 1/2*log(totVar)
                  
                  tot <- cbind(totMu, totVar, totScore)
                  totTT  <- totTT + tot
                  totTT2 <- totTT2 + tot^2
                  ntt <- ntt + 1
 
                
                gg <- grep( paste(rownames(mcov)[1],'_-',sep=''), 
                            colnames(mcov) )                      #based on first site
                gg <- c(grep(paste(rownames(mcov)[1],'_0', sep=''), 
                             colnames(mcov) ), gg)
                tmu <- tmu[,gg,drop=F]
                
                scov <- mcov[,gg,drop=F]
                vars <- mcov[ cbind(rownames(mcov), paste(rownames(mcov),'_0',sep='')) ]
                vars <- matrix(vars, nrow(scov), ncol(scov))
                
                scov[-1] <- scov[-1]*2   #covariances count twice
                
                wtrow <- matrix(1:nrow(scov),nrow(scov),ncol(scov)) 
                wtcol <- matrix(1:ncol(scov),nrow(scov),ncol(scov), byrow=T) 
                
                v1 <- wtcol*vars[1]   # count diagonal elements
                v2 <- wtrow*vars
                
                scov[1] <- 0
                scov <- scov + v1 + v2
                
                scum0 <- t(apply(scov, 1, cumsum))
                scum  <- apply(t(scum0), 1, cumsum)
                if(!is.matrix(scum))scum <- scum0*0 + scum
                
                
                tcum0 <- t(apply(tmu, 1, cumsum))
                tcum <- apply(t(tcum0), 1, cumsum)
                if(!is.matrix(scum))tcum <- tcum0*0 + tcum
                
                
                tscore <- log(tcum) - 1/2*log(scum)
                rscore <- log( sum(tmu) ) - 1/2*log( length(tmu)*var(as.vector(fm)) )
                delta  <- tscore - rscore
                
                ir <- 1:nrow(delta)
                ic <- 1:ncol(delta)
                
                tdmat[ir,ic]  <- tdmat[ir,ic] + delta
                tdmat2[ir,ic] <- tdmat2[ir,ic] + delta^2
                ntdmat[ir,ic] <- ntdmat[ir,ic] + 1
                ttmat[ir,ic]  <- ttmat[ir,ic] + tscore
                ttmat2[ir,ic] <- ttmat2[ir,ic] + tscore^2
                nttmat[ir,ic] <- nttmat[ir,ic] + 1
              }
            }
            
      #      names(rvec) <- sm
      #      rmm   <- fm*rvec      
            rmm   <- fk               #ALREADY MASS UNITS (SEE ABOVE)
            wm    <- which(rmm > 0)
            rtree <- mean( rmm[wm] ) # mean per reproductive tree
            
            Tk  <- cov(t(rmm))       # tree cov
            Yk  <- cov(rmm)          # year cov
            
            varTk <- sum(Tk)
            varYk <- sum(Yk)
            
            rTtree <- rYtree <- sum(rmm)
            
            if(!is.na(max(Tk))){
              tmp        <- var2score(rTtree, varTk, Tk) # var between trees 
              entTtree   <- tmp$entropy
            }
            if(!is.na(max(Yk))){
              tmp        <- var2score(rYtree, varYk, Yk) # var between years
              entYtree   <- tmp$entropy
            }
          } #end canopy
          
          lagCanopy <- append(lagCanopy, list(fcor))
          
        }
        
        ############# seed traps or seed prediction grid
        
        smat <- smat*0
        
        wy <- unique(sgrid$year[sgrid$plot == plots[m]])
        wy <- wy[wy %in% obsYr]
        wm <- which(sgrid$plot == plots[m] & 
                      sgrid$year == wy[1])
        ix <- sample(wm, 1)
        wo <- wm[wm != ix]
        
        dist <- NULL
        scor <- NULL
        
        if(CLOSE){
          distSite <- .distmat( sgrid$x[ix], sgrid$y[ix], 
                                sgrid$x[wo], sgrid$y[wo] )
          oo <- order(distSite)
          #     if(length(oo) > cspace)oo <- oo[1:(cspace-1)]
          wm <- c(ix,wo[oo])
          dist <- c(0,distSite[oo])
        }else{
          #     if(length(wm) > cspace)wm <- sample(wm,cspace)
        }
        
        trapIDS <- as.character( sgrid$trapID[wm] )
        if(!is.null(dist))names(dist) <- trapIDS
        wm <- which( as.character(sgrid$trapID) %in% trapIDS &
                       sgrid$year %in% yrm &
                       sgrid$plot == plots[m])
        j <- match(sgrid$year[wm], obsYr)
        i <- match(as.character(sgrid$trapID[wm]),rownames(smat))
        
        smat[ cbind(i,j) ] <- rowSums(sgrid[wm, meanCols,drop=F],
                                      na.rm=T)
        
        yall <- sort(unique(j))
        nyrj <- length(yall)
        
        wsp <- columnSplit(rownames(smat),'-')[,1]
        rkeep <- which(wsp == plots[m])
        
        #    rkeep <- which(rowSums(smat) > 0)
        rmm <- smat[drop=F, rkeep, as.character(yrm)]
        
        if(k == 1){
          seedAll <- append(seedAll, list(rmm))
          names(seedAll)[length(seedAll)] <- plots[m]
        }
        
        crr <- which(colSums(rmm) > 0)
        rmm <- rmm[,crr]
        
        
        gind  <- match(rownames(rmm),sgrid$trapID)
        carea <- diff(range(sgrid$x[gind]))*
          diff(range(sgrid$y[gind]))
        if(carea == 0 | !is.finite(carea))carea <- 100
        
        
        if(LAGMAT & length(crr) > 2){
          
          if(!is.null(dist)){
            attr(rmm,'distance') <- dist
            i  <- findInterval(dist,rseq)
            ii <- rep( i, ncol(rmm) )
            jj <- rep( 1:ncol(rmm), each=nrow(rmm) )
            tmp <- .myBy(as.vector(rmm), ii, jj, fun='mean')*darea  # per m2
            rownames(tmp) <- rseq[ min(i):max(i) ]
            colnames(tmp) <- colnames(rmm)
            tmp <- tmp[,colSums(tmp) != 0, drop=F]
            tmp <- tmp[drop=F, rowSums(tmp) != 0,]
          }else{
            tmp <- rmm
            if(nrow(tmp) > maxSite)tmp <- tmp[sample(nrow(rmm),maxSite),]
          }
          
          tt   <- makeCrossCov( tmat = tmp, win = win, MATRIX=T, COR=F )
          mcov <- tt$lagCov
          tmu  <- tt$lagMean
          
          if(length(mcov) > 1){
            

              ml     <- as.numeric( columnSplit(colnames(mcov),'_')[,2] )   
              maxLag <- 1 + max(ml)
              
              hh <- grep('_-', colnames(mcov))
              totCov <- mcov[drop=F,,-hh]
              nn <- cbind(rownames(totCov), paste(rownames(totCov),'_0',sep=''))
              totVar <- totCov[nn]*maxLag # each variance repeated for each lag (2nd-order stat.)
              totCov[nn] <- 0
              scov   <- sum(totCov*2)       # covariance twice
              totVar <- sum(totVar) + scov
              totMu  <- sum(tmu[,1])
              totScore <- log(totMu) - 1/2*log(totVar)
              
              tot <- cbind(totMu, totVar, totScore)
              
              totSS <- totSS + tot
              totSS2 <- totSS2 + tot^2
              nss <- nss + 1

          }
          
          zrows <- rownames(mcov)
          zcols <- paste(rownames(mcov),'_0',sep='')
          
          if(!is.null(dist)){
            
            p1 <- paste('^',rownames(mcov)[1],'_',sep='')
            
            gg <- grep(p1,colnames(mcov))
            scov <- mcov
            #      if(length(gg) > 0){
            scov <- mcov[,gg, drop=F]
            tmu <- tmu[,gg, drop=F]
            #      }
            gg <- grep('-',colnames(scov))
            hh <- grep('_0',colnames(scov))
            gg <- sort(c(gg,hh))
            scov <- scov[,gg, drop=F]
            tmu <- tmu[,gg, drop=F]
            
          }else{
            gg <- grep( paste(rownames(mcov)[1],'_-',sep=''), 
                        colnames(mcov) )
            gg <- c(grep(paste(rownames(mcov)[1],'_0', sep=''), 
                         colnames(mcov) ), gg)
            scov <- mcov[,gg]
            tmu <- tmu[,gg]
            
            wz    <- which(!zcols %in% colnames(mcov))
            if(is.matrix(scov) & length(wz) > 0){
              zcols <- zcols[-wz]
              zrows <- zrows[-wz]
              scov  <- scov[-wz,]
              tmu   <- tmu[-wz,]
            }
            #   vars <- mcov[ cbind(zrows, zcols) ]
          }
          
          
          if(length(mcov) > 2)vars <- mcov[ cbind(zrows, zcols) ]
          
          if(is.matrix(scov)){
            
            vars <- matrix(vars, nrow(scov), ncol(scov))
            
            scov[-1] <- scov[-1]*2   #covariances count twice
            
            wtrow <- matrix(1:nrow(scov),nrow(scov),ncol(scov)) 
            wtcol <- matrix(1:ncol(scov),nrow(scov),ncol(scov), byrow=T) 
            
            v1 <- wtcol*vars[1]   # count diagonal elements
            v2 <- wtrow*vars
            
            scov[1] <- 0
            scov <- scov + v1 + v2
            
            scum <- t(apply(scov, 1, cumsum))
            scum <- apply(t(scum), 1, cumsum)
            
            tcum <- t(apply(tmu, 1, cumsum))
            tcum <- apply(t(tcum), 1, cumsum)
            
            tscore <- log(tcum) - 1/2*log(scum)
            rscore <- log( sum(tmu) ) - 1/2*log( length(tmu)*var(as.vector(tmp)) )
            delta  <- tscore - rscore
            
            delta  <- vec2mat(delta)
            tscore <- vec2mat(tscore)
            
            if(!is.null(dist)){
              if(is.null(rownames(delta)))
                rownames(delta) <- rownames(tscore) <- rownames(scov)
              rownames(delta) <- rownames(tscore) <- 
                columnSplit(rownames(delta),'_')[,1]
              colnames(delta) <- colnames(tscore) <- 
                colnames(ssmat)[1:ncol(delta)]
            }else{
              rownames(delta) <- rownames(tscore) <- 
                rownames(sdmat)[1:nrow(delta)]
              ccc <- columnSplit(colnames(delta),'_')[,2]
              ccc <- .replaceString(ccc,'-','')
              ccc <- paste('0_',ccc,sep='')
              colnames(delta) <- colnames(tscore) <- ccc
            }
            
            #      ir <- 1:nrow(delta)
            ic <- 1:ncol(delta)
            rd <- rownames(delta)
            
            sdmat[rd, ic]  <- sdmat[rd, ic] + delta
            sdmat2[rd, ic] <- sdmat2[rd, ic] + delta^2
            nsdmat[rd, ic] <- nsdmat[rd, ic] + 1
            ssmat[rd, ic]  <- ssmat[rd, ic] + tscore
            ssmat2[rd, ic] <- ssmat2[rd, ic] + tscore^2
            nstmat[rd, ic] <- nstmat[rd, ic] + 1
          }
          
          
          if(k == 1){
            scor <- makeCrossCov( tmat = tmp, win = win, MATRIX=T, COR=T )[[1]]
            scor[!is.finite(scor)] <- 0
            
            rjtrap   <- c(rjtrap, plots[m])
          }
        }
        
        if(k == 1)lagGround <- append(lagGround, list(scor))
        
        if(is.matrix(rmm) & length(rmm) > 1){
          
          rtot <- sum(rmm)
          
          Ts <- cov(t(rmm))  # site cov
          Ys <- cov(rmm)     # year cov
          
          varTs <- sum(Ts)
          varYs <- sum(Ys)
          
          rTseed <- rYseed <- sum(rmm)
          
          tmp        <- var2score(rTseed, varTs, Ts)
          entTseed   <- tmp$entropy
          tmp        <- var2score(rYseed, varYs, Ys)
          entYseed   <- tmp$entropy
          
          n1 <- n2 <- n3 <- n4 <- NA
          if(is.matrix(Tk))n1 <- nrow(Tk)
          if(is.matrix(Ts))n2 <- nrow(Ts)
          if(is.matrix(Yk))n3 <- nrow(Yk)
          if(is.matrix(Ys))n4 <- nrow(Ys)
          
          emat[k,] <- c(entTtree, entTseed, entYtree, entYseed)
          cmat[k,] <- c(rtree, rtot)
          rmat[k,] <- c(rTtree, rTseed, rYtree, rYseed)
          size[k,] <- c(n1,n2,n3, n4, round(carea)) 
          vmat[k,] <- c(varTk, varTs, varYk, varYs)
        }
      }
      
      tcm <- totTT/ntt
      tcs <- sqrt( totTT2/ntt - tcm^2 )
      tgm <- totSS/nss
      tgs <- sqrt( totSS2/nss - tgm^2 )
      
      totScore <- rbind( cbind(tcm, tcs), cbind(tgm, tgs) )
      colnames(totScore) <- paste( c(rep('canopy',3),rep('ground',3)),
                                   colnames(totScore),sep='_' )
      rownames(totScore) <- paste(plots[m],c('mu','se'),sep='_')
      
      totalScore <- rbind(totalScore,totScore)
      
     
    if( LAGMAT){
      TREE <- GROUND <- T
      deltaTree <- scoreTree <- deltaSeed <- scoreSeed <- 
        deltaTrSe <- scoreTrSe <- deltaSdSe <- scoreSdSe <- NULL
      
      if(sum(ntdmat) == 0)TREE <- F
      if(sum(nttmat) == 0)GROUND <- F
      
      if(TREE){
        deltaTree <- tdmat/ntdmat
        scoreTree <- ttmat/nttmat
        deltaTrSe <- tdmat2/ntdmat - deltaTree^2
        scoreTrSe <- ttmat2/nttmat - scoreTree^2
        wr <- which(rowSums(deltaTree,na.rm=T) != 0)
        wc <- which(colSums(deltaTree,na.rm=T) != 0)
        deltaTree <- deltaTree[drop=F,wr,wc]
        deltaTrSe <- sqrt(deltaTrSe[drop=F,wr,wc])
        scoreTree <- scoreTree[drop=F,wr,wc]
        scoreTrSe <- sqrt(scoreTrSe[drop=F,wr,wc])
      }
      if(GROUND){
        deltaSeed <- sdmat/nsdmat
        scoreSeed <- ssmat/nstmat
        deltaSdSe <- sdmat2/nsdmat - deltaSeed^2
        scoreSdSe <- ssmat2/nstmat - scoreSeed^2
        wr <- which(rowSums(deltaSeed,na.rm=T) != 0)
        wc <- which(colSums(deltaSeed,na.rm=T) != 0)
        deltaSeed <- deltaSeed[drop=F,wr,wc]
        scoreSeed <- scoreSeed[drop=F,wr,wc]
        deltaSdSe <- sqrt(deltaSdSe[drop=F,wr,wc])
        scoreSdSe <- sqrt(scoreSdSe[drop=F,wr,wc])
      }
      
      deltaT <- append(deltaT, list(deltaTree))
      deltaS <- append(deltaS, list(deltaSeed))
      scoreT <- append(scoreT, list(scoreTree))
      scoreS <- append(scoreS, list(scoreSeed))
      deltaTse <- append(deltaTse, list(deltaTrSe))
      deltaSse <- append(deltaSse, list(deltaSdSe))
      scoreTse <- append(scoreTse, list(scoreTrSe))
      scoreSse <- append(scoreSse, list(scoreSdSe))
      
    }
    
    emat[!is.finite(emat)] <- NA
    
    ee <- signif(t( apply(emat, 2, quantile, Q,na.rm=T )),3)
    rownames(ee) <- paste(plots[m],eNames,sep='_')
    vv <- t( apply(vmat, 2, quantile, Q,na.rm=T ))
    rownames(vv) <- paste(plots[m],eNames,sep='_')
    
    rjall <- c(rjall,plots[m])
    
    ii     <- apply(size,2,mean)
    domain <- rbind(domain, ii)
    
    entropy  <- rbind( entropy, ee )
    totalVar <- rbind( totalVar, vv)
    
    #   if(LAGMAT){
    #     treeCor <- append(treeCor, list(signif(fcor,3)))
    #     trapCor <- append(trapCor, list(signif(scor,3)))
    #   }
    
  } #########end plot loop
  
    if(LAGMAT){
      if(length(lagCanopy) > 0)names(lagCanopy) <- rjtree
      if(length(lagGround) > 0)names(lagGround) <- rjtrap
      names(scoreT) <- rjtree
        names(scoreS) <- rjtrap
      names(deltaT) <- rjtree
        names(deltaS) <-  rjtrap
    }
    
    if(length(domain) > 0){
      rownames(domain) <- rjall
      colnames(domain) <- c('trees','sites','treeYr','siteYr','areaM2')
    }
    
    VtreeXtree <- VsiteXsite <- VtreeXlag <- VsiteXlag <- NULL
    
    if(length(totalVar) > 0){
      tpr <- paste(rjtree,'tree-tree',sep='_')
      VtreeXtree <- totalVar[drop=F,tpr,]
      tpr <- paste(rjtree,'site-site',sep='_')
      VsiteXsite <- totalVar[drop=F,tpr,]
      tpr <- paste(rjtree,'tree-lag',sep='_')
      VtreeXlag <- totalVar[drop=F,tpr,]
      tpr <- paste(rjtree,'site-lag',sep='_')
      VsiteXlag <- totalVar[drop=F,tpr,]
      
      rownames(VtreeXtree) <- columnSplit(rownames(VtreeXtree),'_tree-tree')[,1]
      rownames(VsiteXsite) <- columnSplit(rownames(VsiteXsite),'_site-site')[,1]
      rownames(VtreeXlag)  <- columnSplit(rownames(VtreeXlag),'_tree-lag')[,1]
      rownames(VsiteXlag)  <- columnSplit(rownames(VsiteXlag),'_site-lag')[,1]
    }
    
  }else{
    domain <- entropy <- 
      VtreeXtree <- VsiteXsite <- VtreeXlag <- VsiteXlag <- NULL
  }
  
  tmp <- list(domain = domain, entropy = entropy, 
       treeXtreeVar = VtreeXtree, siteXsiteVar = VsiteXsite, 
       treeXlagVar = VtreeXlag, siteXlagVar = VsiteXlag)
  if(LAGMAT){
    tmp$lagCanopy <- lagCanopy
    tmp$lagGround <- lagGround
    tmp$scoreSeed <- scoreS
    tmp$scoreTree <- scoreT
    tmp$deltaSeed <- deltaS
    tmp$deltaTree <- deltaT
    tmp$scoreSeedSe <- scoreSse
    tmp$scoreTreeSe <- scoreTse
    tmp$deltaSeedSe <- deltaSse
    tmp$deltaTreeSe <- deltaTse
  }
  for(k in 1:length(tmp)){
    if(is.null(tmp[[k]]) | is.numeric(0))next
    kcol <- which(sapply(tmp[[k]],is.numeric))
    jcol <- which(sapply(tmp[[k]],is.factor))
    kcol <- intersect(kcol,!jcol)
    for(j in kcol){
      tmp[[k]][,j][ is.finite( tmp[[k]][,j] ) ] <- NA
    }
  }
  tmp$fecAll  <- fecAll
  tmp$seedAll <- seedAll
  tmp$totalScore <- totalScore
    
  tmp
    
}





 
plotMeanVarScoreByDim <- function(x, mu, lo=NULL, hi=NULL, xlab='',
                                  ylab='score', ylim=NULL, YLOG=F,
                                  LINES = T, UNLOGY=F){
  BARS <- F
  if(!is.null(lo))BARS <- T
  if(UNLOGY){
    mu <- exp(mu)
    if(BARS){
      lo <- exp(lo)
      hi <- exp(hi)
    }
  }
  
  if(is.null(ylim)){
    if(!is.null(lo)){
      ylim <- range(c(lo, hi), na.rm=T)
    }else{
      ylim <- range(mu, na.rm=T)
    }
  }
  xlim <- range(x, na.rm=T)
  xlim[2] <- xlim[2] + .2
  xlim[1] <- xlim[1] - .2
  
  gfun <- colorRampPalette( c("forestgreen","#8DD3C7", "#BEBADA", "#FB8072",
                              "#80B1D3", "#FDB462", "brown") )
  plotCol <- gfun(ncol(mu))
  
  #  xs <- 1 + seq(-.2,.2,length=ncol(mu))
  
  if(!YLOG){
 #   plot(NULL, xlim = xlim, ylim = ylim, xlab=xlab, ylab=ylab, log='x')
    plot(NULL, xlim = xlim, ylim = ylim, xlab=xlab, ylab=ylab)
  }else{
    if(ylim[1] == 0)ylim[1] <- .01
    plot(NULL, xlim = xlim, ylim = ylim, xlab=xlab, ylab=ylab, log='xy')
  }
  for(j in 1:ncol(mu)){
    xs <- x[,j]
    xs[xs < xlim[1]] <- xlim[1]
  #  points(xs, mu[,j], col=plotCol[j], lwd=2)
    lohi <- cbind(lo[,j], hi[,j])
    .shadeInterval(xs, loHi=lohi, add=T, col=.getColor(plotCol[j],.1))
  #  if(LINES)lines(xs, mu[,j], col=plotCol[j], lwd=2)
  #  if(BARS){
  #    suppressWarnings(arrows(xs, lo[,j], xs, hi[,j], col=plotCol[j],
  #                 angle=90, length=.04, code=3))
  #  }
  }
  for(j in 1:ncol(mu)){
    xs <- x[,j]
    xs[xs < xlim[1]] <- xlim[1]
    lines(xs, mu[,j], col='white', lwd=4)
#    lines(xs, mu[,j], col=plotCol[j], lwd=2)
#  }
  }
  for(j in 1:ncol(mu)){
    xs <- x[,j]
    xs[xs < xlim[1]] <- xlim[1]
#    lines(xs, mu[,j], col='white', lwd=4)
    lines(xs, mu[,j], col=plotCol[j], lwd=2)
    #  }
  }
}

var2score <- function(rmean, totVr, rvar){
  
  # rmean - mean over sites or years
  # rvar  - covariance matrix
  # totVr - total variance
  # ndim  - dimension of covariance matrix
  
  if(length(rvar) < 4)return( list(score = NA, entropy = NA) )
  
  ndim <- nrow(rvar)
  
  score <- log(rmean) - 1/2*suppressWarnings(log(totVr))
  dt    <- determinant(rvar)$modulus
  if(!is.finite(dt)){
    ev <- eigen(rvar)$values
    dt <- sum( log(ev[ev > 0]) )
  }
  entr  <- ndim/2*(1 + log(2*pi)) + dt/2
  entr  <- entr/ndim
  list(score = score, entropy = entr)
}

plotMeanVarScore <- function(MVS, x1 = 'treeXtreeMu', xlim = NULL,
                             ylim = NULL, xlab=NULL, ylab=NULL, BARS=T, TEXT=F){
  
 # rmean <- MVS$resourceMean
 # score <- MVS$resourceScore
  pl    <- MVS$plots
  
  if(is.null(ylab))ylab <- 'Score'
  
  if(x1 == 'treeXtreeMu'){
    x <- MVS$treeXtreeMu
    y <- MVS$treeXtreeScore
    if(is.null(xlab))xlab <- 'g/tree'
  }
  if(x1 == 'treeXlagMu'){
    x <- MVS$treeXlagMu
    y <- MVS$treeXlagScore
    if(is.null(xlab))xlab <- 'g/tree'
  }
  if(x1 == 'siteXsiteMu'){
    x <- MVS$siteXsiteMu
    y <- MVS$siteXsiteScore
    if(is.null(xlab))xlab <- 'g/m2'
  }
  if(x1 == 'siteXlagMu'){
    x <- MVS$siteXlagMu
    y <- MVS$siteXlagScore
    if(is.null(xlab))xlab <- 'g/m2'
  }
  
  cex <- 1
  if(TEXT)cex = .01
  
  plots <- rownames(x)
  nplot <- length(plots)
  gfun <- colorRampPalette( c("forestgreen","#8DD3C7", "#BEBADA", "#FB8072",
                              "#80B1D3", "#FDB462", "brown") )
  plotCol <- gfun(nplot)
  names(plotCol) <- plots
  
  if(is.null(ylim))ylim <- range(y,na.rm=T)
  if(is.null(xlim))xlim <- range(x,na.rm=T)
  plot(x[,1], y[,1], ylim = ylim, xlab='g/tree',
       ylab='', log='x', xlim = xlim, col=plotCol, cex=cex)
  if(TEXT)text(x[,1], y[,1], plots, col=plotCol)
  if(BARS){
    segments(x[,1], y[,2],x[,1], y[,3], col=plotCol)
    segments(x[,2], y[,1],x[,3], y[,1], col=plotCol)
  }
  invisible(plotCol)
}

crossCovSetup <- function(tmat, win){
  
  nt <- ncol(tmat)
  if(win > nt/2)win <- floor(nt/2)
  
  ni    <- nrow(tmat)
  lead  <- -c(-win:win)
  ntt   <- length(lead)
  mgrid <- as.matrix( expand.grid(1:ntt,1:ni,1:ni ) )
  colnames(mgrid) <- c('t','i1','i2')
  
  ld    <- lead[mgrid[,'t']]
  mgrid <- cbind(ld,mgrid)
  colnames(mgrid)[1] <- 'lead'
  
  cc    <- columnPaste(mgrid[,'i1'],mgrid[,'i2'])
  mdex  <- columnPaste(mgrid[,'t'],cc)
  keep  <- which(mgrid[,'i2'] >= mgrid[,'i1'])
  mgrid <- mgrid[keep,]
  mdex  <- mdex[keep]
  
  mgrid <- as.data.frame(mgrid)
  
  rn <- rownames(tmat)
  if(!is.null(rn)){
    mgrid$ID1 <- rn[mgrid[,'i1']]
    mgrid$ID2 <- rn[mgrid[,'i2']]
  }
    
  list(win = win, ntt = ntt, ni = ni, mgrid = mgrid, 
       mdex = mdex, lead = lead)
}
  
makeCrossCov <- function(tmat, win = 5, MATRIX=F, COR=F ){
  
  # tmat - responses by time matrix
  # cross covariance of each row against population
  # MATRIX  - n by n*lag matrix
  # !MATRIX - n*n*lag vector
  # COR - correlation matrix
  
  tiny <- 1e-8
  
  nt  <- ncol(tmat)
  mid <- round(nt/2)
  rt  <- mid + c(-win,win)
  
  if(rt[2] <= rt[1])return(NULL)
  
  imat <- sweep(tmat, 1, rowMeans(tmat), '-')
  imat[imat == 0] <- tiny                        # no variation
  
  if(win > (ncol(tmat)-1))win <- ncol(tmat) - 1
  
  tmp <- crossCovSetup(tmat, win)
  ntt <- tmp$ntt
  ni  <- tmp$ni
  mgrid <- tmp$mgrid
  mdex  <- tmp$mdex
  lead  <- tmp$lead
  win   <- tmp$win
  
  crossCov <- rep(0,length(mdex))
  names(crossCov) <- mdex
  totSeed <- crossCov
  
  if(COR)ivar <- apply(imat,1,var)*(nt-1)/nt
  
  for(i in 1:(win+1)){
    
    ii <- 1:(nt - win + i - 1)
    pp <- (win - i + 2):nt
    
    ii  <- ii[ii > 0]
    pp  <- pp[pp <= nt]
    ldd <- pp[1] - ii[1]
    
    for(m in 1:ni){
      wm   <- which(mgrid[,'i1'] == m & mgrid[,'lead'] == ldd )
      mdx  <- mgrid[drop=F,wm,]
      
      tres <- rowMeans( imat[mdx[,'i1'],ii,drop=F]*imat[mdx[,'i2'],pp,drop=F] )
      
      tm2 <- tmat[mdx[,'i2'],pp,drop=F]
      if(ldd == 0)tm2[ rownames(tm2) == rownames(tmat[mdx[,'i1'],]) ] <- 0
      tsum <- rowMeans( tmat[mdx[,'i1'],ii,drop=F] + tm2 )
      
      if(COR)tres <- tres/sqrt(ivar[mdx[1,'i1']]*ivar[mdx[,'i2']])
      crossCov[ wm ] <- tres
      totSeed[ wm ]  <- tsum
        
      if(ldd != 0){
        wm   <- which(mgrid[,'i1'] == m & mgrid[,'lead'] == -ldd )
        mdx  <- mgrid[drop=F,wm,]
        tres <- rowMeans( imat[mdx[,'i1'], pp,drop=F]*imat[mdx[,'i2'], ii,drop=F] )
        if( identical(mdx[,'i1'], mdx[,'i2']) ){
          tres <- rowMeans( tmat[mdx[,'i1'],ii,drop=F] )
        }else{
          tsum <- rowMeans( tmat[mdx[,'i1'], pp,drop=F] + tmat[mdx[,'i2'], ii,drop=F] )
        }
        
        if(COR)tres <- tres/sqrt(ivar[mdx[1,'i1']]*ivar[mdx[,'i2']])
        crossCov[ wm ] <- tres
        totSeed[ wm ] <- tsum
      }
    }
  }
  
  totSeed <- round(totSeed, 2)
  
  covMu <- cbind(mgrid, crossCov, totSeed)
  
#  wt  <- which(covMu[,'crossCov'] != 0)
#  covMu <- covMu[wt,]
  
  if(!MATRIX)return( lagCov = covMu, lagMean = NULL )
  
  t2 <- covMu$t[covMu$lead == 0][1]
  
  rn <- columnPaste(covMu[,'ID1'],covMu[,'lead'],'_')
  cn <- columnPaste(covMu[,'ID2'],t2,'_')
  rt <- rn[!duplicated(rn)]
  ct <- cn[!duplicated(cn)]
  
  stmat <- ttmat <- matrix(0,length(rt),length(ct))
  rownames(stmat) <- rownames(ttmat) <- rt
  colnames(stmat) <- colnames(ttmat) <- ct
  cii <- cbind(rn,cn)
  stmat[ cii ] <- covMu[,'crossCov']
  stmat <- t(stmat)
  
  ttmat <- stmat*0
  tmean <- rowMeans(tmat)
  rm    <- columnSplit(ct,'_')[,1]
  ttmat[1:nrow(ttmat),] <- tmean[rm]
  
 # css <- columnSplit(rownames(stmat),'_')
 # rnn <- css[,1]
 # if( ncol(css) > 2 ){
 #   for(k in 2:(ncol(css)-1)){
 #     rnn <- columnPaste(rnn,css[,k])
 #   }
 # }
  rnn <- columnSplit(rownames(stmat),'_')[,1]
  rownames(stmat) <- rnn
  list(lagCov = stmat, lagMean = ttmat)
}
  
.updateBetaAR <- function(betaYr, yg, mu, z,lagGroup, plag, ngroup, sg)  {
  
  # AR(p), fixed groups
  
  ylag <- yg*0
  
  for(m in 1:ngroup){
    
    lmm <- lagGroup[[m]]
    lmm <- lmm[drop=F,z[lmm[,plag+1]] == 1,]
    if(nrow(lmm) <= (ncol(lmm)+5))next
    
    ym  <- yg[lmm[,1]] - mu[lmm[,1]]
    xm  <- matrix( yg[ lmm[,-1] ], nrow(lmm) )
    V   <- solve( crossprod(xm) )*sg
    v   <- crossprod(xm,ym)/sg
    tmp <- rmvnormRcpp(1,V%*%v,V) 
    whi <- which( abs(tmp) > 1)
    if(length(whi) > 0){
      tmp <- .tnormMVNmatrix(tmp,tmp,V,tmp*0 - 1,tmp*0 + 1, 
                             whichSample=c(1:length(tmp)) )
    }
    betaYr[m,] <- tmp
    
    lmm <- lagGroup[[m]]
    xm  <- matrix( yg[ lmm[,-1] ], nrow(lmm) )
    ylag[lmm[,1]] <- xm%*%t(tmp)
  }
  
  wfinite <- which(!betaYr == 0)
  list( betaYr = betaYr, ylag = ylag, wfinite = wfinite)
}

.updateBetaAR_RE <- function(betaYrF, betaYrR, Alag,
                             yg, mu, z, lagGroup, lagMatrix, plag, ngroup, sg){
  
  # AR(p), random groups
  # betaYrF - 1 by plag fixed effects
  # betaYrR - ngroup by plag random effects
  # Alag    - random effects covariance
  
  ylag <- yg*0
  AIlag <- solve(Alag)
  
  # fixed effects
  cg   <- which(z[lagMatrix[,plag+1]] == 1)  # mature plag yr ago
  
  if(length(cg) <= plag)
    stop('too few mature individuals in AR groups--fewer groups or smaller p')
  lmm  <- lagMatrix[drop=F,cg,]
  xm   <- matrix( yg[ lmm[,-1] ], nrow(lmm))
  mvec <- yg[ lmm[,1] ] - mu[ lmm[,1] ] - 
          rowSums( betaYrR[ lagGroup[cg],]*xm )  # remove random AR effects
  v <- crossprod(xm,mvec)/sg
  V <- solve(crossprod(xm)/sg + diag(1,plag))
 
  tmp <- rmvnormRcpp(1,V%*%v,V) 
  whi <- which( abs(tmp) > 1)                               # for stability (may not be desirable)
  if(length(whi) > 0){
    tmp <- .tnormMVNmatrix(tmp,tmp,V,tmp*0 - 1,tmp*0 + 1, 
                           whichSample=c(1:length(tmp)) )
  }
  
  betaYrF <- tmp
  ylag[lmm[,1]] <- xm%*%t(betaYrF)
  
  if(ngroup == 1) return( list( betaYrF = betaYrF, betaYrR = betaYrR, ylag = ylag, Alag = Alag) )
  
  # random effects
  
  for(m in 1:ngroup){
    tg  <- lagGroup == m
    cg  <- z[lagMatrix[,plag+1]] == 1  # mature plag yr ago
    wm  <- which(tg & cg)
    
    if(length(wm) < 2){      #
      betaYrR[m,] <- 0
      next
    }
      
    if(length(wm) < plag){
      V <- AIlag
      v <- t(betaYrF)*0
    }else{
      lmm <- lagMatrix[drop=F, wm, ]
      xm  <- matrix( yg[ lmm[,-1] ], nrow(lmm) )
      mvec <- yg[lmm[,1]] - mu[lmm[,1]] - xm%*%t(betaYrF)
      v    <- crossprod(xm, mvec)/sg
      V    <- solve(crossprod(xm)/sg + Alag)
    }
    tmp <- rmvnormRcpp(1,V%*%v,V) 
    whi <- which( abs(tmp) > 1)
    if(length(whi) > 0){
      tmp <- .tnormMVNmatrix(tmp,tmp,V,tmp*0 - 1,tmp*0 + 1, 
                             whichSample=c(1:length(tmp)) )
    }
    betaYrR[m,] <- tmp 
    if(length(wm) > plag)ylag[lmm[,1]] <- ylag[lmm[,1]] + xm%*%betaYrR[m,]
  }
  
  bmu <- colMeans(betaYrR)
  
  betaYrR <- betaYrR - matrix(bmu, nrow(betaYrR), ncol(betaYrR), byrow=T) 
  
  # random effects covariance
  LL   <- crossprod(betaYrR)
  Alag <- .updateCovariance(LL, diag(1,plag), ngroup, plag+1)
  
  list( betaYrF = betaYrF, betaYrR = betaYrR, ylag = ylag, Alag = Alag)
}

acfEmp <- function(res, irow, time){
  
  # empirical (for model-based use .updateBetaAc)
  # assumes res values have unique irow and time
  # detrend
  mt <- max(time)
  st <- c(0:(mt-1))
  ni <- max(irow)
  
  resMat <- matrix(0,ni,mt)
  resMat[ cbind(irow,time) ] <- res
  xy <- t( matrix(st*t(resMat),mt) ) 
  xx <-  matrix(st^2,ni,mt,byrow=T) 
  bs <- rowSums(xy,na.rm=T)/rowSums(xx,na.rm=T)
  bi <- rowMeans(resMat,na.rm=T) - bs*mean(st)
  yy <- resMat - bi + matrix(bs,ncol=1)%*%st 
  res <- yy[ cbind(irow, time) ]
  
 # res <- res - predict.lm( lm(res ~ time) )
  
  FF  <- .myBy(res, irow, time, matrix(0,max(irow),max(time)),fun='sum')
  FF  <- crossprod(FF)
  z   <- FF[lower.tri(FF, diag=T)]
  ii  <- row(FF)-col(FF)
  ii  <- ii[lower.tri(ii, diag=T)] + 1
  tmp <- as.vector(.myBy(z,ii,ii*0+1,fun='sum'))
  tmp  <- tmp/tmp[1]

  names(tmp) <- paste('lag',st,sep='-')
  
  tmp
}

pacf <- function(xacf){
  
  nj <- length(xacf)
  st <- c(0:(nj-1))
  rmat <- diag(1,nj)
  rmat <- matrix( xacf[1 + abs( row(rmat)-col(rmat) )], nj, nj)
  tmp <- c(1, solve( toeplitz(xacf[1:(nj-1)]), xacf[2:nj] ) )
  names(tmp) <- paste('lag',st,sep='-')
  tmp
}

.mapSetup <- function(xlim,ylim,scale=NULL,widex=10.5,widey=6.5){  
  
  #scale is x per inch
  #new means not a new plot
  
  if(is.null(scale))scale <- 1
  
  px   <- diff(xlim)/scale
  py   <- diff(ylim)/scale
  
  if(px > widex){
    dx <- widex/px
    px <- widex
    py <- py*dx
  }
  if(py > widey){
    dx <- widey/py
    py <- widey
    px <- px*dx
  }
  
  par(pin=c(px,py))
  invisible( c(px,py) )
}


checkPlotDims <- function(plots, years, xytree, xytrap, plotDims, plotArea){
  
  if(is.null(plotDims)){
    plotDims <- getPlotDims(xytree, xytrap)
  }else{
    rownames(plotDims) <- .fixNames(rownames(plotDims), all=T)$fixed
    if(ncol(plotDims) != 5)stop('plotDims has 5 columns: xmin, xmax, ymin, ymax, area')
    wc <- which(!plots %in% rownames(plotDims))
    if(length(wc) > 0){
      xx <- paste(plots[wc],' missing from plotDims ')
      stop(xx)
    }
  }
  plotDims <- plotDims[drop=F,plots,]
  
  if(is.null(plotArea)){
    plotArea <- matrix(plotDims[,'area'],nrow(plotDims),length(years))
    rownames(plotArea) <- plots
    colnames(plotArea) <- years
  }else{
    rownames(plotArea) <- .fixNames(rownames(plotArea), all=T)$fixed
  }
    
  list(plotDims = plotDims, plotArea = plotArea)
}



mastMap <- function(mapList){
  
  # if PREDICT, needs seedPredGrid, treePredGrid
  
  mapPlot <- mapYears <- treeSymbol <- xlim <- ylim <- NULL
  seedMax <- fecMax <- fecPred <- seedPred <- RMD <- 
    seedPredGrid <- treePredGrid <- treeData <- seedData <- 
    specNames <- seedNames <- NULL
  
  PREDICT <- LEGEND <- SCALEBAR  <- F
  MAPTRAPS <- MAPTREES <- COLORSCALE <- T  
  
  treeScale <- trapScale <- plotScale  <- 1
  scaleValue <- 20
  mfrow <- c(1,1)
  
  if('chains' %in% names(mapList))class(mapList) <- 'mastif'
  
  if( class(mapList) == 'mastif' ){
    indat <- c('treeData', 'seedData', 'specNames', 'seedNames',
               'xytree', 'xytrap')
    mi    <- match(indat, names(mapList$inputs))
    for(i in mi){
      mapList <- append( mapList, mapList$inputs[i] )
    }
    fecPred  <- mapList$prediction$fecPred
    seedPred <- mapList$prediction$seedPred
    treePredGrid  <- mapList$prediction$treePredGrid
    seedPredGrid  <- mapList$prediction$seedPredGrid
  }
  
  
  minPars <- c('specNames','seedNames','treeData','seedData','xytree','xytrap',
               'mapPlot','mapYears')
  
  wk <- which(!minPars %in% names(mapList))
  if(length(wk) > 0){
    mp <- paste0(minPars[wk], collapse=', ')
    stop('missing from mapList: ',mp)
  }
  minPars <- c(minPars, 'treeSymbol')
  for(k in 1:length(minPars)){
    wk <- which(names(mapList) == minPars[k])
    assign( minPars[k], mapList[[wk[1]]] )
  }
  
  tdata <- treeData
  sdata <- seedData

  rm(treeData)
  rm(seedData)
  
  plotVars <- c('fecPred','seedPred','PREDICT','treeScale',
                'trapScale','xlim','ylim','MAPTRAPS','MAPTREES','seedMax','NULL',
                'fecMax','mfrow','LEGEND','plotScale ','SCALEBAR','scaleValue',
                'COLORSCALE','RMD')
  
  for(k in 1:length(plotVars)){
    wk <- which(names(mapList) == plotVars[k])
    if(length(wk) == 0)next
    assign( plotVars[k], mapList[[wk]] )
  }
  
  
  mapPlot     <- .fixNames(mapPlot, all=T)$fixed
  tdata$plot  <- .fixNames(tdata$plot, all=T)$fixed
  sdata$plot  <- .fixNames(sdata$plot, all=T)$fixed
  xytree$plot <- .fixNames(xytree$plot, all=T)$fixed
  xytrap$plot <- .fixNames(xytrap$plot, all=T)$fixed
  
  
  
  if(length(specNames) == 1)LEGEND <- F
  
  xytrap$trapID <- columnPaste(xytrap$plot,xytrap$trap)
  sdata$trapID <- columnPaste(sdata$plot,sdata$trap)
  xytree$treeID <- columnPaste(xytree$plot,xytree$tree)
  tdata$treeID <- columnPaste(tdata$plot,tdata$tree)
  
  
  mapTreeYr <- mapYears
  
  wp <- which(tdata$plot == mapPlot)
  if(length(wp) == 0 & MAPTREES)stop('no trees on this plot')
  
  censYr <- table(tdata$plot,tdata$year)[mapPlot,]
  cmiss  <- which(censYr[as.character(mapYears)] == 0)
  cmiss  <- as.numeric(names(cmiss))
  cmiss  <- sort(c(cmiss, mapYears[!mapYears %in% names(censYr)]))
  
  if( MAPTREES & length(cmiss) > 0 ){
    
    yy <- as.numeric(names(censYr))
    yy[censYr == 0] <- Inf
    
    dy <- abs( outer( mapYears, yy, '-' ) )
    cy <- yy[ apply(dy, 1, which.min) ]
    mapTreeYr <- cy
    
    mpp <- paste0(mapTreeYr, collapse=', ')
    
    cat(paste('\nThere are not tree censuses in all mapYears, used',mpp,'\n'))
  }
  
  wtdata <- which(tdata$year %in% mapTreeYr & 
                  as.character(tdata$plot) %in% mapPlot)
  tree <- tdata[wtdata,]
  
  wt <- match(as.character(tree$treeID),
              as.character(xytree$treeID) )
  tree$x <- xytree$x[wt]
  tree$y <- xytree$y[wt]
  
  fmat <- tree
  if(is.null(treeSymbol)){
    treeSymbol <- tree$diam
  }else{
    treeSymbol <- treeSymbol[wtdata]
  }
  
  wsdata <- which(sdata$year %in% mapYears & 
                    as.character(sdata$plot) %in% mapPlot)
  seed <- sdata[wsdata,]
  ws   <- match(as.character(seed$trapID),
              as.character(xytrap$trapID) )
  seed$x <- xytrap$x[ws]
  seed$y <- xytrap$y[ws]
  
  if(is.null(seedPredGrid))PREDICT <- F
  
  wtpred <- numeric(0)
  
  if(PREDICT){
    wtpred <- which(treePredGrid$year %in% mapTreeYr & 
                      treePredGrid$plot %in% mapPlot)
    if(length(wtpred) == 0)PREDICT <- F
  }
  if(PREDICT){
    treePredGrid <- treePredGrid[wtpred,]

    wt <- match(as.character(treePredGrid$treeID),
                as.character(xytree$treeID) )
    treePredGrid$x <- xytree$x[wt]
    treePredGrid$y <- xytree$y[wt]
    
    fmat <- treePredGrid
    
    if(is.null(treeSymbol)){
      treeSymbol <- treePredGrid$fecEstMu
      fmat <- tree
    }
    
    wsdata <- which(seedPred$year %in% mapYears & 
                      as.character(seedPred$plot) %in% mapPlot)
    seedPred <- seedPred[wsdata,]
    wt <- match(as.character(seedPred$trapID),
                        as.character(xytrap$trapID) )
    seedPred$x <- xytrap$x[wt]
    seedPred$y <- xytrap$y[wt]
    
    wspred <- which(seedPredGrid$year %in% mapYears & 
                      seedPredGrid$plot %in% mapPlot)
    seedPredGrid <- seedPredGrid[wspred,]
    
    scols <- paste(specNames, '_meanM2', sep='')
    scols <- c('plot','trapID','year','x','y',scols)
    
    seedPredGrid <- rbind(seedPred[,scols],seedPredGrid[,scols])
    
    
  }else{
    if(is.null(treeSymbol))treeSymbol <- tree$diam
  }
  
  if(length(wtdata) == 0 & length(wtpred) == 0 & MAPTREES){
    cat('\nNo obs or preds for mapPlot, mapYears\n')
    return(add=F)
  }
  
  SEED <- T
  snames <- paste(seedNames,'_meanM2',sep='')
  seedCount <- as.matrix(seed[,seedNames, drop=F])
  if(nrow(seed) == 0)SEED <- F
  
  if(is.null(seedMax) & length(seedCount) > 0)
    seedMax <- max( seedCount, na.rm=T )
  
 
  
  if(is.null(fecMax) & MAPTREES)fecMax <- max( treeSymbol, na.rm=T )
  fecMax <- max(fecMax)
  
  nspec <- length(specNames)
  
  cfun <- colorRampPalette( c('#66c2a5','#fc8d62','#8da0cb') )
  specCol <- cfun(nspec) 
  names(specCol) <- specNames
  
  
  checkXY <- apply(xytree[,c('x','y')], 2, min)
  if(!all(is.finite(checkXY)))stop('missing x, y in xytree')
  
  checkXY <- apply(xytrap[,c('x','y')], 2, min)
  if(!all(is.finite(checkXY)))stop('missing x, y in xytrap')
  
  xlimk <- ylimk <- numeric(0)
  dx <- dy <- numeric(0)
  
  npp  <- length(mapPlot)
  
  for(j in 1:npp){
    
    if(is.null(xlim)){
      wxy1 <- which(xytree$plot == mapPlot[j])
      wxy2 <- which(xytrap$plot == mapPlot[j])
      
      xlimj <- range( c(xytree[wxy1,'x'], xytrap[wxy2,'x']) )
      ylimj <- range( c(xytree[wxy1,'y'], xytrap[wxy2,'y']) )
      if(PREDICT){
        wj <- which(seedPredGrid$plot == mapPlot[j])
        xlimj <- range( c(xlimj, seedPredGrid$x[wj]) )
        ylimj <- range( c(ylimj, seedPredGrid$y[wj]) )
      }

    }else{
      xlimj <-  xlim
      ylimj <-  ylim
    }
    dxj <- diff(xlimj)
    dyj <- diff(ylimj)
    
    dx <- c(dx, dxj)
    dy <- c(dy, dyj)
    
    xlimk <- rbind(xlimk, xlimj)
    ylimk <- rbind(ylimk, ylimj)
  }
  xlimit <- matrix(xlimk,npp,2,byrow=F)
  ylimit <- matrix(ylimk,npp,2,byrow=F)
  rownames(xlimit) <- rownames(ylimit) <- mapPlot
  
  rr  <- apply( rbind(xlimit, ylimit), 2, range)
  sc  <- max( apply(rr,1,diff) )/20
  
  opin <- par()$pin
  
  obs <- oyr <- numeric(0)
  if(SEED){
    stab <- with( seed, table(plot, year) )
    stab <- stab[drop=F, mapPlot, ]
    obs  <- stab[, colnames(stab) %in% mapYears, drop=F]
    oyr  <- as.numeric( colnames(obs)[ colSums(obs) > 0 ] )
  }
  
  pyr  <- numeric(0)
  pred <- NULL
  
  if(PREDICT){
    ptab <- with( seedPredGrid, table(plot, year) )
    if(!mapPlot %in% rownames(ptab)){
      cat('\nNo prediction for this plot\n')
      PREDICT <- F
    }else{
      ptab <- ptab[drop=F, mapPlot, ]
      wss  <- which(colnames(ptab) %in% mapYears)
      if(length(wss) == 0){
        cat('\nNo prediction for this plot-year\n')
        PREDICT <- F
      }else{
        pred <- ptab[, colnames(ptab) %in% mapYears, drop=F]
        pyr  <- colnames(pred)[ colSums(pred) > 0 ]
      }
    }
    pyr <- as.numeric(pyr)
  }
  yr  <- sort( unique( c(oyr, pyr) ) )
  if( length(oyr) > 0 ){
    oyr <- oyr[oyr %in% yr]
    obs <- obs[, as.character(oyr), drop=F]
  }else{
    obs <- NULL
  }

  if(PREDICT){
    if( length(pyr) > 0 ){
      pyr <- pyr[pyr %in% yr]
      pred <- pred[, as.character(pyr), drop=F]
    }
  }
  
  specAll  <- table(tree$species)
  specAll  <- specAll[specAll > 0]
  specPred <- table(tree$species[tree$plot %in% rownames(pred) &
                                   tree$year %in% pyr])
  specPred  <- names(specPred)[specPred > 0]
  colList <- numeric(0)
  
  for(j in 1:npp){
    
    WOJ <- WPJ <- F
    
    jobs <- jpred <- jyr <- numeric(0)
    
    if(!is.null(obs)){
      jobs  <- obs[drop=F, mapPlot[j],]
      WOJ <- T
    }
    if(!is.null(pred)){
      jpred <- pred[drop=F, mapPlot[j],]
      WPJ <- T
    }
    jyr   <- sort(unique(as.numeric(c(colnames(jobs),colnames(jpred)))))
    njyr  <- length(jyr)
    
    if(is.null(mfrow))mfrow <- c(1,1)
    
    suppressWarnings(
      par(bty='o',mar=c(1,.4,2,.4), oma=c(3,3,1,1))
    )
    if(LEGEND)par(oma=c(3,3,1,3))
    
    par(mfrow=mfrow)
    
    if(!is.null(RMD)){
      mfrow <- c(1,1)
      njyr  <- 1
      par( mfrow=mfrow, mar=c(2,2,2,1), bty='o' )
    }
    
    if(njyr == 1){
      scale <- max( c(dx[j],dy[j]) )/2
      if(scale < 50)scale <- 50
    }else{
      if(prod(mfrow) == 1)mfrow <- .getPlotLayout(njyr)$mfrow
      par( mfrow=mfrow, mar=c(2,2,2,1), bty='o' )
      scale <- max(c(dx[j],dy[j]))/plotScale/3*max(mfrow)
    }
    
    if(!is.null(RMD))scale <- scale*1.1
    .mapSetup(xlimit[j,], ylimit[j,], scale =  scale)
    
    cyr <- as.character(yr)
    
    for(k in 1:njyr){
      
      add <- WO <- WP <- WT <- F
      
      if(WOJ){
        if( cyr[k] %in% colnames(obs) &
            MAPTRAPS )WO <- obs[1,colnames(obs) == cyr[k]] > 0
      }
      if(WPJ){
        if( cyr[k] %in% colnames(pred) )WP <- pred[,colnames(pred) == cyr[k]] > 0
      }
      
      if(!WO & !WP & !MAPTREES)next
      
      if(WP){  #predicted surface, fecundity
        
        tmp <- .pmap(specNames=specNames, # xytree=xytree, 
                     plot=mapPlot[j], MAPTREES,
                     year=jyr[k], seedPredGrid=seedPredGrid, 
                     treePredGrid = treePredGrid,
                     xlim=xlimit[j,], ylim=ylimit[j,], treeScale, trapScale,
                     sCol = specCol[specNames], add=add)
        add <- tmp$add
        tmp <- tmp[names(tmp) != 'add']
        
        if(add)colList <- append(colList, list(tmp))
        names(colList)[length(colList)] <- mapPlot[j]
      }
      
      if(WO){  #observed seed
        
        seedk <- seed[seed$year == jyr[k],]
        sx <- seedk$x
        sy <- seedk$y
        z  <- as.matrix( seedk[,seedNames] )
        
     #   if(length(snames) > 1)z <- rowSums(z,na.rm=T)
        
        z <- rowSums(z, na.rm=T)
        
        w1 <- which(z > 0)
        w0 <- which(z == 0)
    
        
        if(length(w1) > 0){
          z <- z/seedMax
          z <- 5*sqrt(sc*z)*trapScale
          symbols(sx[w1], sy[w1], squares=z[w1], inches = F,
                  xlab='', ylab='',bg = .getColor('black',.3), 
                  fg = .getColor('black',.5), add=add,
                  xaxt='n', yaxt='n', xlim=xlimit[j,], ylim=ylimit[j,])
          for(i in 1:4)axis(i, labels=F, tck=.01)
          add <- T
        }
        if(add == F){
          plot(NULL, xlim = xlim, ylim = ylim, xlab='', ylab='',
               axes = F)
          for(i in 1:4)axis(i, labels=F, tck=.01)
        }
        if(length(w0) > 0)points(sx[w0], sy[w0], pch=3, cex=.3,
                                 col=.getColor('black',.8))
        add <- T
      }
      
   #   if( (WO & !WP) & MAPTREES){ #est fecundity
      if(MAPTREES & !PREDICT){
        
        treek <-  fmat[fmat$year == jyr[k],]
        
        
        if(nrow(treek) == 0){
      #    cat(paste( '/nThere are no trees in year',yr[k],'\n'))
          next
        }
        
        sx <- treek$x
        sy <- treek$y
        
        z  <- treeSymbol[fmat$year == jyr[k]]
        
        
        if(!all(is.na(z))){
          mmm <- max(z, na.rm=T)
          if(mmm == 0)mmm <- 1
          z <- 1*sc*z/mmm*treeScale
          ic <- match(treek$species, specNames)
          
          symbols(sx, sy, circles=z*1.3, inches = F, add=add,
                  xlim = xlim, ylim = ylim,
                  fg = .getColor('white',.5), xlab = '', ylab = '',
                  bg =.getColor('white',.5), xaxt='n', yaxt='n')
          
          symbols(sx, sy, circles=z, inches = F, add=T,
                  xlab = '', ylab = '',
                  fg = .getColor(specCol[ specNames[ic] ],.6), 
                  bg=.getColor(specCol[ specNames[ic] ],.3), xaxt='n', yaxt='n')
          if(!add)for(i in 1:4)axis(i, labels=F, tck=.01)
        }
      }
      
      if(!add)next
      
      cex <- sum(mfrow)^(-.1)
      .plotLabel(jyr[k], 'topright',cex = cex, above=T) 
      .plotLabel(mapPlot[j],'topleft',cex = cex,above=T)
    }
  }
  if(PREDICT)colList <- colList[ !duplicated(names(colList)) ]
  
  if(SCALEBAR)scaleBar('m', value = scaleValue, yadj=.07, cex=.8)
  if(LEGEND){
    cornerLegend('bottomright', names(specAll),
           text.col = specCol[match(names(specAll),specNames)],
           cex=.7, bty='n')
  }
  
  if(COLORSCALE & PREDICT){
    
    # use last plot (bottom or right side)
    cols <- colList[[length(colList)]]
    nss   <- length(cols$species)
    endLabels <- NULL
    
    for(k in 1:nss){
      
      if(k == nss)endLabels <- c(0, signif(seedMax,1) )
      
      ck <- .getColor(specCol[cols$species[k]], cols$colorLevels)
      
      clist <- list( kplot=k, ytick=NULL, text.col = 'black',
                     cols=ck, labside='right', text.col=col,
                     bg='grey', endLabels=endLabels) 
      cornerScale( clist )
  #    kk <- kk + 1
    }
  }
  invisible(add)
}
 
cornerLegend <- function(...) {
  suppressWarnings(
  opar <- par(fig=c(0, 1, 0, 1), oma=c(0, 0, 0, 0), 
              mar=c(0, 0, 0, 0), new=TRUE)
  )
  on.exit(par(opar))
  plot(0, 0, type='n', bty='n', xaxt='n', yaxt='n')
  legend(...)
}


cornerScale <- function( clist ) {
  
  opar <- par(fig=c(0, 1, 0, 1), oma=c(0, 0, 0, 0), 
              mar=c(0, 0, 0, 0), new=T)
  on.exit(par(opar))
  plot(0, 0, type='n', bty='n', xaxt='n', yaxt='n')
  
  .cornerLegendScale( clist )
}

.cornerLegendScale <- function( clist ){  
  
  # left and right corners: xx = (x1,x2), y = (y1,y2)
  # bg is color of border
  # cols  - matching color sequence
   kplot <- 1
  
  opar <- par(fig=c(0, 1, 0, 1), oma=c(0, 0, 0, 0), 
              mar=c(0, 0, 0, 0), new=TRUE)
  on.exit(par(opar))
  
  xx <- yy <- cols <- NULL
  ytick <- scale <- text.col <- text.col <- bg <- endLabels <- NULL
  labside <- 'right'
  
  for(k in 1:length(clist))assign( names(clist)[k], clist[[k]] ) 
  
  xx <- -1.08 + .1*(kplot - 1) + c(.1, .2)
  yy <- c(-1, -.75)
  
  nn <- length(cols)
  ys <- seq(yy[1],yy[2],length=nn)
  if(is.null(scale))scale <- ys
  
  for(j in 1:(length(scale)-1)){
    
    rect(xx[1],ys[j],xx[2],ys[j+1],col=cols[j],border=NA)
  }
  if(!is.null(bg))rect(xx[1],yy[1],xx[2],yy[2],border=bg,lwd=1)
  if(!is.null(ytick)){
    
    ys <- diff(yy)/diff(range(ytick))*ytick
    yt <- ys - min(ys) + yy[1]
    
    for(j in 1:length(yt)){
      lines(xx,yt[c(j,j)])
    }
  }
  if(!is.null(endLabels)){ 
    if(labside == 'right')text(diff(xx)+c(xx[2],xx[2]),yy,endLabels)
    if(labside == 'left')text(c(xx[1],xx[1]),yy,endLabels,pos=2)
  }
}

values2grid <- function(x, y, z, nx=NULL, ny=NULL, dx=NULL, dy=NULL,
                        ksearch = 4, MATFORMAT=T){
  
  xl <- range(x)
  yl <- range(y)
  
  xs <- seq(xl[1],xl[2],length=nx)
  ys <- seq(yl[1],yl[2],length=ny)
  
  grid <- as.matrix(expand.grid(xs,ys))
  
  tmp <- nn2(cbind(x,y),grid,k=ksearch)
  nn  <- tmp[[1]]
  wt  <- tmp[[2]]
  mn  <- min(wt[wt > 0])
  wt  <- 1/(wt + mn)
  
  zz  <- matrix(z[nn],nrow(nn),ncol(nn))
  zz  <- rowSums(zz*wt)/rowSums(wt)
  
  if(!MATFORMAT)return(  cbind(grid,zz) )
  
  zmat <- matrix(NA, nx, ny)
  ix  <- match(grid[,1],xs)
  iy  <- match(grid[,2],ys)
  zmat[ cbind(ix,iy) ] <- zz
  
  rownames(zmat) <- xs
  colnames(zmat) <- ys
  
  list( x = xs, y = ys, z = zmat )
}



.pmap <- function(specNames=NULL, plot=NULL, MAPTREES = T,
                  year=NULL, seedPredGrid=NULL,
                  treePredGrid, xlim, ylim, treeScale, trapScale,
                  sCol = 'blue', add=F){
  
  #multiple species for single plot-year
  
  ADD <- F
  if(add)ADD <- T
  
  pnames   <- paste(specNames,'_meanM2',sep='')
  nspec    <- length(specNames)
  predCols <- c('x','y',pnames)
  
  if(length(sCol) == 1 & nspec > 1)sCol <- rep(sCol, nspec)
  
 # wtree <- which( treePredGrid$year %in% year & 
 #                   treePredGrid$plot %in% plot )
 # tmat <- treePredGrid[wtree,]
 # tmat$x <- xytree$x[ match(tmat$treeID, xytree$treeID) ]
 # tmat$y <- xytree$y[ match(tmat$treeID, xytree$treeID) ]
  
  fec  <- treePredGrid[,'fecEstMu']
  matr <- treePredGrid[,'matrPred']
  
 # wtrap <- which( seedPredGrid$year %in% year & 
 #                   seedPredGrid$plot %in% plot )
  
 # if(length(wtrap) == 0){
 #   if(add)plot(NULL, xlim = xlim, ylim = ylim, axes= F, xlab='',
 #               ylab='')
 #   return()
 # }
    
 # smat   <- as.matrix( seedPredGrid[wtrap,predCols] )
  
  smat <- as.matrix(seedPredGrid[,predCols])
  
 # dens <- nrow(smat)/diff(xlim)/diff(ylim)
 # nx <- ny <- ceiling(1/dens)
  
  nx <- ceiling(diff(xlim)/3)
  ny <- ceiling(diff(ylim)/3)
  
  fecMax  <- max(fec,na.rm=T)
  seedMax <- max(smat[,pnames],na.rm=T)
  
 # xseq <- sort(unique(smat[,'x']))
 # yseq <- sort(unique(smat[,'y']))
 # nx   <- length(xseq)
 # ny   <- length(yseq)
 # zmat <- matrix(NA, nx, ny)
 # ix  <- match(smat[,'x'],xseq)
 # iy  <- match(smat[,'y'],yseq)
  
  rr  <- apply( rbind(xlim, ylim), 2, range)
  sc  <- max( apply(rr,1,diff) )/20
  
  wspec <- which(colSums(smat[,pnames, drop=F]) > 0)
  
  sn <- 4
  if(seedMax > 1)sn <- 3
  if(seedMax > 10)sn <- 2
  
  q <- seq(0, 1, length=10)^.3
  q[1] <- .3
  
  levels <- signif( quantile(smat[,pnames], q ) , sn)
  levels <- c(levels, signif(max(seedMax)*1.3, sn) )
  levels <- sort(unique(levels))
  colorLevels <- seq(.001, .99, length=length(levels))^3
  
  for(k in wspec){
    
    tmp <- values2grid(x=smat[,'x'],y=smat[,'y'],z=smat[,pnames[k]],
                       nx=nx, ny=ny)
    xseq <- tmp$x
    yseq <- tmp$y
    zmat <- tmp$z
    
   # zmat[ cbind(ix, iy) ] <- smat[,pnames[k]]
    
    col <- .getColor(sCol[specNames[k]],colorLevels)
    contour(xseq, yseq, zmat, levels=levels, add=add, 
            col=col, labcex = 1, frame.plot=F,
            drawlabels=F, axes = F)
    .filled.contour(xseq, yseq, zmat, levels=levels, col=col)
    if(!add){
      for(m in 1:4)axis(m, labels=F, tck=.03)
    }
    if(!ADD)add <- T
    
  }
  
  if(MAPTREES){
    for(k in wspec){
      wk <- which( treePredGrid$species == specNames[k] )
      if(length(wk) == 0) next
      
      z   <- 5*sc*fec[wk]*treeScale
      z[z > 0] <- z[z > 0]/fecMax
      .mapSpec(x = treePredGrid[wk,'x'],y = treePredGrid[wk,'y'], z*1.5,  
               add = add, 
               mapx = xlim, mapy = ylim,
               colVec='white', fill = 'white')
      .mapSpec(x = treePredGrid[wk,'x'],y = treePredGrid[wk,'y'], z,  add = T, 
               mapx = xlim, mapy = ylim,
               colVec=sCol[specNames[k]], fill = sCol[specNames[k]])
    }
  }
  invisible( list(species = wspec, colorLevels = colorLevels, add = add) )
}

.colPaste <- function(...){
  
  # ... are vectors, all same length to be combined row-wise
  
  mm <- list(...)
  nn <- as.character(mm[[1]])
  for(i in 2:length(mm)){
    mi <- as.character(mm[[i]])
    nn <- apply( cbind(nn,mi),1,paste0,collapse='-')
  }
  nn
}
 
.updateCovariance <- function(SS, priorSS, n, df){
  
  SI   <- solveRcpp(SS + df*priorSS)
  sinv <- .rwish(n + df, SI)
  solveRcpp(sinv)
}

.updateAlphaRand <- function(ntree, yy, xfecA, sg, reIndexA, reGroups,
                             xrandCols, Arand, priorVA, dfA, minmax = 2){
  
  ONEA <- F
  if(length(Arand) == 1)ONEA <- T
  
  arand <- matrix(0, ntree, length(xrandCols))
  
  w1 <- table(reIndexA)
  w1 <- as.numeric(names(w1)[w1 > 1])
  
  ww <- which(reIndexA %in% w1)   
  wg <- xfecA[ww, xrandCols, drop=F]
  
  rea <- reIndexA[ww]
  rei <- sort(unique(rea))
  rei <- cbind(1:length(rei), rei)
  
  rindex <- match(rea, rei[,2])
  
  alphaRand <- randEffectRcpp(gindex=rindex, groups = rei[,1], 
                              wg, yy[ww], sg, solve(Arand))
  alphaRand[alphaRand < -minmax] <- -minmax
  alphaRand[alphaRand > minmax]  <- minmax
  
  if(ONEA){
    alphaRand <- alphaRand - mean(arand)
  }else{
    mrand <- colMeans(alphaRand)
    alphaRand <- alphaRand - matrix(mrand, nrow(alphaRand), ncol(alphaRand), byrow=T)
  }
  
  arand[rei[,2],] <- alphaRand
  
  rz    <- which( rowSums(abs(arand)) != 0)
  
  if(length(rz) < 2)return(list(alphaRand = arand, Arand = Arand))
  
  if(ONEA){
    arand <- arand - mean(arand[rz])
    Arand <- matrix(1/rgamma(1,1 + length(rz)/2, 1 + 1/2*sum(arand[rz]^2)),1)
  }else{
    AA    <- crossprod(arand[rz,])
    Arand <- .updateCovariance(AA, priorVA, length(rz), dfA)
  }
  
  list(alphaRand = arand, Arand = Arand)
}


.updateAlphaRandOld <- function(yy, xfecA, zz, sg, reIndexA, reGroups,
                             xrandCols, Arand, priorVA, dfA, minmax = 3){
  
  ONEA <- F
  if(length(Arand) == 1)ONEA <- T
  
  wg <- xfecA[zz == 1, xrandCols, drop=F]
  
  alphaRand <- randEffectRcpp(reIndexA[zz == 1], reGroups, 
                              wg, yy[zz == 1], sg, solve(Arand))
  alphaRand[alphaRand < -minmax] <- -minmax
  alphaRand[alphaRand > minmax]  <- minmax
  rz    <- which( rowSums(alphaRand) != 0)
  
  if(length(rz) < 2)return(list(alphaRand = alphaRand, Arand = Arand))
  
  if(ONEA){
    Arand <- matrix(1/rgamma(1,1 + length(rz)/2, 1 + 1/2*sum(alphaRand[rz]^2)),1)
  }else{
    AA    <- crossprod(alphaRand[rz,])
    Arand <- .updateCovariance(AA, priorVA, length(rz), dfA)
  }
  
  list(alphaRand = alphaRand, Arand = Arand)
}

.rwish <- function(df,SS){
  z  <- matrix(rnorm(df*nrow(SS)),df,nrow(SS))%*%chol(SS)
  crossprod(z)
}

.riwish <- function(df,S){
  solveRcpp(.rwish(df,solveRcpp(S)))
}

print.mastif <- function(x, ...){
  
  rMu <- rSe <- usigma <- betaYrMu <- betaYrSe <- NULL
  
  cat("\nDIC:\n")
  print( round(x$fit$DIC,0) )
  
  cat("\nFecundity coefficients:\n")
  print( signif(x$parameters$betaFec, 3) )
  
  cat("\nMaturation coefficients:\n")
  print( signif(x$parameters$betaRep, 3) )
  
  if('betaYrMu' %in% names(x$parameters)){
    cat("\nYear effects:\n")
    print( signif(betaYrMu, 3) )
    print( signif(betaYrSe, 3) )
  }
  
  if('rgibbs' %in% names(x$chains)){
    cat("\nSpecies to seed type matrix R:\n")
    print( signif(rMu, 3) )
    print( signif(rSe, 3) )
  }
  
  cat("\nSigma, RMSPE:\n")
  usigma <- x$parameters$sigma
  print( signif(usigma, 3) )
  
  cat("\nDispersal parameter u (m^2):\n")
  print( x$parameters$upars )
  
  cat("\nKernel mean distance (m):\n")
  print( x$parameters$dpars )
}

summary.mastif <- function(object, verbose=T, ...){ 
  
  betaFec   <- object$parameters$betaFec
  betaRep   <- object$parameters$betaRep
  priorTable <- object$inputs$priorTable
  seedNames <- object$inputs$seedNames
  specNames <- object$inputs$specNames
  tdata     <- object$inputs$treeData
  sdata     <- object$inputs$seedData
  plots     <- sort(unique(as.character(tdata$plot)))
  ntype     <- length(seedNames)
  nseed     <- nrow(sdata)
  nplot     <- length(plots)
  words     <- character(0)
  
 # priorR <- .setupR(sdata, tdata, seedNames, specNames)$priorR
  
  out <- list()

  AR <- YR <- RANDOM <- SAMPR <- F
  
  RMSPE <- object$fit$RMSPE
  DIC   <- object$fit$DIC
  
  if("arList" %in% names(object$data)){
    AR <- T
    plag <- object$data$arList$p
  }
  
  #model
  model <- rbind( as.character(object$inputs$formulaRep), 
                  as.character(object$inputs$formulaFec ))[, 2, drop=F]
  model <- .replaceString(model, 'I(', '')
  model <- .replaceString(model, '^2)', '^2')
  rownames(model) <- c('Maturation:', 'Fecundity:')
  attr(model, 'caption') <- 'Model terms'
  re <- object$inputs$randomEffect
  if(!is.null(re)){
    ref <- paste( re$randGroups, re$formulaRan, sep='_' )[2]
    ref <- paste( ' + r(', ref, ')', sep='')
    model[2,1] <- paste(model[2,1], ref)
    attr(model, 'caption') <- paste(attr(model,'caption'), 
                                    'r(g_m) indicates a random effect for groups g and model m. ', sep='')
  }
  ye <- object$inputs$yearEffect
  if(!is.null(ye)){
    yef <- unlist(ye)
    if(length(yef) > 1)yef <- paste0(yef, collapse = '_')
    if(!AR){
      yef <- paste( ' + y(', yef, ')', sep='')
      model[2,1] <- paste(model[2,1], yef)
      attr(model, 'caption') <- 
        paste(attr(model,'caption'), 
              'y(h) indicates a year effect for random h. ', sep='')
    }
    if(AR){
      yef <- paste( ' + AR(',plag,', ', yef, ')', sep='')
      model[2,1] <- paste(model[2,1], yef)
      attr(model, 'caption') <- 
        paste(attr(model,'caption'), 
              'AR(p, h) indicates an AR(p) model for random group h. ', sep='')
    }
  }
  model <- .replaceString(model, ' * ', 'X')
  model <- .replaceString(model, '*', 'X')
  model <- .replaceString(model, '  ', ' ')
  model[1,1] <- paste("'", model[1,1], "'", sep='')
  model[2,1] <- paste("'", model[2,1], "'", sep='')
  colnames(model) <- 'model'
  out$amodel <- model
  
  attr(priorTable, 'caption') <- 'Prior parameter values'
  out$aprior <- priorTable
  
  #data summary
  wd <- which(!duplicated(tdata$treeID))
  trees <- table(tdata$species[wd],tdata$plot[wd])[,plots,drop=F]
  rownames(trees) <- paste('trees',rownames(trees), sep='_')
  
  wd <- which(!duplicated(sdata$trapID))
  traps <- table(sdata$plot[wd])[plots]
  ntr   <- names(traps)
  traps <- matrix(traps,1)
  colnames(traps) <- ntr
  rownames(traps) <- 'traps'
  
  treeYears <- table(tdata$species,tdata$plot)[,plots,drop=F]
  rownames(treeYears) <- paste('tree-yrs',rownames(treeYears), sep='_')
  trapYears <- table(sdata$plot)[plots]
  dataTab <- rbind(trees,treeYears,traps,trapYears)
  rownames(dataTab)[nrow(dataTab)] <- 'trap-yrs'
  
  
  ####################################
  
  totalSeed <- buildSeedByPlot(sdata, seedNames)
  censSeed  <- buildSeedByPlot(sdata, paste(seedNames,'_min',sep=''))
  
  
  dataTab <- rbind(dataTab,totalSeed)
  
  if(nplot > 1){
    total   <- rowSums(dataTab)
    dataTab <- cbind(dataTab,total)
  }
  
  attr(dataTab, 'caption') <- 'Summary of observations by plot'
  attr(betaFec, 'caption') <- 'Fecundity coefficients (betaFec, log scale)'
  attr(betaRep, 'caption') <- 'Maturation coefficients (betaRep, probit)'
  
  out$adata   <- dataTab
  out$betaFec <- betaFec[,1:4]
  out$betaRep <- betaRep[,1:4]
  attr(out$betaFec, 'caption') <- 'Fecundity coefficients (betaFec, log scale)'
  attr(out$betaRep, 'caption') <- 'Maturation coefficients (betaRep, probit)'
  
  
  if(verbose){
    cat('\nData summary:\n')
    print(dataTab)
    
    cat("\nFecundity parameters (log scale):\n")
    print( betaFec )
    
    cat("\nMaturation parameters (probit):\n")
    print( betaRep )
  }
  
  if('betaYrMu' %in% names(object$parameters)){
    YR <- T
    byr <- t( rbind(object$parameters$betaYrMu, object$parameters$betaYrSe) )
    colnames(byr) <- c('  Estimate','  Standard_Error')
    attr(byr, 'caption') <- 'Year effects for fecundity (log scale)'
    
    if(verbose){
      cat("\nYear effects, only mature individuals:\n")
      print( signif(byr, 3) )
    }
    out$betaYr <- signif(byr, 3)
  }
  
  if('betaYrRand' %in% names(object$parameters)){
    
    byrRand <- signif(object$parameters$betaYrRand, 3)
    byrRSE  <- signif(object$parameters$betaYrSe, 3)
    attr(byrRand, 'caption') <- 'Year random effects for fecundity'
    attr(byrRSE, 'caption') <- 'Year standard deviation between random groups'
    
    if(verbose){
      cat("\nYear effects, random group means:\n")
      print( byrRand )
      cat("\nYear effects, standard deviation between groups:\n")
      print( byrRSE )
    }
    
    out$betaYrRand    <- byrRand
    out$betaYrGroupSE <- byrRSE
  }
  
  pacfmu <- signif( object$parameters$pacfMat, 3 )
  pacfse <- signif( object$parameters$pacfSe, 3 )
  pacfss <- signif( object$parameters$pacsMat, 3 )
  attr(pacfmu, 'caption') <- 'Partial autocorrelation in fecundity (log scale)'
  attr(pacfse, 'caption') <- 'Partial autocorrelation standard error in fecundity'
  attr(pacfss, 'caption') <- 'Partial autocorrelation in seed rain, all plots'
  
  out$pacfmu <- pacfmu
  out$pacfse <- pacfse
  out$pacfss <- pacfss
  
  if('aMu' %in% names(object$parameters)){
    RANDOM <- T
    amu <- diag( object$parameters$aMu)
    ase <- diag( object$parameters$aSe )
    
    arand <- signif(cbind(amu,ase),3)
    rownames(arand) <- .replaceString(rownames(arand),'species','')
    colnames(arand) <- c('  Estimate','  Standard_error')
    
    if(verbose){
      cat("\nDiagonal elements of random effects covariance matrix (aMu):\n")
      print( arand )
    }
    attr(arand, 'caption') <- 'Diagonal elements of random effects covariance matrix (A)'
    out$arand <- arand
  }
  
  if('rgibbs' %in% names(object$chains)){
    SAMPR <- T
    
    rMu <- signif(object$parameters$rMu, 3)
    rSe <- signif(object$parameters$rSe, 3)
    
    attr(rMu,'species') <- attr(rSe,'species') <- 
      attr(rMu,'posR') <- attr(rSe,'posR') <- 
      attr(rMu,'plot') <- attr(rSe,'plot') <- NULL
    
    if(verbose){
      cat("\nSpecies to seed type matrix R:\n")
      print( rMu )
      
      cat("\nStandard errors for R:\n")
      print( rSe )
    }
    
    attr(rMu, 'caption') <- 'ID error matrix mean estimate (R)'
    attr(rSe, 'caption') <- 'ID error matrix standard error (R)'
    
    out$rMu <- rMu
    out$rSe <- rSe
  }
  
  sigma <- object$parameters$sigma
  
  if(verbose){
    cat("\nSigma, RMSPE:\n")
    print( signif(sigma, 3) )
  }
  attr(sigma, 'caption') <- 'Sigma^2, RMSPE, and deviance'
  out$sigma <- signif(sigma, 3)
  
  utab <- object$parameters$upars
 # dpars <- object$parameters$dpars
 # utab  <- signif(rbind(upars,dpars),3)
  
  upars <- utab[grep('u',rownames(utab)),]
  pu    <- rownames(utab)
  rownames(utab) <- NULL
  utab  <- data.frame(parameter = pu, utab)
  
  rownames(utab) <- NULL
  
  if(verbose){
    cat("\nKernel estimates:\n")
    print(utab)
  }
  attr(utab, 'caption') <- 'Kernel estimates, parameter u in 2Dt kernel and kernel mean d'

  
  if(AR){
    out$eigenMu <- signif(object$parameters$eigenMu, 3)
    out$eigenSe <- signif(object$parameters$eigenSe, 3)
    attr(out$eigenMu, 'caption') <- 'Eigenvalues for autoregressive terms'
    attr(out$eigenSe, 'caption') <- 'Eigenvalue standard errors for autoregressive terms'
  }
  
  ty <- dataTab[grep('tree-yrs',rownames(dataTab)),]
# sy <- dataTab[grep('trap-yrs',rownames(dataTab)),]
  
  ntreeYr  <- sum(ty)
  ntrapYr  <- sum(dataTab['trap-yrs',])
  years    <- object$data$setupData$years
  ntree    <- ncol(object$data$setupData$distall)
  ntrap    <- nrow(object$data$setupData$distall)
  plots    <- object$data$setupData$plots
  nplot    <- length(plots)
  nyr      <- length(years)
  
  words <- paste("The sample contains ", ntreeYr, " tree-years and ",
                 ntrapYr, " trap-years on ", ntree, " individuals and ", 
                 ntrap, " seed traps on ", nplot, " plots, over ", nyr, 
                 " years. The RMSPE is ",
                 signif(object$fit$RMSPE,3),
                 ", and the DIC is ",round(object$fit$DIC),".", sep="")
  
  if('trueValues' %in% names(object$inputs)){
    words <- paste('The data are generated by mastSim. ', words, sep='')
  }
  
  if('censMin' %in% names(object$inputs)){
    cmin <- object$inputs$censMin
    cmax <- object$inputs$censMax
    if(length(cmin) > 0){
      ncens <- nrow(cmin)
      words <- paste(words, paste("There are", ncens, 
                              "censored seed trap observations") )
    }
  }
  
  if(!is.null(object$inputs$inwords)){
    ww <- paste0(object$inputs$inwords, collapse='. ')
    ww <- .replaceString(ww, '\n','. ')
    ww <- .replaceString(ww, '\n','')
    ww <- .replaceString(ww, '\"','')
    ww <- .replaceString(ww, '. .','. ')
    ww <- .replaceString(ww, ':.',': ')
    words <- paste( words, ww, sep='. ')
  }
  
  if(RANDOM){
    
    morewords <- paste("Random effects were fitted on ",
                            length(object$data$setupRandom$rnGroups), 
                            " individuals.", sep='')
    words <- paste(words, morewords)
  #  if(verbose){
  #    cat("\n",morewords)
  #  }
  }
  
  if(verbose){
    cat("\n",words)
  }
  
  fit <- cbind(round(object$fit$DIC), object$fit$RMSPE)
  colnames(fit) <- c('  DIC','  RMSPE')
  attr(fit, 'caption') <- 'Model fit'
  
  out$fit   <- fit
  out$words <- words
 
  class(out) <- "summary.mastif"
  invisible(out) 
}

.getMuCv <- function(seed, tran){
  
  mu  <- .myBy(as.vector(seed),tran[,1],tran[,2],fun='mean')
  s1  <- .myBy(as.vector(seed)*0 + 1,tran[,1],tran[,2],fun='sum')
  v1  <- .myBy(as.vector(seed),tran[,1],tran[,2],fun='sum')
  v2  <- .myBy(as.vector(seed^2),tran[,1],tran[,2],fun='sum')
  vs  <- v2/s1 - mu^2
  cv  <- sqrt(vs)/mu
  list(mu = mu, sd = sqrt(vs), cv = cv)
}

.getTran <- function(grid, new){
  newx <- seq(min(grid[,'x']),max(grid[,'x']),by=new)
  newy <- seq(min(grid[,'y']),max(grid[,'y']),by=new)
  tx   <- findInterval(grid[,'x'],newx)
  ty   <- findInterval(grid[,'y'],newy)
  cbind(tx,ty)
}

mastSim <- function(sim){       # setup and simulate fecundity data
  
  if(!'seedNames' %in% names(sim))
    stop('sim must include seedNames')
  if(!'specNames' %in% names(sim))
    stop('sim must include specNames')
  
  .dsim( sim ) 
}
 
.dsim <- function(sim){
  
  nyr <- 5; ntree  <-  10; ntrap <- 20; plotWide  <-  100; nplot  <-  3
  meanDist  <-  25; Q  <-  2
  minDiam <- 10
  maxDiam <- 40
  yearEffect <- NULL
  facLevels <- character(0)
  seedNames <- specNames <- c('piceaGlauca','piceaMariana','piceaUNKN')
  SPECS <- SAMPR <- AR <- F
  maxFec <- 1e+7
  
  for(k in 1:length(sim))assign( names(sim)[k], sim[[k]] )
  S         <- length(specNames)
  ntreePlot <- rpois(nplot, ntree) + 1  # trees per plot
  ntrapPlot <- rpois(nplot, ntrap) + 4  # traps per plot
  nyrPlot   <- rpois(nplot, nyr) + 1
  plotNames <- paste('p',1:nplot,sep='')
  yearNames <- 2017 - c(max(nyrPlot):1)
  if(length(specNames) > 1)SPECS <- T
  if(length(seedNames) > 1)SAMPR <- T
  nyr <- max(nyrPlot)
  
  upar <- (2*meanDist/pi)^2
  
  year <- plot <- tree <- trap <- yrsd <- plsd <- numeric(0)
  
  for(j in 1:nplot){
    
    tree <- c( tree, rep(1:ntreePlot[j], each=nyrPlot[j]) )
    year <- c( year, rep(1:nyrPlot[j], ntreePlot[j]) ) 
    plot <- c( plot, rep(j, (nyrPlot[j]*ntreePlot[j]) ) )
    trap <- c( trap, rep(1:ntrapPlot[j], each=nyrPlot[j]) )
    yrsd <- c( yrsd, rep(1:nyrPlot[j], ntrapPlot[j]) ) 
    plsd <- c( plsd, rep(j, (nyrPlot[j]*ntrapPlot[j]) ) )
  }
  
  tree <- data.frame(plot = plotNames[plot], year = yearNames[year], tree )
  tree <- tree[order(tree$plot, tree$tree, tree$year),]
  
  tree$treeID  <- columnPaste( tree$plot, tree$tree )
  treeID       <- as.character( tree$treeID ) 
  
  id           <- unique(as.character(tree$treeID))
  species      <- sample(specNames, length(id), replace=T) 
  tree$species <- factor(species[match(tree$treeID,id)], levels = specNames)
  
  tree$dcol <- match(as.character(tree$treeID),id)
  
  tree$plotYr <- columnPaste(tree$plot, tree$year )
  plotyr      <- unique(tree$plotYr)
  tree$plotyr <- match(tree$plotYr, plotyr )
  
  years <- sort(unique(tree$year))
  
  trap <- data.frame(plot = plotNames[plsd], year = yearNames[yrsd], trap )
  trap <- trap[order(trap$plot, trap$trap, trap$year),]
  
  trap$trapID  <- columnPaste( trap$plot, trap$trap )
  trapid       <- as.character( trap$trapID )
  drow         <- unique(trapid)
  trap$drow    <- match(trapid,drow)

  trap$plotYr <- columnPaste(trap$plot, trap$year )
  plotyr      <- unique(trap$plotYr)
  trap$plotyr <- match(trap$plotYr, plotyr )
  
  n <- nrow(tree)
  
  xfec <- round( matrix( .tnorm(n*(Q-1), 5, 50, 35, 5), n, (Q-1) ), 3)
  xnames <- paste('x',1:(Q-1),sep='')
  xnames[1] <- 'diam'
  colnames(xfec) <-  xnames
 
  xdata   <- data.frame( species = tree$species, xfec)
  
  formulaFec <- as.formula( '~ diam'  )
  formulaRep <- as.formula( '~ diam' )
  
  if(SPECS){
    formulaFec <- as.formula( '~ species*diam'  ) 
    formulaRep <- as.formula( ' ~ species*diam' )
  }
  xfec    <- model.matrix(formulaFec, xdata)
  Qf      <- ncol(xfec)
  xrep    <- model.matrix(formulaRep, xdata)
  Qr      <- ncol(xrep)
  
  if(!SPECS){
    ss     <- paste('species',specNames,sep='')
    xnames <- paste(ss,colnames(xfec),sep=':')
    xnames[1] <- .replaceString(xnames[1],':(Intercept)','')
    colnames(xfec) <- xnames
  }
    
  xytree <- xytrap <- distall <- numeric(0)
  
  for(j in 1:nplot){
    
    xy1 <- matrix( runif(2*ntreePlot[j],0,plotWide), ntreePlot[j],2)  
    xy2 <- matrix( runif(2*ntrapPlot[j],0,plotWide), ntrapPlot[j],2)
    xy1 <- round(xy1,1)
    xy2 <- round(xy2,1)
    
    rownames(xy1) <- columnPaste(rep(plotNames[j],ntreePlot[j]), 
                                 c(1:ntreePlot[j]), '-')
    rownames(xy2) <- columnPaste(rep(plotNames[j],ntrapPlot[j]), 
                                 c(1:ntrapPlot[j]), '-')
    xytree  <- rbind(xytree, xy1)
    xytrap  <- rbind(xytrap, xy2)
  }
  
  xdata <- xdata[,!colnames(xdata) %in% colnames(tree),drop=F]
  
  treeData <- cbind(tree,xdata)
  count    <- matrix(0, nrow(trap), length(seedNames))
  colnames(count) <- seedNames
  seedData <- data.frame(trap, count)
  
  colnames(xytree) <- colnames(xytrap) <- c('x','y')
  xy <- columnSplit(rownames(xytree),'-')
  colnames(xy) <- c('plot','tree')
  xytree <- data.frame( xy, xytree )
  wws <- match(rownames(xytree), 
               as.character(treeData$treeID))
  xytree$species <- as.character( treeData$species[ wws ] )
  
  xy <- columnSplit(rownames(xytrap),'-')
  colnames(xy) <- c('plot','trap')
  xytrap <- data.frame( xy, xytrap )
  
  xytree$treeID <- rownames(xytree)
  xytrap$trapID <- rownames(xytrap)
  
 # formulaFec <- .specFormula(formulaFec)
 # formulaRep <- .specFormula(formulaRep)
  
  seedData$active <- 1
  seedData$area   <- 1
  
  ntree    <- nrow(xytree)
  nyr      <- max(nyrPlot)
  dmat     <- matrix(runif(ntree*nyr, .2, .5), ntree, nyr )
  
  dmat[,1] <- .tnorm(ntree, 1, 70, 35, 40) 
  small    <- sample(ntree,round(ntree/3))
  dmat[small,1] <- .tnorm(length(small), 1, 40, 8, 30)
  if(nyr > 1)dmat <- round(t( apply(dmat,1,cumsum) ), 2)
  
  
  tyindex  <- cbind(treeData$dcol, match(treeData$year,years))
  treeData$diam <- dmat[ tyindex ]
  
  treeData$obs <- 1
  seedData$obs <- 1
  
  tmp <- .setupData(formulaFec, formulaRep, treeData, seedData, 
                    xytree, xytrap, specNames, seedNames, 
                    AR=F, YR=F, yearEffect, minDiam, maxDiam)
  treeData  <- tmp$tdata
  seedData  <- tmp$sdata
  distall   <- tmp$distall
  xytree    <- tmp$xytree
  xytrap    <- tmp$xytrap
  plotNames <- tmp$plotNames
  plots     <- tmp$plots
  years     <- tmp$years
  xfec      <- tmp$xfec
  xrep      <- tmp$xrep
  nseed     <- nrow(seedData)
  scode     <- tmp$scode
  nplot     <- length(plotNames)
  n         <- nrow(xfec)
  ntobs     <- table(treeData$plot) 
  nsobs     <- table(seedData$plot)
  ttab      <- table(treeData$plot, treeData$year)
  wtab      <- which(ttab > 0, arr.ind=T) 
  xfecMiss <- tmp$xfecMiss
  xrepMiss <- tmp$xrepMiss
  xfecCols <- tmp$xfecCols
  xrepCols <- tmp$xrepCols
  ntree    <- nrow(xytree)
  ntrap    <- nrow(xytrap)
  xfecU    <- tmp$xfecU; xfecT <- tmp$xfecT
  xrepU    <- tmp$xrepU; xrepT <- tmp$xrepT
  xfecs2u  <- tmp$xfecs2u
  xfecu2s  <- tmp$xfecu2s
  xreps2u  <- tmp$xreps2u
  xrepu2s  <- tmp$xrepu2s
  nspec    <- length(specNames)
  
 # attr(distall,'species') <- rep(1, ncol(distall) )
  
 
  
  dmin <- dmax <- numeric(0)
  for(k in 1:nspec){
    wk <- which(treeData$species == specNames[k])
    wm <- which.min( (treeData$diam[wk] - minDiam)^2 )
    wf <- xfec[wk[wm],]
    dmin <- c(dmin, wf[!wf %in% c(0,1)][1])
    
    wm <- which.min( (treeData$diam[wk] - maxDiam)^2 )
    wf <- xfec[wk[wm],]
    dmax <- c(dmax, wf[!wf %in% c(0,1)][1])
  }
  
  plotTreeYr <- columnPaste(as.character(treeData$treeID), 
                            as.character(tree$year), '_')
  
   dcols <- grep('diam',colnames(xfec))
   dd    <- rowSums(xfec[,dcols, drop=F])
   w30   <- which.min( (treeData$diam - 25)^2 )
   dmin  <- dd[w30]
   ddev  <- dd - dmin
   
   #2, 3
   betaFec <- matrix( runif(ncol(xfec), 2, 4), ncol=1)
   rownames(betaFec) <- colnames(xfec)
   wcol  <- grep('diam',colnames(xfec)) 
   q20   <- quantile(xfec[!xfec %in% c(0,1)],.3)
   slope <- (1.0*log(maxFec) - betaFec[-wcol])/(max(xfec[,wcol]) - dmin)
   
   betaFec[wcol,1] <- slope
   betaFec[-wcol,1] <- t( -slope*dmin )
   fec <- xfec%*%betaFec
   
   betaRep <- solve(crossprod(xrep))%*%crossprod(xrep,ddev)
  
  w <- rnorm(nrow(xrep), xrep%*%betaRep, .5)
  z <- w*0
  z[w > 0] <- 1
  
  zmat <- matrix(0, ntree, nyr )
  dmat <- zmat + 1
  zmat[ tyindex ] <- z
  #dmat[ tyindex ] <- ddev
  #dmat[dmat < 0] <- 0
 # dmat[dmat > 0] <- 1
  
  if(nyr > 1)zmat <- round(t( apply(zmat*dmat,1,cumsum) ), 2)
  zmat[zmat > 1] <- 1
  
  z <- zmat[ tyindex ]
  z[treeData$diam < minDiam] <- 0
  
  lo <- hi <- z*0
  lo[z == 0] <- -10
  hi[z == 1] <- 10
  w <- .tnorm(length(fec), lo, hi, xrep%*%betaRep, .01)
  betaRep <- solve(crossprod(xrep))%*%crossprod(xrep,w)
  
   hi  <- 0*fec + log(maxFec)
   lo <- -hi/3
   hi[z == 0] <- 0
   lo[z ==1] <- 0
   
   for(j in 1:10){
     fec <- .tnorm(nrow(xfec), lo, hi, xfec%*%betaFec, .01)
     betaFec <- solve( crossprod(xfec) )%*%crossprod(xfec,fec)
   }
  
  ztrue <- z
  zmat[ sample(n,n/20) ] <- NA
  
  treeData$repr <- zmat[ tyindex ]

  tmp <- .getRepro(zmat, dmat, minDiam, maxDiam)
  last0first1 <- tmp$last0first1
  
  q <- which(ztrue == 1)
  betaFec <- solve( crossprod(xfec[q,]) )%*%crossprod(xfec[q,],fec[q])
  hi[ztrue > 0]  <- log(maxFec)
  lo[ztrue <= 0] <- -log(maxFec)/2
  fec <- .tnorm(nrow(xfec), lo, hi, xfec%*%betaFec, .01)
  betaFec <- solve( crossprod(xfec[q,]) )%*%crossprod(xfec[q,],fec[q])
  fec <- .tnorm(nrow(xfec), lo, hi, xfec%*%betaFec, .01)
 
 # attr(distall,'group') <- rep(1, ncol(distall) )

  
  seedData$active <- seedData$area <- 1
  
  fec <- exp(fec)
  
  #unstandardize coefficients
  bfecSave <- xfecs2u%*%betaFec      
  brepSave <- xreps2u%*%betaRep

  # R matrix
  
  fill <- 0
  if(length(seedNames) == 1)fill <- 1
  
  R <- matrix(fill, length(plots)*nspec, length(seedNames))
  colnames(R) <- seedNames
  rr <- as.vector( outer(specNames, plots, paste, sep='-') )
  rownames(R) <- rr
    
  wun <- grep('UNKN', seedNames)
  if(length(wun) > 0){
    kk <- c(1:length(seedNames))[-wun]
    for(k in kk){
      wsp <- grep(seedNames[k],rownames(R))
      R[wsp,seedNames[k]] <- 1
    }
    R[,wun] <- 2
    R <- sweep(R, 1, rowSums(R), '/')
  }
  tmp <- columnSplit(rownames(R),'-')
  attr(R, 'species') <- tmp[,1]
  attr(R, 'plot')    <- tmp[,2]
  
  treeData$specPlot <- columnPaste(treeData$species,treeData$plot)
   
  lambda <- .getLambda(treeData, seedData, 
                       seedData$area, upar, fec*z, R,
                       SAMPR, distall, years, PERAREA=F) 
  lambda <- lambda + 1e-8
  ss     <- matrix(rpois(length(lambda),lambda),nrow(lambda), ncol(lambda))
  seedData[,seedNames] <-   ss
  seedData$active <- 1
  seedData$area   <- 1
  
  seedData$active <- 1
  seedData$area   <- 1
  
  stab <- with( seedData, table(plot, year) )
  ttab <- with( treeData, table(plot, year) )
  sc   <- colSums(stab)
  stab <- stab[,sc > 0, drop=F]
  ttab <- ttab[,sc > 0, drop=F]
  
  form <- as.character( formulaFec )
  form <- .replaceString( form, 'species *', '')
  formulaFec <- as.formula(form)
  
  form <- as.character( formulaRep )
  form <- .replaceString( form, 'species *', '')
  formulaRep <- as.formula(form)

 # xx <- cbind(1, treeData$diam)
  
  names(fec) <- names(ztrue) <- plotTreeYr
  
  trueValues <- list(fec = fec, repr = ztrue, betaFec = bfecSave, 
                     betaRep = brepSave,upar = upar, R = R)
  
  treeData <- treeData[,c('plot','tree','year','species','diam','repr','repMu')]
  seedData <- seedData[,c('plot','trap','year','area','active',seedNames)]
  xytree   <- xytree[,c('plot','tree','x','y')]
  xytrap   <- xytrap[,c('plot','trap','x','y')]
  
  out <- list(trueValues = trueValues, treeData = treeData, seedData = seedData, 
       distall = distall, xytree = xytree, xytrap = xytrap, formulaFec = formulaFec,
       formulaRep = formulaRep, plots = plots, years = years,
       sim = sim,seedNames = seedNames, specNames = specNames, R = R)
  orr <- order(names(out))
  out <- out[orr]
  out
}
      
.seedFormat <- function(sfile, lfile, trapFile = NULL, seedNames = NULL, 
                        genusName = NULL, omitNames = NULL, plot,
                        newplot = NULL, trapID, monthYr = 7 ) {
  
  if(is.null(trapFile))trapFile <- "/Users/jimclark/makeMast/dataFiles/seedTrapArea.txt"
  
  if(is.null(newplot))newplot <- plot
  
  hcols <- c('trapnum','basket','month','day','year','pineyr','spryr','fallyr')
  
  midCD <- c( 273890.6, 3938623.3 )  #plot center for (x,y) at GSNP_CD
  
  loc  <- read.table(lfile, header=T)
  if(!'x' %in% colnames(loc)){
    xy <- loc[,c('UTMx','UTMy')]
    xy <- round(sweep(xy,2,colMeans(xy),'-'),1)
    loc$x <- xy[,1]
    loc$y <- xy[,2]
  }
  loc  <- loc[is.finite(loc[,'UTMx']) & is.finite(loc[,'UTMy']),]
  pcol <- rep(newplot, nrow(loc))
  id   <- apply( cbind(newplot, loc[,trapID]), 1, paste0, collapse='-')
  loc  <- data.frame(trapID = id, trap = loc[,trapID], 
                     loc[,!colnames(loc) == trapID])
  loc$plot <- pcol
  loc$UTMx <- loc[,'UTMx']
  loc$UTMy <- loc[,'UTMy']
  
  if(plot == "GSNP_CD" | plot == "GRSM_CD"){
    loc$x <- loc$UTMx - midCD[1]
    loc$y <- loc$UTMy - midCD[2]
  }
  
  counts <- read.table(sfile, header=T)
  counts[is.na(counts$month),'month'] <- 3
  counts[counts[,'month'] < monthYr,'year'] <- 
    counts[counts[,'month'] < monthYr,'year'] - 1
  
  #all NA
  dmat <- as.matrix( counts[,!colnames(counts) %in% hcols] )
  dmat[is.finite(dmat)] <- 1
  miss <- which(rowSums(dmat, na.rm=T) == 0)
  
  if(is.null(genusName)){
    sj <- counts[,colnames(counts) %in% seedNames, drop=F]
  }else{
    sj <- counts[,grep(genusName, colnames(counts)), drop=F]
    seedNames <- colnames(sj)
  }
  if(!is.null(omitNames)){
    sj <- sj[,!colnames(sj) %in% omitNames, drop=F]
    seedNames <- colnames(sj)
  }
  
  if(length(sj) == 0){
    sj <- matrix(0,nrow(counts),1)
    seedNames <- colnames(sj) <- paste(genusName,'UNKN',sep='')
  }
  
  yr <- sort(unique(counts[,'year']))
  tn <- sort(unique(counts[,trapID]))
  jj <- match(counts[,'year'],yr)
  ii <- match(counts[,trapID],tn)
  smat <- matrix(0, length(tn), length(yr))
  
  seedj <- numeric(0)
  
  for(k in 1:ncol(sj)){
    
    # seed counts
    ck <- sj[,k]
    wk <- which(is.finite(ck))
    ck <- ck[wk]
    ik <- ii[wk]
    jk <- jj[wk]
    ky <- .myBy(ck, ik, jk, summat=smat, fun='sum')
  #  sy <- .myBy(ck*0 + 1, ik, jk, summat=smat, fun='sum')
    colnames(ky) <- yr
    rownames(ky) <- tn
    
    # missing values
    ck <- nk <- sj[,k]*0+1
    wk <- which(is.na(ck))
    ck[wk] <- 0
    nk[wk] <- 1
    ik <- ii
    jk <- jj
    ny <- .myBy(ck, ik, jk, summat=smat, fun='sum')       #active intervals
    my <- .myBy(nk, ik, jk, summat=smat, fun='sum') #total intervals
    colnames(ny) <- yr
    rownames(ny) <- tn
    
    seedj <- cbind(seedj, as.vector(ky))
    
    if(k == 1){
      active <- round(ny/my, 2)
      active[!is.finite(active)] <- 0
    }
  }
  colnames(seedj) <- colnames(sj)
  seed <- matrix(0, nrow(seedj), length(seedNames))
  colnames(seed) <- seedNames
  
  active <- as.vector(active)
  area <- read.table(trapFile,header=T)[,c('plot','seedArea')]
  area <- area[area$plot == newplot,'seedArea']
  
  seed[,colnames(seedj)] <- seedj
  
  year <- rep(yr, each = length(tn))
  trap <- rep(tn, length(yr) )
 # plot <- rep(plot, length(trap))
  tr <- apply(cbind(newplot, trap), 1, paste0, collapse='-')
  
  sd   <- data.frame( plot=rep(newplot, length(tr)), trapID=tr, trap=trap, 
                      year=year,active=active, area = area) 
  seed <- cbind(sd, seed)
  rownames(seed) <- 
    apply( cbind(newplot, trap, year), 1, paste0, collapse='-')
  
  seed <- seed[seed$trapID %in% loc$trapID,]
  
  list(counts = seed, xy = loc, active = active, seedNames = seedNames )
}

.getRepro <- function(rmat, dmat, minDiam, maxDiam){
  
  nc <- ncol(rmat)
  nr <- nrow(rmat)
  
  minDiam <- mean(minDiam)
  maxDiam <- mean(maxDiam)
  
  zknown <- rmat
  
  zeros <- ones <- ind <- matrix(1:nc, nr, nc, byrow=T)
  ones  <- ones*rmat
  ones[ones == 0] <- NA
  first1  <- suppressWarnings(apply(ones, 1, min, na.rm=T)) # this is first 1
  ones  <- matrix( first1, nr, nc)
  ones[ones <= ind] <- 1
  ones[ones > ind] <- 0
  first1[first1 == Inf] <- ncol(rmat) + 1
  all1 <- which(rowSums(ones) == ncol(ones))
  
  zeros <- zeros*(1 - rmat)
  zeros[ ones == 1 ] <- 0
  last0  <- suppressWarnings(apply(zeros, 1, max, na.rm=T)) # this is last 0
  zeros  <- matrix( last0, nr, nc)
  zeros[ zeros == 0] <- NA
  zeros[ zeros == -Inf ] <- NA
  zeros[zeros < ind] <- 0
  zeros[zeros >= ind] <- 1
  rmat[ ones == 1 ] <- 1
  rmat[ zeros == 1 ] <- 0
  last0[last0 < 0] <- 0
  all0 <- which(rowSums(zeros) == ncol(zeros))
  
  last0first1 <- cbind(last0, first1)
  
  mm <- matrix(0, length(last0), 2)
  colnames(mm) <- c('all0','all1')
  mm[all0,1] <- 1
  mm[all1,2] <- 1
  last0first1 <- cbind(last0first1,mm)
  
  rownames(last0first1) <- paste('drow',1:nrow(last0first1),sep='_')
  
  mmat <- matrix(1:nc, nr, nc, byrow=T)
  
  mid <- (maxDiam + minDiam)/2
  ss  <- (mid - minDiam)/2
  pd  <- pnorm(dmat,mid,ss)
  pd  <- rowMeans(pd, na.rm=T)
  rr  <- rbinom(length(pd),1,pd)
  rr[all1] <- 1
  rr[all0] <- 0
  
  wm   <- which(rr == 1)
  wf   <- which(first1 <= nc)
  ones <- zeros <- mmat*0
  ones[ cbind(1:nr, first1)[wf,] ] <- 1
  ones  <- t(apply(ones,1,cumsum))
  
  wl  <- which(last0 > 0)
  zeros[ cbind(1:nr, last0)[wl,] ] <- 1
  zeros[,nc] <- 0
  
  zeros <- t(apply(zeros,1,rev))
  zeros <- t(apply(zeros,1,cumsum))
  zeros <- t(apply(zeros,1,rev))
  zeros[all0,] <- 1
  
  mmat[rr == 1,] <- 1
  mmat[ones == 1] <- 1
  mmat[zeros > 0] <- 0
  
  mmat[mmat == 0] <- 1000
  
  myr <- apply(mmat, 1, which.min)
  myr[all0] <- nc + 1
  
  mmat[mmat == 1000] <- 0
  mmat[mmat > 0] <- 1
  
  list(rmat = mmat, matYr = myr, last0first1 = last0first1)
}

.treeFormat <- function( tfile, specNames = NULL, genusName = NULL, 
                         changeNames = NULL, plot, newplot = NULL, years, yrCols  ){
  
  
  midCD <- c( 273890.6, 3938623.3 )  #plot center for (x,y) at GSNP_CD
  
  region <- unlist(strsplit(plot,'_'))[1]
  trees  <- read.table( tfile, header=T)

  trees$ID   <- as.character(trees$ID)
  
  if(plot == "GSNP_CD"){
    trees$x <- trees$UTMx - midCD[1]
    trees$y <- trees$UTMy - midCD[2]
  }
  
  trees$plot <- newplot
  trees$species <- as.character(trees$species)
  
  if( is.null(genusName) ){
    wj     <- which(trees$species %in% specNames & is.finite(trees$x) &
                      is.finite(trees$y))
  }else{
    ww <- grep(genusName,as.character(trees$species) )
    wj <- ww[which(is.finite(trees$x[ww]) & is.finite(trees$y[ww]))]
    specNames <- sort(unique(trees$species[wj]))
  }
  if(length(wj) == 0)return( list(yrDat = numeric(0)) )
  
  trees  <- trees[drop=F,wj,]
  wchange <- which( as.character(trees$species) %in% changeNames[,1])
  if(length(wchange) > 0){
    ts <- as.character(trees$species)
    wm <- match(ts[wchange],changeNames[,1])
    ts[wchange] <- changeNames[wm,2]
    trees$species <- as.factor(ts)
  }
  
  for(k in 1:length(yrCols)){                      # yrCol2017
    
    tk <- as.matrix( trees[,grep(yrCols[k],colnames(trees))] )
    wmin <- suppressWarnings( apply(tk,1,min, na.rm=T) )
    wna <- which(! is.finite( wmin ) )
    if(length(wna) > 0)trees <- trees[-wna,]
  }
  if(nrow(trees) == 0)return( list(yrDat = numeric(0)) )
  
  # trees with multiple stems
  ID      <- as.character(trees$ID)
  dup     <- which(duplicated(ID))
  diamCol <- grep('diam',colnames(trees))
  
  if(length(dup) > 0){
    
    omit <- numeric(0)
    
    for(j in dup){
      
      idup <- which(ID == ID[j])
      tj   <- apply(trees[idup,diamCol], 1, max, na.rm=T)
      tj   <- which.max(tj)
      omit <- c(omit, idup[-tj])
    }
    omit <- unique(omit)
    trees <- trees[-omit,]
  }
  
  scols <- trees[,grep('sex',colnames(trees))]
  
  ccol <- matrix( unlist( strsplit(colnames(scols),'sex') ), ncol=2,byrow=2)[,2]
  colnames(scols) <- ccol
  
  snew <- matrix(NA, nrow(trees), length(years))
  colnames(snew) <- years
  
  snot <- which(scols == 'N', arr.ind=T)
  srep <- which(scols == 'R' | scols == 'F', arr.ind=T)
  sfem <- which(scols == 'F', arr.ind=T)
  smal <- which(scols == 'M', arr.ind=T)
  
  smal <- smal[!smal[,1] %in% sfem[,1],]  # female overrides male
  if(!is.matrix(smal))smal <- matrix(smal,1)
  
  matr <- repr <- matrix(NA, nrow(trees), ncol(scols))
  colnames(matr) <- ccol
  repr[smal[,1],] <- 0
  repr[sfem[,1],] <- 1
  
  matr[snot] <- 0
  matr[srep] <- 1
  
  #########
  
  snew[,colnames(matr)] <- matr
  
  #  repStatus <- tmp$repStatus
  
  yrDat  <- matrix(NA, length(years)*nrow(trees), length(yrCols))
  id     <- sort( unique(as.character(trees$ID)) )
  tindex <- rep(id, each=length(years) )
  yindex <- rep(years, length(id) )
  
  index <- apply(cbind(tindex,yindex),1,paste0,collapse='-')
  rownames(yrDat) <- index
  colnames(yrDat) <- yrCols
  
  
  elev <- NA
  if('elev' %in% colnames(trees))elev <- trees[,'elev']
  
  xytree <- trees[,c('x','y','UTMx','UTMy')]
  id     <- apply( cbind(newplot, as.character(trees$ID)), 1, paste0, 
                   collapse='-')
  xytree <- data.frame(treeID = id, plot = newplot, tree = trees$ID, xytree)
  xytree$elev <- elev
  
  
  for(k in 1:length(yrCols)){                      # yrCol2017
    
    tk <- as.matrix( trees[,grep(yrCols[k],colnames(trees))] )
    kk <- matrix( unlist(strsplit(colnames(tk),yrCols[k])), ncol=2,byrow=T)[,2]
    yk <- as.numeric(kk)
    yseq <- min(yk):max(yk)
    
    syr  <- trees[,'censinyr']                             # left censored
    imat <- matrix(years, nrow(trees), length(years), byrow=T) 
    wmin <- which(is.finite(tk),arr.ind=T)                 # measurements exist
    tmp  <- .myBy( yk[wmin[,2]], wmin[,1], wmin[,1]*0+1, fun='min')
    syr  <- pmin(syr, tmp, na.rm=T)
    
    syr  <- matrix(syr, nrow(trees), length(years))           # start
    eyr  <- suppressWarnings( apply(trees[,c('deathyr','censoryr')],1,min, na.rm=T) )
    eyr  <- matrix(eyr, nrow(trees), length(years))               # end
    eyr[eyr == Inf] <- max(yk) 
    imat[imat < syr | imat > eyr] <- NA
    tmat <- matrix(trees[,'ID'], nrow(tk), length(years))
    
    dmat <- matrix(NA, nrow(tk), length(years))
    icol <- match(yk, years)
    irow <- rep(1:nrow(tk),each=length(icol))
    icol <- rep(icol, nrow(tk))
    jcol <- rep(1:length(yk),nrow(tk))
    dmat[ cbind(irow,icol) ] <- tk[ cbind(irow, jcol) ]   # interpolate here
    colnames(dmat) <- years
    
    start <- match( suppressWarnings( apply(imat,1,min,na.rm=T)), years)
    end   <- match( suppressWarnings( apply(imat,1,max,na.rm=T)), years)
    
    wf <- which(is.finite(start) & is.finite(end) & end > start)
    
    if(length(wf) > 0){
      minVal <- 0
      maxVal <- 400
      if(yrCols[k] == 'canopy'){
        minVal <- 0
        maxVal <- 2
      } 
      
      tmp <- .interpRows(dmat[drop=F,wf,],startIndex=start[wf],endIndex=end[wf],
                         INCREASING=F,minVal=minVal,maxVal=maxVal,
                         defaultValue=NULL,tinySlope=.001)
      dmat[wf,] <- tmp
    }
    
    if(yrCols[k] == 'canopy'){
      maxVal <- suppressWarnings( apply(dmat[drop=F,wf,], 1, max,na.rm=T) )
      wmm    <- which(is.finite(maxVal))
      mmat   <- matrix(maxVal[wmm],length(wmm),ncol(tmp))
      ww     <- which(tmp[wmm,] > mmat)
      tmp[wmm,][ww] <- mmat[ww]
    }
    
    dvec <- dmat[is.finite(imat)]
    
    it   <- tmat[is.finite(imat)]
    iy   <- imat[is.finite(imat)]
    inn  <- apply(cbind(it,iy),1,paste0,collapse='-')
    yrDat[match(inn, index),k] <- dvec
    
    if(yrCols[k] == 'diam'){
      dinc <- t(apply(dmat,1,diff,na.rm=T))
      dinc <- cbind(dinc[,1],dinc)
      dinc <- dinc[is.finite(imat)]
      growth  <- rep(0,nrow(yrDat))
      growth[match(inn, index)] <- dinc
    }
  }
  
  if('diam' %in% yrCols){
    yrDat <- cbind(yrDat,growth)
  }
  
  spec <- trees[match(tindex,trees[,'ID']),'species']
  repr <- rep(NA, nrow(yrDat))
  repr[match(inn, index)] <- snew[is.finite(imat)]
  
  
  treeID <- apply(cbind(newplot, tindex),1,paste0, collapse='-')
  yrDat <- data.frame(plot = newplot, treeID = treeID, tree = tindex, species = spec, 
                      year = yindex, 
                      repr = repr, yrDat)
  yrDat <- yrDat[is.finite(yrDat$diam) & yrDat$diam > 1,]
  xytree <- xytree[xytree$treeID %in% yrDat$treeID,]
  
  rownames(yrDat) <- NULL
  
  list(yrDat = yrDat, xytree = xytree)
}

.fac2num <- function(xx){ 
  
  dims <- dn <- NULL
  
  if(!is.null(ncol(xx))){
    dims <- dim(xx)
    dn   <- dimnames(xx)
  }
  xx <- if(is.list(xx))unlist(xx)
  xx <- as.numeric(as.character(xx)) 
  if(!is.null(dims))xx <- matrix(xx, dims[1], dims[2], 
                                 dimnames = dn)
  xx
}

.replaceString <- function(xx, now='_', new=' '){  #replace now string in vector with new
  
  ww <- grep(now,xx,fixed=T)
  if(length(ww) == 0)return(xx)
  
  if(length(new) == 1){
    for(k in ww){
      s  <- unlist( strsplit(xx[k],now,fixed=T) )
      ss <- s[1]
      if(length(s) == 1)ss <- paste( ss,new,sep='')
      if(length(s) > 1)for(kk in 2:length(s)) ss <- paste( ss,s[kk],sep=new)
      xx[k] <- ss
    }
  }else{
    # new is a vector
    s  <- unlist( strsplit(xx,now,fixed=T) )
    nx <- length(xx)
    nc <- length(s)/length(xx)

    ss <- matrix(s, ncol=nc, byrow=T)
    nl <- nchar(ss[1,])
    
    if(nl[1] == 0)ss <- paste(new, ss[,2], sep='')
    if(nl[2] == 0)ss <- paste(ss[,1], new, sep='')
      
    xx <- ss
  }
  xx
}

.Iformat2Var <- function(iname){
  
  tt <- .replaceString(iname, 'I(','')
  tt <- .replaceString(tt, 'log(','')
  tt <- .replaceString(tt, 'sqrt(','')
  tt <- .replaceString(tt, '^2','')
  tt <- .replaceString(tt, ')','')
  tt <- .replaceString(tt, ' ','')
  tt
}

.get.model.frame <- function(formula, data){
  
  tmp <- model.frame(formula, data, na.action=NULL)
  
  wchar <- which( sapply(tmp, is.character) )
  
  if(length(wchar) == 0)return( tmp )
  
  for(k in 1:length(wchar)){
    data[,wchar[k]] <- as.character( data[,wchar[k]] )
  }
  model.frame(formula, data, na.action=NULL)
}
  
  
  

.getDesign <- function(formula, data){
  
  # one set of columns for each tree species, retain NAs
  
  specNames <- sort(unique(as.character(data$species)))
  nspec     <- length(specNames)
  
  f1 <- paste0( as.character(formula), collapse='')
  
  if(f1  == '~1' & nspec == 1){
    x  <-  matrix(1, nrow(data), 1)
    colnames(x) <- "(Intercept)"
    return( list(x = x, missx = integer(0), specCols = numeric(0) ) )
  }
  
  attr(data$species,'contrasts') <- contrasts(data$species, contrasts=F)
  
  tmp1 <- .get.model.frame(formula, data )
  tn1  <- attr( terms(tmp1), 'dataClasses' )
  sp1  <- names(tn1)[tn1 == 'numeric' | tn1 == 'nmatrix.1']
  sp1  <- .Iformat2Var(sp1)
  sp1  <- unique(sp1)
  miss <- which(is.na(data[,sp1]),arr.ind=T)
  
  if(length(miss) > 0){
    xmean <- colMeans(data[,sp1], na.rm=T)
    data[,sp1][miss] <- 1e+10
    cat('\nNote: missing values in xfec filled with mean values\n')
  }
  
  x  <- model.matrix(formula, data)
  if(nspec > 1){
    ws <- grep('species',colnames(x))
    x  <- x[,ws]
  }
  missx <- which(x > 1e+9,arr.ind=T)
  
  if(length(missx) > 0){
    data[,sp1][miss] <- xmean[miss[,2]]
    
    mux <- apply(x, 2, mean, na.rm=T)
    x[missx] <- mux[missx[,2]]
  }
  x  <- model.matrix(formula, data)
  if(nspec > 1){
    ws <- grep('species',colnames(x))
    x  <- x[,ws]
  }
  
  # specNames <- attr(data$species,'levels')
  specCols  <- numeric(0)
  if(nspec > 1){
    for(j in 1:length(specNames)){
      specCols <- rbind(specCols, grep( paste('species',specNames[j],sep=''),
                                        colnames(x)))
    }
    rownames(specCols) <- specNames
  }
  
  list(x = x, missx = missx, specCols = specCols)
}

columnSplit <- function(vec, sep='_', ASFACTOR = F, ASNUMERIC=F,
                        LASTONLY=F){
  
  vec <- as.character(vec)
  nc  <- length( strsplit(vec[1], sep, fixed=T)[[1]] )
  
  mat <- matrix( unlist( strsplit(vec, sep) ), ncol=nc, byrow=T )
  if(LASTONLY & ncol(mat) > 2){
    rnn <- mat[,1]
    for(k in 2:(ncol(mat)-1)){
      rnn <- columnPaste(rnn,mat[,k])
    }
    mat <- cbind(rnn,mat[,ncol(mat)])
  }
  if(ASNUMERIC){
    mat <- matrix( as.numeric(mat), ncol=nc )
  }
  if(ASFACTOR){
    mat <- data.frame(mat)
  }
  if(LASTONLY)mat <- mat[,2]
  mat
}

columnPaste <- function(c1, c2, sep='-', MODE='character'){
  
  FACT <- T
  if(!is.factor(c1) | !MODE == 'factor')FACT <- F
  c1    <- as.character(c1)
  c2    <- as.character(c2)
  c12   <- apply( cbind(c1, c2) , 1, paste0, collapse=sep)
  c12   <- .replaceString(c12, ' ', '')
  if(FACT) c12 <- as.factor(c12)
  c12
}

specPriorVector <- function(pVar, tdata){
  
  if(length(pVar) > 1){
    pVar <- pVar[tdata$species]
  }else{
    pVar <- rep(pVar, nrow(tdata))
  }
  pVar
}

reprInit <- function(tdata, minDiam = 1, maxDiam = 50){
  
  if(!'repr' %in% colnames(tdata))tdata$repr <- NA
  if(!'repMu' %in% colnames(tdata))tdata$repMu <- .2
  if(!'repSd' %in% colnames(tdata))tdata$repSd <- .25
  
  minDiam <- specPriorVector(minDiam, tdata)
  maxDiam <- specPriorVector(maxDiam, tdata)
  
  tdata$repr[is.na(tdata$repr) & tdata$diam < minDiam] <- 0
  tdata$repr[is.na(tdata$repr) & tdata$diam > maxDiam] <- 1
  
  tdata$repMu[is.na(tdata$repr) & tdata$diam > minDiam] <- .5   # prior mean
  tdata$repMu[is.na(tdata$repr) & tdata$diam < minDiam] <- 0
  
  tdata$repMu[is.na(tdata$repr) & tdata$diam > maxDiam] <- 1
  
  tdata$repMu[!is.finite(tdata$repMu)] <- .5
  tdata$repSd[!is.finite(tdata$repSd)] <- .25
  
  tdata
}

.setupData <- function(formulaFec, formulaRep, tdata, sdata,
                          xytree, xytrap, specNames, seedNames, AR, YR, 
                          yearEffect, minDiam, maxDiam){
  
  # formulas have 'species *' already
  arList <- numeric(0)
  plag <- 0
  notCols <- designTable <- NULL
  words <- character(0)
  
  plotNames <- sort(unique( as.character(xytrap$plot) ))
  years <- sort(unique(c(sdata$year[sdata$obs == 1],tdata$year[tdata$obs == 1])))
  years <- c(min(years):max(years))
  
  allYears <- sort(unique(c(sdata$year,tdata$year)))
  allYears <- c(min(allYears):max(allYears))

  nplot <- length(plotNames)
  nspec <- length(specNames)
  nyr   <- length(allYears)
  
  plotYears <- sort(unique( c(as.character(tdata$plotYr), 
                              as.character(sdata$plotYr))) )
  
  tdata <- reprInit(tdata, minDiam, maxDiam)
  
  if(is.character(tdata$species))tdata$species <- as.factor(tdata$species)
  
  yeGr <- specNames[1]
  
  tdata$group <- 1
  
  if(YR | AR){
    gnames <- character(0)
    if('groups' %in% names(yearEffect))gnames <- yearEffect$groups
    wg <- which(!gnames %in% colnames(tdata))
    if(length(wg) > 0){
      words <- paste('columns specified in yearEffect not found in treeData:\n"',
                     gnames[wg],'"',sep='' )
      stop( words )
    }
    
    group <- as.character( tdata[,gnames] )
    if(length(gnames) > 1){
      ws <- which(gnames == 'species')     # 'species' must be last
      if(length(ws) > 0){
        gnames <- c('species',gnames)
        gnames <- gnames[!duplicated(gnames)]
        gnames <- rev(gnames)
      }
      group <- apply( tdata[,gnames], 1, paste0, collapse='-')
    }
    
    tdata$groupName <- group
    yeGr <- sort(unique(as.character(group)))
    tdata$group <- match(as.character(group), yeGr)
  }
  
  
  times <- match(tdata$year, allYears)
  yrIndex <- cbind(tdata$group, times)
  colnames(yrIndex) <- c('group','year')

  if(AR){        
    plag   <- yearEffect$p
    
    tdata$groupName <- as.factor(tdata$group)
    levels(tdata$groupName) <- yeGr

    tmp   <- msarSetup(tdata, plag, icol='treeID', jcol = 'times',
                       gcol = 'groupName')
    groupByInd <- tmp$groupByInd
    betaYr     <- tmp$betaYr
    yeGr       <- tmp$yeGr
    ngroup     <- length(yeGr)
    tdata$groupName <- as.character(tdata$groupName)
    
  #  g <- match(as.character(tdata$group),attr(tdata$group,'levels'))
    
    yrIndex    <- cbind(tdata$group, tdata$times)
    colnames(yrIndex) <- c('group','year')
    
    nocol <- c('i','j','g')
    tdata <- tdata[,!colnames(tdata) %in% nocol]
    
    lagMat <- msarLagTemplate(plag, tdata, icol='treeID', jcol='times', 
                              gcol='group', ocol='obs')
    rownames(lagMat[[1]]) <- tdata$plotTreeYr[lagMat[[1]][,1]]
    
    arList <- list(times = tdata$times, groupByInd = groupByInd, betaYr = betaYr,
                   yeGr = rownames(betaYr), ngroup = length(yeGr),
                   lagMatrix = lagMat$matrix, lagGroup = lagMat$group)
  }
  
  seedSummary <- with(sdata, table(plot, year) )
  treeSummary <- with(tdata, table(plot, year) )
  plotNames   <- rownames(treeSummary)
  
  if(nspec == 1){
    formulaFec <- as.formula( .replaceString( as.character(formulaFec), 'species *','') )
    formulaRep <- as.formula( .replaceString( as.character(formulaRep), 'species *','') )
  }
  
  tmp   <- .get.model.frame( formulaFec, tdata )
  
  if(ncol(tmp) == 1){
    checkNA <- range(tmp)
    if(is.na(checkNA[1])){
      pmiss <- colnames(tmp)
      cat('\nFix missing values in:\n')
      print(pmiss)
    }
  }else{
  #  checkNA <- sapply(tmp[-1],range)
    inn     <- which( !sapply(tmp, is.factor) )
    checkNA <- sapply(tmp[inn], range)
    wna <- which(is.na(checkNA[drop=F,1,]))
    if(length(wna) > 0){
      pmiss <- paste0(colnames(checkNA)[wna],collapse=', ')
      cat('\nNote: fix missing values in these variables:\n')
      print(pmiss)
    }
  }
  
  if(length(tmp) == 0)tmp <- numeric(0)
  tmp1  <- .get.model.frame(formulaRep, tdata)
  
  if(length(tmp1) > 0){
    
    wnew <- which(!colnames(tmp1) %in% colnames(tmp))
    
    if(length(wnew) > 0){                               # all unique columns
      tmp <- cbind(tmp,tmp1[,wnew])
    }
  }
  xallNames <- colnames(tmp)
  
  scode <- names(tmp[ which(sapply( tmp, is.factor )) ])
  if(length(scode) > 0){
    for(j in 1:length(scode)) tdata[,scode[j]] <- droplevels(tdata[,scode[j]])
  }
  ccode <- names(tmp[ which(sapply( tmp, is.character )) ])
  scode <- c(ccode, scode)
  
  specNames <- sort(unique(as.character(tdata$species)))
  
  standX <- character(0)
  xmean <- xsd <- numeric(0)
  
  wstand <- which(!colnames(tmp) %in% scode)
  
  # standardize columns in tdata
  if(length(wstand) > 0){
    
    standX <- colnames(tmp)[wstand]
    
    wlog <- grep( "log(", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    wlog <- grep( "sqrt(", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    wlog <- grep( "^2", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    
    if(length(standX) > 0){
      treeUnstand <- tdata[,standX, drop=F]
      
      xmean <- colMeans(tdata[,standX, drop=F],na.rm=T)
      xsd   <- apply(tdata[,standX, drop=F],2, sd, na.rm=T)
      xss   <- t( (t(tdata[,standX, drop=F]) - xmean)/xsd )
      tdata[,colnames(treeUnstand)] <- xss
    }
  }
  
  tmp  <- .getDesign(formulaFec, tdata)
  xfec <- tmp$x
  if(nspec > 1)xfec <- xfec[,grep('species',colnames(xfec)),drop=F]
  xfecMiss <- tmp$missx
  xfecCols <- tmp$specCols
  
  tmp  <- .getDesign(formulaRep, tdata)
  xrep <- tmp$x
  
  if(nspec > 1)xrep <- xrep[,grep('species',colnames(xrep)),drop=F]
  xrepMiss <- tmp$missx
  xrepCols <- tmp$specCols
  
  rank <- qr(xfec)$rank
  notFit <- notFull <- character(0)
  
 # if(rank < ncol(xfec)){
    
    if(ncol(xfec)/nspec > 2){   # more than intercept and slope
      for(m in 1:nspec){
        sname <- "(Intercept)"
        if(nspec > 1){
          sname <- paste('species',specNames[m],sep='')
          wk <- grep( sname, colnames(xfec) )
          wn <- which(colnames(xfec)[wk] != sname)
          wk <- wk[wn]
        }else{
          wk <- colnames(xfec)[colnames(xfec) != sname]
        }
        wr <- which(xfec[,sname] == 1)
        
 #       print(sname)
 #       print(wk)
 #       print(colnames(xfec))
 #       print(colnames(xfec)[wk])
        
        
        rmm <- qr(xfec[wr,wk])$rank
   #     cc <- suppressWarnings( cor(xfec[wr,wk][,-1]) )
        cc <- suppressWarnings( cor(xfec[wr,wk]) )
        cc[upper.tri(cc, diag=T)] <- 0
        ww <- which(abs(cc) > .95 | is.na(cc), arr.ind=T)
        
       if(rmm < length(wk) | length(ww) > 0){
          notFit <- c(notFit, unique(rownames(ww)))
        }
      }
    }
  if(length(notFit) > 0){
    kwords <- paste0(notFit, collapse='\n')
    kwords <- paste(' Fecundity is not full rank, omitted columns:\n',kwords)
    cat( paste('\nNote: ',kwords) )
    
    notCols <- match(notFit, colnames(xfec))
    words <- paste(words, kwords)
  }
#  }
  
  rank <- qr(xrep)$rank
  if(rank < ncol(xrep))stop('maturation design not full rank')
  
  xfecU <- xfec
  xrepU <- xrep
  xfecT <- xrepT <- NULL
  
  xfecs2u <- diag(ncol(xfec))
  xreps2u <- diag(ncol(xrep))
  colnames(xfecs2u) <- rownames(xfecs2u) <- colnames(xfec)
  colnames(xreps2u) <- rownames(xreps2u) <- colnames(xrep)
  
  xfecu2s <- xfecs2u
  xrepu2s <- xreps2u
  
  if(length(xmean) > 0){   # unstandardized
    
    tdata[,standX] <- treeUnstand
    tmp <- .unstandBeta(formula = formulaFec, xdata = tdata, xnow = xfec, 
                        xmean = xmean, notCols = notCols)
    xfecU   <- tmp$x
    xfecs2u <- tmp$unstand    #unstandardize
    xfecu2s <- tmp$stand
    
    tmp <- .unstandBeta(formula = formulaRep, xdata = tdata, xnow = xrep, 
                        xmean = xmean, notCols = notCols)
    xrepU   <- tmp$x
    xreps2u <- tmp$unstand
    xrepu2s <- tmp$stand
    
    xmean[abs(xmean) < 1e-10] <- 0
  }
  
  tdata <- cleanFactors(tdata)
  sdata <- cleanFactors(sdata)
  
  treeIDs <- sort(unique(as.character(tdata$treeID)))
  trapIDs <- sort(unique(as.character(sdata$trapID)))
  
  distall  <- numeric(0)
  treeid   <- trapid <- species <- character(0)
  
  plotRm <- character(0)
  
  for(j in plotNames){
    
    tj <- which(xytree$plot == j)
    sj <- which(xytrap$plot == j)
    
    if(length(tj) == 0){
      plotRm <- c(plotRm,j)
      message(paste('plot ',j,' is absent from xytree'))
      next
    }
    if(length(sj) == 0)stop( paste('plot', j ,'has no traps in xytrap') )
    
    xy1     <- xytree[tj,]
    xy2     <- xytrap[sj,]
    treeid  <- c(treeid,xytree$treeID[tj])
    trapid  <- c(trapid,xytrap$trapID[sj])
    species <- c(species, xytree$species[tj])
    da      <- .distmat(xy1[,'x'],xy1[,'y'],xy2[,'x'],xy2[,'y']) 
    da      <- round(da, 1)
    colnames(da) <- xy1$treeID
    rownames(da) <- xy2$trapID
    distall <- .blockDiag(distall,da)
  }
  
  names(species) <- treeIDs
  distall <- distall[,treeIDs]
  distall <- distall[trapIDs,]
  species <- species[treeIDs]
  names(species) <- NULL
  attr(distall,'species') <- species
  
 # attr(distall, 'group')  <- NULL######################################
  
  
  
  dcol  <- match(as.character(tdata$treeID), treeIDs)
  drow  <- match(as.character(sdata$trapID), trapIDs)
  tdata$dcol <- dcol
  sdata$drow <- drow
  
  distall[distall == 0] <- 10000
  
  tdata$species <- droplevels(tdata$species)
  
  seedNames <- seedNames[seedNames %in% colnames(sdata)]
  
  keepCol <- c('trapID','plot','year','trap','plotYr','plotyr','drow',
               'area','active','obs',seedNames)
  sdata <- sdata[,keepCol]
   
 # if(!AR){
 #   ngroup  <- 1
 #   yrIndex <- matrix(1,nrow(tdata),4)
 #   colnames(yrIndex) <- c('dcol','group','year','groupYr')
 #   yrIndex[,'year']  <- match(tdata$year,years)
 #   yrIndex[,'dcol']  <- tdata$dcol
 # }
  
  ynow   <- colnames(yrIndex)
  gy     <- columnPaste(tdata$group, yrIndex[,'year'])
  gyall  <- sort(unique(gy))
  groupYr <- match(gy,gyall)
  yrIndex <- cbind(yrIndex, tdata$dcol, groupYr)
  colnames(yrIndex) <- c(ynow, 'dcol','groupYr')

  
  
  specPlot  <- columnPaste( as.character( tdata$species), 
                            as.character(tdata$plot) )
  tdata$specPlot <- specPlot
  specPlots <- sort(unique(as.character(specPlot)))
  specPlot  <- match(specPlot,specPlots)
  yrIndex   <- cbind(yrIndex,specPlot)
  
 # ic <- sapply(tdata,is.character)
 # wc <- which(ic)
 # if(length(wc) > 0){
 #   for(j in wc){ tdata[[j]] <- as.factor(tdata[[j]]) }
 # }
  
  tdata$species <- as.factor(tdata$species)
  
  if(ncol(xfec)/nspec > 2){
    cat('\nVariance Inflation Factors, range, and correlation matrix:\n')
  }
  for(k in 1:nspec){
    if(nspec == 1){
      gg <- 1:ncol(xfec)
      xt <- xfec
      xu <- xfecU
      if(ncol(xt) <= 2)next
    }else{
      sk <- paste('species',specNames[k],sep='')
      st <- paste(sk,':',sep='')
      gg <- grep( sk, colnames(xfec))
      rr <- which(xfec[,sk] == 1)
      xt <- xfec[rr,gg]
      xu <- xfecU[rr,gg]
      colnames(xt)[1] <- 'intercept'
      colnames(xt)    <- .replaceString(colnames(xt), st, '')
    }
    
    if(ncol(xt) < 3)next

    xcheck <- .checkDesign(xt)
    VIF <- xcheck$VIF
    designTable <- xcheck$design
    
    cfx <- round( xcheck$correlation,1 )
    colnames(cfx) <- substr(colnames(cfx), 1, 5)
    cfx <- cfx[,1:(ncol(cfx)-1),drop=0]
    colnames(cfx) <- paste('corr',colnames(cfx),sep='_')
    
    xrange <- signif( t( apply(xu[,-1], 2, range) ), 3)
    colnames(xrange) <- c('min','max')
    
    cat( paste('\n                     ',specNames[k],'\n', sep='') )
    print( cbind(VIF, xrange, cfx) )
    
    if(max(xcheck$VIF, na.rm=T) > 10 | is.na(max(xcheck$VIF)))
      cat('\nVIF too high or undefined--too many predictors\n')
  }
  
  tdata$species <- as.character(tdata$species)
  tdata$treeID  <- as.factor(tdata$treeID)
  
  list(tdata = tdata, sdata = sdata, distall = distall, seedNames = seedNames,
       specNames = specNames, arList = arList, plotYears = plotYears,
       xytree = xytree, xytrap = xytrap, plotNames = plotNames,
       plots = plotNames, years = years, xfec = xfec, xrep = xrep, scode = scode,
       xfecMiss = xfecMiss, yeGr = yeGr,
       xrepMiss = xrepMiss, xfecCols = xfecCols, xrepCols = xrepCols,
       xmean = xmean, xsd = xsd, xfecU = xfecU, 
       xfecs2u = xfecs2u, xfecu2s = xfecu2s, xreps2u = xreps2u, xrepu2s = xrepu2s,
       xrepU = xrepU, xrepT = xrepT, specPlots = specPlots, yrIndex = yrIndex, notFit = notFit)
}
   

.stripI <- function( vname ){
  
  vname <- .replaceString( vname, "I(log(", "")
  vname <- .replaceString( vname, "I(sqrt(", "")
  vname <- .replaceString( vname, "I(", "")
  vname <- .replaceString( vname, "^2)", "")
  vname <- .replaceString( vname, "))", "")
  vname
}

.unstandBeta <- function(formula, xdata, xnow, xmean=NULL, notCols=NULL){
  
  # xnow  - current standardized matrix
  # xdata - data.frame, unstandardized variables
  
  tmp <- .get.model.frame(formula, xdata)  #unstandardized
  
  xterm <- names( tmp )
  st    <- grep('species',xterm)
  if(length(st) > 0)xterm <- xterm[-st]
  
 # if(length(xmean) > 0){
 #   xterm <- xterm[xterm %in% names(xmean)]
 #   if(length(xterm) == 0)return( list(x = xnow, stand = diag(1, ncol(xnow)),
 #                                      unstand = diag(1, ncol(xnow)) ) )
 # }
  
  xfu  <- .getDesign(formula, xdata)$x    # unstandardized
  
  if(length(st) > 0 & length(xterm) > 1)xfu  <- xfu[,grep('species',colnames(xfu))]
  
  xmm <- xfu
  xss <- xnow  # standardized
  
  if(length(notCols) > 0){
    xmm <- xfu[,-notCols, drop=T]
    xss <- xnow[,-notCols, drop=T]
  }
  UU <- crossprod(xss)                      # unstandardized
 # unstand <- solve(UU)%*%crossprod(xmm,xss) # stand to unstand
  stand <- solve(UU)%*%crossprod(xss,xmm)   # unstand to stand
  
  SS <- crossprod(xmm)                      # standardardized
 # stand <- solve(SS)%*%crossprod(xss,xmm)   # unstand to stand
  unstand <- solve(SS)%*%crossprod(xmm,xss) # stand to unstand
  
  if(length(notCols) > 0){                  # reorder
    m1 <- m2 <- crossprod(xnow)*0
    m1[rownames(unstand),colnames(unstand)] <- unstand
    m2[rownames(stand),colnames(stand)] <- stand
    unstand <- m1
    stand <- m2
  }
    
  list(x = xfu, unstand = unstand, stand = stand)
}


buildAllSeed <- function(tmp, ytmp, scols, acols, bcols){
  
  # tmp  - current data.frame
  # ytmp - new data.frame
  # both include 1 plot, 1 year
  
  if(length(tmp) == 0)return(ytmp)
  
  tscols <- colnames(tmp)
  tscols <- tscols[!tscols %in% scols]
  mat1 <- tmp[,tscols]
  mat2 <- ytmp[, c(acols, bcols) ]
  
  wmm <- match( colnames(mat2), colnames(mat1) )
  wf  <- which(is.finite(wmm))
  if( length(wf) > 0 ){
    pmat <- rbind(mat1[,wmm[wf]], mat2[,wf])
    wn   <- c(1:ncol(mat1))[-wmm[wf]]
    if(length(wn) > 0){
      pn <- matrix(0, nrow(pmat), length(wn))
      colnames(pn) <- colnames(mat1)[wn]
      pn[1:nrow(mat1),] <- as.matrix(mat1[,wn])
      pmat <- cbind(pn, pmat)
    }
  }else{
    pmat <- .blockDiag( mat1, mat2  )
  }
  cmat <- rbind(tmp[,scols],ytmp[,scols])
  tmp  <- cbind(cmat, pmat)
  tmp
}

.blockDiag <- function(mat1,mat2){
  
  #creates block diagional
  
  if(length(mat1) == 0)return(mat2)
  
  if(!is.matrix(mat1))mat1 <- as.matrix(mat1)
  if(!is.matrix(mat2))mat2 <- as.matrix(mat2)
  
  namesc <- c(colnames(mat1),colnames(mat2))
  namesr <- c(rownames(mat1),rownames(mat2))
  
  nr1 <- nrow(mat1)
  nr2 <- nrow(mat2)
  nc1 <- ncol(mat1)
  nc2 <- ncol(mat2)
  nr  <- nr1 + nr2
  nc  <- nc1 + nc2
  
  new <- matrix(0,nr,nc)
  new[ 1:nr1, 1:nc1 ] <- mat1
  new[ (nr1+1):nr, (nc1+1):nc ] <- mat2
  colnames(new) <- namesc
  rownames(new) <- namesr
  new
}

.getLambda <- function(tdat1, sdat1, AA, ug, fz, R, SAMPR, 
                       distance, yrs, PERAREA=F, SPECPRED = F){
  
  # tdat needs species, year, dcol
  # sdat needs year, drow
  
  # PERAREA - from per-trap to per-area
  # if length(AA === 1) then it must equal 1
  # SPECPRED - predict species rather than seed types
  
  nf <- length(fz)
  
  if(SAMPR | length(R) > 1){
    if(SPECPRED){
      ff <- matrix(0, nf, nrow(R))
      jj <- match(as.character(tdat1$specPlot),rownames(R)) # predict species
      ff[ cbind(1:nf,jj) ] <- fz
    }else{
      ff <- matrix(fz,length(fz),ncol=ncol(R))*
            R[drop=F,tdat1$specPlot,] # predict types
    }
  }else{
    ff <- matrix(fz,ncol=1)
  }
  
 # lindex <- c(1:ncol(ff)) - 1
  if(length(ug) == 1){
    uvec <- ug
  }else{
    uvec <- ug[ attr(distance,'species') ]
  }
  dmat <- t(uvec/pi/(uvec + t(distance)^2)^2)
  dmat[dmat < 1e-8] <- 0

  lambda <- kernYrRcpp(dmat, ff, yrs, seedyear = sdat1[,'year'],
                    treeyear = tdat1[,'year'], seedrow = sdat1[,'drow'],
                    treecol = tdat1[,'dcol'])
  if(SPECPRED){
    colnames(lambda) <- rownames(R)
    sname  <- sort(unique(attr(R,'species')))
    ii     <- rep( c(1:nrow(lambda)), ncol(lambda) )
    jj     <- match(attr(R,'species'),sname)
    jj     <- rep(jj, each=nrow(lambda))
    lambda <- .myBy(as.vector(lambda), ii, jj, fun='sum')
    colnames(lambda) <- sname
    
  }else{
    colnames(lambda) <- colnames(R)
  }
  
  if(PERAREA | length(AA) == 1) return(lambda)    # per area
  
  lambda*matrix( AA, nrow(lambda), ncol(lambda) )  # per trap
}

.tnorm <- function(n,lo,hi,mu,sig, tiny=0){   
  
  #normal truncated lo and hi
  
  if(length(lo) == 1 & length(mu) > 1)lo <- rep(lo,length(mu))
  if(length(hi) == 1 & length(mu) > 1)hi <- rep(hi,length(mu))
  
  q1 <- pnorm(lo,mu,sig)
  q2 <- pnorm(hi,mu,sig) 
  
  z <- runif(n,q1,q2)
  z <- qnorm(z,mu,sig)
  
  
  
  if(length(lo) != length(mu)){
    print(length(lo))
    print(length(mu))
    stop()
  }
  
  
  z[z == Inf]  <- lo[z == Inf] + tiny
  z[z == -Inf] <- hi[z == -Inf] + tiny
  z
}

rtpois <- function(lo, hi, mu){
  
  #Poisson truncated lo and hi
  
  # lo, hi, and mu are matrices
  
  ww <- which(hi > lo, arr.ind=T)  #only update where there is an interval
  xx <- lo
  
  p1 <- ppois(lo[ww],mu[ww])
  p2 <- ppois(hi[ww],mu[ww]) 
  
  xx[ ww[p2 == 0,] ] <- hi[ ww[p2 == 0,] ]
  
  vv <- which(p1 < 1)
  qq <- runif(length(vv),p1[vv],p2[vv])
  zz <- qpois(qq,mu[ww[vv,]]) - 1
  zz[zz < 0] <- 0
  
  wx <- ww[drop=F,vv[zz == Inf],]
  if(length(wx) > 0)zz[zz == Inf]  <- lo[wx]
  
  wx <- ww[drop=F,vv[zz == -Inf],]
  if(length(wx) > 0)zz[zz == -Inf] <- hi[wx]
  
  xx[ ww[vv,] ] <- zz
  xx
}

dtpois <- function(lo, hi, mu, index = NULL, tiny = 1e-10){

  # Poisson probability interval censusored lo and hi
  # index used for matrices
  
  xx <- lo*0 + 1
  
  if(!is.null(index)){
    hi <- hi[index]
    lo <- lo[index]
    mu <- mu[index]
    pr <-  ppois(hi, mu) - ppois(lo, mu)
    pr[pr < tiny] <- tiny
    xx[index] <- pr
    return(xx)
  }
  
  ppois(hi, mu) - ppois(lo, mu)
}


.getPlotLayout <- function(np){
  
  # np - no. plots
  
  if(np == 1)return( list( mfrow=c(1,1), left=1, bottom=c(1,2) ) )
  if(np == 2)return( list( mfrow=c(1,2), left = 1, bottom = c(1,2) ) )
  if(np == 3)return( list( mfrow=c(1,3), left = 1, bottom = c(1:3) ) )
  if(np <= 4)return( list( mfrow=c(2,2), left = c(1, 3), bottom = c(3:4) ) )
  if(np <= 6)return( list( mfrow=c(2,3), left = c(1, 4), bottom = c(4:6) ) )
  if(np <= 9)return( list( mfrow=c(3,3), left = c(1, 4, 7), bottom = c(7:9) ) )
  if(np <= 12)return( list( mfrow=c(3,4), left = c(1, 5, 9), bottom = c(9:12) ) )
  if(np <= 16)return( list( mfrow=c(4,4), left = c(1, 5, 9, 13), 
                            bottom = c(13:16) ) )
  if(np <= 20)return( list( mfrow=c(4,5), left = c(1, 6, 11, 15), 
                            bottom = c(15:20) ) )
  if(np <= 25)return( list( mfrow=c(5,5), left = c(1, 6, 11, 15, 20), 
                            bottom = c(20:25) ) )
  if(np <= 25)return( list( mfrow=c(5,6), left = c(1, 6, 11, 15, 20, 25), 
                            bottom = c(25:30) ) )
  return( list( mfrow=c(6,6), left = c(1, 7, 13, 19, 25, 31), bottom = c(31:36) ) )
}

.seedProb <- function(tdat1, ug, fz, distall, sdat1, 
                      seedNames, R, SAMPR, year1){
  
  lambda <- .getLambda(tdat1, sdat1, sdat1$area, ug, fz, R, SAMPR, 
                       distall, year1, PERAREA=F)
  lambda <- lambda + 1e-8
  ss     <- as.matrix(sdat1[,seedNames])
  dpois(ss, lambda, log=T)
}
  
.myBy <- function(x, i, j, summat=matrix(0,max(i),max(j)), 
                    totmat=summat, fun='mean'){  
  
  nn <- length(x)
  if( nn != length(i) | nn != length(j) )
    stop('vectors unequal in byFunctionRcpp')
  if( nrow(summat) < max(i) | ncol(summat) < max(j) )
    stop('matrix too small')
  
  ww <- which(is.na(x))
  if(length(ww) > 0){
    x <- x[-ww]
    i <- i[-ww]
    j <- j[-ww]
  }
  
  frommat <- cbind(i,j,x)
  
  nr  <- nrow(frommat)
  
  maxmat <- summat*0 - Inf
  minmat <- summat*0 + Inf
  
  tmp <- byRcpp(nr, frommat, totmat, summat, minmat, maxmat)
  
  if(fun == 'sum')return(tmp$sum)
  if(fun == 'mean'){
    mu <- tmp$sum/tmp$total
    mu[is.na(mu)] <- 0
    return(mu)
  }
  if(fun == 'min'){
    return( tmp$min )
  }
  tmp$max
}

.tnormMVNmatrix <- function(avec, muvec, smat, 
                            lo=matrix(-1000,nrow(muvec),ncol(muvec)), 
                            hi=matrix(1000,nrow(muvec),ncol(muvec)),
                            whichSample = c(1:nrow(smat))){
  
  # lo, hi must be same dimensions as muvec,avec
  # each sample is a row
  
  lo[lo < -1000] <- -1000
  hi[hi > 1000]  <- 1000
  
  if(max(whichSample) > length(muvec))
    stop('whichSample outside length(muvec)')
  
  whichSample <- sample(whichSample) # randomize order
  
  nd <- dim(avec)
  
  r <- avec
  a <- trMVNmatrixRcpp(avec, muvec, smat, 
                       lo, hi, whichSample, 
                       idxALL = c(0:(nrow(smat)-1)) ) 
  r[,whichSample] <- a[,whichSample]
  r
}

.initEM <- function(last0first1, yeGr, distall, priorU,
                    tdata, sdata, specNames, seedNames, R, SAMPR, years, 
                    plotYears, z, xfec, zobs, fstart, nsim=100){
  
  FSTART <- F
  tiny <- 1e-3
  id <- sort(unique(as.character(tdata$treeID)))
  tt <- tdata[ match(id,as.character(tdata$treeID)), ]  #unique trees
  
  tdata$fecMin[zobs == 0 & tdata$fecMin > .0001] <- .0001
  tdata$fecMin[zobs == 1 & tdata$fecMin < 1] <- 1.001
  tdata$fecMax[zobs == 0 & tdata$fecMax > 1] <- 1
  tdata$fecMax[zobs == 1 & tdata$fecMax < 1.001] <- 1.001
  
  nspec  <- length(specNames)
  
  dcol <- numeric(0)
  
  for(j in 1:nspec){
    
    if(nspec > 1){
      wj <- which(tt$species == specNames[j])
      tj <- tt[drop=F,wj,]
    }else{
      wj <- 1:nrow(tt)
      tj <- tt
    }
    
    dtmp <- distall[,tt$dcol[wj],drop=F]
    dtmp[dtmp > 1000] <- NA
    
    dmin  <- apply(dtmp,2,min, na.rm=T)
    qdiam <- quantile(tj$diam,.5)
    
    ww  <- which(dmin < 30 & tj$diam > qdiam)
    dcol <- c(dcol, tj$dcol[ww])
  }
  wtree <- which(tdata$dcol %in% dcol & zobs != 0)
  
  fg <- rep(.5,nrow(tdata))
  
  ss <- sdata[,seedNames,drop=F]
  ff <- sapply(ss,is.factor)
  if(!all(!ff))ss <- .fac2num( ss )
  ss <- rowSums(ss, na.rm=T)
  
  wfix <- which(is.finite(fstart))
  if(length(wfix) > 0)FSTART <- T
  
  for(j in 1:length(plotYears)){
    
    i  <- which(as.character(tdata$plotYr) == plotYears[j] )
    m  <- i[i %in% wtree]
    k  <- which(sdata$plotYr == plotYears[j])
    sj <- sum(ss[k])
    
    if(length(k) == 0)next
    if(length(i) == 0)next
    if(length(m) == 0 & sj > 0)m <- i
    if(length(m) == 0)next
    
    d <- unique(tdata$dcol[m])
    dj <- d[d %in% dcol]
    ij <- m[d %in% dcol]
    if(length(dj) < 1){
      ij <- which(tdata$plotYr == plotYears[j] & tdata$dcol %in% d)
      dj <- tdata$dcol[ij]
    }
 
    dk     <- distall[ sdata[k,'drow'], dj, drop=F ]
    kern   <- priorU/pi/(priorU + dk^2)^2
    fg[ij] <- .getF( kern, gg = ss[k]/(.1 + sdata$area[k]) )
  }
  
  fg[!is.finite(fg)] <- .1
  
  nn <- length(fg)
  
  lo <- tdata$fecMin
  hi <- tdata$fecMax
  
  fg[fg < lo] <- lo[fg < lo]
  fg[fg > hi] <- hi[fg > hi]
  
  fg <- .tnorm(nn, lo, hi, fg, .1)
  if(FSTART)fg[wfix] <- fstart[wfix]
  
  propF <- fg/20
  propU <- .1
  
  # by plot-yr
  ii <- tdata[,'plotyr']     #consider bnow[znow == 0] = 0
  sm <- matrix(0, max(c(tdata$plotyr, sdata$plotyr)), 1)
  
  pcheck <- seq(1,nsim,by=20)
  
  cat("\ninitializing\n")
  
  pbar <- txtProgressBar(min=1,max=nsim,style=1)
  
  
  ug <- rep(priorU, nspec )
  nn <- nrow(tdata)
  
  pall <- -1e+10
  count <- 0
  
  for(g in 1:nsim){
    
    fnew <- .tnorm(nn, lo, hi, fg, rexp(nn,1/propF))
    fnew[fnew < 0] <- 0
    
    if(FSTART)fnew[wfix] <- fstart[wfix]

    
    
    pnow <- .seedProb(tdata[,c('specPlot','year','dcol')],
                      ug, fz = fg*z, distall, sdata, 
                      seedNames, R, SAMPR, years)
    pnew <- .seedProb(tdata[,c('specPlot','year','dcol')],
                      ug, fnew*z, distall, sdata, 
                      seedNames, R, SAMPR, years)
    
    pnow[pnow < -1e+8] <- -1e+8   # intensity parameter is zero
    pnew[pnew < -1e+8] <- -1e+8
    
    # by plot-yr
    ii <- sdata[,'plotyr']
    ii <- rep(ii, length(seedNames))
    
    pnow <- .myBy(as.vector(pnow), ii, ii*0 + 1, summat = sm*0, fun='sum')
    pnew <- .myBy(as.vector(pnew), ii, ii*0 + 1, summat = sm*0, fun='sum')
    
    if(g == 1)accept <- pnow*0
    
    a  <- exp(pnew - pnow)        #wt on seed data
    az  <- runif(length(a),0,1)
    aw  <- which(az < a)
    
    if(length(aw) > 0){
      wa <- which(tdata[,'plotyr'] %in% aw)
      fg[ wa ] <- fnew[ wa ]
      accept[aw] <- accept[aw] + 1
    }
    
    if(g %in% pcheck){
      whi <- which(accept > g/2)
      if(length(whi) > 0)propF[whi] <- propF[whi]*2
      wlo <- which(accept < g/5)
      if(length(wlo) > 0)propF[wlo] <- propF[wlo]/2
     
      pq   <- sum(pnow)
      dl   <- pq - pall
      pall <- pq
      
      if(dl < 0){
        count <- count + 1
        if(count > 4)break
      }
      
    }
    setTxtProgressBar(pbar,g)
  }
  fg[fg < tiny] <- tiny
  

  XX <- crossprod(xfec[wtree,])
  diag(XX) <- diag(XX) + .000001
  
  bf <- solve(XX)%*%crossprod(xfec[wtree,],log(fg[wtree]))
  mu <- exp(xfec%*%bf)
  mu[wtree] <- fg[wtree]
  if(FSTART)mu[wfix] <- fstart[wfix]
  
  fstart <- .tnorm(nn,lo,hi,mu,.1)
  fstart[wtree] <- fg[wtree]
  fstart[fstart >= .95 & z == 0] <- .95
  fstart[fstart < 1 & z == 1] <- 1.01
  fstart
}


.checkDesign <- function( x, intName='intercept', xflag=':', 
                          isFactor = character(0) ){  # 
  
  # xflag - indicates that variable is an interaction
  # isFactor - character vector of factor names returned if not supplied
  
  p <- ncol(x)
  
  if(ncol(x) < 3){
    return( list(VIF = 0, correlation = 1, rank = 2, p = 2, isFactor=isFactor) )
  }
  
  if(is.null(colnames(x))){
    colnames(x) <- paste('x',c(1:p),sep='_')
  }
  xrange      <- apply(x,2,range,na.rm=T)
  wi          <- which(xrange[1,] == 1 & xrange[2,] == 1)
  if(length(wi) > 0)colnames(x)[wi] <- 'intercept'
  
  wx <- grep(xflag,colnames(x))
  wi <- which(colnames(x) == 'intercept')
  wi <- unique(c(wi,wx))
  
  xname <- colnames(x)
  
  wmiss <- which(is.na(x),arr.ind=T)
  
  if(length(wmiss) > 0){
    rowTab <- table( table(wmiss[,1]) )
    colTab <- table(wmiss[,2])
  }
  
  VIF <- rep(NA,p)
  names(VIF) <- xname
  
  GETF <- F
  if(length(isFactor) > 0)GETF <- T
  
  for(k in 1:p){
    
    if(xname[k] %in% wi)next
    
    notk <- xname[xname != xname[k] & !xname %in% xname[wi]]
    ykk  <- x[,xname[k]]
    xkk  <- x[,notk,drop=F]
    
    wna <- which(is.na(ykk) | is.na(rowSums(xkk)))
    if(length(wna) > 0){
      ykk <- ykk[-wna]
      xkk <- xkk[-wna,]
    }
    
    ttt <- suppressWarnings( lm(ykk ~ xkk) )
    
    tkk <- suppressWarnings( summary(ttt)$adj.r.squared )
    VIF[k] <- 1/(1 - tkk)
    
    xu <- sort( unique(x[,k]) )
    tmp <- identical(c(0,1),xu)
    if(GETF)if(tmp)isFactor <- c(isFactor,xname[k])
  }
  
  VIF <- VIF[-wi] 
  
  corx <- suppressWarnings( cor(x[,-wi], use="complete.obs") )
  if(length(wna) == 0){
    rankx <- qr(x)$rank
  } else {
    rankx <- qr(x[-wna,])$rank
  }
  corx[upper.tri(corx,diag=T)] <- NA
  
  findex <- rep(0,p)
  
  findex[xname %in% isFactor] <- 1
  
  designTable <- list('table' = rbind( round(VIF,2),findex[-wi],round(corx,2)) )
  rownames(designTable$table) <- c('VIF','factor',xname[-wi])
  
  designTable$table <- designTable$table[-3,]
  
  if(p == rankx)designTable$rank <- paste('full rank:',rankx,'= ncol(x)')
  if(p < rankx) designTable$rank <- paste('not full rank:',rankx,'< ncol(x)')
  
  list(VIF = round(VIF,2), correlation = round(corx,2), rank = rankx, p = p,
       isFactor = isFactor, designTable = designTable)
}

.ranEffVar <- function(yy, xf, Arand, sg, xrandCols){   # rewrite in cpp
  
  # marginalized variance from random effects
  # xr = xfec[,xrandCols]
  
  xx    <- xf[,xrandCols]%*%Arand           # w'A
  revar <- sg + rowSums(xx*xf[,xrandCols])  # sigma + w'Aw
  XR    <- t(xf/revar)                      
  VI    <- XR%*%xf                          # Q x Q
  V     <- solve(VI)
  v     <- XR%*%yy
  XX    <- XR*t(xf)                         # (x'x/s)_it
  XY    <- XR*yy                            # (x'y/s)_it
  u     <- rowSums(1/XX*XY)
  list(v = v, V = V)
}

.wrapperBeta <- function( priorB, priorIVB, SAMPR, obsRows, obsYr, obsRowSeed,
                          tdata, xfecCols, xrepCols, last0first1, ntree, nyr, 
                          betaPrior, years, distall, YR, AR, yrIndex,
                          RANDOM, reIndex, xrandCols, RANDYR, fitCols){
  
  function(pars, xfec, xrep, w, z, zmat, matYr, muyr){
    
    fg        <- pars$fg
    sg        <- pars$sg
    nspec     <- nrow(pars$R)
    bgFec     <- pars$bgFec
    bgRep     <- pars$bgRep
    betaYrF   <- pars$betaYrF
    betaYrR   <- pars$betaYrR
    alphaRand <- pars$alphaRand
    Arand     <- pars$Arand
    ngroup    <- length(pars$ug)
    
    qf <- length(fitCols)
    qr <- ncol(xrep)
    
    accept <- 0

    ONEF <- ONER <- ONEA <- F
    if(ncol(xfec) == 1)ONEF <- T
    if(ncol(xrep) == 1)ONER <- T
    if(length(Arand) == 1)ONEA <- T
    
    nxx <- length(obsRows)
    yg  <- log(fg)[obsRows]
    
    yeffect <- reffect <- 0
    
    
    xfz <- xfec[drop=F,obsRows,]
    bgf <- bgFec
    
    w0  <- which( colSums(xfz) == 0 )  
    fitCols <- fitCols[!fitCols %in% w0]
    xfz <- xfz[,fitCols, drop=F]
    bgf <- bgf[drop=F,fitCols,]
    
    if(YR){                            # yeffect in mean
      yg <- yg - betaYrF[yrIndex[obsRows,'year']] 
      if(RANDYR) yg <- yg - betaYrR[yrIndex[obsRows,c('group','year')]]
    }
    if(AR){
      yg <- yg - muyr[obsRows]
    }
    
    if(RANDOM){                        
      reffect <- xfec[,xrandCols]*alphaRand[reIndex,]
      if(!ONEA)reffect <- rowSums( reffect )
      yg <- yg - reffect[obsRows]
    }
    
    zrow <- z[obsRows]
    
    if(ONEF){
      
      V <- 1/(sum(zrow)/sg + .1)
      v <- sum(yg[zrow == 1])/sg
      bgf <- matrix( rnorm(1,V*v,sqrt(V)), 1)
      
    }else{
      
      XX    <- 1/sg*crossprod(xfz[zrow == 1,]) + diag(.1, qf)
      testv <- try( chol(XX) ,T)
      if( inherits(testv,'try-error') ){
        diag(XX)  <- diag(XX) + .001
        testv <- try(chol(XX, pivot=T),T)
      }
      V  <- chol2inv(testv)
      v  <- 1/sg*crossprod(xfz[zrow == 1,],yg[zrow == 1]) 
      if(is.null(betaPrior)){
        bgf  <- t( rmvnormRcpp(1, V%*%v, V) )
        ww   <- which( abs(bgf) > 10 )
        if(length(ww) > 0){
          bgf <- t(.tnormMVNmatrix( avec=t(bgf), muvec=t(bgf), smat=V,
                             lo=matrix(-10,1, length(bgf)), 
                             hi=matrix(10, 1, length(bgf)),
                             whichSample = ww) )
        }
      }else{
        diag(V) <- diag(V)*1.000000001
        lims <- betaPrior$fec[fitCols,]
        bgf  <- t(.tnormMVNmatrix( avec=t(V%*%v), muvec=t(V%*%v), smat=V,
                                   lo=matrix(lims[,1],1), 
                                   hi=matrix(lims[,2],1)))
      }
    }
    
    bgFec <- bgFec*0
    bgFec[fitCols,] <- bgf
    
    # maturation
    if(ONER){
      
      V <- 1/(nxx/sg + .1)
      v <- sum(w[obsRows])/sg
      bgRep <- rnorm(1,V*v,sqrt(V))
      
    }else{
      V  <- solve(1/sg*crossprod(xrep[obsRows,])  + diag(.1, qr))
      v  <- 1/sg*crossprod(xrep[obsRows,], w[obsRows]) 
      if(is.null(betaPrior)){
        bgRep <- t( rmvnormRcpp(1, V%*%v, V) )
      }else{
        lims <- betaPrior$rep
        bgRep <- t(.tnormMVNmatrix( avec=matrix(bgRep,1), muvec=t(V%*%v), 
                                    smat=V,
                                    lo=matrix(lims[,1],1), 
                                    hi=matrix(lims[,2],1)))
      }
    }
    rownames(bgFec) <- colnames(xfec) 
    rownames(bgRep) <- colnames(xrep) 
    
    list(bgFec = bgFec, bgRep = bgRep)
  }
}
    
    
    
.wrapperU <- function(distall, tdata, minU, maxU, priorU, priorVU,
                      seedNames, nspec, obsRows, obsRowSeed, obsYr, 
                      tau1, tau2, SAMPR, RANDYR){
  
  tdat <- tdata[obsRows,c('specPlot','year','dcol')]
  
  function(pars, z, propU, sdata){
                    
    fg <- pars$fg
    ug <- pars$ug
    umean <- pars$umean
    uvar  <- pars$uvar
    R     <- pars$R
    
    unew <- .tnorm(nspec, minU, maxU, ug, rexp(nspec, 1/propU) )
    names(unew) <- names(ug)
    
    if(!RANDYR){
      umean <- priorU
      uvar  <- priorVU
    }
    
    pnow <- .seedProb(tdat, ug, fg[obsRows]*z[obsRows], distall, 
                      sdata[obsRowSeed,], seedNames, 
                      R, SAMPR, obsYr)
    pnew <- .seedProb(tdat, unew, fg[obsRows]*z[obsRows], distall, 
                      sdata[obsRowSeed,], seedNames, 
                      R, SAMPR, obsYr) 
    
    pnow[pnow < -1e+9] <- -1e+9   # intensity parameter is zero
    pnew[pnew < -1e+9] <- -1e+9
    pnow <- sum(pnow) + sum( dnorm(ug, umean, sqrt(uvar),log=T) )
    pnew <- sum(pnew) + sum( dnorm(unew, umean, sqrt(uvar),log=T) )
    
    pdif <- pnew - pnow
    
    a <- exp(pdif)
    if(is.finite(a)){
      if( runif(1,0,1) < a){
        ug   <- unew
        propU <- propU*2
      }else{
        propU <- propU*.9
      }
    }
    
    if(RANDYR){  # prior
      
      V <- 1/(nspec/uvar + 1/priorVU)
      v <- 1/uvar*sum(ug) + priorU/priorVU
      umean <- .tnorm(1, min(minU), max(maxU), V*v, sqrt(V)) 
      uvar  <- 1/rgamma(1, tau1 + nspec/2, tau2 + .5*sum( (ug - umean)^2 ) )
    }
    
    list(ug = ug, umean = umean, uvar = uvar, propU = propU)
  }
}

.lambda <- function(ug, ff, zz, R, tdata, sdata, obsRows, obsRowSeed, obsYr, 
                    distall, AA, SAMPR, PERAREA=F, SPECPRED = F){
  
  # PERAREA - from per-trap to per-area
  # if length(AA === 1) then it must equal 1
  # SPECPRED - predict species rather than seed types
  #AA   - area, vector or one number
  
  nf <- length(ff)
  fz <- ff*zz
  
  if( SAMPR | length(R) > 1 ){
    if(SPECPRED){
      fk <- matrix(0, nf, nrow(R))
      jj <- match(as.character(tdata$specPlot[obsRows]),rownames(R)) 
      fk[ cbind(1:nf,jj) ] <- fz
      fz <- fk
      colnames(fz) <- rownames(R)
    }else{
      fz <- matrix(fz,length(ff),ncol=ncol(R))*
        R[drop=F,as.character(tdata$specPlot)[obsRows],] 
    }
  }else{
    fz <- matrix(fz,ncol=1)
  }
  
  uvec <- ug[ attr(distall,'species') ]
  dmat <- t(uvec/pi/(uvec + t(distall)^2)^2)
  dmat[dmat < 1e-8] <- 0
  
  lambda <- kernYrRcpp(dmat, fz, years = obsYr, 
                       seedyear = sdata$year[obsRowSeed],
                       treeyear = tdata$year[obsRows], 
                       seedrow = sdata$drow[obsRowSeed],
                       treecol = tdata$dcol[obsRows])
  if(SPECPRED){
    colnames(lambda) <- rownames(R)
    
    sname <- sort(unique(attr(R,'species')))
    ii <- rep( c(1:nrow(lambda)), ncol(lambda) )
    jj <- match(attr(R,'species'),sname)
    jj <- rep(jj, each=nrow(lambda))
    
    lambda <- .myBy(as.vector(lambda), ii, jj, fun='sum')
    colnames(lambda) <- sname
    
  }else{
    colnames(lambda) <- colnames(R)
  }
  
  if( PERAREA | length(AA) == 1 ) return(as.matrix(lambda))   # per area
  
  if( length(AA) > 1 )AA <- AA[obsRowSeed]
  
  as.matrix( lambda*matrix( AA, nrow(lambda), ncol(lambda) ) )  # per trap
}

.wrapperStates <- function( maxFec, SAMPR, RANDOM, obsTimes, plotYears,
                            sdata, tdat, seedNames, last0first1, distall, 
                            YR, AR, obsRows, obsYr, predYr, obsRowSeed, 
                            ntree, years, nyr, xrandCols, reIndex, yrIndex, 
                            plag, groupByInd, RANDYR, updateProp, seedsPerCone){
  
  maxF <- specPriorVector(maxFec, tdat)
  
  function(g, pars, xfec, xrep, propF, z, zmat, matYr, muyr, 
           epsilon = .00001, pHMC = .1){
    
    # tdat    - species, dcol, year, plotyr
    # pHMC    - fraction of steps that are Hamiltonian
    
    fg        <- pars$fg
    fecMin    <- pars$fecMin
    fecMax    <- pars$fecMax
    ug        <- pars$ug
    sg        <- pars$sg
    bgFec     <- pars$bgFec
    bgRep     <- pars$bgRep
    betaYrF   <- pars$betaYrF
    betaYrR   <- pars$betaYrR
    alphaRand <- pars$alphaRand
    Arand     <- pars$Arand
    R         <- pars$R
    nxx       <- length(fg)
    ngroup    <- nrow(betaYrR)
    bottom    <- -15
    
    accept  <- 0
      
    nspec  <- nrow(R)
    
    ONEF <- ONER <- ONEA <- F
    if(ncol(xfec) == 1)ONEF <- T
    if(ncol(xrep) == 1)ONER <- T
    if(length(Arand) == 1)ONEA <- T
    
    if(AR)lindex <- 1:plag
    
    fg[fg > fecMax] <- fecMax[fg > fecMax]
    fg[fg < fecMin] <- fecMin[fg < fecMin]
    propF[propF > .1*fg] <- .1*fg[propF > .1*fg]
    
    yg <- log(fg)
    yg[yg < bottom] <- bottom
    
    yeffect <- reffect <- 0
    
    xfz <- xfec
    bgf <- bgFec 
    
    w0  <- which( colSums(xfz) == 0 )  
    if(length(w0) > 0){
      xfz <- xfz[,-w0]
      bgf <- bgf[drop=F,-w0,]
    }
    
    if(YR & !AR){                            # yeffect in mean
      yeffect <- betaYrF[yrIndex[,'year']]
      if(RANDYR)yeffect <- yeffect + betaYrR[yrIndex[,c('group','year')]]
    }
    
    if(RANDOM){                        
      reffect <- xfec[,xrandCols]*alphaRand[reIndex,]
      if(!ONEA)reffect <- rowSums( reffect )
  #    yg <- yg - reffect
    }
    
    lmu           <- xfec%*%bgFec
    if(YR)lmu     <- lmu + yeffect
    if(RANDOM)lmu <- lmu + reffect
    nall <- length(fg)
    
    tt <- rbinom(1,1,pHMC)
    
    if(tt == 1){
      
      fg[fg < 1e-6] <- 1e-6
      tmp <- HMC(ff = fg[obsRows], fMin = fecMin[obsRows], fMax = fecMax[obsRows], 
                 ep = epsilon[obsRows],   
                 L = 4, tdat[obsRows,], sdat = sdata[obsRowSeed,], ug, 
                 mu = lmu[obsRows], sg, zz = z[obsRows], R, SAMPR, 
                 distance = distall, obsRows, obsYr, seedNames)
      fg[obsRows] <- tmp$fg
      epsilon[obsRows] <- tmp$epsilon
      
      fg[fg > fecMax] <- fecMax[fg > fecMax]
      fg[fg < fecMin] <- fecMin[fg < fecMin]
      
      fg[fg < 1e-6] <- 1e-6
      
      return( list(fg = fg, fecMin = fecMin, fecMax = fecMax,
                   z = z, zmat = zmat, matYr = matYr, propF = propF,
                   accept = tmp$accept, epsilon = epsilon) )
    }
    
    # maturation
    pr  <- pnorm( xrep%*%bgRep )
    iss <- sdata$plotyr
    ii  <- rep(iss, length(seedNames))
    
    if( !AR ){               
      
      tmp      <- .propZ(zmat, last0first1, matYr)
      zmatNew  <- tmp$zmat
      znew     <- zmatNew[ yrIndex[,c('dcol','year')] ] 
      matYrNew <- tmp$matYr 
      mnow <- z*log(pr) + (1 - z)*log(1 - pr)
      mnew <- znew*log(pr) + (1 - znew)*log(1 - pr)
      
      dz <- znew - z
      lo <- fecMin
      hi <- fecMax
      lo[dz == 1] <- 1
      hi[dz == 1] <- maxF[dz == 1]
      lo[dz == -1] <- 1e-6
      hi[dz == -1] <- 1
      
      fnew <- .tnorm(nall, lo, hi, fg, rexp(nxx,1/propF), .001)
      fnew[fnew < 1e-6] <- 1e-6
      ynew <- log(fnew)
      
      # fecundity model
      bnow <- bnew <- fg*0
      bnow[z == 1] <- dnorm(yg[z == 1], lmu[z == 1], sqrt(sg), log=T) 
      bnew[znew == 1] <- dnorm(ynew[znew == 1], lmu[znew == 1], sqrt(sg), log=T) 
      
      if(!is.null(seedsPerCone)){
        wc <- which(z == 1 & is.finite(tdat$coneCount))
        fc <- round(fg[wc])
        
        oss <- tdat$coneCount[wc]*seedsPerCone[tdat$species[wc],1]
        
        cnow <- cnew <- fc*0
        cnow <- dbinom(oss, round(fc), tdat$coneFraction[wc], log=T)
        bnow[wc] <- bnow[wc] + cnow
        
        fn <- round(fnew[wc])
        cnew <- dbinom(oss, round(fn), tdat$coneFraction[wc], log=T)
        bnew[wc] <- bnew[wc] + cnew 
      }
      
      w0 <- which(z == 0 | znew == 0)
      bnew[w0] <- bnow[w0] <- 0
      
      # seed
      pnow <- pnew <- matrix(0,nrow(sdata),length(seedNames))
      pnow[obsRowSeed,] <- .seedProb(tdat[obsRows,c('specPlot','year','dcol')],
                                     ug, fg[obsRows]*z[obsRows], 
                                    distall, sdata[obsRowSeed,], seedNames, R, 
                                    SAMPR, obsYr)
      pnew[obsRowSeed,] <- .seedProb(tdat[obsRows,c('specPlot','year','dcol')], 
                                     ug, fnew[obsRows]*znew[obsRows], 
                                    distall, sdata[obsRowSeed,], seedNames, R, 
                                    SAMPR, obsYr)
      pnow[pnow < -1e+8] <- -1e+8   # intensity parameter is zero
      pnew[pnew < -1e+8] <- -1e+8
      
      # by plot-yr
      ii <- tdat$plotyr     #consider bnow[znow == 0] = 0
      sm <- matrix(0, max(c(tdat$plotyr, sdata$plotyr)), 1)
      
      mdif <- .myBy(mnew - mnow, ii, ii*0+1,summat = sm, fun='sum')
      bdif <- .myBy(bnew - bnow, i = ii, j = ii*0 + 1, summat = sm*0, fun='sum')
      
      ii <- sdata$plotyr
      ii <- rep(ii, length(seedNames))
      
      pdif <- .myBy(as.vector(pnew - pnow), ii, ii*0 + 1, summat = sm*0, fun='sum')

      a  <- exp( pdif + bdif + mdif )        
      az  <- runif(length(a),0,1)
      aw  <- which(az < a)
      
      accept <- accept + length(aw)
      
      propF <- propF/2
      
      if(length(aw) > 0){
        
        wa <- which(tdat$plotyr %in% aw)
        
        yg[ wa ] <- ynew[ wa ]
        z[ wa ]  <- znew[ wa ]
        fecMin[wa] <- lo[wa]
        fecMax[wa] <- hi[wa]
        zmat[ yrIndex[,c('dcol','year')] ] <- z  
        
        tmp <- apply(zmat,1,which.max)
        tmp[rowSums(zmat) == 0] <- ncol(zmat)
        matYr <- tmp
        
        if(g %in% updateProp){
          propF[wa] <- propF[wa]*5
  #        propF[propF > maxProp] <- maxProp
        }
        
      }else{
        propF <- propF*.5
      }
      
    }else{         # AR
      
      #independence sampler
      
      p2s <- rep(0,length(plotYears))
      
      yy <- mu <- matrix(0, ntree, nyr)
      yy[ yrIndex[,c('dcol','year')] ] <- yg
      mu[ yrIndex[,c('dcol','year')] ] <- lmu
      
      #prior for backcast based on obsRows
      
      yprior <- .myBy(yg[obsRows], yrIndex[obsRows,'dcol'], 
                      obsRows*0+1, fun='mean')
      
      for(t in 1:length(predYr)){        
        
        tii <- which(yrIndex[,'year'] == t)  # row in tdat
        oii <- tii[ tdat$obs[tii] == 1]      # with observations
        yii <- yrIndex[tii,'dcol']           # location in ytmp
        nii <- length(yii)
        fmin <- log(fecMin[tii])
        fmax <- log(fecMax[tii])
        
        zt <- zmat[yii,t]
        zp <- rbinom(length(zt),1,.5)
        
        #new and current
        ln <- lo <- fmin
        hn <- hi <- fmax
        
        wp <- last0first1[yii,'first1'] <= t
        wn <- last0first1[yii,'last0'] >= t
        if(t > 1)  wp <- wp | zmat[yii,t-1] == 1
        if(t < nyr)wn <- wn | zmat[yii,t+1] == 0
        zp[wp] <- 1
        zp[wn] <- 0
        
        dz <- zp - zt
        ln[dz == 1] <- 0  #from zero to one
        hn[dz == 1] <- fmax[dz == 1]
        ln[dz == -1] <- -fmax[dz == -1]  #from one to zero
        hn[dz == -1] <- 0
        
        mnow <- zt*log(pr[tii]) + (1 - zt)*log(1 - pr[tii])
        mnew <- zp*log(pr[tii]) + (1 - zp)*log(1 - pr[tii])
        
        a  <- exp( mnew - mnow )        
        az  <- runif(nii,0,1)
        aw  <- which(az < a)
        
        accept <- accept + length(aw)
        
        pindex <- t - (1:plag)
        w0     <- which(pindex > 0)
        mt     <- mu[,t]
        VI     <- rep(1,ntree)       # prior
        if(t > 1){                   # m_t and VI
          pindex <- pindex[w0]
          byr <- matrix(betaYrF[w0],ntree,length(w0),byrow=T)
          if(RANDYR)byr <- byr + betaYrR[groupByInd,w0,drop=F]
          mt <- mt + rowSums( byr*yy[,pindex] )
          VI <- VI + rowSums( byr^2 )
        }
        V <- sg/VI
        
        if(t > max(obsTimes)){    ###### predict forward
          
          if(length(aw) > 0){
            z[ tii[aw] ] <- zp[ aw ]
       #     lo[aw] <- ln[aw]
       #     hi[aw] <- hn[aw]
            zmat[ yii[aw],t]   <- zp[ aw ]
            fecMin[ tii[aw] ]  <- exp(ln[aw])
            fecMax[ tii[aw] ]  <- exp(hn[aw])
          }
          yy[yii,t] <- .tnorm(nii,lo,hi,mt[yii],sqrt(sg))
          next
        }
        
        vt <- mt            # v_t
        
        for(k in 1:plag){

          tindex <- t + k - lindex
          wt  <- which(lindex != k & tindex > 0)
          
          if(length(wt) == 0)next
          
          byr1 <- matrix(betaYrF[wt],ntree,length(wt),byrow=T) 
          byr2 <- betaYrF[k]
          if(RANDYR){
            byr1 <- byr1 + betaYrR[groupByInd,wt,drop=F]
            byr2 <- byr2 + betaYrR[groupByInd,k]
          }
          
          ntl <- yy[,t+k] - mu[,t+k] - rowSums( byr1*yy[,tindex[wt]] )
          vt  <- vt + ntl*byr2
        }
        vt <- vt/sg 
        
        if(t <= plag){       #### imput backward
          
          if(length(aw) > 0){
            z[ tii[aw] ] <- zp[ aw ]
       #     lo[aw] <- ln[aw]
       #     hi[aw] <- hn[aw]
            zmat[ yii[aw],t] <- zp[ aw ]
            fecMin[ tii[aw] ]  <- exp(ln[aw])
            fecMax[ tii[aw] ]  <- exp(hn[aw])
            
          }
          V[yii]  <- 1/(1/V[yii] + 1/.5)
          vt[yii] <- vt[yii] + yprior[yii]/.5
          yy[yii,t] <- .tnorm(nii,lo,hi,(V*vt)[yii],sqrt(V[yii]))
          
          next
        }
        
        
        # seed data
        ynew <- .tnorm(nii,ln,hn,(V*vt)[yii],sqrt(V[yii])) # from conditional
        
        sii  <- which(sdata$year == years[t]) # year row in seedData
        
        tree <- tdat[tii,]
        seed <- sdata[sii,]
        
        wtt <- which(!tree$plotyr %in% seed$plotyr) 
        
        if(length(wtt) > 0){         #year before seed data, draw from conditional
          if(length(aw) > 0){
            aww <- aw[aw %in% wtt]   #year before and update
            z[ tii[aww] ] <- zp[ aww ]
            zmat[ yii[aww],t] <- zp[ aww ]
            fecMin[ tii[aww] ]  <- exp(ln[aww])
            fecMax[ tii[aww] ]  <- exp(hn[aww])
            
          }
          yy[yii[wtt],t] <- .tnorm(length(wtt),lo[wtt],hi[wtt],
                                   (V*vt)[yii[wtt]],sqrt(V[yii[wtt]]))
          wtk <- which(tree$plotyr %in% seed$plotyr)
          tii <- tii[ wtk ]
          yii <- yii[ wtk ]
          
          tree <- tdat[tii,]
          mnow  <- mnow[wtk]
          mnew  <- mnew[wtk]
          ynew  <- ynew[wtk]
          zp    <- zp[wtk]
        }
        
        cnow <- cnew <- 0
        #########################
        if(!is.null(seedsPerCone)){
          cc <- is.finite(tree$coneCount)
          wc <- which(z[tii] == 1 & cc)
          
          if(length(wc) > 0){
            fc <- round(fg[tii[wc]])
            
            oss <- tree$coneCount[wc]*seedsPerCone[tree$species[wc],1]
            
            cnow <- cnew <- fc*0
            cnow <- dbinom(oss, round(fc), tree$coneFraction[wc], log=T)
            
            fn <- round(exp(ynew[wc]))
            cnew <- dbinom(oss, round(fn), tree$coneFraction[wc], log=T)
            ip <- match(tree$plotYr[wc],plotYears)
            sm <- matrix(0,max(ip),1)
            
            cnow <- .myBy(cnow, ip, ip*0+1,summat = sm, fun='sum')
            cnew <- .myBy(cnew, ip, ip*0+1,summat = sm, fun='sum')
          }
        }

        #########################
        
        pnow <- .seedProb(tree[,c('specPlot','year','dcol')],
                          ug, fg[tii]*z[tii], distall, seed,
                          seedNames, R, SAMPR, years[t])
        pnew <- .seedProb(tree[,c('specPlot','year','dcol')],
                          ug, exp(ynew)*zp, distall, seed,
                          seedNames, R, SAMPR, years[t]) ###############z[tii]
        pnow[pnow < -1e+9] <- -1e+9   # intensity parameter is zero
        pnew[pnew < -1e+9] <- -1e+9
        
  #      iy <- match(seed$plotYr,plotYears)
        iy <- seed$plotyr
        iy <- rep(iy,length(seedNames))
        
        pnow <- .myBy(as.vector(pnow), iy, iy*0 + 1, fun='sum')
        pnew <- .myBy(as.vector(pnew), iy, iy*0 + 1, fun='sum')
        
        pyID <- unique(iy)       # plot yr for pnew/pnow
        p2s[pyID] <- p2s[pyID] + pnew[pyID] - pnow[pyID]
        
        ip <- match(tree$plotYr,plotYears)
        sm <- matrix(0,max(ip),1)
        
        mnow <- .myBy(mnow, ip, ip*0+1,summat = sm, fun='sum')
        mnew <- .myBy(mnew, ip, ip*0+1,summat = sm, fun='sum')
        
        myID <- unique(ip)
        p2s[myID] <- p2s[myID] +  mnew[myID] - mnow[myID]
        if(!is.null(seedsPerCone) & length(cnow) > 1)
          p2s[myID] <- p2s[myID] +  cnew[myID] - cnow[myID]
        
        a  <- exp( p2s )        
        az  <- runif(length(a),0,1)
        aw  <- which(az < a)
        
        accept <- length(aw)  # no. plot-years
        
        if(length(aw) > 0){
          wa <- which(tree$plotyr %in% aw)  #rows in tdat[tii,]
          yy[ yii[wa],t] <- ynew[wa]
          z[ tii[wa] ]  <- zp[ wa ]
          fecMin[ tii[wa] ]  <- exp(ln[wa])
          fecMax[ tii[wa] ]  <- exp(hn[wa])
    #      zmat[wa,t] <- z[ tii[wa] ]
        }
      }
      
      yg <- yy[ cbind(tdat$dcol, tdat$times) ]
      tmp <- apply(zmat,1,which.max)
      tmp[rowSums(zmat) == 0] <- ncol(zmat)
      matYr <- tmp
    }
    
    fg <- exp(yg)
    
    wf <- which(propF < fg/100)
    
    if(length(wf) > 0)propF[wf] <- fg[wf]/100
    
    fecMin[fecMin < 1e-6] <- 1e-6
    fecMax[fecMax < 1] <- 1
    
    fg[fg > fecMax] <- fecMax[fg > fecMax]
    fg[fg < fecMin] <- fecMin[fg < fecMin]
    fg[fg < 1e-6] <- 1e-6
  #  fg[fg > maxF] <- maxF
            
    list(fg = fg, fecMin = fecMin, fecMax = fecMax, 
         z = z, zmat = zmat, matYr = matYr, propF = propF, 
         epsilon = epsilon, accept = accept) 
  } 
}

.getF <- function(kern, gg ){
  
  tiny <- .0001
  
  fec <- rep(0, ncol(kern))
  
  kk <- kern
  K   <- crossprod(kk)
  K   <- K + diag(tiny*diag(K), nrow(K), nrow(K))
  fec <- solve(K)%*%crossprod(kk, gg)
  
  fec[fec < tiny] <- tiny
  fec
}

.specFormula <- function(formula, NOINTERCEPT=F){
  
  form <- paste0( as.character(formula), collapse=' ')
  form <- .replaceString(form, '~', '~ species*')
  form <- .replaceString(form, ' + ', '+ species*')
  form <- .replaceString(form, '* 1','')
  form <- .replaceString(form, '*1','')
  if(NOINTERCEPT) form <- paste(form, '-1')
  as.formula(form)
}

.getBetaPrior <- function(betaPrior, bgFec, bgRep, specNames){
  
  fecHi <- bgFec*0 + 10
  fecLo <- bgFec*0 - 10
  repHi <- bgRep*0 + 10
  repLo <- bgRep*0 - 10
  nspec <- length(specNames)
  
  if('pos' %in% names(betaPrior)){
    for(j in 1:length(betaPrior$pos)){
      jn <- character(0)
      if(nspec > 1)jn <- paste('species',specNames,':',sep='')
      if(betaPrior$pos[j] != 'intercept')jn <- paste(jn,betaPrior$pos[j],sep='')
      fecLo[rownames(fecLo) %in% jn] <- 0
      repLo[rownames(repLo) %in% jn] <- 0
    }
  }
  if('neg' %in% names(betaPrior)){
    for(j in 1:length(betaPrior$neg)){
      jn <- character(0)
      if(nspec > 1)jn <- paste('species',specNames,':',sep='')
      if(betaPrior$neg[j] != 'intercept')jn <- paste(jn,betaPrior$neg[j],sep='')
      fecHi[rownames(fecHi) %in% jn] <- 0
      repHi[rownames(repHi) %in% jn] <- 0
    }
  }
  list(fec = cbind(fecLo, fecHi), rep = cbind(repLo, repHi) )
}

.updateBetaYr <- function(yg, z, sg, sgYr, betaYrF, betaYrR, yrIndex, yeGr,
                          RANDYR, obs){
  
  #fixed effects
  
  wz <- which(z == 1 & obs == 1)
  nk <- max(yrIndex[,'year'])              # no. years
  yk <- yrIndex[wz,c('group','year')]      # year groups, years
  G  <- length(yeGr)
  
  yfix <- yg[wz] 
  if(RANDYR)yfix <- yfix - betaYrR[yrIndex[wz,c('group','year')]]
  
  ygroup <- .myBy(yfix, yk[,2]*0+1, yk[,2], 
                  summat=matrix(0, 1, nk), fun='sum')
  ngr  <- .myBy(yfix*0+1, yk[,2]*0+1, yk[,2], 
                  summat=matrix(0, 1, nk), fun='sum')
  v <- ygroup/sg
  V <- 1/(ngr /sg + .1)
  bf <- matrix( .tnorm(length(v), -1.5, 1.5, V*v, sqrt(V)), 1, nk)
  bf <- bf - mean(bf)                                   # sum to zero
  
  if(!RANDYR)return( list(betaYrF = bf, betaYrR = bf*0, sgYr = sgYr, 
                 wfinite = 1:nk) )
  
  # random effects
  
  yfix <- yg[wz] - bf[yrIndex[wz,'year']]
  
  ygroup <- .myBy(yfix, yk[,1], yk[,2], 
                  summat=matrix(0, G, nk), fun='sum')
  ngr  <- .myBy(yfix*0+1, yk[,1], yk[,2], 
                  summat=matrix(0, G, nk), fun='sum')
  v  <- ygroup/sg 
  V  <- 1/(ngr /sg + matrix(1/sgYr, G, nk, byrow=T))
  nc <- ngr 
  nc[nc > 1] <- 1
  ns <- colSums(nc)
  nc[,ns == 1] <- 0     # no group effect if only one group
  
  br <- matrix( .tnorm(length(v), -1.5, 1.5, V*v, sqrt(V)), G, nk )
  br <- br*nc
  
  rs <- rowSums(nc)
  ws <- which(rs > 0)
  
  br[ws,] <- sweep(br[drop=F,ws,], 1, rowSums(br[drop=F,ws,])/rs[ws], '-')*nc[drop=F,ws,]
  
  sgYr <- 1/rgamma(nk, 2 + ns/2, 1 + .5* colSums(br^2))
  
  list(betaYrF = bf, betaYrR = br, sgYr = sgYr, wfinite = which(nc > 0))
}

.multivarChainNames <- function(rowNames,colNames){
  as.vector( t(outer(colNames,rowNames,paste,sep='_')) )
}

.rdirichlet <- function(pmat, n = nrow(pmat) ){
  
  # pmat - rows are parameter vectors
  # if pmat is a vector, then n is the number of random vectors
  
  if(!is.matrix(pmat)){
    pmat <- matrix(pmat,1)
    pmat <- pmat[rep(1,n),]
  }
  pmat <- matrix( rgamma(n*ncol(pmat),pmat,1), n, ncol(pmat))
  sweep(pmat, 1, rowSums(pmat), '/')
}

.updateR <- function(ug, fz, SAMPR, distall, sdata, seedNames, 
                     tdat, R, priorR, priorRwt, years, posR, plots){
  
 # a <- .tnorm(length(posR), 0, 2, 1, 1)
 # b <- a/R[posR]
  
  mnew <- R
  mnew[posR] <- .tnorm(length(posR), 0, 1, R[posR], .02)
  
  mnew <- sweep(mnew, 1, rowSums(mnew,na.rm=T), '/')
 # mnew[-posR] <- 0

  qnow <- 2*priorRwt*log(R)
  qnow[-posR] <- 0
  qnew <- 2*priorRwt*log(mnew)
  qnew[-posR] <- 0
  
  jj <- rep(attr(R,'plot'), ncol(R))
  qnow <- tapply(as.vector(qnow), jj, sum, na.rm=T)
  qnew <- tapply(as.vector(qnew), jj, sum, na.rm=T)
  

  tnow <- .seedProb(tdat[,c('specPlot','year','dcol')],
                    ug, fz, distall, sdata, seedNames,
                        R, SAMPR, years)
  tnew <- .seedProb(tdat[,c('specPlot','year','dcol')],
                    ug, fz, distall, sdata, seedNames,
                    mnew, SAMPR, years)
  tnow[!is.finite(tnow)] <- -8   # intensity parameter is zero
  tnew[!is.finite(tnew)] <- -8
  
  ii <- match(sdata$plot, plots)
  pnow <- .myBy( rowSums(tnow), ii, ii*0+1, fun='sum')[,1]
  pnew <- .myBy( rowSums(tnew), ii, ii*0+1, fun='sum')[,1]
  
  a <- exp(pnew + qnew - pnow - qnow) 
  wa <- which(a > runif(length(a),0,1))
  if(length(wa) > 0){
    R[attr(R,'plot') %in% plots[wa],] <- mnew[attr(R,'plot') %in% plots[wa],]
  }
  R
}

.distmat <- function(x1,y1,x2,y2){
    xd <- outer(x1,x2,function(x1,x2) (x1 - x2)^2)
    yd <- outer(y1,y2,function(y1,y2) (y1 - y2)^2)
    t(sqrt(xd + yd)) 
}

.updateVariance <- function(y,mu,s1=1,s2=1){
  
  u1 <- s1 + length(y)/2
  u2 <- s2 + .5*sum( (y - mu)^2 )
  1/rgamma(1,u1,u2) 
  
}

sqrtSeq <- function(maxval){ #labels for sqrt scale
  
  # maxval on sqrt scale
  
  by   <- signif(maxval^1.7, 1)
  labs <- seq(0, maxval^2, by = by)
  at   <- sqrt(labs)

  list(at = at, labs = labs)
}

.plotObsPred <- function(obs, yMean, ySE=NULL, opt = NULL){
  
  nbin <- nPerBin <- xlimit <- ylimit <- NULL
  add <- log <- SQRT <- F
  xlabel <- 'Observed'
  ylabel <- 'Predicted'
  trans <- .4
  col <- 'black'
  bins <- NULL
  atx <- aty <- labx <- laby <- NULL
  ptcol <- 'black'
  
  for(k in 1:length(opt))assign( names(opt)[k], opt[[k]] )
  
  if(!is.null(bins))nbin <- length(bins)
  
  if(log & SQRT)stop('cannot have both log and SQRT scale')
  
  yMean <- as.matrix(yMean)
  obs   <- as.matrix(obs)
  
  if(SQRT){
    xlim <- sqrt(xlimit)
    ylim <- sqrt(ylimit)
    obs   <- as.vector(sqrt(obs))
    yMean <- as.vector(sqrt(yMean))
    if(!is.null(bins))bins <- sqrt(bins)
    xlimit <- sqrt(range(obs,na.rm=T))
    xlimit[2] <- xlimit[2]*2
    ylimit <- sqrt(range(yMean,na.rm=T))
    ylimit[2] <- 1.2*ylimit[2]
 
    maxy <- max(yMean,na.rm=T)
    maxx   <- max(obs,na.rm=T)
    maxval <- max( c(maxx, maxy) )
    
    tt   <- sqrtSeq(1.2*maxx)
    if(is.null(atx))atx   <- tt$at
    if(is.null(labx))labx <- tt$labs
    
    
    if(ylimit[2] < xlimit[2]) ylimit[2] <- xlimit[2]
    if(xlimit[2] < xlim[2])   xlimit[2] <- xlim[2]
    if(ylimit[2] < ylim[2])   ylimit[2] <- ylim[2]
    
    tt   <- sqrtSeq(1.2*ylimit[2])
    if(is.null(aty))aty   <- tt$at
    if(is.null(laby))laby <- tt$labs

  }
    
  if(is.null(xlimit))xlimit <- range(obs)
  if(is.null(ylimit) & !add){                      # can only happen if !SQRT
    if(!log){
      plot(obs,yMean,col=.getColor(ptcol,.2),cex=.2, xlim=xlimit,
           xlab=xlabel,ylab=ylabel)
      if(log) suppressWarnings( plot(obs,yMean,col=.getColor('black',.2),cex=.3,
                                     xlim=xlimit,xlab=xlabel,ylab=ylabel,log='xy') )
    }
  }
    
  if( !is.null(ylimit) ){
    if(!log & !add){
      if(!SQRT){
        plot(obs,yMean,col=.getColor(ptcol,trans),cex=.2,
                 xlim=xlimit,xlab=xlabel,ylab=ylabel,ylim=ylimit)
      }else{
        plot(obs,yMean,col=.getColor(ptcol,trans),cex=.2,
             xlim=xlimit,xlab=xlabel,ylab=ylabel,ylim=ylimit,
             xaxt='n',yaxt='n')
        
        axis(1, at = atx, labels = labx)
        axis(2, at = aty, labels = laby, las=2)
      }
    }
    if(log & !add) plot(obs,yMean,col=.getColor(ptcol,trans),cex=.2,
                 xlim=xlimit,xlab=xlabel,ylab=ylabel,log='xy',ylim=ylimit)
  }
  if(!is.null(ySE)){
    ylo <- yMean - 1.96*ySE
    yhi <- yMean + 1.96*ySE
    for(i in 1:length(obs))lines(c(obs[i],obs[i]),c(ylo[i],yhi[i]),
                                 col='grey',lwd=2)
  }
  
  if( !is.null(nbin) | !is.null(nPerBin) ){
    
    if(is.null(bins)){
      nbin <- 20
      bins <- seq(min(obs,na.rm=T),max(obs,na.rm=T),length=nbin)
    }else{
      nbin <- length(bins)
    }
    
    if(!is.null(nPerBin)){
      nbb <- nPerBin/length(obs)
      nbb <- seq(0,1,by=nbb)
      if(max(nbb) < 1)nbb <- c(nbb,1)
      bins <- quantile(obs,nbb,na.rm=T)
      bins <- bins[!duplicated(bins)]
      nbin <- length(bins)
    }
    
    xxk <- findInterval(obs,bins)
    
    if(SQRT & is.null(bins)){
      opos <- obs[obs > 0]
      qq <- seq(0, 1, length=15)
      bins <- quantile(opos, qq)
      dbb  <- diff(bins)
      bins <- c(bins[1], bins[-1][dbb > .01])
      
      nbin <- length(bins)
      
      xxk <- findInterval(obs,bins)
      xxk[xxk == max(xxk)] <- max(xxk) - 1
    }
    xxk[xxk == nbin] <- nbin - 1
    
    wide <- diff(bins)/2
    db   <- 1
    for(k in 2:(nbin-1)){
      
      qk <- which(is.finite(yMean) & xxk == k)
      q  <- quantile(yMean[qk],c(.5,.025,.158,.841,.975),na.rm=T)
      
      if(!is.finite(q[1]))next
      if(q[1] == q[2])next
      
      ym <- mean(yMean[qk])
      xx <- mean(bins[k:(k+1)])
      rwide <- wide[k]
      
      if(k > 1)db <- bins[k] - bins[k-1]
      
      if( xx > (bins[k] + db) ){
        xx <- bins[k] + db
        rwide <- wide[ max(c(1,k-1)) ]
      }
      
      suppressWarnings(
        arrows(xx, q[2], xx, q[5], lwd=2, angle=90, code=3, col=.getColor(col,.8),
               length=.05)
      )
      lines(c(xx-.5*rwide,xx+.5*rwide),q[c(1,1)],lwd=2, 
            col=.getColor(col,.8))
      rect(xx-.4*rwide,q[3],xx+.4*rwide,q[4], col=.getColor(col,.5), border=col)
    }
  }
  invisible( list(atx = atx, labx = labx, aty = aty, laby = laby) )
}

.getKern <- function(u,dij){
  
  uvec <- u[ attr(dij,'group') ]
  kk <- t(uvec/pi/(uvec + t(dij)^2)^2)
  
 # kk <- u/pi/(u + dij^2)^2
  kk[is.na(kk)] <- 0
  kk
}

.mapSpec <- function(x, y, z, mapx=range(x), mapy=range(y), scale=0,
                     add=F, sym='circles',
                     colVec=rep(1,length(x)), fill=F){
  
  fillCol <- NA
  if(is.logical(fill))fillCol <- colVec
  if(is.character(fill))fillCol <- fill
  
  opin <- par()$pin
  
  if(scale > 0).mapSetup(mapx,mapy,scale)
  if(!add){
    plot(NA, xlim=mapx, ylim=mapy, axes = F, xlab='', ylab='')
    Axis(side=1, labels=FALSE)
    Axis(side=2, labels=FALSE)
    add <- T
  }
  
  if(sym == 'circles'){

    symbols(x,y,circles=z/10,inches=F,
                              xlim=mapx,ylim=mapy,fg=colVec,bg=fillCol,
                              lwd=2,add=add)
  }
  if(sym == 'squares'){
    symbols(x,y,squares=z/10,inches=F,
                              xlim=mapx,ylim=mapy,fg=colVec,bg=fillCol,
                              lwd=2,add=add)
  }
  par(pin = opin)
}

scaleBar = function(label, value = 1, fromLeft = .5, yadj = .1, 
                    lwd = 3, cex = 1) {
  
  xl <- par("usr")[1:2]
  yl <- par("usr")[3:4]
  
  xm <- xl[1] + fromLeft*diff(xl)
  x1 <- xm - value/2
  x2 <- xm + value/2
  
  y  <- yl[1] + .05*diff(yl)
  ym <- y + yadj*diff(yl)
    
  lines(c(x1,x2),c(y,y), lwd=lwd + 2, col='white')
  lines(c(x1,x2),c(y,y), lwd=lwd)
  
  lab <- paste(value, label)
  text(xm, ym, lab, cex = cex)
}

.mapSetup<- function(xlim,ylim,scale){  #scale is m per inch

  px   <- diff(xlim)/scale
  py   <- diff(ylim)/scale
  pin  <- c(px, py)
  par(pin = pin)
  invisible( pin )
}

.getColor <- function(col,trans){
  
  # trans - transparency fraction [0, 1]
  
  tmp <- col2rgb(col)
  rgb(tmp[1,], tmp[2,], tmp[3,], maxColorValue = 255, 
      alpha = 255*trans, names = paste(col,trans,sep='_'))
}

.interp <- function(y,INCREASING=F,minVal=-Inf,maxVal=Inf,defaultValue=NULL,
                   tinySlope=NULL){  #interpolate vector x
  
  if(is.null(defaultValue))defaultValue <- NA
  
  tiny <- .00001
  if(!is.null(tinySlope))tiny <- tinySlope
  
  y[y < minVal] <- minVal
  y[y > maxVal] <- maxVal
  
  n  <- length(y)
  wi <- which(is.finite(y))
  
  if(length(wi) == 0)return(rep(defaultValue,n))
  if(length(wi) == 1)ss <- tiny
  
  xx  <- c(1:n)
  z  <- y
  
  if(wi[1] != 1) wi <- c(1,wi)
  if(max(wi) < n)wi <- c(wi,n)
  
  ss <- diff(z[wi])/diff(xx[wi])
  
  ss[is.na(ss)] <- 0
  
  if(length(ss) > 1){
    if(length(ss) > 2)ss[1] <- ss[2]
    ss[length(ss)] <- ss[length(ss)-1]
  }
  if(INCREASING)ss[ss < tiny] <- tiny
  
  if(is.na(y[1]))  z[1] <- z[wi[2]] - xx[wi[2]]*ss[1]
  if(z[1] < minVal)z[1] <- minVal
  if(z[1] > maxVal)z[1] <- maxVal
  
  for(k in 2:length(wi)){
    
    ki <- c(wi[k-1]:wi[k])
    yk <- z[wi[k-1]] + (xx[ki] - xx[wi[k-1]])*ss[k-1]
    yk[yk < minVal] <- minVal
    yk[yk > maxVal] <- maxVal
    z[ki] <- yk
  }
  z
}

.interpRows <- function(x, startIndex=rep(1,nrow(x)), endIndex=rep(ncol(x),nrow(x)),
                       INCREASING=F, minVal=-Inf, maxVal=Inf,
                       defaultValue=NULL,tinySlope=.001){  
  #interpolate rows of x subject to increasing
  
  nn  <- nrow(x)
  p  <- ncol(x)
  xx <- c(1:p)
  
  if(length(minVal) == 1)minVal <- rep(minVal,nn)
  if(length(maxVal) == 1)maxVal <- rep(maxVal,nn)
  
  ni   <- rep(NA,nn)
  flag <- numeric(0)
  
  z <- x
  
  for(i in 1:nn){
    if(startIndex[i] == endIndex[i]){
      z[i,-startIndex[i]] <- NA
      next
    }
    z[i,startIndex[i]:endIndex[i]] <- .interp(x[i,startIndex[i]:endIndex[i]],
                                             INCREASING,minVal[i],maxVal[i],
                                             defaultValue,tinySlope)
  }
  
  z
}

.shadeInterval <- function(xvalues,loHi,col='grey',PLOT=T,add=T,
                           xlab=' ',ylab=' ', xlim = NULL, ylim = NULL, 
                           LOG=F, trans = .5){
  
  #draw shaded interval
  
  tmp <- smooth.na(xvalues,loHi)

  xvalues <- tmp[,1]
  loHi <- tmp[,-1]
  
  xbound <- c(xvalues,rev(xvalues))
  ybound <- c(loHi[,1],rev(loHi[,2]))
  if(is.null(ylim))ylim <- range(as.numeric(loHi))
  if(is.null(xlim))xlim <- range(xvalues)
  
  if(!add){
    if(!LOG)plot(NULL, xlim = xlim, ylim=ylim, 
                 xlab=xlab, ylab=ylab)
    if(LOG)suppressWarnings( plot(NULL,  xlim = xlim, ylim=ylim, 
                xlab=xlab, ylab=ylab, log='y') )
  }
 
  
  if(PLOT)polygon(xbound,ybound, border=NA,col=.getColor(col, trans))
  
  invisible(cbind(xbound,ybound))
  
}

smooth.na <- function(x,y){   
  
  #remove missing values
  #x is the index
  #y is a matrix with rows indexed by x
  
  if(!is.matrix(y))y <- matrix(y,ncol=1)
  
  wy <- which(!is.finite(y),arr.ind =T)
  if(length(wy) == 0)return(cbind(x,y))
  wy <- unique(wy[,1])
  ynew <- y[-wy,]
  xnew <- x[-wy]
  
  return(cbind(xnew,ynew))
}

.appendMatrix <- function(m1,m2,fill=NA,SORT=F,asNumbers=F){  
  
  # matches matrices by column names
  # asNumbers: if column heads are numbers and SORT, then sort numerically
  
  if(length(m1) == 0){
    if(is.matrix(m2)){
      m3 <- m2
    } else {
      m3 <- matrix(m2,nrow=1)
    }
    if( !is.null(names(m2)) )colnames(m3) <- names(m2)
    return(m3)
  }
  if(length(m2) == 0){
    if(!is.matrix(m1))m1 <- matrix(m1,nrow=1)
    return(m1)
  }
  if( is.vector(m1) | (length(m1) > 0 & !is.matrix(m1)) ){
    nn <- names(m1)
    if(is.null(nn))message('cannot append matrix without names')
    m1 <- matrix(m1,1)
    colnames(m1) <- nn
  }  
  if( is.vector(m2) | (length(m2) > 0 & !is.matrix(m2)) ){
    nn <- names(m2)
    if(is.null(nn))message('cannot append matrix without names')
    m2 <- matrix(m2,1)
    colnames(m2) <- nn
  }
  
  c1 <- colnames(m1)
  c2 <- colnames(m2)
  r1 <- rownames(m1)
  r2 <- rownames(m2)
  n1 <- nrow(m1)
  n2 <- nrow(m2)
  
  allc <-  unique( c(c1,c2) ) 
  if(SORT & !asNumbers)allc <- sort(allc)
  if(SORT & asNumbers){
    ac <- as.numeric(allc)
    allc <- as.character( sort(ac) )
  }
  
  nr <- n1 + n2
  nc <- length(allc)
  
  if(is.null(r1))r1 <- paste('r',c(1:n1),sep='-')
  if(is.null(r2))r2 <- paste('r',c((n1+1):nr),sep='-')
  new <- c(r1,r2)
  
  mat1 <- match(c1,allc)
  mat2 <- match(c2,allc)
  
  out <- matrix(fill,nr,nc)
  colnames(out) <- allc
  rownames(out) <- new
  
  out[1:n1,mat1] <- m1
  out[(n1+1):nr,mat2] <- m2
  out
}

.myBoxPlot <- function(mat, tnam, snames, specColor, label){
  
  # tnam is columns of mat, with values of snames used to match specColor
  
  ord <- order(colMeans(mat),decreasing=F)
  mat  <- mat[,ord]
  tnam <- tnam[ord]
  bb   <- specColor[ match(tnam, snames) ]
  ry   <- range(mat)
  ymin <- min(mat) - diff(ry)*.15
  ymax <- max(mat) + diff(ry)*.15
  bx   <- .getColor(bb,.4)
  
  tmp <- .boxplotQuant( mat,xaxt='n',outline=F,ylim=c(ymin,ymax),
                        col=bx, border=bb, xaxt='n',lty=1)
  abline(h=0,lwd=2,col='grey',lty=2)
  
  dy <- .05*diff(par()$yaxp[1:2])
  
  cext <- .fitText2Fig(tnam,fraction=1)
  text((1:length(ord)) - .1,dy + tmp$stats[5,],tnam,srt=70,pos=4,
       col=bb, cex=cext)
  
  pl    <- par('usr')
  xtext <- pl[1]
  ytext <- pl[3] + diff(pl[3:4])*.85
  .plotLabel(label,location='topleft', cex=1.0)
}

.boxplotQuant <- function( xx, ..., boxfill=NULL ){
  
  tmp <- boxplot( xx, ..., plot=F)
  ss  <- apply( xx, 2, quantile, pnorm(c(-1.96,-1,0,1,1.96)), na.rm=T ) 
  tmp$stats <- ss
  
  pars <- list(...)
  if( 'col' %in% names(pars) )boxfill <- pars$col
  
  bxp( tmp, ..., boxfill = boxfill )
  
  invisible( tmp )
}

.fitText2Fig <- function(xx, width=T, fraction=1, cex.max=1){
  
  # returns cex to fit xx within fraction of the current plotting device
  # width - horizontal labels stacked vertically
  #!width - vertical labels plotted horizontally
  
  px <- par('pin')[1]
  py <- par('pin')[2]
  cl <- max( strwidth(xx, units='inches') )
  ch <- strheight(xx, units='inches')[1]*length(xx)  # ht of stacked vector
  
  if(width){              #horizontal labels stacked vertically
    xf <- fraction*px/cl
    yf <- fraction*py/ch
  } else {                #vertical labels plotted horizontally
    xf <- fraction*px/ch
    yf <- fraction*py/cl
  }
  
  cexx <- min(c(xf,yf))
  if(cexx > cex.max)cexx <- cex.max
  cexx
}

deltaScore <- function(mu, vr, scale, score){
  
#  mu <- colMeans(mu/scale, na.rm=T)
#  vr <- colMeans(vr/scale, na.rm=T)
  
  mu <- matrix( mu[nrow(mu),], nrow(mu), ncol(mu), byrow=T)
  vr <- matrix( vr[nrow(vr),], nrow(mu), ncol(mu), byrow=T)
  
  muScore <- log(mu) + 1/2*( log(scale) - log(vr))
  score - muScore
}



