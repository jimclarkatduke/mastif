## ----outform, echo=F-----------------------------------------------------
bigskip <- function(){
    "<br>"
}

## ----getFiles, eval = F, echo=F------------------------------------------
#  Rcpp::sourceCpp('../RcppFunctions/cppFns.cpp')
#  source('../RFunctions/mastfunctions.r')

## ----simSetup0, eval = F-------------------------------------------------
#  seedNames  <- specNames  <- 'acerRubr'
#  sim <- list(nyr=10, ntree=30, nplot=5, ntrap=40, meanDist = 15,
#                 specNames = specNames, seedNames = seedNames)

## ----sim0, eval = F------------------------------------------------------
#  inputs     <- mastSim(sim)        # simulate dispersal data
#  seedData   <- inputs$seedData     # year, plot, trap, seed counts
#  trueValues <- inputs$trueValues   # true states and parameter values
#  treeData   <- inputs$treeData     # year, plot, tree data
#  xytree     <- inputs$xytree       # tree locations
#  xytrap     <- inputs$xytrap       # trap locations
#  formulaFec <- inputs$formulaFec   # fecundity model
#  formulaRep <- inputs$formulaRep   # maturation model

## ----formulaFec, eval = F------------------------------------------------
#  formulaFec

## ----treeData0, eval = F-------------------------------------------------
#  head(treeData)

## ----xytree, eval = F----------------------------------------------------
#  head(xytree, 5)

## ----treeData1, eval = F-------------------------------------------------
#  head(seedData)

## ----map1a, eval = F-----------------------------------------------------
#  dataTab <- table(treeData$plot,treeData$year)
#  
#  w <- which(dataTab > 0,arr.ind=T) # a plot-year with observations
#  w <- w[sample(nrow(w),1),]
#  
#  mapYears <- as.numeric( colnames(dataTab)[w[2]] )
#  mapPlot  <- rownames(dataTab)[w[1]]
#  
#  mastMap(inputs, treeSymbol=treeData$diam, mapPlot = mapPlot,
#          mapYears = mapYears, SCALEBAR = T)

## ----map3, eval=F--------------------------------------------------------
#  trueValues <- inputs$trueValues
#  mastMap(inputs, treeSymbol=trueValues$fec, mapPlot = mapPlot,
#          mapYears = mapYears, scaleTree=1, scaleTrap = 1, SCALEBAR = T)

## ----hist0, eval = F-----------------------------------------------------
#  par( mfrow=c(2,1),bty='n', mar=c(4,4,1,1) )
#  seedData <- inputs$seedData
#  seedNames <- inputs$seedNames
#  
#  hist( as.matrix(seedData[,seedNames]) ,nclass=100,
#        xlab = 'seed count', ylab='per trap', main='' )
#  hist( trueValues$fec,nclass=100, xlab = 'seeds produced', ylab = 'per tree',
#        main = '')

## ----mast2, eval = F-----------------------------------------------------
#  output   <- mastif( inputs = inputs, ng = 1500, burnin = 500 )

## ----tabPars0, eval = F--------------------------------------------------
#  summary( output )

## ----pars, eval = F------------------------------------------------------
#  plotPars <- list(trueValues = trueValues)
#  mastPlot(output, plotPars)

## ----restart, eval=F-----------------------------------------------------
#  predList <- list( mapMeters = 3, plots = mapPlot, years = mapYears )
#  output   <- mastif( inputs = output, ng = 2000, burnin = 1000,
#                    predList = predList)

## ----mapout, eval = F----------------------------------------------------
#  mastMap(output, mapPlot = predList$plots, mapYears = predList$years,
#          scaleTree = 2, scaleTrap = .5, PREDICT = T, scaleValue = 20)

## ----simSetup, eval = F--------------------------------------------------
#  specNames <- c('querRubr','querAlba','querFalc')
#  seedNames <- c('querRubr','querAlba','querFalc','querUNKN')
#  sim    <- list(nyr=5, ntree=40, nplot=8, ntrap=50, specNames = specNames,
#                    seedNames = seedNames)

## ----sim, eval = F-------------------------------------------------------
#  inputs <- mastSim(sim)        # simulate dispersal data
#  R      <- inputs$trueValues$R # species to seedNames probability matrix
#  R

## ----mast3, eval = F-----------------------------------------------------
#  tab  <- with( seedData, table(plot, year) )
#  years <- as.numeric( colnames(tab)[tab[1,] > 0] ) # years with data for 1st plot
#  
#  inputs$priorR    <- R                              # prior for M
#  inputs$priorRwt  <- R*10
#  inputs$priorDist <- 30
#  inputs$minDist   <- 10
#  inputs$maxDist   <- 70
#  inputs$priorVdist <- 50
#  
#  output <- mastif( inputs = inputs, ng = 2000, burnin = 1000)

## ----tabPars, eval = F---------------------------------------------------
#  summary( output )

## ----pars0, eval = F-----------------------------------------------------
#  plotPars <- list(trueValues = inputs$trueValues)
#  mastPlot(output, plotPars)

## ----again, eval=F-------------------------------------------------------
#  predList <- list( plots = 'p1', years = years )
#  output <- mastif( inputs = output, ng = 10000, burnin = 2000,
#                    predList = predList)
#  mastPlot(output, plotPars)

## ----readDF, eval=F, echo=F----------------------------------------------
#  
#  years       <- 1991:2017
#  
#  
#  genera <- c('abie','acer','aila','amel','betu','carp',
#              'cary','celt','cerc','chio','corn','fagu','frax',
#              'ilex','juni','liqu','liri','magn',
#              'moru','nyss','ostr','oxyd','pice','pinu','prun',
#              'quer','robi','sass','sorb','tili','tsug','ulmu')
#  genFull <- c('abies','acer','ailanthus','amelanchier','betula','carpinus',
#               'carya','celtis','cercis','chionanthus','cornus','fagus','fraxinus',
#               'ilex','juniperus','liquidambar','liriodendron','magnolia',
#               'morus','nyssa','ostrya','oxydendron','picea','pinus','prunus',
#               'quercus','robinia','sassafras','sorbus','tilia','tsuga','ulmua')
#  
#  omitNames   <- c('acerIMMA','liriTuli_flower','betuUNKN_flower','caryIMMA',
#                   'cornIMMA','acerRubr_flower',' betuUNKN_flower',
#                   'nyssIMMA','oxydArbo_flower','oxydIMMA','pinuImma_fruit',
#                   'piceRubeIMMA','querIMMA','tiliAmer_flower')
#  changeNames <- rbind( cbind('ulmuUNKN','ulmuAlat'),
#                        cbind('acerUNKN','acerRubr'),
#                        cbind('acerrubr','acerRubr'))
#  colnames(changeNames) <- c('from','to')
#  
#  #genusName   <- 'abie'
#  
#  treeID      <- 'ID'
#  yrCols      <- c('diam','canopy')
#  treeStart   <- 'censinyr'
#  treeEnd     <- c('deathyr','censoryr')
#  x           <- 'x'
#  y           <- 'y'
#  
#  trapCols <- c("plot","trapID","trap","x","y","UTMx","UTMy","elev")
#  
#  trapID <- 'trapnum'
#  
#  path  <- "../dataFiles/"
#  
#  
#  path <- "/Volumes/Research/clark/clark.unix/allocationmodel/datafiles/"
#  
#  #path <- "/nfs/clark/clark.unix/allocationmodel/datafiles/"
#  
#  
#  plots <- c('CW_118', 'CW_218', 'CW_318', 'CW_427', 'CW_527', 'CW_LG','CW_UG',
#             'MH_F','MH_P','DF_HW', 'DF_EW', 'DF_BW','DF_EE',
#             'GSNP_PK', 'GSNP_CD', 'GSNP_ND','HF_S', 'HF_BW')
#  
#  #plots    <- list.files(paste0(path, 'trees/', sep=''))
#  #treeFile <- plots[ grep('active',plots) ]
#  #locFile  <- plots[ grep('UTM',plots) ]
#  
#  sfiles    <- list.files(paste0(path, 'seeds/', sep=''))
#  seedFile <- sfiles[ grep('active',sfiles) ]
#  locFile  <- sfiles[ grep('UTM',sfiles) ]
#  
#  plots <- unlist( strsplit(plots, "_active.txt") )
#  
#  seedFile <- paste0(path, 'seeds/', plots, '_active.txt', sep='')
#  locFile  <- paste0(path, 'seeds/', plots, '_UTM.txt', sep='')
#  treeFile <- paste0(path, 'trees/', plots, '_active.txt', sep='')
#  
#  for(i in 1:length(genera)){
#  
#    genusName <- genera[i]
#  
#    seedData <- xytrap <- numeric(0)
#    plotAll <- seedNames <- character(0)
#  
#    treeData <- xytree <- numeric(0)
#    seedcols <- numeric(0)
#    seedData <- character(0)
#  
#    for(j in 1:length(plots)){
#  
#      tfile <- treeFile[grep(plots[j],treeFile)]
#      sfile <- seedFile[grep(plots[j],seedFile)]
#      lfile <- locFile[grep(plots[j],locFile)]
#  
#      tmp    <- .treeFormat( tfile, genusName = genusName, changeNames = changeNames,
#                             plot = plots[j],
#                             years = years, yrCols = yrCols  )
#      yrDat  <- tmp$yrDat
#      xyt    <- tmp$xytree
#      if(length(yrDat) == 0)next
#  
#  
#      tmp <- .seedFormat(sfile, lfile, trapFile = '../dataFiles/seedTrapArea.txt',
#                         genusName = genusName, omitNames = omitNames,
#                         plot = plots[j], trapID = trapID )
#      if(length(tmp) == 0)next
#  
#      seedNames <- sort(unique(c(seedNames, tmp$seedNames)))
#      xyseed   <- tmp$xy
#      #  if(length(xytrap) > 0)xyseed   <- tmp$xy[,colnames(xytrap)]
#      xytrap   <- rbind( xytrap, xyseed[,trapCols] )
#  
#      seedj  <- tmp$counts
#      wcol <- sapply(seedj, is.numeric)
#      counts <- as.matrix( tmp$counts[,which(wcol), drop=F] )
#  
#  
#      seedData <- .appendMatrix(seedData, counts, fill=0)
#      seedcols <- rbind(seedcols, seedj[,which(!wcol)])
#  
#      yrDat <- yrDat[yrDat$year %in% seedj$year,]
#      xyt   <- xyt[xyt$treeID %in% yrDat$treeID,]
#  
#      treeData <- rbind(treeData, yrDat)
#      xytree   <- rbind(xytree, xyt)
#  
#    }
#  
#    plotj <- plots[plots %in% seedcols[,'plot']]
#  
#    ws <- which( colSums(seedData[,seedNames, drop=F]) == 0 )
#    if(length(ws) > 0){
#      seedData <- seedData[,!colnames(seedData) %in% names(ws), drop=F]
#      seedNames <- seedNames[!seedNames %in% names(ws)]
#    }
#  
#    seedData <- data.frame(seedcols, seedData)
#    specNames <- attr( treeData$species, 'levels')
#  
#    treeData <- treeData[treeData$year %in% seedData$year,]
#    seedData <- seedData[seedData$year %in% treeData$year,]
#    xytree   <- xytree[xytree$treeID %in% treeData$treeID,]
#  
#    # reproduction prior, probit scale
#  
#    repMu <- (treeData$diam - 30)/sd( treeData$diam, na.rm=T )
#    repSd <- sqrt(1 + treeData$diam*( max( treeData$diam, na.rm=T ) - treeData$diam ) )
#  
#    treeData$repr[treeData$diam < 8] <- 0
#    treeData$repr[treeData$diam > 30 & treeData$canopy > 0] <- 1
#    treeData$repr[treeData$diam > 40] <- 1
#  
#    treeData$repMu <- signif(repMu, 3)
#    treeData$repSd <- signif(repSd, 3)
#  
#    treeData$canopy <- jitter(treeData$canopy)
#  
#    #M <- .getM(specNames, seedNames, unknown = 'UNKN', unFraction = .9)
#  
#    treeData <- treeData[,c("plot","treeID","tree","species","year","region",
#                            "repr","diam","canopy","growth")]
#    seedData <- seedData[,c("plot","trapID","trap","year","active","area",seedNames)]
#  
#    xytree <- xytree[,c('tree','treeID','plot','x','y','UTMx','UTMy','elev')]
#    xytrap <- xytrap[,c('trap','trapID','plot','x','y','UTMx','UTMy','elev')]
#  
#    wc <- which(colnames(xytree) %in% c('x','y','UTMx','UTMy'))
#    colnames(xytree)[wc] <- c('xplot','yplot','x','y')
#    colnames(xytrap)[wc] <- c('xplot','yplot','x','y')
#  
#    treeData[,c('diam','canopy','growth')] <-
#               round( treeData[,c('diam','canopy','growth')], 2 )
#  
#    save(treeData, seedData, specNames, seedNames,
#         xytree, xytrap, plotj, years, # M,
#         file=paste('../compressedFiles/clarkLab/', genFull[i],'.Rdata',sep='') )
#    print(seedNames)
#  }

## ---- echo=F, eval=F-----------------------------------------------------
#  
#  #temporary ailanthus
#  # set i = 3 and read in data
#  
#  load('../compressedFiles/aila.Rdata')
#  plots <- 'DF_BW'
#  ylim <- c(0,50)
#  yl <- c(0,.06)
#  file <- 'AlianthusBA.pdf'
#  years <- c(1999:2016)
#  
#  load('../compressedFiles/tsug.Rdata')
#  plots <- c("CW_LG", "CW_UG")
#  ylim <- c(0,300)
#  yl <- c(0,2)
#  file <- 'tsugaBA.pdf'
#  years <- c(1999:2016)
#  
#  load('../compressedFiles/corn.Rdata')
#  plots <- c("CW_218","DF_HW", "DF_BW", "DF_EW")
#  plots <- 'CW_218'
#  ylim <- c(0,30)
#  yl <- c(0,1)
#  file <- 'cornBA.pdf'
#  years <- c(1991:2016)
#  
#  
#  pdf( file=file, width=6, height=4 )
#  
#  cols <- c('darkgreen','brown','darkblue', 'black')
#  
#  ff       <- paste(path,'treePlotDataDuke.txt',sep='')
#  traparea <- read.table(ff, header=T)[,1:2]
#  
#  ff       <- paste(path,'treePlotAreaDuke.txt',sep='')
#  plotarea <- read.table(ff, header=T)
#  pyr      <- as.numeric( matrix( unlist(strsplit(colnames(plotarea)[-1],'X')),
#                          ncol=2,byrow=T)[,2] )
#  
#  ba <- pi*(treeData$diam/2)^2
#  
#  aa <- max( traparea[traparea[,'plot'] %in% plots,'seedArea'] )
#  maxSeed <- max(as.vector(seedData[seedData$plot %in%   plots,seedNames])/aa,na.rm=T)
#  
#  par(bty='n', mar=c(4,4,1,4))
#  
#  plot(NULL,xlim=range(years),ylim=c(0,1.5*sqrt(maxSeed)), xlab='Year',
#       ylab='Seeds per m2', yaxt='n')
#  
#  tt   <- sqrtSeq(1.2*sqrt(maxSeed))
#  at   <- tt$at
#  labs <- tt$labs
#  axis(2, at = at, labels = labs)
#  
#  for(j in 1:length(plots)){
#  
#    ws <- which(seedData$plot == plots[j])
#    aa <- traparea[traparea[,'plot'] == plots[j],'seedArea']
#    smat <- as.matrix(seedData[ws,seedNames])/aa
#    svec <- sqrt(as.vector(smat))
#    yy   <- seedData$year[ws]
#    yy   <- rep(yy, length(seedNames))
#    points(jitter(yy),jitter(svec),
#           pch=16, col=.getColor(cols[j], .6),
#           cex= .2 + 2*(svec/sqrt(maxSeed))^.3)
#  }
#  
#  par(new = T)
#  plot(NULL, pch=16, xlim=c(1998,2017),ylim=yl,
#       axes=F, xlab='', ylab='')
#  
#    for(j in 1:length(plots)){
#  
#      wt <- which(treeData$plot == plots[j])
#  
#      pa <- as.numeric(plotarea[plotarea[,'plot'] == plots[j],-1])
#  
#      aa <- pa[ match(treeData$year[wt],pyr) ]
#      btj <- ba[wt]/aa/10000
#  
#      bt <- tapply(btj,treeData$year[wt],sum)
#      yt <- as.numeric(names(bt))
#  
#      lines(yt,bt,col=cols[j], lwd=2)
#    }
#  axis(side = 4)
#  mtext(side = 4, line = 3, 'Basal area (m^2/ha)')
#  legend("topright", plots, text.col=cols, bty='n')
#  dev.off()
#  
#  
#  
#  formulaFec <- formulaRep <- as.formula( ~ I(log(diam)) )   # fecundity model
#  
#  inputs   <- list(specNames = specNames, seedNames = seedNames,
#                   treeData = treeData, seedData = seedData, xytree = xytree,
#                   xytrap = xytrap, priorDist = 15, priorVDist = 5, minDist = 8,
#                   maxDist = 30, sigmaMu = 1, minDiam = 5, maxDiam = 60)
#  output <- mastif( formulaFec, formulaRep, inputs = inputs,  ng = 1500,
#                    burnin = 500 )
#  predList <- list( mapMeters = 10, plots ='DF_BW', years = 1999:2015 )
#  output <- mastif( inputs = output, ng = 2500, burnin = 500,
#                    predList = predList )
#  
#  # map plots
#  mapList <- list( treeData = treeData, seedData = seedData,
#                   specNames = specNames, seedNames = seedNames,
#                   xytree = xytree, xytrap = xytrap)
#  
#  for(j in 1999:2015){
#    file <- paste('mapAlianthus_',j,'.pdf',sep='')
#    pdf( file=file, width=4, height=5 )
#    seedMax <- 10
#    mastMap(mapList = output, mapPlot = 'DF_BW', PREDICT=T, MAPTRAPS=F,
#            mapYears = j,  scaleTree = 1, scaleTrap = .5, seedMax = seedMax,
#            LEGEND=F, SCALEBAR=F, scaleValue=50, COLORSCALE = F,
#            scalePlot = 5)
#    dev.off()
#  }
#  
#  # hemlock decline
#  
#  
#  

## ----map21, eval=F-------------------------------------------------------
#  library(repmis)
#  d <- "https://github.com/jimclarkatduke/mast/blob/master/mast_liri.Rdata?raw=True"
#  source_data(d)
#  mapList <- list( treeData = treeData, seedData = seedData,
#                   specNames = specNames, seedNames = seedNames,
#                   xytree = xytree, xytrap = xytrap)
#  mastMap(mapList, mapPlot = 'DF_HW', mapYear = 2011:2014,
#          treeSymbol = treeData$diam, scaleTree = 1, scaleTrap=.7,
#          SCALEBAR=T, scaleValue=50)

## ----litu1, eval=F-------------------------------------------------------
#  head(treeData, 3)

## ----litu2, eval=F-------------------------------------------------------
#  head(seedData, 3)

## ----fit, eval=F---------------------------------------------------------
#  formulaFec <- as.formula( ~ canopy + I(log(diam)) )   # fecundity model
#  formulaRep <- as.formula( ~ I(log(diam)) )            # maturation model
#  
#  inputs   <- list(specNames = specNames, seedNames = seedNames,
#                   treeData = treeData, seedData = seedData, xytree = xytree,
#                   xytrap = xytrap, priorDist = 12, priorVDist = 5, minDist = 8,
#                   maxDist = 30, sigmaMu = 1, minDiam = 10, maxDiam = 60)
#  output <- mastif( formulaFec, formulaRep, inputs = inputs,  ng = 1500,
#                    burnin = 500 )

## ----more, eval=F--------------------------------------------------------
#  predList <- list( mapMeters = 10, plots = 'DF_HW', years = 2010:2015 )
#  output <- mastif( inputs = output, ng = 4000, burnin = 1500, predList = predList )

## ----plotmydata1, eval=F-------------------------------------------------
#  mastPlot(output)

## ----outpars, eval=F-----------------------------------------------------
#  summary( output )

## ----fitSum, eval=F------------------------------------------------------
#  output$fit

## ----ranEff0, eval=F-----------------------------------------------------
#  randomEffect <- list(randGroups = 'tree',
#                       formulaRan = as.formula( ~ I(log(diam)) ) )

## ----reinit0, eval=F-----------------------------------------------------
#  treeData$lastFec <- output$inputs$treeData$lastFec
#  treeData$lastRep <- output$inputs$treeData$lastRep
#  inputs$treeData  <- treeData

## ----ranEff, eval=F------------------------------------------------------
#  randomEffect <- list(randGroups = 'tree',
#                       formulaRan = as.formula( ~ I(log(diam)) ) )
#  output <- mastif( formulaFec, formulaRep, inputs = inputs,
#                    ng = 2000, burnin = 1000,
#                    randomEffect = randomEffect )

## ----ranEff2, eval=F-----------------------------------------------------
#  output <- mastif( inputs = output, ng = 4000, burnin = 1000,
#                    randomEffect = randomEffect)
#  mastPlot(output)

## ----fitSum2, eval=F-----------------------------------------------------
#  output$fit

## ----regtab, eval=F------------------------------------------------------
#  with(treeData, colSums( table(treeID, region)) )

## ----newgr, eval=F-------------------------------------------------------
#  province <- rep('mtn',nrow(treeData))
#  province[treeData$region == 'DF'] <- 'piedmont'
#  treeData$province <- as.factor(province)

## ----yrpl, eval=F--------------------------------------------------------
#  yearEffect <- list(plotGroups = 'province')

## ----reinit, eval=F------------------------------------------------------
#  treeData$lastFec <- output$inputs$treeData$lastFec
#  treeData$lastRep <- output$inputs$treeData$lastRep
#  inputs$treeData  <- treeData

## ----fit3, eval=F--------------------------------------------------------
#  output <- mastif(formulaFec, formulaRep,  inputs = inputs, ng = 1500, burnin = 500,
#                 randomEffect = randomEffect, yearEffect = yearEffect)

## ----moreYR, eval=F------------------------------------------------------
#  predList <- list( mapMeters = 10, plots = 'DF_HW', years = 1998:2014 )
#  output <- mastif(inputs = output, predList = predList,
#                 randomEffect = randomEffect, yearEffect = yearEffect,
#                 ng = 3000, burnin = 1000)
#  mastPlot(output)

## ----map2, eval=F--------------------------------------------------------
#  d <- "https://github.com/jimclarkatduke/mast/blob/master/mast_pinu.Rdata?raw=True"
#  repmis::source_data(d)
#  
#  mapList <- list( treeData = treeData, seedData = seedData,
#                   specNames = specNames, seedNames = seedNames,
#                   xytree = xytree, xytrap = xytrap)
#  mastMap(mapList, mapPlot = 'DF_HW', mapYears = c(2004:2007),
#          treeSymbol = treeData$diam, scaleTree = .5, scaleTrap=.5,
#          scalePlot = 1.2, LEGEND=T)

## ----M1, eval = F--------------------------------------------------------
#  priorR <- mastRmatrix(specNames, seedNames, unknown = 'UNKN', unFraction = .8)

## ----M2, eval = F--------------------------------------------------------
#  mastRmatrix(specNames = c('this','that','neither'),
#       seedNames = c('this', 'that', 'whatEver'),
#       unknown = 'what', unFraction = .9)

## ----fit0, eval=F--------------------------------------------------------
#  formulaFec <- as.formula( ~ canopy + I(log(diam)) )   # fecundity model
#  formulaRep <- as.formula( ~ I(log(diam)) )            # maturation model
#  
#  yearEffect   <- list(specGroups = 'species', plotGroups = 'region', p = 5)
#  randomEffect <- list(randGroups = 'tree',
#                       formulaRan = as.formula( ~ I(log(diam)) ) )
#  
#  priorR <- mastRmatrix(specNames, seedNames, unknown = 'UNKN', unFraction = .9)
#  
#  #tmp <- read.table('traitTable.txt',header=T)
#  #seedMass <- tmp[match(specNames,tmp$code4),'gmPerSeed',drop=F]
#  
#  
#  
#  seedMass <- matrix( c(0.0170,0.0270,0.0167,0.0070,0.0080), ncol=1)
#  rownames(seedMass) <- c('pinuEchi','pinuRigi','pinuStro','pinuTaed','pinuVirg')
#  colnames(seedMass) <- 'gmPerSeed'
#  
#  
#  rownames(seedMass) <- specNames
#  
#  inputs   <- list( specNames = specNames, seedNames = seedNames,
#                    treeData = treeData, seedData = seedData,
#                    xytree = xytree, xytrap = xytrap, priorDist = 8,
#                    priorVDist = 2, priorR = priorR, priorRwt = priorR*5,
#                    minDist = 5, maxDist = 20, minDiam = 15, maxDiam = 40,
#                    maxF = 1e+8, seedMass = seedMass)
#  output <- mastif(formulaFec, formulaRep, inputs = inputs, ng = 500,
#                 burnin = 200, yearEffect = yearEffect,
#                 randomEffect = randomEffect)

## ----moreAR, eval=F------------------------------------------------------
#   output <- mastif(inputs = output, ng = 2000,
#                 burnin = 1000, yearEffect = yearEffect,
#                 randomEffect = randomEffect)
#  plotPars <- list(MAPS = F, SPACETIME=T, SAVEPLOTS=T)
#  mastPlot(output, plotPars = plotPars)

## ----moreYR2, eval=F-----------------------------------------------------
#  plots <- c('DF_EW','DF_BW','DF_HW','HF_ST')
#  years <- 1980:2025
#  predList <- list( mapMeters = 8, plots = plots, years = years )
#  output <- mastif(inputs = output, predList = predList, yearEffect = yearEffect,
#                 randomEffect = randomEffect, ng = 2000, burnin = 1000)

## ----yrPlot, eval=F------------------------------------------------------
#  mastPlot( output, plotPars = list(MAPS=F) )

## ----onemap, eval=F------------------------------------------------------
#  mastMap(output, mapPlot = 'DF_EW', mapYears = c(2011:2012),
#          PREDICT=T, scaleTree = 1, scaleTrap=.3, LEGEND=T, scaleValue=50,
#          scalePlot = 1.5, COLORSCALE = T, mfrow=c(2,1))

## ----onemap1, eval=F-----------------------------------------------------
#  mastMap(output, mapPlot = 'DF_EW', mapYears = 2014, PREDICT=T,
#          scaleTree = 1, scaleTrap=.3, LEGEND=T, scalePlot = 10,
#          SCALEBAR = T, COLORSCALE = T)

## ----outpars0, eval=F----------------------------------------------------
#  summary( output )

## ----experiments, echo=F, eval=F-----------------------------------------
#  rCons <- rMu[,1:2]
#  
#  rCons[,1] <- .9
#  rCons[,2] <- .1
#  rCons[4,1] <- .1
#  rCons[4,2] <- .1
#  
#  tmp <- getCvol(output, plot='DF_HW', rCons, npoints = 5, nyears = 5,
#                      sampleYears = 2003:2015, nrep = 50)
#  rCons
#  tmp$entropy
#  C <- tmp$C
#  index <- tmp$index
#  
#  library(corrplot)
#  
#  #C[upper.tri(C)] <- NA
#  ccor <- cov2cor(C)
#  
#  diag(ccor) <- min(ccor)
#  
#  clim <- range(ccor[lower.tri(ccor)])
#  clim[1] <- clim[1] - .0001
#  clim[2] <- clim[2] + .0001
#  
#  col1 <- colorRampPalette(c("white","white","white","white","white",
#                             "white","white",
#                             "white", "yellow", "red"))
#  
#  corrplot(ccor, method='square',  cl.lim = clim, is.cor=F, col = col1(20),
#           cl.length=21,
#           diag = F, type = 'lower', addgrid.col=NA, tl.pos = 'n')

## ----nopred, eval=F------------------------------------------------------
#  d <- "https://github.com/jimclarkatduke/mast/blob/master/mast_liri.Rdata?raw=True"
#  repmis::source_data(d)
#  
#  formulaFec   <- as.formula(~ 1)
#  formulaRep   <- as.formula( ~ I(log(diam)) )
#  yearEffect   <- list(specGroups = 'species', plotGroups = 'region')
#  randomEffect <- list(randGroups = 'treeID',
#                       formulaRan = as.formula( ~ 1 ) )
#  inputs <- list(specNames = specNames, seedNames = seedNames,
#                 treeData = treeData, seedData = seedData,
#                 xytree = xytree, xytrap = xytrap,
#                 priorDist = 10, priorVDist = 5, maxDist = 50, minDist = 5,
#                 minDiam = 25, maxF = 1e+6)
#  output <- mastif(inputs, formulaFec, formulaRep, ng = 4000, burnin = 1500,
#                 randomEffect = randomEffect, yearEffect = yearEffect )
#  mastPlot(output)

## ----land, eval=F, echo=F------------------------------------------------
#  
#  # rank distances from random locations in a plot:
#  
#  wj <- which( as.character(xytree$plot) == 'DF_EW' )
#  xy <- xytree[wj, c('x','y')]
#  lims <- apply(xy,2,range)
#  
#  nsite <- 50
#  x <- runif(nsite, lims[1,1],lims[2,1])
#  y <- runif(nsite, lims[1,2],lims[2,2])
#  xysite <- cbind(x,y)
#  colnames(xysite) <- c('x','y')
#  
#  tmp <- rankNeighbors(xy, xysite, dr = 1, nrank=10)
#  rmat <- tmp$rmat
#  mh   <- tmp$mh
#  breaks <- tmp$breaks
#  
#  par(mfrow=c(1,1), bty='n')
#  
#  plot(breaks, rmat[1,], type='s', lwd=2)
#  
#  for(k in 1:nrow(rmat)){
#    lines(breaks, rmat[k,], type='s', col=.getColor('black',1/k))
#  }
#  plot(breaks, mh, type='s')
#  
#  upar <- 15
#  f    <- 10000
#  kern <- t(upar/pi/(upar + breaks^2)^2)
#  elam <- f*sum(kern*mh)
#  vlam <- f^2*sum(mh^2*kern) - elam^2

