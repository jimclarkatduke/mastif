## ----outform, echo=F-----------------------------------------------------
bigskip <- function(){
    "<br>"
}

## ----getFiles, eval = F, echo=F------------------------------------------
#  Rcpp::sourceCpp('../RcppFunctions/cppFns.cpp')
#  source('../RFunctions/mastfunctions.r')

## ----simSetup0, eval = F-------------------------------------------------
#  specNames <- seedNames <- 'larry'
#  inputs <- list(nyr=10, ntree=20, nplot=2, ntrap=50,
#                 specNames = specNames, seedNames = seedNames)

## ----sim0, eval = F------------------------------------------------------
#  f <- mastSim(inputs)     # simulate dispersal data
#  seedData   <- f$seedData     # year, plot, trap, seed counts
#  trueValues <- f$trueValues   # true states and parameter values
#  treeData   <- f$treeData     # year, plot, tree data
#  distall    <- f$distall      # trap by tree distances
#  xytree     <- f$xytree       # tree locations
#  xytrap     <- f$xytrap       # trap locations
#  formulaFec <- f$formulaFec   # fecundity model
#  formulaRep <- f$formulaRep   # maturation model
#  years      <- f$years        # years by plot
#  tables     <- f$sample       # summaries

## ----formulaFec, eval = F------------------------------------------------
#  formulaFec

## ----treeData0, eval = F-------------------------------------------------
#  head(treeData)

## ----xytree, eval = F----------------------------------------------------
#  head(xytree, 5)

## ----treeData1, eval = F-------------------------------------------------
#  head(seedData)

## ----tab, eval = F-------------------------------------------------------
#  knitr::kable(tables[[1]])

## ----stab, eval = F------------------------------------------------------
#  knitr::kable(tables[[2]])

## ----map1, eval = F------------------------------------------------------
#  years <- colnames(tables$trees)
#  if(length(years) > 4)years <- years[1:4]
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              treeSymbol=trueValues$fMat, plots = 'p1', years = years, scaleTree=150,
#              scaleTrap = 150)

## ----hist0, eval = F-----------------------------------------------------
#  par( mfrow=c(2,1),bty='n', mar=c(3,3,2,1) )
#  hist( as.matrix(seedData[,seedNames]) ,nclass=100, main='seed count' )
#  hist( trueValues$fMat,nclass=100, main = 'fecundity' )

## ----mast2, eval = F-----------------------------------------------------
#  init   <- list(ng = 10000, burnin = 5000)
#  output <- mast(formulaFec, formulaRep, specNames, seedNames, treeData,
#                     seedData, xytree, xytrap, init)

## ----tabPars0, eval = F--------------------------------------------------
#  summary( output )

## ----pars, eval = F------------------------------------------------------
#  plotPars <- list(trueValues = trueValues)
#  mastPlot(output, plotPars)

## ----mapout, eval = F----------------------------------------------------
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              trueValues$fMat, plots = 'p1')

## ----pmap, eval = F------------------------------------------------------
#  plotyr <- table( treeData$plot, treeData$year )
#  w    <- which(plotyr > 0, arr.ind=T)[1,]
#  plot <- rownames(plotyr)[w[1]]
#  year <- as.numeric( colnames(plotyr)[w[2]] )
#  pmap <- mastPredict(output, plot = plot, year = year,
#                          nsim = 500, ngrid=30, PLOT=T)      # new map

## ----newmap, eval = F----------------------------------------------------
#  mastMap(treeData, seedData, specNames, seedNames, f$xytree, f$xytrap,
#              treeSymbol=trueValues$fMat, plots = plot, years = year,
#              predict=pmap, scaleTree=20, scaleTrap = 20)

## ----simSetup, eval = F--------------------------------------------------
#  specNames <- c('stoogeLarry','stoogeCurly','stoogeMoe')
#  seedNames <- c('stoogeLarry','stoogeUNKN')
#  inputs    <- list(nyr=10, ntree=20, nplot=2,
#                    ntrap=50, distance = 20, Q=2, specNames = specNames,
#                    seedNames = seedNames)

## ----sim, eval = F-------------------------------------------------------
#  f <- mastSim(inputs)         # simulate dispersal data
#  seedData   <- f$seedData     # year, plot, trap, seed counts
#  trueValues <- f$trueValues   # true states and parameter values
#  treeData   <- f$treeData     # year, plot, tree data
#  distall    <- f$distall      # trap by tree distances
#  xytree     <- f$xytree       # tree locations
#  xytrap     <- f$xytrap       # trap locations
#  formulaFec <- f$formulaFec   # fecundity model
#  formulaRep <- f$formulaRep   # maturation model
#  tables     <- f$sample       # summary
#  years      <- f$years        # years by plot
#  M          <- f$trueValues$M # species to seedNames probability matrix

## ----M, eval = F---------------------------------------------------------
#  M

## ----mast3, eval = F-----------------------------------------------------
#  init <- list(ng = 5000, burnin = 2000, priorM = M, priorMwt = M*2,
#               priorDist = 20, priorVDist = 10, maxF = 1e+10)
#  output <- mast(formulaFec, formulaRep, specNames, seedNames, treeData,
#                     seedData, xytree, xytrap, init)

## ----tabPars, eval = F---------------------------------------------------
#  summary( output )

## ----pars0, eval = F-----------------------------------------------------
#  plotPars <- list(trueValues = trueValues)
#  mastPlot(output, plotPars)

## ----readDF, eval=F, echo=F----------------------------------------------
#  
#  years       <- 1991:2017
#  
#  genera <- c('abie','acer','aila','amel','betu','carp','cary','celt','cerc','chio',
#              'corn','fagu','frax','ilex','juni','liqu','liri',
#              'magn','moru','nyss','ostr','oxyd','pice','pinu','prun','quer',
#              'robi','sass','sorb','tili','tsug','ulmu')
#  
#  omitNames   <- c('abieFras_fruit','acerIMMA','pinuUNKN_fruit','liriTuli_flower',
#                   'betuUNKN_flower','caryIMMA',
#                   'cornIMMA','acerRubr_flower',' betuUNKN_flower','betuUNKN_fruit',
#                   'nyssIMMA','oxydArbo_flower','oxydIMMA','pinuImma_fruit',
#                   'piceRube_fruit','piceRubeIMMA','pinuStro_fruit',
#                   'querIMMA','tiliAmer_flower')
#  changeNames <- rbind( cbind('ulmuUNKN','ulmuAlat'),
#                        cbind('acerUNKN','acerRubr'),
#                        cbind('acerrubr','acerRubr'))
#  colnames(changeNames) <- c('from','to')
#  
#  #genusName   <- 'abie'
#  
#  treeID      <- 'ID'
#  yrCols      <- c('diam','canopy')
#  treeStart   <- 'censinyr'
#  treeEnd     <- c('deathyr','censoryr')
#  x           <- 'x'
#  y           <- 'y'
#  
#  trapCols <- c("plot","trapID","trap","x","y","UTMx","UTMy","elev")
#  
#  trapID <- 'trapnum'
#  
#  path  <- "../dataFiles/"
#  plots <- c('CW_118', 'CW_218', 'CW_318', 'CW_427', 'CW_527', 'CW_LG','CW_UG',
#             'MH_F','MH_P','DF_HW', 'DF_EW', 'DF_BW','DF_EE',
#             'GSNP_PK', 'GSNP_CD', 'GSNP_ND','HF_S', 'HF_BW')
#  
#  #plots    <- list.files(paste0(path, 'trees/', sep=''))
#  #treeFile <- plots[ grep('active',plots) ]
#  #locFile  <- plots[ grep('UTM',plots) ]
#  
#  sfiles    <- list.files(paste0(path, 'seeds/', sep=''))
#  seedFile <- sfiles[ grep('active',sfiles) ]
#  locFile  <- sfiles[ grep('UTM',sfiles) ]
#  
#  plots <- unlist( strsplit(plots, "_active.txt") )
#  
#  seedFile <- paste0(path, 'seeds/', plots, '_active.txt', sep='')
#  locFile  <- paste0(path, 'seeds/', plots, '_UTM.txt', sep='')
#  treeFile <- paste0(path, 'trees/', plots, '_active.txt', sep='')
#  
#  # seed year for 2014 is June 2014 to June 2015
#  # idCols <- c('trapnum','month','day','year')
#  
#  #outSeeds <- paste(path, 'seeds/', plots, 'SeedData.txt', sep='')
#  
#  for(i in 1:length(genera)){
#  
#    genusName <- genera[i]
#  
#    seedData <- xytrap <- numeric(0)
#    plotAll <- seedNames <- character(0)
#  
#    treeData <- xytree <- numeric(0)
#    seedcols <- numeric(0)
#    seedData <- character(0)
#  
#    for(j in 1:length(plots)){
#  
#      tfile <- treeFile[grep(plots[j],treeFile)]
#      sfile <- seedFile[grep(plots[j],seedFile)]
#      lfile <- locFile[grep(plots[j],locFile)]
#  
#      tmp    <- .treeFormat( tfile, genusName = genusName, changeNames = changeNames,
#                             plot = plots[j],
#                             years = years, yrCols = yrCols  )
#      yrDat  <- tmp$yrDat
#      xyt    <- tmp$xytree
#      if(length(yrDat) == 0)next
#  
#      tmp <- .seedFormat(sfile, lfile, trapFile = '../dataFiles/seedTrapArea.txt',
#                         genusName = genusName, omitNames = omitNames,
#                         plot = plots[j], trapID = trapID )
#      if(length(tmp) == 0)next
#  
#      seedNames <- sort(unique(c(seedNames, tmp$seedNames)))
#      xyseed   <- tmp$xy
#      #  if(length(xytrap) > 0)xyseed   <- tmp$xy[,colnames(xytrap)]
#      xytrap   <- rbind( xytrap, xyseed[,trapCols] )
#  
#      seedj  <- tmp$counts
#      wcol <- sapply(seedj, is.numeric)
#      counts <- as.matrix( tmp$counts[,which(wcol), drop=F] )
#  
#  
#      seedData <- .appendMatrix(seedData, counts, fill=0)
#      seedcols <- rbind(seedcols, seedj[,which(!wcol)])
#  
#      yrDat <- yrDat[yrDat$year %in% seedj$year,]
#      xyt   <- xyt[xyt$treeID %in% yrDat$treeID,]
#  
#      treeData <- rbind(treeData, yrDat)
#      xytree   <- rbind(xytree, xyt)
#  
#    }
#  
#    plotj <- plots[plots %in% seedcols[,'plot']]
#  
#    ws <- which( colSums(seedData[,seedNames, drop=F]) == 0 )
#    if(length(ws) > 0){
#      seedData <- seedData[,!colnames(seedData) %in% names(ws), drop=F]
#      seedNames <- seedNames[!seedNames %in% names(ws)]
#    }
#  
#    seedData <- data.frame(seedcols, seedData)
#    specNames <- attr( treeData$species, 'levels')
#  
#    treeData <- treeData[treeData$year %in% seedData$year,]
#    seedData <- seedData[seedData$year %in% treeData$year,]
#    xytree   <- xytree[xytree$treeID %in% treeData$treeID,]
#  
#    # reproduction prior, probit scale
#  
#    repMu <- (treeData$diam - 30)/sd( treeData$diam, na.rm=T )
#    repSd <- sqrt(1 + treeData$diam*( max( treeData$diam, na.rm=T ) - treeData$diam ) )
#  
#    treeData$repr[treeData$diam < 8] <- 0
#    treeData$repr[treeData$diam > 30 & treeData$canopy > 0] <- 1
#    treeData$repr[treeData$diam > 40] <- 1
#  
#    treeData$repMu <- signif(repMu, 3)
#    treeData$repSd <- signif(repSd, 3)
#  
#    treeData$canopy <- jitter(treeData$canopy)
#  
#    #M <- .getM(specNames, seedNames, unknown = 'UNKN', unFraction = .9)
#  
#    treeData <- treeData[,c("plot","treeID","tree","species","year","region",
#                            "repr","diam","canopy","growth")]
#    seedData <- seedData[,c("plot","trapID","trap","year","active","area",seedNames)]
#  
#    xytree <- xytree[,c('tree','treeID','plot','x','y','UTMx','UTMy','elev')]
#    xytrap <- xytrap[,c('trap','trapID','plot','x','y','UTMx','UTMy','elev')]
#  
#    wc <- which(colnames(xytree) %in% c('x','y','UTMx','UTMy'))
#    colnames(xytree)[wc] <- c('xplot','yplot','x','y')
#    colnames(xytrap)[wc] <- c('xplot','yplot','x','y')
#  
#    treeData[,c('diam','canopy','growth')] <- round(treeData[,c('diam','canopy','growth')], 2)
#  
#    save(treeData, seedData, specNames, seedNames,
#         xytree, xytrap, plotj, years, # M,
#         file=paste('../compressedFiles/', genusName,'.Rdata',sep='') )
#  
#    print(seedNames)
#  
#  }
#  

## ----map21, eval=F-------------------------------------------------------
#  library(repmis)
#  d <- "https://github.com/jimclarkatduke/mast/blob/master/mast_liri.Rdata?raw=True"
#  source_data(d)
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              treeSymbol = treeData$diam, plots = 'DF_HW', years = 2013,
#              scaleTree = 5, scaleTrap=10)

## ----litu1, eval=F-------------------------------------------------------
#  head(treeData, 3)

## ----litu2, eval=F-------------------------------------------------------
#  head(seedData, 3)

## ----fit, eval=F---------------------------------------------------------
#  
#  formulaFec <- as.formula( ~ growth + I(log(diam)) )   # fecundity model
#  formulaRep <- as.formula( ~ I(log(diam)) )            # maturation model
#  
#  init   <- list(ng = 5000, burnin = 2000)
#  output <- mast(formulaFec, formulaRep, specNames, seedNames, treeData,
#                  seedData, xytree, xytrap, init)

## ----plotmydata1, eval=F-------------------------------------------------
#  mastPlot(output)

## ----outpars, eval=F-----------------------------------------------------
#  summary( output )

## ----lituprior, eval=F---------------------------------------------------
#  
#  betaPrior <- list(pos = 'I(log(diam))', neg='intercept' )
#  init      <- list(ng = 5000, burnin = 2000, betaPrior = betaPrior)
#  output    <- mast(formulaFec, formulaRep, specNames, seedNames, treeData,
#                  seedData, xytree, xytrap, init)
#  mastPlot(output)

## ----map2, eval=F--------------------------------------------------------
#  d <- "https://github.com/jimclarkatduke/mast/blob/master/mast_pinu.Rdata?raw=True"
#  source_data(d)
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              treeSymbol = treeData$diam, plots = plots, years = 2012:2013,
#              scaleTree = .7, scaleTrap=1.2)

## ----maphere, eval=F-----------------------------------------------------
#  # one plot-year
#  graphics.off()
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              treeSymbol = treeData$diam, plots = c('DF_EW','DF_HW'), years = 2012,
#              scaleTree = 1.5, scaleTrap=5)

## ----yrpl, eval=F--------------------------------------------------------
#  yearEffect <- list(specGroups = 'species')

## ----yrpl1, eval=F-------------------------------------------------------
#  yearEffect <- list(specGroups = 'species', plotGroups = 'region')

## ----M1, eval = F--------------------------------------------------------
#  getM <- function(specNames, seedNames, unknown = 'UNKN', unFraction = .8){
#  
#    # unknown    - indicates seedNames for unknowns
#    # unFraction - prior fraction of seed to unknown
#  
#    if(length(specNames) > 1 | length(seedNames) > 1){
#  
#      M <- matrix(0, length(specNames), length(seedNames),
#                  dimnames=list(specNames, seedNames))
#      notun  <- rep(1 - unFraction, nrow(M))
#      wu     <- grep(unknown, seedNames)
#      M[,wu] <- unFraction
#  
#      wm <- which(rownames(M) %in% colnames(M))
#      M[ cbind( match(rownames(M)[wm], colnames(M)), wm) ] <- notun[wm]
#      M <- sweep(M, 1, rowSums(M), '/')
#      return(M)
#    }
#    matrix(1)
#  }

## ----M2, eval = F--------------------------------------------------------
#  getM(specNames = c('this','that','neither'),
#       seedNames = c('this', 'that', 'whatEver'),
#       unknown = 'what', unFraction = .9)

## ----fit0, eval=F--------------------------------------------------------
#  
#  formulaFec <- as.formula( ~ growth + I(log(diam)) )   # fecundity model
#  formulaRep <- as.formula( ~ I(log(diam)) )            # maturation model
#  
#  M <- getM(specNames, seedNames, unknown = 'UNKN', unFraction = .9) #species to seeds
#  yearEffect   <- list(specGroups = 'species', plotGroups = 'region')
#  randomEffect <- list(randGroups = 'treeID', formulaRan = as.formula( ~ I(log(diam)) ) )
#  
#  init <- list(ng = 15000, burnin = 5000, priorM = M, priorMwt = M*2,
#               priorDist = 20, priorVDist = 5, maxDist = 40, minDist = 3,
#               minDiam = 10,
#               maxF = 1e+9, randomEffect = randomEffect,
#               yearEffect = yearEffect)
#  output <- mast(formulaFec, formulaRep, specNames, seedNames, treeData,
#                  seedData, xytree, xytrap, init)

## ----plotmydata0, eval=F-------------------------------------------------
#  mastPlot(output)

## ----outpars0, eval=F----------------------------------------------------
#  summary( output )

## ----newnames, eval=F----------------------------------------------------
#  treeData  <- output$inputs$treeData
#  seedData  <- output$inputs$seedData
#  specNames <- output$inputs$specNames
#  seedNames <- output$inputs$seedNames
#  xytree    <- output$inputs$xytree
#  xytrap    <- output$inputs$xytrap

## ----map3, eval=F--------------------------------------------------------
#  fmu <- output$prediction$fecMu
#  
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              treeSymbol = fmu, plots = 'DF_EW', years = 2013,
#              scaleTree = 1, scaleTrap = 5)

## ----pred2, eval=F-------------------------------------------------------
#  predVars <- list(species = specNames, diam = 'gradient')
#  pmap     <- mastPredict(output, plot = 'DF_EW', year = 2014,
#                              nsim = 500, predVars = predVars)

## ----pmap3, eval=F-------------------------------------------------------
#  plot <- 'DF_EW'
#  year <- 2012
#  xytree <- output$inputs$xytree
#  xytrap <- output$inputs$xytrap
#  newdata <- list(treeData = output$inputs$treeData[treeData$plot == plot &
#                                                      treeData$year == year,],
#                  xytree = xytree[xytree$plot == plot,],
#                  xytrap = xytrap[xytrap$plot == plot,],
#                  xlim = range(xytrap$x), ylim = range(xytrap$y))
#  
#  pmap <- mastPredict(output, newdata = newdata, plot = plot, year = year,
#                         nsim = 500, ngrid=50, PLOT=T)

## ----pmap4, eval=F-------------------------------------------------------
#  
#  mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap,
#              plots = plot, years = year,
#              scaleTree = 1, scaleTrap = 1, predict=pmap, mapPred='CV')

