#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* .Call calls */
extern SEXP mast_kernYrRcpp(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP mast_byRcpp(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP mast_trMVNmatrixRcpp(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP mast_tnormRcpp(SEXP, SEXP, SEXP, SEXP);
extern SEXP mast_betaRcpp(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP mast_randEffectRcpp(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP mast_solveRcpp(SEXP);
extern SEXP mast_rmvnormRcpp(SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
  {"mast_kernYrRcpp",       (DL_FUNC) &mast_kernYrRcpp,      8},
  {"mast_byRcpp",           (DL_FUNC) &mast_byRcpp,          6},
  {"mast_trMVNmatrixRcpp",  (DL_FUNC) &mast_trMVNmatrixRcpp, 7},
  {"mast_tnormRcpp",        (DL_FUNC) &mast_tnormRcpp,       4},
  {"mast_betaRcpp",         (DL_FUNC) &mast_betaRcpp,        5},
  {"mast_randEffectRcpp",   (DL_FUNC) &mast_randEffectRcpp,  6},
  {"mast_solveRcpp",        (DL_FUNC) &mast_solveRcpp,       1},
  {"mast_rmvnormRcpp",      (DL_FUNC) &mast_rmvnormRcpp,     3},
	{NULL, NULL, 0}
};

void R_init_mast(DllInfo *dll) {
	R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
	R_useDynamicSymbols(dll, FALSE);
}
