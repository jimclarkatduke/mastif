
.propZ <- function(znow, last0first1, matYr){
  
  # repr - known repr from treeData
  # random walk proposal
  
  new <- matYr + sample( c(-1:1), nrow(znow), replace=T)
  
  new[last0first1[,'all0'] == 1] <- 0
  new[last0first1[,'all1'] == 1] <- ncol(znow) + 1
  
  ww  <- which(new < last0first1[,1])
  new[ww] <- last0first1[ww,1]
  
  ww  <- which(new > last0first1[,2])
  new[ww] <- last0first1[ww,2]
  
  down <- which(new < matYr & new > 0)
  znow[ cbind(down,new[down]) ] <- 1   # advance 1 year
  
  up <- which(new > matYr & new < ncol(znow))
  znow[ cbind(up,matYr[up]) ] <- 0     # delay 1 year
  
  znow[last0first1[,'all0'] == 1, ] <- 0
  znow[last0first1[,'all1'] == 1, ] <- 1
  
  list(zmat = znow, matYr = new)
}

.setupYear <- function(yearEffect, treeData, years){
  
  specNames <- NULL
  
  yrnames <- names(yearEffect)
  mcol    <- unlist(yearEffect)
  yeGroup <- treeData[,mcol]
  if(length(mcol) > 1){
    if(length(mcol) > 2)stop('only two groups available for yearEffects')
    cy <- cbind(as.character(yeGroup[,1]),as.character(yeGroup[,2]))
    yeGroup <- apply( cy, 1, paste0, collapse='-')
  }
  yeGr   <- sort(unique(yeGroup))      
  ygr    <- match(yeGroup, yeGr)
  yyr    <- match(treeData$year,years)
  yrindex <- cbind(ygr, yyr)
  colnames(yrindex) <- c('group','year')
  
  betaYr  <- matrix(0, length(yeGr), length(years))
  rownames(betaYr) <- yeGr
  colnames(betaYr) <- years
  
  betaYr <- .myBy(ygr*0+1, yrindex[,1], yrindex[,2], fun='sum')
  rownames(betaYr) <- yeGr
  colnames(betaYr) <- years
  
  print(betaYr)
  
  # reference class removed if specGroups are species
  yeRef <- yeGr
  dash <- grep('-', yeGr)
  if(length(dash) > 0){
    yeRef <- matrix( unlist(strsplit(yeGr,'-')), ncol=2,byrow=T) 
    wr    <- match(yeRef[,1],specNames)
    yeRef <- yeGr[ !duplicated(wr)  ]
  }
  betaYr <- betaYr*0
  list(betaYr = betaYr, yrRef = yeGr, yrindex = yrindex, yeGr = yeGr)
}


mastPlot <- function(output, plotPars = NULL){
  
  SAVEPLOTS <- F
  seedNames <- specNames <- M <- formulaFec <- formulaRep <- xfec <- xrep <-
    treeData <- seedData <- xytree <- xytrap <- distall <- ng <- burnin <- nplot <-
    ntree <- ntrap <- nyr <- maxF <- bfec <- brep <- upar <- mgibbs <- 
    betaFec <- betaRep <- mMu <- mSe <- usigma <- fecMu <- fecSe <- matrMu <- 
    seedMu <- seedSe <- inputs <- chains <- parameters <- predictions <- 
    trueValues <- betaYrMu <- betaYrSe <- betaYrMu <- betaYrSe <- 
    prediction <- NULL
  randGroups <- formulaRan <- rnGroups <- reIndex <- xrandCols <- NULL  
  specGroups <- plotGroups <- yrindex <- randomEffect <- yearEffect <- NULL
  YR <- RANDOM <- TV <- SAMPM <- F
  outFolder <- 'mastPlots'
  
  for(k in 1:length(output))assign( names(output)[k], output[[k]] )
  for(k in 1:length(inputs))assign( names(inputs)[k], inputs[[k]] )
  for(k in 1:length(chains))assign( names(chains)[k], chains[[k]] )
  for(k in 1:length(parameters))assign( names(parameters)[k], parameters[[k]] )
  for(k in 1:length(prediction))assign( names(prediction)[k], prediction[[k]] )
  if(!is.null(plotPars)){
    for(k in 1:length(plotPars))assign( names(plotPars)[k], plotPars[[k]] )
    if( 'trueValues' %in% names(plotPars) ){
      TV <- T
      for(k in 1:length(trueValues))assign( names(trueValues)[k], trueValues[[k]] )
    }
  }
  if('mgibbs' %in% names(output$chains))SAMPM <- T
  if('randomEffect' %in% names(output$inputs)){
    RANDOM <- T
    for(k in 1:length(randomEffect))assign( names(randomEffect)[k], randomEffect[[k]] )
  }
  if('yearEffect' %in% names(output$inputs)){
    YR <- T
    for(k in 1:length(yearEffect))assign( names(yearEffect)[k], yearEffect[[k]] )
  }
  nspec <- length(specNames)
  
  if(SAVEPLOTS){
    ff <- file.exists(outFolder)
    if(!ff)dir.create(outFolder)
  }
  
  ########### MCMC chains
  
  .chainPlot(chains$bfec, burnin, 'fecundity parameters', SAVEPLOTS, outFolder)
  
  .chainPlot(chains$brep, burnin, 'maturation parameters', SAVEPLOTS, outFolder)
  
  .chainPlot(chains$ugibbs, burnin, 'variances, dispersal', SAVEPLOTS, outFolder)
  
  if(SAMPM){
    mg <- chains$mgibbs
    wc <- which(apply(mg, 2, FUN=sum) > 0)
    
    .chainPlot(mg[,wc,drop=F], burnin, 'species -> seed type', SAVEPLOTS, outFolder)
  }
  
  if(RANDOM){
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'chainsREvariance.pdf') )
    
    aMu <- parameters$aMu
    att <- aMu*0
    diag(att) <- 1
    wc <- which(att == 1)
    
    .chainPlot(chains$agibbs[,wc], burnin, 
               'random effects variance', SAVEPLOTS, outFolder)
  }
  
  ########### coefficients

  if(SAVEPLOTS)pdf( file=.outFile(outFolder,'fecundityCoeffs.pdf') )
  
  par(mfrow=c(2,1), mar=c(2,5,2,.1), bty='n')
  .boxCoeffs(chains$bfec[burnin:ng,], specNames, xlab = 'Fecundity')
  
  .boxCoeffs(chains$brep[burnin:ng,], specNames, xlab = 'Maturation')
  
  if(!SAVEPLOTS){
    readline('fecundity, maturation -- return to continue ')
  } else {
    dev.off( )
  }
  
  ########### random coefficients
  
  if(RANDOM){
    
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'randomCoeffs.pdf') )
    
    xrandCols  <- output$inputs$randomEffect$xrandCols
    formulaRan <- output$inputs$randomEffect$formulaRan
    
    betaFec <- parameters$betaFec[,1]
    alphaMu <- parameters$alphaMu
    intercept <- paste('species',specNames,sep='')
    slopes    <- names(xrandCols)[!names(xrandCols) %in% intercept]
    slopeLab  <- matrix( unlist( strsplit( slopes, ':')), ncol=2,byrow=T)[,2]
    
    nplot <- length(slopes)/length(intercept)
    
    mfrow <- c(1,1)
    if(nplot > 1)mfrow <- c(2,2)
    
    par(mfrow=mfrow, bty='n', mar=c(4,4,1,1))
    
    icol <- match(intercept, colnames(alphaMu))
    jcol <- match(slopes, colnames(alphaMu))
    
    xlim <- range(betaFec[icol] + alphaMu[,icol])
    ylim <- range(betaFec[jcol] + alphaMu[,jcol])
    
    
    plot(betaFec[icol],betaFec[jcol],col=.getColor(1:length(specNames),.7), 
         xlim=xlim, ylim=ylim, cex=.5, xlab='intercept',ylab=slopeLab[1])
    abline(h = 0, lwd=2, lty=2, col='grey')
    abline(v = 0, lwd=2, lty=2, col='grey')
    
    for(s in 1:length(specNames)){
      points(betaFec[icol[s]] + alphaMu[,icol[s]],
             betaFec[jcol[s]] + alphaMu[,jcol[s]],
           col=.getColor(s,.3), pch=16, cex=.6)
    }
    legend('topright', specNames, text.col = 1:length(specNames),bty='n')
    
    if(!SAVEPLOTS){
      readline('random effects -- return to continue ')
    } else {
      dev.off( )
    }
  }
  
  ########### predicted seed counts, true fecundity
  
  if(SAVEPLOTS)pdf( file=.outFile(outFolder,'seedPrediction.pdf') )
  
  xs <- as.matrix(seedData[,seedNames])
  ys <- seedMu
  ys <- ys[xs > 0]
  xs <- xs[xs > 0]
  nPerBin <- length(xs)/50
  ylim <- range(ys)
  ylim[1] <- max(c(ylim[1],.1), na.rm=T)
  
  mfrow <- c(1,1)
  if(TV)mfrow <- c(1,2)
  
  par(mfrow=mfrow, mar=c(4,4,2,1), bty='n')
  .plotObsPred(xs, ys, nPerBin=nPerBin, log=T, xlabel='Observed',
               ylabel='Predicted', col='brown', ylimit=ylim)
  .plotLabel('a) Seed prediction', above=T, cex=.8)
  abline(0,1,lty=2)
  
  if(TV){
    ylim <- range(prediction$fecMu[prediction$fecMu > 1])
    ylim[1] <- max(c(ylim[1],1))
    
    .plotObsPred(trueValues$fMat,prediction$fecMu, ylimit = ylim,
                 nPerBin=20, log=T, xlabel='True values', 
                 ylabel='Estimates', col='brown')
    .plotLabel('a) Fecundity prediction', above=T, cex=.8)
    abline(0,1,lty=2)
  }
  if(!SAVEPLOTS){
    readline('Prediction -- return to continue ')
  } else {
    dev.off( )
  }
  
  # true parameter values
  
  if(TV){
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,'trueParameters.pdf') )
    
    par(mfrow=c(1,2),bty='n', mar=c(4,4,3,1))
    bfec <- output$parameters$betaFec
    brep <- output$parameters$betaRep
    plot( trueValues$betaFec, bfec[,1], ylim=range(bfec), 
          xlab='True value', ylab='Estimate', pch=3)
    abline(0,1, lwd=2, lty=2, col=.getColor('black',.4))
    segments( trueValues$betaFec, bfec[,3], betaFec, bfec[,4], lwd=2 )
    .plotLabel('a) Fecundity parameters', above=T, cex=.8)
    
    plot( trueValues$betaRep, brep[,1], ylim = range(brep), xlab='True value', 
          ylab=' ', pch=3)
    abline(0, 1, lwd=2, lty=2, col=.getColor('black',.4))
    segments( trueValues$betaRep, brep[,3], betaRep, brep[,4], lwd=2)
    .plotLabel('b) Maturation parameters', above=T, cex=.8)
    if(!SAVEPLOTS){
      readline('Parameter recovery -- return to continue ')
    } else {
      dev.off( )
    }
  }
  
  ############# fitted maps
  
  years  <- output$inputs$years
  nyears <- max(nyr)
  plots  <- output$inputs$plots
  stab   <- table(seedData$plot, seedData$year)
  
  graphics.off()
  
  for(m in 1:length(plots)){
    
    yrm <- years[ which(stab[m,] > 0) ]
    ny  <- length(yrm)
    
    k   <- 0
    add <- F
    o   <- 1:9
    o   <- o[o <= ny]
    
    while( max(o) <=  ny){
      
      file <- paste('map_',plots[m],'_',years[o[1]],'.pdf',sep='')
      
      if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
      
      mastMap(treeData, seedData, specNames, seedNames, xytree, xytrap, 
              treeSymbol=prediction$fecMu, plots = plots[m], years = yrm[o], 
                  scaleTree = .8, scaleTrap = 1)
      o <- o + 9
      o <- o[o <= ny]
      if(length(o) == 0)break
      
      if(!SAVEPLOTS){
        readline('y prediction -- return to continue ')
      } else {
        dev.off()
      }
    }  
  }
  
  ################# year effects
  
  if('betaYrMu' %in% names(parameters)){
    
    graphics.off()
    
    file <- paste('yearEffect.pdf',sep='')
    
    if(SAVEPLOTS)pdf( file=.outFile(outFolder,file) )
    
    YR <- T
    par(mfrow=c(1,1),bty='n', mar=c(5,4,2,4))
    
    yr <- as.numeric(colnames(betaYrMu))
    
    mr <- 2*max(betaYrMu + betaYrSe, na.rm=T)
    
    plot(NULL, xlim = range(yr), ylim = c(-mr,mr),
         xlab = ' ', ylab = 'log fecundity')
    abline(h = 0, lty=2, col='grey', lwd=2)
    leg <- character(0); col <- numeric(0)
    
    col <- numeric(0)
    
    for(j in 1:nrow(betaYrMu)){
      wj <- which(is.finite(betaYrMu[j,]))
      if(length(wj) < 3)next
      lines(yr[wj], betaYrMu[j,wj], col=j, lwd=2)
      loHi <- cbind( betaYrMu[j,wj] - 1.96*betaYrSe[j,wj],
                     betaYrMu[j,wj] + 1.96*betaYrSe[j,wj])
      .shadeInterval(yr[wj],loHi,col=j,PLOT=T,add=T, trans = .4)
      leg <- c(leg,rownames(betaYrMu)[j])
      col <- c(col,j)
    }
    legend('topleft', leg, text.col = col, 
           ncol = ceiling(length(col)/2),bty='n')
    
    s2p <- as.matrix( seedData[,seedNames] )
    s2p <- s2p%*%t(mMu)       # invert M
    
    par(new = T)
    ymax <- 2*max(sqrt(s2p))
    plot(jitter(seedData[,'year']),sqrt( s2p[,1]), cex=.8, axes=F,
         xlab='Year', ylim=c(0,ymax), ylab=NA, pch=16, col=.getColor(col[1],.4))
    if(nspec > 1){
      for(j in 2:nspec){
        points(jitter(seedData[,'year']),sqrt( s2p[,j]), cex=.6, 
       pch=16, col=.getColor(col[1],.4))
      }
    }
    ii <- match(seedData$year,years)
    ii <- rep(ii, ncol(s2p))
    jj <- rep(1, length=length(s2p))
    ssum <- .myBy(as.vector( sqrt(s2p) ), ii, jj, 
                   summat = matrix(0, length(years), 1), fun='sum')
    nsum <- .myBy(as.vector( s2p*0 + 1 ), ii, jj, 
                  summat = matrix(0, length(years), 1), fun='sum')
    
    sall <- ssum/nsum
    lines(years, sall, lwd=6, col='white')
    lines(years, sall, lwd=2, col='black')
    
    
    axis(side = 4)
    mtext(side = 4, line = 3, 'sqrt(seed count)')
    
    if(!SAVEPLOTS){
      readline('year effect groups -- return to continue ')
    } else {
      dev.off()
    }
  }
}

.chainPlot <- function(mat, burnin, label, SAVEPLOTS=F, outFolder=''){
  
  cseq <- 1:nrow(mat)
  if(length(cseq) > 1000)cseq <- seq(1,length(cseq),length=1000)
  
  if(SAVEPLOTS){
    fileName <- .replaceString(label,',','')
    fileName <- .replaceString(label,' ','')
    fileName <- paste(fileName,'.pdf',sep='')
    pdf( file=.outFile(outFolder,'chainsFecundity.pdf') )
  }
  
  colnames(mat) <- .replaceString(colnames(mat),'species','')
  
  .processPars(mat[cseq,], xtrue=0, burnin = 5, CPLOT = T)
  abline(v=burnin*length(cseq)/nrow(mat), lty=2, col=.getColor('black',.3))
  
  if(!SAVEPLOTS){
    lab <- paste(label, ' -- return to continue')
    readline(lab)
  } else {
    dev.off( )
  }
}
 
.outFile <- function(outFolder=character(0),file){
  paste(outFolder,file,sep='/')
}

.splitNames <- function(nameVec, snames=NULL, split='_'){
  
  vnam <- matrix( unlist( strsplit(nameVec,split) ),ncol=2,byrow=T)
  
  if(is.null(snames))return( list(vnam = vnam, xnam = NULL) )
  
  ix <- 1
  nc <- 2
  y1 <- which(vnam[,1] %in% snames)
  y2 <- which(vnam[,2] %in% snames)
  if(length(y1) > length(y2))ix <- 2
  if(ix == 2)nc <- 1
  
  xnam <- vnam[,ix]
  vnam <- vnam[,nc]
  list(vnam = vnam, xnam = xnam)
}
.plotLabel <- function(label,location='topleft',cex=1.3,font=1,
                       above=F,below=F,bg=NULL){
  
  if(above){
    adj <- 0
    if(location == 'topright')adj=1
    title(label,adj=adj, font.main = font, font.lab =font)
    return()
  }
  if(below){
    adj <- 0
    if(location == 'bottomright')adj=1
    mtext(label,side=1,adj=adj, outer=F,font.main = font, font.lab =font,cex=cex)
    return()
  }
  
  if(is.null(bg)){
    tmp <- legend(location,legend=' ',bty='n')
  } else {
    tmp <- legend(location,legend=label,bg=bg,border=bg,text.col=bg,bty='o')
  }
  
  xt <- tmp$rect$left # + tmp$rect$w
  yt <- tmp$text$y
  
  pos <- 4
  tmp <- grep('right',location)
  if(length(tmp) > 0)pos <- 2
  
  XX <- par()$xlog
  YY <- par()$ylog
  
  if(XX)xt <- 10^xt
  if(YY)yt <- 10^yt
  
  text(xt,yt,label,cex=cex,font=font,pos=pos)
}

.boxCoeffs <- function(chain, specNames, xlab = ""){
  
  nspec <- length(specNames)
  
  cnames <- colnames(chain)
  
  gnames <- paste('species',specNames,sep='')
  vnames <- numeric(0)
  for(j in 1:nspec){
    wj <- grep(gnames[j],cnames)
    vnames <- rbind(vnames, wj)
    
    wk <- grep(':',cnames[wj])
    if(length(wk) > 0){
      xn <- matrix( unlist( strsplit(cnames[wj[wk]],':')),
                    ncol=2, byrow=T)[,2]
    }
  }
  rownames(vnames) <- specNames
  colnames(vnames) <- c('intercept',xn)
  nv <- ncol(vnames)
  
  atvals <- c(1:nspec)/(nspec + 1)
  atvals <- atvals - mean(atvals)
  sseq   <- c(1:nv)
  xlim   <- c(.5, nv +.5)
#  ylim   <- c(-6,6)
  
  ylim <- range(chain)
  ylim[1] <- ylim[1] - diff(ylim)*.25
  
  add <- F
  cols <- seq(1:nspec)
  
  xlabel <- ''
  
  for(j in 1:nv){
    
    jcol <- vnames[,j]
    if(j > 1)add <- T
    chainj <- chain[,jcol, drop=F]
    mj     <- mean(chainj)
    sj     <- sd(chainj)
    chainj <- chainj #/sj
    
    if(j == nv)xlabel <- xlab
    
    tmp <- .boxplotQuant( chainj,xaxt='n', add = add,
                          at = atvals + j, xlim = xlim,
                          outline=F, ylim=ylim,
                          col=.getColor(cols, .4), 
                          border=cols, xaxt='n',lty=1,
                          ylab = 'Coefficient')
    text(j,ylim[1],colnames(vnames)[j],pos=3)
  }
  .plotLabel(xlab,'topleft',above=T)
 # legend('topright',specNames, text.col=1:nspec, bty='n')
  abline(h = 0, lwd=2, lty=2, col=.getColor('grey',.6))
}

.fixNames <- function(cvec){
  
  cvec <- .replaceString(cvec, '_','')
  cvec <- .replaceString(cvec, '-','')
  cvec <- .replaceString(cvec, ' ','')
  cvec
}
  

mast <- function(formulaFec, formulaRep, specNames, seedNames, 
                     treeData, seedData, xytree, xytrap, init){   
  
  tmp <- model.frame(formulaFec, treeData)  # check predictors
  tmp <- model.frame(formulaRep, treeData)
  
  .mast(formulaFec, formulaRep, specNames, seedNames, 
            treeData, seedData, xytree, xytrap, init) 
}


.mast <- function(formulaFec, formulaRep, specNames, seedNames, 
                      treeData, seedData, xytree, xytrap, init){
  
  ng        <-  2500
  burnin    <-  500
  priorDist <- 10; priorVDist <- 50; maxDist <- 50; minDist <- 2
  minDiam   <- 10
  maxF      <- 1e+9
  priorM    <- priorMwt <- NULL
  priorB <- priorIVB <- betaPrior <- yearEffect <- randomEffect <- NULL
  RANDOM <- YR <- F
  
  for(k in 1:length(init))assign( names(init)[k], init[[k]] )
  
  priorU  <- (2*priorDist/pi)^2
  priorVU <- (2*sqrt(priorVDist)/pi)^4
  maxU    <- (2*maxDist/pi)^2
  minU    <- (2*minDist/pi)^2
  
  if(!is.null(betaPrior)){
    if(!is.null(yearEffect) | !is.null(randomEffect))
      stop('if betaPrior is included, do not include yearEffect or randomEffect')
  }
  
  # fix names
  treeData$species <- as.factor( .fixNames(as.character(treeData$species)) )
  specNames <- .fixNames(specNames)
  seedNames <- .fixNames(seedNames)
  colnames(seedData) <- .fixNames(colnames(seedData))
  if('species' %in% colnames(xytree)){
    xytree$species <- as.factor( .fixNames(as.character(xytree$species)) )
  }
  if(!is.null(priorM)){
    rownames(priorM) <- .fixNames(rownames(priorM))
    colnames(priorM) <- .fixNames(colnames(priorM))
  }
  if(!is.null(priorMwt)){
    rownames(priorMwt) <- rownames(priorM)
    colnames(priorMwt) <- colnames(priorM)
  }
  
  if(!'diam' %in% colnames(treeData))stop("include 'diam' column in treeData")
  
  formulaFec <- as.formula( .replaceString( as.character(formulaFec),'species *',''))
  formulaRep <- as.formula( .replaceString( as.character(formulaRep),'species *',''))
  
  formulaFec <- .specFormula(formulaFec)
  formulaRep <- .specFormula(formulaRep)
  
  if(!'repMu' %in% names(treeData))treeData$repMu <- 0
  if(!'repSd' %in% names(treeData))treeData$repSd <- 1
  
  treeData <- treeData[treeData$year %in% seedData$year,]
  
#  seedData <- seedData[seedData$year %in% treeData$year,]
  
  treeData  <- treeData[,!names(treeData) %in% c('treeID','plotYr')]
  seedData  <- seedData[,!names(seedData) %in% c('trapID','plotYr')]
  
  treeData$year <- as.numeric(treeData$year)
  seedData$year <- as.numeric(seedData$year)
  
  
  
  tmp <- .setupData(formulaFec, formulaRep, treeData, seedData, 
                    xytree, xytrap, specNames, seedNames)
  specNames <- tmp$specNames
  treeData  <- tmp$treeData
  seedData  <- tmp$seedData
  distall   <- tmp$distall
  xytree    <- tmp$xytree
  xytrap    <- tmp$xytrap
  plotNames <- tmp$plotNames
  plots     <- tmp$plots
  years     <- tmp$years
  xfec      <- tmp$xfec
  xrep      <- tmp$xrep
  nseed     <- nrow(seedData)
  scode     <- tmp$scode
  nplot     <- length(plotNames)
  n         <- nrow(xfec)
  ntobs     <- table(treeData$plot) 
  nsobs     <- table(seedData$plot)
  ttab      <- table(treeData$plot, treeData$year)
  wtab      <- which(ttab > 0, arr.ind=T) 
  nyr       <- table(wtab[,1])
  distTree  <- tmp$distTree
  distTrap  <- tmp$distTrap
  xfecMiss <- tmp$xfecMiss
  xrepMiss <- tmp$xrepMiss
  xfecCols <- tmp$xfecCols
  xrepCols <- tmp$xrepCols
  ntree    <- nrow(xytree)
  ntrap    <- nrow(xytrap)
  xmean    <- tmp$xmean
  xsd      <- tmp$xsd
  xfecU    <- tmp$xfecU
  xfecT    <- tmp$xfecT
  xrepU    <- tmp$xrepU
  xrepT    <- tmp$xrepT
  nyr      <- length(years)
  
  UNSTAND <- T
  if(length(xmean) == 0)UNSTAND <- F
  
  specNames <- attr(treeData$species,'levels')
  nspec     <- length(specNames)
  
  Qfec <- ncol(xfec)
  Qrep <- ncol(xrep)
  n <- nrow(xfec)
  xnamesFec <- colnames(xfec)
  xnamesRep <- colnames(xrep)
  
  # year effects
  betaYr <- NULL
  if(!is.null(yearEffect)){
    YR <- T
    tmp     <- .setupYear(yearEffect, treeData, years)
    betaYr  <- tmp$betaYr
    yrRef   <- tmp$yrRef
    yrindex <- tmp$yrindex
    yeGr    <- tmp$yeGr         #factor!
  }
  
  # random effects
  rnGroups <- reIndex <- reGroups <- priorVA <- NULL
  alphaRand <- Arand <- NULL
  if(!is.null(randomEffect)){
    RANDOM    <- T
    formulaRan <- .specFormula(randomEffect$formulaRan)
    
    tmp        <- .getDesign(formulaRan, treeData)$x
    tmp        <- tmp[,grep('species',colnames(tmp))]
    xrandCols  <- match(colnames(tmp),colnames(xfec))
    Qrand      <- length(xrandCols)
    reI        <- treeData[,randomEffect$randGroups]
    rnGroups  <- sort(unique(reI))
    reIndex    <- match(reI, rnGroups)
    reGroups   <- sort(unique(reIndex))
    nRand      <- length(reGroups)
    Arand      <- priorVA <- diag(1, Qrand)
    dfA        <- ceiling( Qrand + nRand/4 )
    alphaRand  <- matrix(0, nRand, Qrand)
    colnames(alphaRand) <- xnamesFec[xrandCols]
    rownames(alphaRand) <- rnGroups
  }
  
  # species to seed type
  seedCount <- as.matrix(seedData[,seedNames])
  totSeed   <- colSums(seedCount)
  fracSeed  <- totSeed/sum(totSeed)
  
  SAMPM <- T
  
  if(!is.null(priorMwt))priorMwt <- priorMwt[drop=F,specNames,]
  if(!is.null(priorM)){
    priorM <- priorM[drop=F,specNames,]
    wmore  <- which(colSums(priorM) == 0 & fracSeed > 0)  #correct prior
    if(length(wmore) > 0){
      priorM[,wmore] <- fracSeed[wmore]
      priorM <- sweep(priorM,1,rowSums(priorM),'/')
      priorMwt[,wmore] <- 1
    }
  }else{
    if(length(seedNames) == 1 & length(specNames) == 1){
      SAMPM <- F
      priorM <- priorMwt <- matrix(1,1)
    }else{
      priorM <- matrix(1/length(seedNames),length(specNames),
                       length(seedNames))
      rownames(priorM) <- specNames
      colnames(priorM) <- seedNames
      priorMwt <- priorM
    }
  }
  M <- priorM
  
  # initialize repro
  iy   <- match(treeData$year, years)
  if(minDiam > 0)treeData$repr[treeData$diam < minDiam] <- 0
  zknown <- matrix(NA, max(treeData$dcol), length(years))
  zknown[ cbind(treeData$dcol, iy) ] <- treeData$repr
  
  tmp <- .getRepro(zknown)
  last0first1 <- tmp$last0first1
  zmat  <- tmp$imat
  matYr <- tmp$matYr
                
  tmp <- .propZ(zmat, last0first1, matYr)
  zmat <- tmp$zmat
  matYr <- tmp$matYr
  
  # attributes for zmat
  tt <- matrix(NA, max(treeData$dcol), max(nyr))
  tt[ cbind(treeData$dcol, iy) ] <- treeData$treeID
  tt <- rowMeans(tt,na.rm=T)
  tt <- attr(treeData$treeID,'levels')[tt]
  pt <- matrix( unlist( strsplit(tt, '-') ), ncol=2, byrow=T)
 
  attr(zmat,'plot') <- pt[,1]
  attr(zmat,'treeID') <- tt
  
  tyindex <- cbind(treeData$dcol, iy)  #tree-yr index
  z    <- zmat[ tyindex ]
  
  plotYears <- sort(unique(treeData$plotYr))
  
  # initial fecundity
  
  fg <- .initEM(distall, priorU, minDiam, maxF, minU, maxU, treeData, seedData,
                specNames, seedNames, M, SAMPM, years, plotYears,
                z, xfec)
  
  # priors, proposals
  ug    <- priorU
  propU <- priorU/100
  propF <- fg/10
  propF[propF < .01] <- .01
  
  sg <- .1
  
  if(!RANDOM){
    s1 <- nrow(treeData)/100
  }else{
    sg <- .1
    s1 <- nrow(treeData)
  }
  s2 <- sg*(s1 - 1)
  slo <- sg/2
  shi <- sg*4
  
  pbar <- txtProgressBar(min=1,max=ng,style=1)
  
  wlo <- rep(-Inf, length(z))
  whi <- rep(Inf, length(z))
  whi[z == 0] <- 0
  wlo[z == 1] <- 0
  w <- .tnorm(length(z), wlo, whi, treeData$repMu, 1)
  
  xFecNames <- colnames(xfec)
  xRepNames <- colnames(xrep)
  
  bgFec <- matrix(0, Qfec, 1)
  bgRep <- matrix(0, Qrep, 1)
  rownames(bgFec) <- xFecNames
  rownames(bgRep) <- xRepNames
  
  if(!is.null(betaPrior)){
    betaPrior <- .getBetaPrior(betaPrior, bgFec, bgRep, specNames)
  }
  
  .updateBeta <- .wrapperBeta(priorB, priorIVB, minU, maxU, maxF,
                              priorU, priorVU, SAMPM,
                              seedData, treeData, seedNames, xfecCols,
                              xrepCols, last0first1, ntree, nyr, tyindex,
                              betaPrior, years, distall, YR, yrindex, 
                              RANDOM, reIndex, xrandCols)
  
  bfgibbs <- matrix(0, ng, Qfec); colnames(bfgibbs) <- xnamesFec
  brgibbs <- matrix(0, ng, Qrep); colnames(brgibbs) <- xnamesRep
  bygibbs <- NULL
  if(YR){
    bygibbs <- matrix(NA, ng, length(betaYr))
    colnames(bygibbs) <- .multivarChainNames(yeGr, years)
  }
  if(RANDOM){
    agibbs <- matrix(NA, ng, length(Arand))
    colnames(agibbs) <- .multivarChainNames(xnamesFec[xrandCols],
                                            xnamesFec[xrandCols])
    asum <- asum2 <- alphaRand*0
  }
    
  colnames(brgibbs) <- xnamesRep
  ugibbs <- matrix(0, ng, 3)
  if(SAMPM){
    mgibbs <- matrix(0, ng, length(M))
    colnames(mgibbs) <- .multivarChainNames(rownames(M), colnames(M) )
  }
  
  colnames(ugibbs) <- c('sigma','u','rmspe')
  
  ntot <- 0
 # mf <- M[drop=F,treeData[,'species'],]
  
  zpred <- fp <- fp2 <- fpred <- fpred2 <- fg*0 # fecundity predictions
  sumDev <- 0   #for DIC
  
  spred <- spred2 <- matrix(0,nseed, length(seedNames)) # seed predictions
  
  gupdate <- c(5,10, 15, 20, 25, 50, 100, 200, 500, 800, 1200,2000)  #reset proposal variance
  g1      <- 1
  
  accept <- rep(0, length(plotYears))
  
  print('MCMC')
  
  pars  <- list(fg = fg, ug = ug, sg = sg, bgFec = bgFec, bgRep = bgRep,
                betaYr = betaYr, alphaRand = alphaRand, 
                Arand = Arand)
  
  mufec <- xfec%*%bgFec
  muyr  <- muran <- mufec*0
  
  tmp <- .updateBeta( pars = pars, bgFec, bgRep, xfec, xrep, 
                      M, propU, propF, w, z, zmat, matYr)
  ug    <- pars$ug    <- tmp$ug
  bgFec <- pars$bgFec <- tmp$bgFec
  bgRep <- pars$bgRep <- tmp$bgRep
  fg    <- pars$fg    <- tmp$fg
  z     <- tmp$z
  zmat  <- tmp$zmat
  matYr <- tmp$matYr
  accept <- tmp$accept
  w0    <- which(accept == 0)
  propF[treeData$dcol %in% w0] <- propF[treeData$dcol %in% w0]/5
  
  for(g in 1:ng){
    
    yg    <- log(fg)
    mufec <- xfec%*%bgFec
    
    if(RANDOM){
      yg <- log(fg) - mufec
      if(YR)yg <- yg - betaYr[yrindex]
      tmp <- .updateAlphaRand(yg, xfec, z, sg, reIndex, reGroups,
                              xrandCols, Arand, priorVA, dfA)
      alphaRand  <- pars$alphaRand <- tmp$alphaRand
      Arand      <- pars$Arand <- tmp$Arand
      agibbs[g,] <- as.vector(Arand)
      muran <- rowSums( xfec[,xrandCols]*alphaRand[reIndex,] )
    }
    
    if(YR){
      yg <- log(fg) - mufec
      if(RANDOM)yg <- yg - muran
      tmp     <- .updateBetaYr(yg, z, sg, yrindex, yeGr)
      betaYr  <- pars$betaYr <- tmp$beta
      wfinite <- tmp$wfinite
      bygibbs[g,wfinite] <- betaYr[ wfinite ]
      muyr <- betaYr[yrindex]
    }
    
    tmp <- .updateBeta( pars = pars, bgFec, bgRep, xfec, xrep, 
                        M, propU, propF, w, z, zmat, matYr)
    ug    <- pars$ug    <- tmp$ug
    bgFec <- pars$bgFec <- tmp$bgFec
    bgRep <- pars$bgRep <- tmp$bgRep
    fg    <- pars$fg    <- tmp$fg
    z     <- tmp$z
    zmat  <- tmp$zmat
    matYr <- tmp$matYr
    accept <- accept + tmp$accept
    
    lo <- hi <- z*0
    lo[z == 0] <- -Inf
    hi[z == 1] <- Inf
    
    w <- .tnorm(n, lo, hi, xrep%*%bgRep, 1 )
    
    muf <- xfec%*%bgFec
    if(YR)muf <- muf + muyr
    if(RANDOM)muf <- muf + muran
    
    sg <- pars$sg <- .updateVariance(log(fg[z == 1]), muf[z == 1], s1, s2)
    if(sg > 10)sg <- pars$sg <- 10          # stabilize first iterations
    
    if(SAMPM){
      M  <- .updateM(ug, fg, z, SAMPM, distall, seedData, seedNames,
                            treeData, M, priorM, priorMwt, years)
      mgibbs[g,]  <- M
    }
    
    fmu <- exp( rnorm( length(muf), muf, sqrt(sg) ) )
    
    la <- .getLambda(ug, fmu, z, M, SAMPM, seedData, treeData, 
                     distall, years, PERAREA=F)
    
    pg <- matrix( rpois(nseed*ncol(la), la), nseed, ncol(la) )
    
    rmspe <- sqrt( mean( (seedCount - la)^2 ) )
    
 #   print(c(sg,rmspe))
    
    
    if(UNSTAND){
      if(length(xfecT) > 0)bgFec <- xfecT%*%bgFec
      if(length(xrepT) > 0)bgRep <- xrepT%*%bgRep
    }
    
    bfgibbs[g,] <- bgFec
    brgibbs[g,] <- bgRep

    ugibbs[g,]  <- c(sg, ug, rmspe)

    
    fp <- fp + fmu        # only for proposals
    fp2 <- fp2 + fmu^2
    
    if(g %in% gupdate){
      gi <- g1:g
      g1 <- g
      propU  <- var(ugibbs[gi,'u']) + .01
      
      ng1 <- length(gi)
      
      w0    <- which(accept/ng1 < .1)
      propF[treeData$plotyr %in% w0] <- propF[treeData$plotyr %in% w0]/10
      
      w0 <- which(accept/ng1 > .5)
      propF[treeData$plotyr %in% w0] <- propF[treeData$plotyr %in% w0]*3
      
      propF[propF < 1e-5] <- 1e-5
      
  #    fm <- pmax(fp2/g - (fp/g)^2, .5)/10
  #    propF <- .1 + sqrt( fm )
  #    propF[propF > fg/10] <- fg[propF > fg/10]/10
      accept <- accept*0
    }
    
    if(g >= burnin){
      ntot <- ntot + 1
      zpred <- zpred + z
      fpred <- fpred + fg*z
      fpred2 <- fpred2 + (fg*z)^2
      spred  <- spred + la
      spred2 <- spred2 + la^2
      sumDev <- sumDev - 2*sum(dpois(seedCount, la, log=T))
      if(RANDOM){
        asum <- asum + alphaRand
        asum2 <- asum2 + alphaRand^2
      }
    }
    
    setTxtProgressBar(pbar,g)
  }
  
  
  fecMu  <- fpred/ntot
  fecSe  <-  fpred2/ntot - fecMu^2
  fecSe[fecSe < 0] <- 0
  seedMu <- spred/ntot
  seedSe <- spred2/ntot - seedMu^2
  seedSe[seedSe < 0] <- 0
  fecSe  <- sqrt(fecSe)
  seedSe <- sqrt(seedSe)
  
  matrMu <- zpred/ntot
  
  kg <- burnin:ng
  
  betaFecMu <- matrix( colMeans(bfgibbs[kg,]), Qfec )
  betaFecSe <- matrix( apply(bfgibbs[kg,],2,sd), Qfec )
  betaFecCI <- t( apply( bfgibbs[kg,],2,quantile,c(.025,.975) ) )
  rownames(betaFecMu) <- rownames(betaFecSe) <- rownames(betaFecCI) <- xFecNames
  betaFec <- cbind(betaFecMu, betaFecSe, betaFecCI)

  betaRepMu <- matrix( colMeans(brgibbs[kg,]), Qrep )
  betaRepSe <- matrix( apply(brgibbs[kg,],2,sd), Qrep )
  betaRepCI <- t( apply( brgibbs[kg,],2,quantile,c(.025,.975) ) )
  rownames(betaRepMu) <- rownames(betaRepSe) <- rownames(betaRepCI) <- xRepNames
  betaRep <- cbind(betaRepMu, betaRepSe, betaRepCI)
  colnames(betaFec)[1:2] <- colnames(betaRep)[1:2] <- c('estimate','se')
  
  usPars <- cbind( apply(ugibbs[kg,],2,mean), apply(ugibbs[kg,], 2, sd), 
                   t( apply(ugibbs[kg,],2, quantile, c(.025, .975) )) )
  colnames(usPars)[1:2] <- c('estimate','se')
  
  if(YR){
    betaYrMu <- matrix( colMeans(bygibbs, na.rm=T), 
                        nrow(betaYr), ncol(betaYr) )
    betaYrSe <- matrix( apply(bygibbs,2, sd, na.rm=T), 
                        nrow(betaYr), ncol(betaYr) )
    rownames(betaYrMu) <- rownames(betaYrSe) <- yeGr
    colnames(betaYrMu) <- colnames(betaYrSe) <- years
  }
  
  if(RANDOM){
    alphaMu <- asum/ntot
    av    <- asum2/ntot - alphaMu^2
    av[av < 0] <- 0
    alphaSe <- sqrt(av)
    colnames(alphaMu) <- colnames(alphaSe) <- xnamesFec[xrandCols]
    rownames(alphaMu) <- rownames(alphaSe) <- as.character()
    aMu <- matrix( apply(agibbs, 2, mean), Qrand, Qrand )
    aSe <- matrix( apply(agibbs, 2, sd), Qrand, Qrand )
    colnames(aMu) <- rownames(aMu) <- colnames(aSe) <- rownames(aSe) <-
      colnames(alphaMu)
    names(xrandCols) <- xnamesFec[xrandCols]
  }
  
  mmu <- 1
  if(SAMPM){
    mmu <- matrix( apply(mgibbs, 2, mean), nrow(M), ncol(M) )
    mse <- matrix( apply(mgibbs, 2, sd), nrow(M), ncol(M) )
    colnames(mmu) <- colnames(mse) <- seedNames
    rownames(mmu) <- rownames(mse) <- specNames
  }
  
  su <- cbind( colMeans(ugibbs), apply(ugibbs,2,sd), 
               t(apply(ugibbs,2,quantile,c(.025,.975))) )
  colnames(su) <- c('estimate','std err', '0.025','0.975')
  
  if(UNSTAND){
    colnames(xfecU) <- colnames(xfec)
    colnames(xrepU) <- colnames(xrep)
    xfec <- xfecU
    xrep <- xrepU
  }
  
  ########## fit
  zp <- pnorm(xrep%*%betaRepMu)
  fp <- xfec%*%betaFecMu
  if(YR){
    by <- betaYrMu[ yrindex ]
    by[is.na(by)] <- 0
    fp <- fp + by
  }
  fp <- exp(fp + usPars['sigma','estimate']/2)
  
  meanDev <- sumDev/ntot
  um <- usPars['u','estimate']
  la <- .getLambda(um, as.vector(fp), as.vector(zp), mmu, SAMPM, 
                   seedData, treeData, distall, years, PERAREA=F)
  
  pd  <- meanDev - 2*sum(dpois(seedCount, la, log=T))
  DIC <- pd + meanDev
  
  RMSPE <- mean(ugibbs[burnin:ng,'rmspe'])
  
  fit <- list(DIC = DIC, RMSPE = RMSPE)
  
  print('use new specNames and seedNames in inputs$specNames, inputs$seedNames')
  
  inputs <- list(seedNames = seedNames, specNames = specNames, M = priorM,
                 formulaFec = formulaFec, formulaRep = formulaRep,
                 xfec = xfec, xrep = xrep, treeData = treeData,
                 seedData = seedData, xytree = xytree, xytrap = xytrap,
                 distall = distall, ng = ng, burnin = burnin,
                 nplot = nplot, ntree = ntree, ntrap = ntrap, nyr = nyr,
                 maxF = maxF, years = years, plots = plots, plotYears = plotYears)
  chains <- list(bfec = bfgibbs, brep = brgibbs, ugibbs = ugibbs)
  parameters <- list( betaFec = signif(betaFec, 3),  
                      betaRep = signif(betaRep, 3),
                      usigma = signif(su))
  if(SAMPM){
    chains <- append(chains, list(mgibbs = mgibbs))
    parameters <- append(parameters, list(mMu = signif(mmu,3), 
                                          mSe = signif(mse,3)))
  }
  if(YR){
    yearEffect$yrindex <- yrindex
    inputs     <- append(inputs, list(yearEffect = yearEffect) )
    chains     <- append(chains, list(bygibbs = bygibbs) )
    parameters <- append(parameters, list(betaYrMu = signif(betaYrMu, 3),
                                          betaYrSe = signif(betaYrSe, 3)) )
  }
  if(RANDOM){
    randomEffect$rnGroups <- rnGroups
    randomEffect$reIndex   <- reIndex
    randomEffect$xrandCols <- xrandCols
    inputs     <- append(inputs, list(randomEffect = randomEffect) )
    chains     <- append(chains, list(agibbs = agibbs) )
    parameters <- append(parameters, list(alphaMu = alphaMu, alphaSe = alphaSe,
                                          aMu = aMu, aSe = aSe) )
  }
  
  chains     <- chains[ sort( names(chains) )]
  inputs     <- inputs[ sort( names(inputs) )]
  inputs$ng  <- ng
  inputs$burnin <- burnin
  parameters <- parameters[ sort( names(parameters) )]
  
  out <- list(inputs = inputs, chains = chains, fit = fit, 
              parameters = parameters,
              prediction = list( fecMu = fecMu, fecSe = fecSe, matrMu = matrMu,
                          seedMu = seedMu, seedSe = seedSe, uSigma = usPars,
                          mMu = mmu) )
  
  class(out) <- 'mast'
  out
} 
 
 
.mapSetup <- function(xlim,ylim,scale=NULL,widex=10.5,widey=6.5){  
  
  #scale is x per inch
  #new means not a new plot
  
  if(is.null(scale))scale <- 1
  
  px   <- diff(xlim)/scale
  py   <- diff(ylim)/scale
  
  if(px > widex){
    dx <- widex/px
    px <- widex
    py <- py*dx
  }
  if(py > widey){
    dx <- widey/py
    py <- widey
    px <- px*dx
  }
  
  par(pin=c(px,py))
  invisible( c(px,py) )
}

mastMap <- function(tdata, sdata, specNames, seedNames, xytree, xytrap, 
                    treeSymbol = NULL, plots=NULL, years=NULL, 
                    predict=NULL, xlim = NULL, ylim = NULL,
                        mapPred = 'mean', scaleTree = 1, scaleTrap = 1){
  
  if(!is.null(predict)){
    if(!'map' %in% names(predict)){
      stop('to map predictions, predVars = NULL 
           required in call to mastPredict')
    }
    if(!'prediction' %in% names(predict)){
      stop('to map predictions, specify newdata in call to mastPredict')
    }
  }
  
  .dmap(tdata, sdata, specNames, seedNames, 
        xytree, xytrap, treeSymbol, plots, years, predict,
        xlim = xlim, ylim = ylim,
        mapPred, scaleTree, scaleTrap)
}

     
.dmap <- function(tdata, sdata, specNames, seedNames, xytree, xytrap,
                  treeSymbol, plots, years, predict, 
                  xlim, ylim, mapPred, scaleTree, scaleTrap){
  
  # if mapPred is not 'mean', then prediction error mapped
  
  
  stab <- with( sdata, table(plot, year) )
  years <- years[years %in% colnames(stab)]
  if(!is.null(plots)){
    wp <- which( plots %in% rownames(stab) )
    if(length(wp) == 0){
      rn <- paste0(rownames(stab)[wp],collapse=', ')
      stop( paste( 'input plots', rn, 'not fitted') )
    }
    stab <- stab[drop=F, plots, ]
  }
  if(!is.null(years)){
    wp <- which(years %in% colnames(stab))
    if(length(wp) == 0){
      rn <- paste0(colnames(stab)[wp],collapse=', ')
      stop( paste( 'input years', rn, 'not fitted') )
    }
    stab <- stab[, as.character(years), drop=F]
  }
  
  if(length(stab) == 0)return()
  
  if(is.null(treeSymbol)){
    treeSymbol <- rep(1, nrow(tdata))
    if(!is.null(predict)){
      treeSymbol <- predict$prediction$fecMu
    }
  }
  
  sc    <- colSums(stab)
  stab  <- stab[,sc > 0, drop=F]
  wsc   <- which(stab > 0, arr.ind=T)
  
  if(length(wsc) == 0)return()
  
  if(!'trapID' %in% colnames(sdata))
    sdata$trapID <- .colPaste(sdata$plot,sdata$trap)
  
  if(!'trapID' %in% colnames(xytrap))
    xytrap$trapID <- .colPaste(xytrap$plot,xytrap$trap)
  
  if(!'treeID' %in% colnames(tdata))
    tdata$treeID <- .colPaste(tdata$plot,tdata$tree)
  
  if(!'treeID' %in% colnames(xytree))
    xytree$treeID <- .colPaste(xytree$plot,xytree$tree)
    
  
  if(is.null(xlim))xlim <- range( c(xytree[,'x'], xytrap[,'x']) )
  if(is.null(ylim))ylim <- range( c(xytree[,'y'], xytrap[,'y']) )
  dx <- diff(xlim)
  dy <- diff(ylim)
  
  
  wf         <- which(is.finite(treeSymbol))
  tdat       <- tdata[wf,]
  treeSymbol <- treeSymbol[wf]
  
  graphics.off()
  
  if(nrow(wsc) == 1){
    .mapSetup(xlim,ylim, scale = max(c(dx,dy))/3 )
  }else{
    mfrow <- .getPlotLayout(nrow(wsc))
    par( mfrow=mfrow, bty='n', mar=c(2,2,1,1) )
  }
  
  
  for(k in unique(wsc[,1]) ){
    
    pn <- rownames(stab)[k]
    mk <- which(wsc[,1] == k)
    
    seedMax <- quantile(sdata[,seedNames],.98, na.rm=T)
    if(seedMax == 0)seedMax <- max(sdata[,seedNames],na.rm=T)
    fecMax  <- quantile(treeSymbol,.98, na.rm=T)
    
    xlim <- range( c(xytree[xytree$plot == pn,'x'], 
                     xytrap[xytrap$plot == pn,'x']) )
    ylim <- range( c(xytree[xytree$plot == pn,'y'], 
                     xytrap[xytrap$plot == pn,'y']) )
    dx <- diff(xlim)
    dy <- diff(ylim)
    
    for(m in wsc[mk,2]){
      
      rr <- apply( rbind(xlim, ylim), 2, range)
      sc <- max( apply(rr,1,diff) )/2
      
      add <- F
      yn <- colnames(stab)[m]
      i <- which(tdat[,'plot'] == pn & tdat[,'year'] == yn &
                   tdat[,'species'] %in% specNames)
      if(length(i) > 0){
        ti <- tdat[i,]
        if(length(treeSymbol) == 2){
          fi <- rep(treeSymbol,length(i))
        }else{
          fi <- treeSymbol[i]
        }
        xyt <- xytree[ match(ti[,'treeID'],xytree[,'treeID']) ,c('x','y')]
        .mapSpec(xyt[,1],xyt[,2],sc/2*fi/fecMax*scaleTree,  add = add,
                 mapx = xlim, mapy = ylim, colVec='brown',
                 fill = .getColor('brown',.5))
        add <- T
      }
        
      j <- which(sdata[,'plot'] == pn & sdata[,'year'] == yn)
      sj  <- sdata[j,]

      xys <- xytrap[ match(sj[,'trapID'],xytrap[,'trapID']) ,c('x','y')]
    
      
      ss <- as.matrix( sj[,seedNames] )
      ff <- sapply(ss,is.factor)
      if(!all(!ff))ss <- .fac2num( ss )
      if(is.matrix(ss))ss <- rowSums(ss, na.rm=T)
      ss <- ss/seedMax
      wa <- 1:length(ss)
      ws <- which(!is.finite(ss))
      if(length(ws) > 0){
        wa <- wa[-ws]
        ss[wa] <- 1
        if(length(wa) == 0)ss <- rep(.01, length(ss))
      }
      
      if(length(wa) > 0){
        .mapSpec(xys[wa,1],xys[wa,2],sc*ss[wa]*scaleTrap,add=add, 
                 sym='squares', colVec = 'darkgreen', 
                 fill=.getColor('darkgreen',.5))
        add <- T
      }
      
      if(length(ws) > 0){
        if(!add){
          plot(xys[ws,1],xys[ws,2],pch=3,xlim = xlim, ylim = ylim,col='darkgreen')
        }else{
          points(xys[ws,1],xys[ws,2],pch=3,col='darkgreen')
        }
      }
      
      title(main = list(paste(pn, yn, sep=', '),cex = sum(mfrow)^(-.2) ) ) 
    }
  }
  
  if(!is.null(predict)){
    
    sm <- predict$prediction$seedMu
    if(mapPred == 'Se')sm <- predict$prediction$seedSe
    if(mapPred == 'CV'){
      sm <- predict$prediction$seedSe/sm
      mc <- max(sm, na.rm=T)
      sm[sm < 0] <- 0
      sm[!is.finite(sm)] <- mc
    }
    if(max(sm) == 0){
 #     warning('no seeds predicted for this plot-year')
      return()
    }
    levels <- signif( quantile(sm, seq(0, 1, by=.2) ), 1 )
 #   levels <- round(levels)
 
    levels <- c(levels, max(sm)*1.3)
    levels <- sort(unique(levels))
    col <- .getColor('darkblue',seq(.1, .7, length=length(levels)))
    contour(predict$map$x, predict$map$y, sm, levels=levels, add=T, 
            col=col, labcex = 1)
    .filled.contour(predict$map$x, predict$map$y, sm, levels=levels, col=col)
  }
}


.colPaste <- function(...){
  
  # ... are vectors, all same length to be combined row-wise
  
  mm <- list(...)
  nn <- as.character(mm[[1]])
  for(i in 2:length(mm)){
    mi <- as.character(mm[[i]])
    nn <- apply( cbind(nn,mi),1,paste0,collapse='-')
  }
  nn
}
 
.updateCovariance <- function(SS, priorSS, n, df){
  
  SI   <- solveRcpp(SS + df*priorSS)
  sinv <- .rwish(n + df, SI)
  solveRcpp(sinv)
}

.updateAlphaRand <- function(yg, xfec, z, sg, reIndex, reGroups,
                             xrandCols, Arand, priorVA, dfA, minmax = 2){
  
  wg <- xfec[z == 1, xrandCols]
  alphaRand <- randEffectRcpp(reIndex[z == 1], reGroups, 
                              wg, yg[z == 1,], sg, solve(Arand))
  alphaRand[alphaRand < -minmax] <- -minmax
  alphaRand[alphaRand > minmax]  <- minmax
  rz    <- which( rowSums(alphaRand) != 0)
  
  if(length(rz) < 2)return(list(alphaRand = alphaRand, Arand = Arand))
  
  AA    <- crossprod(alphaRand[rz,])
  Arand <- .updateCovariance(AA, priorVA, length(rz), dfA)
  
  list(alphaRand = alphaRand, Arand = Arand)
}

.rwish <- function(df,SS){
  z  <- matrix(rnorm(df*nrow(SS)),df,nrow(SS))%*%chol(SS)
  crossprod(z)
}

.riwish <- function(df,S){
  solveRcpp(.rwish(df,solveRcpp(S)))
}


print.mast <- function(x, ...){
  
  mMu <- mSe <- usigma <- betaYrMu <- betaYrSe <- NULL
  
  cat("Call:\n")
  print(x$call)
  
  cat("\nDIC:\n")
  print( round(x$fit$DIC,0) )
  
  cat("\nFecundity coefficients:\n")
  print( signif(x$parameters$betaFec, 3) )
  
  cat("\nMaturation coefficients:\n")
  print( signif(x$parameters$betaRep, 3) )
  
  if('betaYrMu' %in% names(x$parameters)){
    cat("\nYear effects:\n")
    print( signif(betaYrMu, 3) )
    print( signif(betaYrSe, 3) )
  }
  
  if('mgibbs' %in% names(x$chains)){
    cat("\nSpecies to seed type matrix:\n")
    print( signif(mMu, 3) )
    print( signif(mSe, 3) )
  }
  
  cat("\nDispersal u and sigma:\n")
  print( signif(usigma, 3) )
  
}
summary.mast <- function(object,...){ 
  
  betaFec   <- object$parameters$betaFec
  betaRep   <- object$parameters$betaRep
  rb <- rownames(beta)
  cb <- colnames(beta)
  Q  <- nrow(beta)
  YR <- RANDOM <- SAMPM <- F
  
  RMSPE       <- object$fit$RMSPE
  DIC         <- object$fit$DIC
 
  cat("\nFecundity parameters:\n")
  print( signif(betaFec, 3) )
  
  cat("\nMaturation parameters:\n")
  print( signif(betaRep, 3) )
  
  if('betaYrMu' %in% names(object$parameters)){
    YR <- T
  cat("\nYear effects with NaN for too few mature individuals:\n")
    print( signif(object$parameters$betaYrMu, 3) )
    
  cat("\nStandard errors:\n")
    print( signif(object$parameters$betaYrSe, 3) )
  }
  
  if('aMu' %in% names(object$parameters)){
    RANDOM <- T
    cat("\nDiagonal elements of random effects covariance matrix:\n")
    print( signif( diag( object$parameters$aMu) , 3) )
    cat("\nStandard errors:\n")
    print( signif(object$parameters$aSe, 3) )
  }
  
  if('mgibbs' %in% names(object$chains)){
    SAMPM <- T
    cat("\nSpecies to seed type matrix:\n")
    print( signif(object$parameters$mMu, 3) )
  
    cat("\nStandard errors:\n")
    print( signif(object$parameters$mSe, 3) )
  }
  
  cat("\nDispersal u and sigma:\n")
  print( signif(object$parameters$usigma, 3) )
  
  ntree  <- nrow(object$inputs$treeData)
  ntrap  <- nrow(object$inputs$seedData)
  years  <- object$inputs$years
  
  words <- paste("Sample contains n = ", ntree, " tree-years on ",
                 object$inputs$nplot, " plots, over ", length(years), 
                 " years, for a total of ", ntrap, " seed trap-years. The RMSPE is ",
                 signif(object$fit$RMSPE,3),
                 ", and the DIC is ",round(object$fit$DIC),".", sep="")
  cat("\n",words)
  if(RANDOM){
    morewords <- paste(" Random effects were fitted on",
                            length(object$inputs$randomEffect$rnGroups), 
                            "groups.")
    cat("\n",morewords)
  }
 
  
  res <- list(DIC=object$fit$DIC, RMSPE=object$fit$RMSPE )
  class(res) <- "summary.mast"
  invisible(res) 
}




buildMast <- function(output,plots,years,xlimit,ylimit,mastList,gridList,treeData, traits,
                      PLOT=F){
  
  #mastPredict objects: mastList has prediction$seedMu by plot, then year
  #                     gridList has map$grid
  
  
  treeData <- output$inputs$treeData
  
  for(p in 1:length(plots)){
    
    ww <- which(names(xlimit) == plots[p])
    xl <- xlimit[[ww]]
    yl <- ylimit[[ww]]
    
    xseq <- seq(xl[1], xl[2],by=3)              # 3 m grid
    yseq <- seq(yl[1], yl[2],by=3)
    gridxy <- as.matrix( expand.grid(xseq,yseq) )
    colnames(gridxy) <- c('x','y')
    
    if(!plots[p] %in% names(mastList)){
      tmpPlot <- numeric(0)
      mastList <- append(mastList, list(tmpPlot))
      names(mastList)[length(mastList)] <- plots[p]
      gridList <- append(gridList, list(gridxy))
      names(gridList)[length(gridList)] <- plots[p]
    }else{
      wp <- which(names(mastList) == plots[p])
      tmpPlot <- mastList[[wp]]
    }
    
    specTab <- table(treeData[treeData$plot == plots[p],'species'])
    
    wtr <- match(names(specTab),traits$code4 )
    wff <- which(is.finite(wtr))
    
    seedMass <- traits$gmPerSeed[wtr[wff]]
    seedMass <- sum( seedMass*specTab[wff] )/sum(specTab[wff])
    
    wplot <- which(names(mastList) == plots[p])
    
    for(t in 1:length(years)){

      pmap <- mastPredict(output, newdata = NULL, plot = plots[p], 
                          year = years[t], nsim = 100, gridxy = gridxy, PLOT=PLOT)
      if(length(pmap) == 0)next
      
      PLOT <- F
      
      seedMu <- pmap$prediction$seedMu
   #   fecMu  <- pmap$prediction$fecMu
      
      if( !years[t] %in% names(tmpPlot) ){
        tmpYear <- seedMu*0
        tmpPlot <- append(tmpPlot,list(tmpYear))
        names(tmpPlot)[length(tmpPlot)] <- years[t]
        mastList[[wplot]] <- tmpPlot
      }else{
        wy <- which(names(tmpPlot) == years[t])
        tmpYear <- tmpPlot[[wy]]
      }
      
      tmpYear <- tmpYear + seedMu*seedMass
      
      tmpPlot[[length(tmpPlot)]] <- tmpYear
      
      wyear <- which(names(mastList[[wplot]]) == years[t])
      mastList[[wplot]][[wyear]] <- tmpYear
        
    }

  }
  
  list(mastList = mastList, gridList = gridList)
}

mastPredict <- function(output, newdata = NULL, plot, year,
                        nsim = 2000, ngrid=30, gridxy = NULL, 
                        predVars = NULL, PLOT=T){
  
  invisible( .dpredict(output, newdata, plot, year, nsim, 
                       ngrid, gridxy, predVars, PLOT) )
}

.dpredict <- function(output, newdata, plot, year, nsim, 
                      ngrid, gridxy, predVars, PLOT){
  
  RANDOM <- YR <- F
  if('randomEffect' %in% names(output$inputs))RANDOM <- T
  if('yearEffect' %in% names(output$inputs)){
    YR <- T
    yrindex <- output$inputs$yearEffect$yrindex
  }
  
  if( is.null(predVars) ){       # predict seed rain, map
    
    tmp <- .getPredict(output, newdata, plot = plot, year, nsim, 
                       ngrid, gridxy, predVars = NULL) 
    if(length(tmp) == 0)return()
    
    if(PLOT ){
      
      treeSymbol <- tmp$prediction$fecMu
      xlim <- ylim <- NULL
      
      if(is.null(newdata)){
        td <- output$inputs$treeData
        xytree <- output$inputs$xytree
        xytrap <- output$inputs$xytrap
      }else{

        td <- newdata$treeData
        xlim <- newdata$xlim
        ylim <- newdata$ylim
        xytree <- newdata$xytree
        xytrap <- newdata$xytrap
      }
       
      if(is.null(xlim))xlim <- range( c(output$inputs$xytree$x, output$inputs$xytrap$x) )
      if(is.null(ylim))ylim <- range( c(output$inputs$xytree$y, output$inputs$xytrap$y) )
            
      mastMap(tdata = td, sdata = output$inputs$seedData, 
              output$inputs$specNames, output$inputs$seedNames, 
              xytree, xytrap, treeSymbol = treeSymbol, plots = plot, years = year,
              xlim = xlim, ylim = ylim, predict=tmp )
    }
    return( tmp )
    
  }else{ # conditional prediction for X
    
    type <- sapply(predVars,mode)
    lg   <- expand.grid(predVars)    # species/variable combinations
    
    pv <- predVars
    repPred <- fecPred <- indEff <- numeric(0)
    
    for(k in 1:nrow(lg)){
      
      pv <- predVars
      pname <- character(0)
      
      for(j in 1:ncol(lg)){
        
        FF <- is.factor(lg[,j])
        if(FF){
          pname <- paste(pname,as.character(lg[k,j]),sep='_')
          ljk <- as.character(lg[k,j])
        }else{
          pn    <- paste(colnames(lg)[j],as.character(lg[k,j]),sep='=')
          pname <- paste(pname,pn,sep='_')
          ljk <- lg[k,j]
        }
        pv[[j]] <- ljk
      }
      
      pname <- .replaceString(pname,'_gradient','')
      npp   <- nchar(pname)
      pname <- substring(pname,2, npp)
      
      tmp <- .getPredict(output, newdata = NULL , plot, year, nsim, ngrid,
                         predVars = pv) # plot/year ignored
      rmat <- tmp$prediction$repPred
      repPred <- append(repPred, list(rmat))
      names(repPred)[[k]] <- pname
      indEff <- append( indEff, list(tmp$prediction$indEffMu))
      names(indEff)[[k]] <- pname
      
      fmat <- tmp$prediction$fecPred
      fecPred <- append(fecPred, list(fmat))
      names(fecPred)[[k]] <- pname
    }
    
    if(PLOT){
      
      par(mfrow=c(2,1), bty='n', mar=c(4,4,.1,1))
      
      plot(repPred[[1]][,1], repPred[[1]][,2],type='l', lwd=2, ylim=c(0,1),
           ylab='Probability', xlab='')
      .shadeInterval(repPred[[1]][,1],repPred[[1]][,3:4],
                     col=k, add=T, trans=.2)
      if(length(repPred) > 1){
        for(k in 2:length(repPred)){
          lines(repPred[[k]][,1], repPred[[k]][,2],type='l', lwd=2)
          .shadeInterval(repPred[[k]][,1],repPred[[k]][,3:4],
                         col=k, add=T, trans=.2)
        }
      }
      xlab <- names(predVars)[predVars == 'gradient']
      
      ylim <- range(fecPred[[1]])
  #    if(RANDOM)ylim <- range(indEff[[1]])
      
      plot(fecPred[[1]][,1], fecPred[[1]][,2]*repPred[[1]][,2],
           type='l', lwd=2, #log = 'y',
           ylim=ylim, 
           ylab = 'seeds per tree', xlab=xlab)
      .shadeInterval(fecPred[[1]][,1],fecPred[[1]][,3:4],
                     col='darkgreen' ,add=T, trans=.2)
      if(length(fecPred) > 1){
        for(k in 2:length(fecPred)){
          lines(fecPred[[k]][,1], fecPred[[k]][,2],type='l', lwd=2)
          .shadeInterval(fecPred[[k]][,1],fecPred[[k]][,3:4],
                         col=k, add=T, trans=.2)
        }
      }
      if(RANDOM){
        tmp <- model.frame(output$inputs$randomEffect$formulaRan, 
                           output$inputs$treeData)
        tmp <- names( attr(terms(tmp),'dataClasses' ) )
        tmp <- .Iformat2Var(tmp)
        if(xlab %in% tmp){
          xx <- output$inputs$treeData[,xlab]
          reIndex <- output$inputs$randomEffect$reIndex
          
          for( m in 1:length(indEff) ){
            for(j in 1:max(reIndex)){
              kj <- which(reIndex == j)
              lines(xx[kj],indEff[[m]][kj], col=.getColor(m, .3))
            }
          }
        }
      }
    }
    
    return( list(fecPred = fecPred, repPred = repPred) ) 
  }
  
}
    

.getPredict <- function(output, newdata , plot, year, nsim, ngrid,
                        gridxy, predVars){

  
  # three modes:
  #   predVars = NULL:    map with ngrid rows
  #      newdata == NULL: from output
  #      newdata != NULL: from newdata
  #   predVars != NULL:   ngrad rows, condition on X
  
  xytrap <- NULL
  RANDOM <- YR <- GRAD <- NEW <- SAMPM <- MAP <- F
  indEffect <- xlim <- ylim <- NULL
  ngrad     <- 100
  maxF      <- output$inputs$maxF
  specNames <- output$inputs$specNames
  years     <- output$inputs$years
  plots     <- output$inputs$plots
  spec      <- specNames
  ispec     <- c(1:length(specNames))
  n         <- nrow(output$inputs$xfec)
  
  if('mgibbs' %in% names(output$chains)){
    SAMPM <- T
    specs <- output$inputs$treeData$species
    ispec <- match(specs, specNames)
  }
  if('yearEffect' %in% names(output$inputs)){
    YR <- T
    yearEffect <- output$inputs$yearEffect
    betaYrMu   <- output$parameters$betaYrMu
    yrindex    <- yearEffect$yrindex
  }
  if('randomEffect' %in% names(output$inputs)){
    RANDOM <- T
    randomEffect <- output$inputs$randomEffect
    amat         <- output$parameters$aMu
    adim         <- nrow(amat)
    xrandCols    <- randomEffect$xrandCols
    reIndex      <- randomEffect$reIndex
    alpha        <- output$parameters$alphaMu
    rnGroups     <- randomEffect$rnGroups
  }
  
  if(!is.null(predVars)){               # not map
    GRAD  <- T
    MAP   <- F
    spec  <- predVars$species       
    ispec <- match(spec, specNames)
  }
  if(!is.null(newdata)){
    NEW <- T                           # only map
    MAP <- T
  }
  
  formulaFec <- output$inputs$formulaFec
  formulaRep <- output$inputs$formulaRep
  M          <- output$inputs$M
  seedNames  <- output$inputs$seedNames
  specNames  <- output$inputs$specNames
  nspec      <- length(specNames)
  nseed      <- length(seedNames)
  treeSymbol <- NULL
  
  treeFit <- output$inputs$treeData
  treexy  <- output$inputs$xytree
  
  if( !NEW ){               # predict from output
    
    if(!GRAD){              # species, plot, year for map

      MAP <- T
      nplot <- length(plot)
      nyr   <- length(year)
      if( (nplot > 1 | max(nyr) > 1) | (is.null(plot) | is.null(year)))
        stop('map needs one plot, one year')
   #   xytree   <- output$inputs$xytree
      wt       <- which(treeFit$plot == plot & treeFit$year == year)

      if(length(wt) == 0){
        warning('combination of plot and year not in treeData')
        return(numeric(0))
      }
      treeFit  <- output$inputs$treeData[wt,]
      xytree   <- treexy[ match(treeFit$treeID, treexy$treeID ),]
      xfec     <- output$inputs$xfec[drop=F,wt,]
      xrep     <- output$inputs$xrep[drop=F,wt,]
      ispec    <- match(as.character(treeFit$species),specNames)
      
      wm     <- which(output$inputs$xytree$plot == plot)
      ws     <- which(output$inputs$xytrap$plot == plot)
      allxy  <- rbind(output$inputs$xytree[wm,c('x','y')], 
                      output$inputs$xytrap[ws,c('x','y')])
      xlim  <- range(allxy[,'x'])
      ylim  <- range(allxy[,'y'])
      
      if(RANDOM){
        xrand <- xrandMap   <- xfec[,xrandCols]
        reIndex <- reIndex[wt]
      }
      if(YR)yrindex <- yrindex[drop=F,wt,]
      
    }else{   # predVars, design is ngrad by Q, only this species
      
      spec  <- predVars$species       
      ispec <- match(spec, specNames)
      
      tmp      <- .getPredictionDesign( form = output$inputs$formulaRep, 
                                        output$inputs$treeData, 
                                        predVars, ngrad )
      xrep <- tmp$x
      xgrad    <- tmp$xgrad
      tmp      <- .getPredictionDesign( form = output$inputs$formulaFec, 
                                        output$inputs$treeData, 
                                        predVars, ngrad )
      xfec <- tmp$x
      
      if(RANDOM){
        xrand     <- xfec[,xrandCols]
        xfecFull <- output$inputs$xfec
        ind1  <- ind2 <- indz <- 
          rep(0, nrow(output$inputs$treeData)) # for full data
      }
    }
    
  }else{    # newdata, only predict seed for new map
    
    treeFit <- newdata$treeData
    xytree  <- newdata$xytree
    wt      <- match(treeFit$treeID, xytree$treeID)
    xytree  <- xytree[wt,]
    xlim    <- newdata$xlim
    ylim    <- newdata$ylim
    if(is.null(xlim) | is.null(ylim))
      stop('xlim and ylim for map must be provided in newdata')
    
    if(SAMPM){
      specs <- treeFit$species
      ispec <- match(specs, specNames)
    }
    
    if(YR){
      if(!'year' %in% names(treeFit)){
        stop('year column needed in newdata$treeData')
      }else
        yrindex <- match(treeFit$year, years)
        wna <- which(is.na(yrindex))          # out-of-sample years
        if(length(wna) > 0){
          yrindex[wna] <- sample(yrindex[-wna],replace=T)
        }
    }
    
    xfec     <- .getDesign(formulaFec, treeFit)$x
    xrep     <- .getDesign(formulaRep, treeFit)$x
    
    xfec <- xfec[,grep('species',colnames(xfec))]
    xrep <- xrep[,grep('species',colnames(xrep))]
    
    if(RANDOM){
      if(randomEffect$randGroups %in% names(treeFit)){
        reIndex <- match(treeFit[,randomEffect$randGroups], rnGroups)
      }else{
        reIndex <- NULL   # out-of-sample trees: marginalize random effects
      }
      xrand <- xfec[,xrandCols]
      ind1  <- ind2 <- rep( 0, nrow(xrand) )
    }
    
    if('treeSymbol' %in% names(newdata))
      treeSymbol <- newdata$treeSymbol[wt]
    
    remove(treeFit)
  }
  
  if(!GRAD){         # map setup
    
    maplims <- cbind(xlim,ylim)
    xb      <- .05*diff(maplims[,1])
    maplims[1] <- maplims[1] - xb
    maplims[2] <- maplims[2] + xb
    
    yb <- .05*diff(maplims[,2])
    maplims[3] <- maplims[3] - yb
    maplims[4] <- maplims[4] + yb
    
    if(!is.null(gridxy)){
      grid <- gridxy
      xs   <- sort(unique(gridxy[,'x']))
      ys   <- sort(unique(gridxy[,'y']))
      nxgrid <- length(xs)
      nygrid <- length(ys)
    }else{
      xs   <- seq(maplims[1], maplims[2], length=ngrid)
      ys   <- seq(maplims[3], maplims[4], length=ngrid)
      grid <- as.matrix( expand.grid(xs, ys) )
      colnames(grid) <- c('x','y')
      nxgrid <- nygrid <- ngrid
    }
    
    distall  <- .distmat(xytree[,'x'], xytree[,'y'], grid[,'x'], grid[,'y'])
    ns <- nrow(grid)
    sp <- sp2 <- matrix(0, ns, length(seedNames))
  }
  
  gg <- sample(output$inputs$burnin:output$inputs$ng, nsim, replace=T)
  nn <- nrow(xfec)

  fp <- fp2 <- rep(0, nrow(xfec))
  
  matGrad <- fecGrad <- matrix(NA, nsim, ngrad)
  
  pbar <- txtProgressBar(min=1,max=nsim,style=1)
  
  for(i in 1:nsim){
    
    g  <- gg[i]
    bgfec <- matrix(output$chains$bfec[g,], ncol=1)
    bgrep <- matrix(output$chains$brep[g,], ncol=1)
    sg <- output$chains$ugibbs[g,'sigma']
    ug <- output$chains$ugibbs[g,'u']
    if(SAMPM)M  <- matrix( output$chains$mgibbs[g,], nseed, nspec )
    
    muf <- xfec%*%bgfec
    if(RANDOM & GRAD)mufFull <- xfecFull%*%bgfec
    
    if(YR){
      bby <- output$chains$bygibbs[g,]
      bby <- matrix( bby, nrow(betaYrMu), ncol(betaYrMu) )
      bby[is.na(bby)] <- 0
      
      if(GRAD){                         # ngrad random years
        byi <- bby[ispec,]
        byi <- byi[is.finite(byi)]
        if(length(byi) == 0)byi <- bby[is.finite(bby)]
        yrEffect <- sample( byi, ngrad, replace=T )
        
        yrEffectFull <- bby[yrindex]
        mufFull <-  mufFull + yrEffectFull
          
      }else{                            # from design matrix, NEW or !NEW
        yrEffect <- bby[yrindex]
        yrEffect[is.na(yrEffect)] <- 0
      }
      muf <- muf + yrEffect
    }
    
    if(RANDOM){
      
      if(GRAD){
        
        A <- matrix( output$chains$agibbs[g,], adim, adim )
        arand <- rmvnormRcpp(ngrad, rep(0,nrow(A)), A)
        
        randEffFull <- rowSums( output$inputs$xfec[,xrandCols]*alpha[reIndex] )
        mufFull <- mufFull + randEffFull
        
        ze <- pnorm( output$inputs$xrep%*%bgrep )
        randFull <- exp( rnorm(length(mufFull), mufFull,
                                sqrt(sg) ) )*ze
        indz <- indz + ze
        ind1 <- ind1 + randFull
        ind2 <- ind2 + randFull^2
        
      } 
      
      if(!GRAD){       # map
  #      randomIndex <- sample(reIndex, length(muf), replace=T)
        arand <- alpha[reIndex,]
      }
      if(NEW){
        if(is.null(randomIndex)){
          randomIndex <- sample(reIndex, length(fg), replace=T)
        }
        arand <- alpha[randomIndex,]
      }
      if(is.matrix(xrand)){
        ree <- rowSums(xrand*arand)
      }else{
        ree <- sum(xrand*arand)
      }
      muf <- muf + ree
    }
    
    z  <- as.vector( pnorm(xrep%*%bgrep) )
    fg <- exp( .tnorm(nn, 1, log(maxF), muf, sqrt(sg)) )
    fg <- fg*z
    
    if(!GRAD){       # predict seed for map
      
      mm <- matrix( M[,ispec], length(fg), length(seedNames), byrow=T)
      
      if(SAMPM) fk <- fg* mm
      if(!SAMPM)fk <- matrix(fg,ncol=1)
      
      kern <- .getKern(ug, distall)
      la   <- kern%*%fk 
      pg   <- matrix(rpois(nseed*ns, la),ns,nseed)
      
      sp   <- sp + pg
      sp2  <- sp2 + pg^2
      
    }else{        # conditional prediction X
      
      matGrad[i,]  <- z
      fecGrad[i,]  <- fg
    }
    fp  <- fp + fg*z
    fp2 <- fp2 + (fg*z)^2

    setTxtProgressBar(pbar,i)
  }
  
  
  fecMu <- fp/nsim
  v     <- fp2/nsim - fecMu^2
  v[v < 0] <- 0
  fecSe <- sqrt( v )
  
  prediction <- list(fecMu = fecMu,fecSe = fecSe)
  map <- numeric(0)
  
  if(!GRAD){
    sm <- sp/nsim
    sd <- sp2/nsim - sm^2
    seedMu <- rowSums( sm, na.rm=T )
    seedSe <- rowSums( sd, na.rm=T )
    seedSe[seedSe < 0] <- 0
    seedSe <- sqrt(seedSe)
    seedMu <- matrix(seedMu, nxgrid, nygrid)
    seedSe <- matrix(seedSe, nxgrid, nygrid)
    prediction <- c(prediction, list(seedMu = seedMu, seedSe = seedSe) )
    map = list(grid = grid, xytree = xytree, x = xs, y = ys)
  }else{
    repPred <- apply(matGrad,2,quantile, c(.5,.025,.975))
    fecPred <- apply(fecGrad,2,quantile, c(.5,.025,.975))
    
    prediction <- append(prediction, list(repPred = cbind(xgrad, t(repPred)),
                                          fecPred = cbind(xgrad, t(fecPred))) )
  }
  if(RANDOM & GRAD){
    indEffMu <- ind1/nsim
    prediction <- append(prediction, list(indEffMu = indEffMu))
    
 #   indEffSe <- ind2/nsim - indEffMu^2
 #   indEffSe[ indEffSe < 0] <- 0
 #   indEffSe <- sqrt(indEffSe)
 #   prediction <- append(prediction, list(indEffMu = indEffMu, indEffSe = indEffSe))
  }
 
  list(map = map, xlim = xlim, ylim = ylim, treeSymbol = treeSymbol, prediction = prediction)
}
  
.getPredictionDesign <- function(form, data, predVars, ngrad){
    
  
    # terms in model
    tmp   <- model.frame(form, data, na.action=NULL)
    tn1   <- attr( terms(tmp), 'dataClasses' )
    fact  <- names(tn1)[tn1 == 'factor']
    numr  <- names(tn1)[tn1 == 'numeric' | tn1 == 'nmatrix.1']
    numr  <- .Iformat2Var(numr)
    
    
    
    # gradient covariate
    wgrad <- names(predVars)[predVars == 'gradient']
    xgrad <- seq(min(data[,wgrad],na.rm=T), 
                 max(data[,wgrad],na.rm=T), length=ngrad)
    
    # default mean values for covariates
    xmeans      <- colMeans(data[,numr,drop=F],na.rm=T)
    data[,numr] <- matrix(xmeans,nrow(data),length(numr),byrow=T)
    
    # fixed covariate value
    wfix <- which( sapply(predVars[numr],is.numeric) )
    if(length(wfix) > 0){
      wfix <- numr[wfix]
      data[,wfix] <- predVars[names(predVars) == wfix][1]
    }
    
    dnew <- data[1:ngrad,]
  
    dnew[,wgrad] <- xgrad
    
    # factors
    wfact <- which(fact %in% names(predVars))
    
    if(length(fact) > 0){      
      
      for(k in 1:length(fact)){
        if( fact[k] %in% names(predVars) ){     # specified level
          tk <- predVars[ fact[k] ]
        }else{                                  # most common level
          tk <- table(data[,fact[k]])
          tk <- names(tk)[which.max(tk)]
        }
        fk <- factor( rep(tk, ngrad),
                      levels = attr(data[,fact[k]],'levels') )
        dnew[,fact[k]] <- fk
      }
    }
    
    x <- .getDesign(form, dnew)$x
    list(x = x, xgrad = xgrad)
  }
  

mastSim <- function(inputs){       # setup and simulate fecundity data
  
  if(!'seedNames' %in% names(inputs))
    stop('inputs must include seedNames')
  if(!'specNames' %in% names(inputs))
    stop('inputs must include specNames')
  
  .dsim(inputs) 
}
 
.dsim <- function(inputs){
  
  nyr <- 5; ntree  <-  10; plotWide  <-  100; nplot  <-  3
  ntrap  <-  20; distance  <-  10; Q  <-  3
  seedNames <- c('piceaGlauca','piceaMariana','piceaUNKN')
  SPECS <- SAMPM <- F
  
  specNames <- Q
  
  for(k in 1:length(inputs))assign( names(inputs)[k], inputs[[k]] )
  S        <- length(specNames)
  ntrap    <- inputs$ntrap
  nplot    <- inputs$nplot
  inputs$ntree <- ntree <- rpois(nplot, inputs$ntree) + 1 # trees per plot
  inputs$ntrap <- ntrap <- rpois(nplot, ntrap) + 4        # traps per plot
  inputs$nyr   <- nyr   <- rpois(nplot, nyr) + 1
  plotNames    <- paste('p',1:nplot,sep='')
  yearNames    <- 2017 - c(max(nyr):1)
  if(length(specNames) > 1)SPECS <- T
  if(length(seedNames) > 1)SAMPM <- T
  
  upar <- (2*distance/pi)^2
  
  year <- year1 <- plot <- plot1 <- tree <- trap <- 
    plotyr <- dcol <- drow <- plotYrTrap <- numeric(0)
  k <- m <- mm <- nn <- 0
  
  for(j in 1:nplot){
    jt     <- rep( 1:nyr[j], each=ntree[j])
    pt     <- rep( 1:ntree[j], nyr[j] )
    plot   <- c(plot, rep( j, (nyr[j]*ntree[j]) ) )
    year   <- c(year, jt )
    tree   <- c(tree, rep( 1:ntree[j], nyr[j]) )
    plotyr <- c(plotyr, jt + k)
    dcol   <- c(dcol, pt + mm)
    k      <- max(plotyr)
    mm     <- max(dcol)
    
    mt     <- rep( 1:nyr[j], each=ntrap[j])
    ct     <- rep( 1:ntrap[j], each=nyr[j])
    plot1  <- c(plot1, rep( j, (nyr[j]*ntrap[j]) ) )
    year1  <- c(year1, mt )
    trap   <- c(trap, rep( 1:ntrap[j], nyr[j]) )
    plotYrTrap <- c(plotYrTrap, mt + m)
    drow   <- c(drow, ct + nn)
    m      <- max(plotYrTrap)
    nn     <- max(drow)
  }
  
  treeIndex <- data.frame(plotNames[plot], yearNames[year], tree, 
                          plotyr, dcol )
  colnames(treeIndex)[1:2] <- c('plot','year')
  n    <- nrow(treeIndex)
  
  treeid <- apply(treeIndex[,c('plot','tree')],1,paste0, collapse='-')
  id <- sort(unique(treeid))
  species <- sample(specNames, length(id), replace=T) 
  species <- factor(species[match(treeid,id)], levels = specNames)
  
  trapIndex <- data.frame(plotNames[plot1],yearNames[year1], trap, 
                          plotYrTrap, drow )
  colnames(trapIndex)[1:4] <- c('plot','year','trap','plotyr')
  
  xfec <- round( matrix( rnorm(n*Q, 0, 1), n, Q ), 3)
  xnames <- paste('x',1:Q,sep='')
  colnames(xfec) <-  xnames
  
  xdata   <- data.frame( species = species, xfec)
  
  ########################
  ii      <- paste0( paste(xnames,sep=''), collapse=' + ' )
  formula <- as.formula( paste( '~' ,ii) )
  
  if(SPECS){
    ii      <- paste0( paste('species*',xnames,sep=''), collapse=' + ' )
    formula <- as.formula( paste( '~' ,ii) ) 
  }
  xrep    <- model.matrix(formula, xdata)
  QS      <- ncol(xrep)
  xfec    <- xrep
  
  if(!SPECS){
    ss     <- paste('species',specNames,sep='')
    xnames <- paste(ss,colnames(xfec),sep=':')
    xnames[1] <- .replaceString(xnames[1],':(Intercept)','')
    colnames(xfec) <- colnames(xrep) <- xnames
  }
  #############################
    
  xytree <- xytrap <- distall <- numeric(0)
  
  for(j in 1:nplot){
    
    xy1 <- matrix( runif(2*ntree[j],0,plotWide), ntree[j],2)  
    xy2 <- matrix( runif(2*ntrap[j],0,plotWide), ntrap[j],2)
    xy1 <- signif(xy1,2)
    xy2 <- signif(xy2,2)
    
    rownames(xy1) <- apply( cbind(rep(plotNames[j],ntree[j]),c(1:ntree[j]) ), 1, 
                            paste0,collapse='_')
    
    rownames(xy2) <- apply( cbind(rep(plotNames[j],ntrap[j]),c(1:ntrap[j])), 1, 
                            paste0,collapse='_')
    xytree  <- rbind(xytree, xy1)
    xytrap  <- rbind(xytrap, xy2)
  }
  
  treeData <- cbind(treeIndex,xdata)
  count <- matrix(0,nrow(trapIndex), length(seedNames))
  colnames(count) <- seedNames
  seedData <- data.frame(trapIndex, count)
  
  colnames(xytree) <- colnames(xytrap) <- c('x','y')
  xy <- matrix( unlist( strsplit(rownames(xytree),'_') ), ncol=2, byrow=T )
  colnames(xy) <- c('plot','tree')
  xytree <- data.frame( xy, xytree )
  
  xy <- matrix( unlist( strsplit(rownames(xytrap),'_') ), ncol=2, byrow=T )
  colnames(xy) <- c('plot','trap')
  xytrap <- data.frame( xy, xytrap )
  
  formulaFec  <- formulaRep <- formula
  
  formulaFec <- .specFormula(formulaFec)
  formulaRep <- .specFormula(formulaRep)
  
  tmp <- .setupData(formulaFec, formulaRep, treeData, seedData, 
                    xytree, xytrap, specNames, seedNames)
  treeData  <- tmp$treeData
  seedData  <- tmp$seedData
  distall   <- tmp$distall
  xytree    <- tmp$xytree
  xytrap    <- tmp$xytrap
  plotNames <- tmp$plotNames
  plots     <- tmp$plots
  years     <- tmp$years
  xfec      <- tmp$xfec
  xrep      <- tmp$xrep
  nseed     <- nrow(seedData)
  scode     <- tmp$scode
  nplot     <- length(plotNames)
  n         <- nrow(xfec)
  ntobs     <- table(treeData$plot) 
  nsobs     <- table(seedData$plot)
  ttab      <- table(treeData$plot, treeData$year)
  wtab      <- which(ttab > 0, arr.ind=T) 
  nyr       <- table(wtab[,1])
  distTree  <- tmp$distTree
  distTrap  <- tmp$distTrap
  xfecMiss <- tmp$xfecMiss
  xrepMiss <- tmp$xrepMiss
  xfecCols <- tmp$xfecCols
  xrepCols <- tmp$xrepCols
  ntree    <- nrow(xytree)
  ntrap    <- nrow(xytrap)
  
  nc   <- ceiling(max(nyr)/2)
  rmat <- matrix(0, ntree, max(nyr))
  rmat[ cbind(1:ntree, sample(c(1:nc),ntree,replace=T)) ] <- 1
  
  tyindex <- cbind(treeData$dcol, match(treeData$year,years))
  
  #include unknown status
  nnot <- round(nrow(rmat)*ncol(rmat)/4)
  zknown <- rmat
  zknown[sample(length(rmat),nnot)] <- NA
  
  tmp <- .getRepro(zknown)
  last0first1 <- tmp$last0first1
  zmat  <- tmp$imat

  z    <- zmat[ tyindex ] 
  zmat[is.na(rmat)] <- NA
  zm    <- zmat[ tyindex ] 
  treeData$repr <- zm          #NA in repr column
  
  lo <- hi <- z*0
  hi[z == 1] <- Inf
  lo[z == 0] <- -Inf
  w <- .tnorm(nrow(xrep), lo, hi, 0, 1)
  
  betaRep  <- solve(crossprod(xrep))%*%crossprod(xrep,w)
  w <- .tnorm(nrow(xrep), lo, hi, xrep%*%betaRep, 1)
  
  M  <- .getM(specNames, seedNames, unknown = 'UNKN', unFraction = .8)

  seedData$active <- 1
  seedData$area   <- 1
  
  # all log scale
  ffec <- .tnorm(nrow(xfec), lo, hi, 8*w, 8) 
  XX   <- crossprod(xfec[z == 1,])
  diag(XX) <- diag(XX) + .000001
  betaFec  <- solve(XX)%*%crossprod(xfec[z == 1,],ffec[z == 1])
  ffec <- .tnorm(length(z), lo, hi, xfec%*%betaFec, .01)
  betaFec  <- solve(XX)%*%crossprod(xfec[z == 1,],ffec[z == 1])
  
  fec    <- as.vector( exp( .tnorm(length(z), lo, hi, xfec%*%betaFec, .001) ) )
  
  lambda <- .getLambda(upar, fec, z, M, SAMPM, seedData, 
                       treeData, distall, years, PERAREA=F) 
  
  seedData[,seedNames] <- rpois(length(lambda),lambda)  
  seedData$active <- 1
  seedData$area   <- 1
  
  stab <- with( seedData, table(plot, year) )
  ttab <- with( treeData, table(plot, year) )
  sc   <- colSums(stab)
  stab <- stab[,sc > 0, drop=F]
  ttab <- ttab[,sc > 0, drop=F]
  
  form <- as.character( formulaFec )
  form <- .replaceString( form, 'species *', '')
  formulaFec <- as.formula(form)
  
  
  wu <- grep('unstand', names(treeData))
  treeData <- treeData[,-wu]
  
  trueValues <- list(fMat = fec*z, z = z, betaFec = betaFec, betaRep = betaRep,
                     upar = upar, M = M)
  
  list(trueValues = trueValues, treeData = treeData, seedData = seedData, 
       distall = distall, xytree = xytree, xytrap = xytrap, formulaFec = formulaFec,
       formulaRep = formulaFec, plots = plots, years = years,
       inputs = inputs, xfec = xfec, xrep = xfec, 
       sample = list(seeds = stab, trees = ttab))
}

.seedFormat <- function(sfile, lfile, trapFile = NULL, seedNames = NULL, genusName = NULL,
                        omitNames = NULL, plot, trapID ) {
  
  if(is.null(trapFile))trapFile <- "/Users/jimclark/makeMast/dataFiles/seedTrapArea.txt"
  
  loc  <- read.table(lfile, header=T)
  if(!'x' %in% colnames(loc)){
    xy <- loc[,c('UTMx','UTMy')]
    xy <- round(sweep(xy,2,colMeans(xy),'-'),1)
    loc$x <- xy[,1]
    loc$y <- xy[,2]
  }
  loc  <- loc[is.finite(loc[,'UTMx']) & is.finite(loc[,'UTMy']),]
  pcol <- rep(plot, nrow(loc))
  id   <- apply( cbind(plot, loc[,trapID]), 1, paste0, collapse='-')
  loc  <- data.frame(trapID = id, trap = loc[,trapID], 
                     loc[,!colnames(loc) == trapID])
  loc$plot <- pcol
  loc$UTMx <- loc[,'UTMx']
  loc$UTMy <- loc[,'UTMy']
  
  counts <- read.table(sfile, header=T)
  counts[is.na(counts$month),'month'] <- 3
  counts[counts[,'month'] < 6,'year'] <- counts[counts[,'month'] < 6,'year'] - 1
  
  if(is.null(genusName)){
    sj <- counts[,colnames(counts) %in% seedNames, drop=F]
  }else{
    sj <- counts[,grep(genusName, colnames(counts)), drop=F]
    seedNames <- colnames(sj)
  }
  if(!is.null(omitNames)){
    sj <- sj[,!colnames(sj) %in% omitNames, drop=F]
    seedNames <- colnames(sj)
  }
  
  if(length(sj) == 0){
    sj <- matrix(0,nrow(counts),1)
    seedNames <- colnames(sj) <- paste(genusName,'UNKN',sep='')
  }
  
  yr <- sort(unique(counts[,'year']))
  tn <- sort(unique(counts[,trapID]))
  jj <- match(counts[,'year'],yr)
  ii <- match(counts[,trapID],tn)
  smat <- matrix(0, length(tn), length(yr))
  
  seedj <- numeric(0)
  
  for(k in 1:ncol(sj)){
    
    # seed counts
    ck <- sj[,k]
    wk <- which(is.finite(ck))
    ck <- ck[wk]
    ik <- ii[wk]
    jk <- jj[wk]
    ky <- .myBy(ck, ik, jk, summat=smat, fun='sum')
    sy <- .myBy(ck*0 + 1, ik, jk, summat=smat, fun='sum')
    colnames(ky) <- yr
    rownames(ky) <- tn
    seedj <- cbind(seedj, as.vector(ky))
    if(k == 1)active <- sy/matrix( apply(sy,2,max), nrow(sy), ncol(sy), byrow=T)
  }
  colnames(seedj) <- colnames(sj)
  seed <- matrix(0, nrow(seedj), length(seedNames))
  colnames(seed) <- seedNames
  
  active <- as.vector(active)
  area <- read.table(trapFile,header=T)[,c('plot','seedArea')]
  area <- area[area$plot == as.character(plot[1]),'seedArea']
  
  seed[,colnames(seedj)] <- seedj
  
  year <- rep(yr, each = length(tn))
  trap <- rep(tn, length(yr) )
  plot <- rep(plot, length(trap))
  tr <- apply(cbind(plot, trap), 1, paste0, collapse='-')
  sd   <- data.frame( plot=plot, trapID=tr, trap=trap, year=year,
                      active=active, area = area) 
  seed <- cbind(sd, seed)
  rownames(seed) <- 
    apply( cbind(plot, trap, year), 1, paste0, collapse='-')
  
  seed <- seed[seed$trapID %in% loc$trapID,]
  
  
  list(counts = seed, xy = loc, active = active, seedNames = seedNames )
}


.getRepro <- function(rmat){
   
   nc <- ncol(rmat)
   nr <- nrow(rmat)
      
  zeros <- ones <- ind <- matrix(1:nc, nr, nc, byrow=T)
  ones  <- ones*rmat
  ones[ones == 0] <- NA
  first1  <- suppressWarnings(apply(ones, 1, min, na.rm=T)) # this is first 1
  ones  <- matrix( first1, nr, nc)
  ones[ones <= ind] <- 1
  ones[ones > ind] <- 0
  first1[first1 == Inf] <- ncol(rmat) + 1
  
  zeros <- zeros*(1 - rmat)
  zeros[ ones == 1 ] <- 0
  last0  <- suppressWarnings(apply(zeros, 1, max, na.rm=T)) # this is last 0
  zeros  <- matrix( last0, nr, nc)
  zeros[ zeros == 0] <- NA
  zeros[ zeros == -Inf ] <- NA
  zeros[zeros < ind] <- 0
  zeros[zeros >= ind] <- 1
  rmat[ ones == 1 ] <- 1
  rmat[ zeros == 1 ] <- 0
  last0[last0 < 0] <- 0
  
  zmat <- matrix(last0, nr, nc)
  omat <- matrix(first1, nr, nc)
  imat <- matrix(1:nc, nr, nc, byrow=T)
  
  rones <- which(imat > zmat,arr.ind=T)                 #zeros
  rzero <- which(imat <= omat,arr.ind=T)                #ones
  rboth <- which(imat > zmat & imat <= omat,arr.ind=T)  #both
  repStatus <- list(zeros = rzero, ones = rones, either = rboth)
  
 
  last0first1 <- cbind(last0, first1)
  
  mu <- round( rowMeans(last0first1, na.rm=T) )
  mu[mu < 1] <- 1
  mu[mu > ncol(imat)] <- ncol(imat)
  
  imat <- imat*0
  imat[is.na(imat)] <- 0
  imat[cbind(1:nrow(imat),mu)] <- 1
  imat <- t( apply(imat,1,cumsum) )
  imat[last0first1[,1] == ncol(imat), ] <- 0
  
  all0 <- all1 <- last0first1[,1]*0
  all1[last0first1[,2] == 1] <- 1
  all0[last0first1[,1] == nc] <- 1
  last0first1 <- cbind(last0first1, all0, all1)
  mu[last0first1[,2] == 1] <- 0
  mu[last0first1[,1] == ncol(imat)] <- ncol(imat) + 1
  
  list(rmat = rmat, imat = imat, matYr = mu,
       repStatus = repStatus, last0first1 = last0first1)
}

.treeFormat <- function( tfile, specNames = NULL, genusName = NULL, changeNames = NULL, 
                         plot, years, yrCols  ){
  
  region <- unlist(strsplit(plot,'_'))[1]
  trees  <- read.table( tfile, header=T)

  
  if(is.null(genusName)){
    wj     <- which(trees$species %in% specNames & is.finite(trees$x) &
                      is.finite(trees$y))
  }else{
    ww <- grep(genusName,trees$species)
    wj <- ww[which(is.finite(trees$x[ww]) & is.finite(trees$y[ww]))]
    specNames <- sort(unique(trees$species[wj]))
  }
  if(length(wj) == 0)return( list(yrDat = numeric(0)) )
  
  trees  <- trees[drop=F,wj,]
  wchange <- which( as.character(trees$species) %in% changeNames[,1])
  if(length(wchange) > 0){
    ts <- as.character(trees$species)
    wm <- match(ts[wchange],changeNames[,1])
    ts[wchange] <- changeNames[wm,2]
    trees$species <- as.factor(ts)
  }
  
  for(k in 1:length(yrCols)){                      # yrCol2017
    
    tk <- as.matrix( trees[,grep(yrCols[k],colnames(trees))] )
    wmin <- suppressWarnings( apply(tk,1,min, na.rm=T) )
    wna <- which(! is.finite( wmin ) )
    if(length(wna) > 0)trees <- trees[-wna,]
  }
  if(nrow(trees) == 0)return( list(yrDat = numeric(0)) )
  
  trees$species <- droplevels(trees$species) 
  
  # trees with multiple stems
  im     <- trees[,'ID']
  ID     <- floor(im)
  dup    <- which(duplicated(ID))
  diamCol <- grep('diam',colnames(trees))
  
  if(length(dup) > 0){
    
    omit <- numeric(0)
    
    for(j in dup){
      
      idup <- which(ID == ID[j])
      tj   <- apply(trees[idup,diamCol], 1, max, na.rm=T)
      tj   <- which.max(tj)
      omit <- c(omit, idup[-tj])
    }
    omit <- unique(omit)
    trees <- trees[-omit,]
    trees$ID <- floor(trees$ID)
  }
  
  scols <- trees[,grep('sex',colnames(trees))]
  
  ccol <- matrix( unlist( strsplit(colnames(scols),'sex') ), ncol=2,byrow=2)[,2]
  colnames(scols) <- ccol
  
  snew <- matrix(NA, nrow(trees), length(years))
  colnames(snew) <- years
  
  snot <- which(scols == 'N', arr.ind=T)
  srep <- which(scols == 'R' | scols == 'F', arr.ind=T)
  sfem <- which(scols == 'F', arr.ind=T)
  smal <- which(scols == 'M', arr.ind=T)
  
  smal <- smal[!smal[,1] %in% sfem[,1],]  # female overrides male
  if(!is.matrix(smal))smal <- matrix(smal,1)
  
  matr <- repr <- matrix(NA, nrow(trees), ncol(scols))
  colnames(matr) <- ccol
  repr[smal[,1],] <- 0
  repr[sfem[,1],] <- 1
  
  matr[snot] <- 0
  matr[srep] <- 1
  
  #########
  
  snew[,colnames(matr)] <- matr
  
  tmp <- .getRepro(snew)
  snew <- tmp$rmat
  #  repStatus <- tmp$repStatus
  
  yrDat  <- matrix(NA, length(years)*nrow(trees), length(yrCols))
  id     <- sort( unique(trees[,'ID']) )
  tindex <- rep(id, each=length(years) )
  yindex <- rep(years, length(id) )
  
  elev <- NA
  if('elev' %in% colnames(trees))elev <- trees[,'elev']
  
  xytree <- trees[,c('x','y','UTMx','UTMy')]
  id     <- apply( cbind(plot, trees[,'ID']), 1, paste0, collapse='-')
  xytree <- data.frame(treeID = id, plot = plot, tree = trees[,'ID'], xytree)
  xytree$elev <- elev
  
  index <- apply(cbind(tindex,yindex),1,paste0,collapse='-')
  rownames(yrDat) <- index
  colnames(yrDat) <- yrCols
  
  for(k in 1:length(yrCols)){                      # yrCol2017
    
    tk <- as.matrix( trees[,grep(yrCols[k],colnames(trees))] )
    kk <- matrix( unlist(strsplit(colnames(tk),yrCols[k])), ncol=2,byrow=T)[,2]
    yk <- as.numeric(kk)
    
    syr  <- trees[,'censinyr']                             # left censored
    imat <- matrix(years, nrow(trees), length(years), byrow=T) 
    wmin <- which(is.finite(tk),arr.ind=T)                 # measurements exist
    tmp  <- .myBy( years[wmin[,2]], wmin[,1], wmin[,1]*0+1, fun='min')
    syr  <- pmin(syr, tmp, na.rm=T)
    
    syr  <- matrix(syr, nrow(trees), length(years))           # start
    eyr  <- suppressWarnings( apply(trees[,c('deathyr','censoryr')],1,min, na.rm=T) )
    eyr  <- matrix(eyr, nrow(trees), length(years))               # end
    eyr[eyr == Inf] <- max(years) 
    imat[imat < syr | imat > eyr] <- NA
    tmat <- matrix(trees[,'ID'], nrow(tk), length(years))
    
    dmat <- matrix(NA, nrow(tk), length(years))
    icol <- match(yk, years)
    irow <- rep(1:nrow(tk),each=length(icol))
    icol <- rep(icol, nrow(tk))
    jcol <- rep(1:length(yk),nrow(tk))
    dmat[ cbind(irow,icol) ] <- tk[ cbind(irow, jcol) ]   # interpolate here
    
    start <- match( suppressWarnings( apply(imat,1,min,na.rm=T)), years)
    end   <- match( suppressWarnings( apply(imat,1,max,na.rm=T)), years)
    
    wf <- which(is.finite(start) & is.finite(end) & end > start)
    
    minVal <- 0
    maxVal <- 100
    if(yrCols[k] == 'canopy'){
      minVal <- 0
      maxVal <- 2
    }
    
    
    
    tmp <- .interpRows(dmat[drop=F,wf,],startIndex=start[wf],endIndex=end[wf],
                       INCREASING=F,minVal=minVal,maxVal=maxVal,
                       defaultValue=NULL,tinySlope=.001)
    dmat[wf,] <- tmp
    
    if(yrCols[k] == 'canopy'){
      maxVal <- suppressWarnings( apply(dmat[drop=F,wf,], 1, max,na.rm=T) )
      wmm    <- which(is.finite(maxVal))
      mmat   <- matrix(maxVal[wmm],length(wmm),ncol(tmp))
      ww     <- which(tmp[wmm,] > mmat)
      tmp[wmm,][ww] <- mmat[ww]
    }
    
    dvec <- dmat[is.finite(imat)]
    
    it   <- tmat[is.finite(imat)]
    iy   <- imat[is.finite(imat)]
    inn  <- apply(cbind(it,iy),1,paste0,collapse='-')
    yrDat[match(inn, index),k] <- dvec
    
    if(yrCols[k] == 'diam'){
      dinc <- t(apply(dmat,1,diff,na.rm=T))
      dinc <- cbind(dinc[,1],dinc)
      dinc <- dinc[is.finite(imat)]
      growth  <- rep(0,nrow(yrDat))
      growth[match(inn, index)] <- dinc
    }
  }
  
  if('diam' %in% yrCols){
    yrDat <- cbind(yrDat,growth)
  }
  
  spec <- trees[match(tindex,trees[,'ID']),'species']
  repr <- rep(NA, nrow(yrDat))
  repr[match(inn, index)] <- snew[is.finite(imat)]
  
  
  plot   <- rep(plot, length(tindex))
  treeID <- apply(cbind(plot, tindex),1,paste0, collapse='-')
  yrDat <- data.frame(treeID = treeID, tree = tindex, species = spec, 
                      year = yindex, region = region,
                      plot = plot, repr = repr, yrDat)
  yrDat <- yrDat[is.finite(yrDat$diam) & yrDat$diam > 1,]
  xytree <- xytree[xytree$treeID %in% yrDat$treeID,]
  
  rownames(yrDat) <- NULL
  
  list(yrDat = yrDat, xytree = xytree)
}

.fac2num <- function(xx){ 
  
  dims <- dn <- NULL
  
  if(!is.null(ncol(xx))){
    dims <- dim(xx)
    dn   <- dimnames(xx)
  }
  xx <- if(is.list(xx))unlist(xx)
  xx <- as.numeric(as.character(xx)) 
  if(!is.null(dims))xx <- matrix(xx, dims[1], dims[2], 
                                 dimnames = dn)
  xx
}

.replaceString <- function(xx,now='_',new=' '){  #replace now string in vector with new
  
  ww <- grep(now,xx,fixed=T)
  if(length(ww) == 0)return(xx)
  
  for(k in ww){
    s  <- unlist( strsplit(xx[k],now,fixed=T) )
    ss <- s[1]
    if(length(s) == 1)ss <- paste( ss,new,sep='')
    if(length(s) > 1)for(kk in 2:length(s)) ss <- paste( ss,s[kk],sep=new)
    xx[k] <- ss
  }
  xx
}

.Iformat2Var <- function(iname){
  
  tt <- .replaceString(iname, 'I(','')
  tt <- .replaceString(tt, 'log(','')
  tt <- .replaceString(tt, 'sqrt(','')
  tt <- .replaceString(tt, '^2','')
  tt <- .replaceString(tt, ')','')
  tt <- .replaceString(tt, ' ','')
  tt
}

.getDesign <- function(formula, data){
  
  # one set of columns for each tree species, retain NAs
  
  specNames <- attr(data$species,'levels')
  nspec     <- length(specNames)
  
  attr(data$species,'contrasts') <- contrasts(data$species, contrasts=F)
  
  tmp1 <- model.frame(formula, data, na.action=NULL )
  tn1  <- attr( terms(tmp1), 'dataClasses' )
  sp1  <- names(tn1)[tn1 == 'numeric' | tn1 == 'nmatrix.1']
  sp1  <- .Iformat2Var(sp1)
  miss <- which(is.na(data[,sp1]),arr.ind=T)
  
  if(length(miss) > 0){
    xmean <- colMeans(data[,sp1], na.rm=T)
    data[,sp1][miss] <- 1e+8
  }
  
  x  <- model.matrix(formula, data)
  if(nspec > 1){
    ws <- grep('species',colnames(x))
    x  <- x[,ws]
  }
  missx <- which(x > 1e+5,arr.ind=T)
  
  if(length(missx) > 0){
    data[,sp1][miss] <- xmean[miss[,2]]
  }
  x  <- model.matrix(formula, data)
  if(nspec > 1){
    ws <- grep('species',colnames(x))
    x  <- x[,ws]
  }
  
  # specNames <- attr(data$species,'levels')
  specCols  <- numeric(0)
  if(nspec > 1){
    for(j in 1:length(specNames)){
      specCols <- rbind(specCols, grep( paste('species',specNames[j],sep=''),
                                        colnames(x)))
    }
    rownames(specCols) <- specNames
  }
  
  list(x = x, missx = missx, specCols = specCols)
}

.setupData <- function(formulaFec, formulaRep, treeData, seedData, 
                       xytree, xytrap, specNames, seedNames){
  
  # formulas have 'species *' already
  
  if(!'active' %in% colnames(seedData)){
    warning('"active" column added to seedData')
    seedData$active <- 1
  }
  if(!'area' %in% colnames(seedData)){
    warning('"area" column added to seedData')
    seedData$area <- 1
  }
  wna <- which(is.na(seedData$active) | seedData$active == 0)
  if(length(wna) > 0){
    warning('some seedData$active values undefined')
    seedData$active[wna] <- .1
  }
  wna <- which(is.na(seedData$area) | seedData$area == 0)
  if(length(wna) > 0){
    warning('some seedData$area values undefined or zero')
    seedData$area[wna] <- 1
  }
  wna <- which(!seedData$trap %in% xytrap$trap)
  if(length(wna) > 0){
    mm <- paste0(seedData$trap[wna], collapse=', ')
    stop(paste('missing traps in xytrap: ',mm,sep=''))
  }
  
  wna <- which(!treeData$tree %in% xytree$tree)
  if(length(wna) > 0){
    mm <- paste0(treeData$tree[wna], collapse=', ')
    treeData <- treeData[-wna,]
    warning(paste('removed trees missing in xytree: ',mm,sep=''))
  }
  wna <- which(is.na(treeData$diam))
  if(length(wna) > 0){
    mm <- paste0(treeData$tree[wna], collapse=', ')
    treeData <- treeData[-wna,]
    warning(paste('removed trees with missing diam: ',mm,sep=''))
  }
  
  tree <- treeData
  w    <- which(tree$species %in% specNames)
  tree <- tree[w,]
  tree$species <- droplevels(tree$species)
  
  
  specTab <- table(tree$species)
  wna <- which(specTab < 3)
  if(length(wna) > 0){
    rn <- paste0(names(specTab)[wna],collapse=', ')
    specNames <- specNames[!specNames %in% names(specTab)[wna]]
    warning( paste('too rare:',rn, ', removed'))
  }
  
  
  ttab <- table(tree$species)
  wna  <- which(ttab < 20)
  if(length(wna) > 0){
    slo <- paste0(names(ttab)[wna],collapse = ', ')
    warning(paste('less than 20 individuals for',slo))
  }
  
  treeID   <- apply(tree[,c('plot','tree')],1,paste0,collapse='-')
  treeID   <- .replaceString(treeID,' ','')
  tree     <- cbind(treeID, tree)
  
  treeID   <- apply(xytree[,c('plot','tree')],1,paste0,collapse='-')
  treeID   <- .replaceString(treeID,' ','')
  xytree$treeID   <- treeID
  xytree   <- xytree[xytree$treeID %in% tree$treeID,]
  
  trapID   <- apply(seedData[,c('plot','trap')],1,paste0,collapse='-')
  trapID   <- .replaceString(trapID,' ','')
  seedData$trapID <- trapID
  
  trapID   <- apply(xytrap[,c('plot','trap')],1,paste0,collapse='-')
  trapID   <- .replaceString(trapID,' ','')
  xytrap$trapID <- trapID
  
  # retain trees in plot-years that have seed traps
  py1  <- apply(tree[,c('plot','year')],1,paste0,collapse='-')  
  py2  <- apply(seedData[,c('plot','year')],1,paste0,collapse='-')
  keep <- which(py1 %in% py2)
  
  tree$plotYr <- py1
  tree        <- tree[keep,]
  seedData$plotYr <- py2
  xytree          <- xytree[xytree$treeID %in% tree$treeID,]
  
  wna <- which(!seedData$trapID %in% xytrap$trapID)
  if(length(wna) > 0){
    mm <- paste0(seedData$trapID[wna], collapse=', ')
    stop(paste('missing traps in xytrap: ',mm,sep=''))
  }
  wna <- which(!treeData$treeID %in% xytree$treeID)
  if(length(wna) > 0){
    mm <- paste0(treeData$treeID[wna], collapse=', ')
    stop(paste('missing trees in xytree: ',mm,sep=''))
  }
  
  
  # when tree census not in seed year
  
  ww <- which(!seedData$plotYr %in% tree$plotYr)
  
  if(length(ww) > 0){
    
    allPlotYr <- sort(unique(seedData$plotYr))
    newPlotYr <- which(!seedData$plotYr %in% tree$plotYr)
    tmp <- data.frame( lapply(tree[1,],rep,length(allPlotYr)) )
    tmp$plotYr <- allPlotYr
    wpmat      <- matrix( unlist(strsplit(allPlotYr,'-')),ncol=2,byrow=T)
    tmp$plot   <- factor(wpmat[,1])
    tmp$year   <- as.numeric(wpmat[,2])
    
    rtmp <- tmp[!tmp$plotYr %in% tree$plotYr,]
    
    rplot <- as.character(rtmp$plot)
    tplot <- as.character(tree$plot)
    
    newRows <- numeric(0)
    
    for(m in 1:nrow(rtmp)){
      wr  <- which(tplot %in% rplot[m])
      if(length(wr) == 0)next
      wt  <- which(rplot == rplot[m])
      nr  <- length(wt)
      for(i in 1:length(wr)){
        new <- data.frame( lapply(tree[wr[i],],rep,nr) )
      
        new$year <- rtmp$year[wt]
        new$plotYr <- rtmp$plotYr[wt]
        newRows <- rbind(newRows,new)
        tplot[wr[i]] <- 'out'
      }
    }
    newRows <- rbind(tree,newRows)
    tree   <- newRows[order(newRows$plot,newRows$tree,newRows$year),]
  }
  
  plots <- sort(unique( as.character(xytrap$plot) ))
  years <- as.numeric( sort(unique( as.character(seedData$year) )) )
  nplot <- length(plots)
  
  
  seedSummary <- with(seedData, table(plot, year) )
  treeSummary <- with(tree, table(plot, year) )
  plotNames   <- rownames(seedSummary)
  
  tmp   <- model.frame(formulaFec, tree, na.action=NULL)
  xfecMiss <- which(is.na(tmp),arr.ind=T)
  
  scode <- names(tmp[ which(sapply( tmp, is.factor )) ])
  if(length(scode) > 0){
    for(j in 1:length(scode)){
      tree[,scode[j]] <- droplevels(tree[,scode[j]])
    }
  }
  standX <- character(0)
  xmean <- xsd <- numeric(0)
  
  wstand <- which(!colnames(tmp) %in% scode)
  
  if(length(wstand) > 0){
    
    standX    <- colnames(tmp)[wstand]
    
    wlog <- grep( "log(", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    wlog <- grep( "sqrt(", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    
    if(length(standX) > 0){
      
      xmean <- colMeans(tree[,standX, drop=F],na.rm=T)
      xsd   <- apply(tree[,standX, drop=F],2, sd, na.rm=T)
      xss <- t( (t(tree[,standX, drop=F]) - xmean)/xsd )
      std <- tree[,standX, drop=F]
      colnames(std) <- paste(standX,'unstand',sep='')
      tree <- cbind(tree, std)
      if(ncol(std) == 1)colnames(tree)[ncol(tree)] <- paste(standX,'unstand',sep='')
      tree[,standX] <- xss
    }
  }
  
  tmp   <- model.frame(formulaRep, tree, na.action=NULL)
  xrepMiss <- which(is.na(tmp),arr.ind=T)
                    
  scode <- names(tmp[ which(sapply( tmp, is.factor )) ])
  if(length(scode) > 0){
    for(j in 1:length(scode)){
      tree[,scode[j]] <- droplevels(tree[,scode[j]])
    }
  }
  wstand <- which(!colnames(tmp) %in% scode & !colnames(tmp) %in% standX)
  if(length(wstand) > 0){
    standX    <- colnames(tmp)[wstand]
    
    wlog <- grep( "log(", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    wlog <- grep( "sqrt(", standX, fixed = T)
    if(length(wlog) > 0)standX <- standX[ -wlog ]
    
    if(length(standX) > 0){
      xmean <- colMeans(tree[,standX],na.rm=T)
      xsd   <- apply(tree[,standX],2, sd, na.rm=T)
      tree[,standX] <- t( (t(tree[,standX]) - xmean)/xsd )
      std <- tree[,standX]
      colnames(std) <- paste(standX,'unstand',sep='')
      tree <- cbind(tree, std)
    }
  }
  
 # if(length(specNames) == 1){
 #   form <- as.character( formulaFec )
 #   ww <- grep('species *', form)
 #   if(length(ww) > 1){
 #     form <- .replaceString( form, 'species *', '')
 #     formulaFec <- as.formula(form)
 #   }
 #   form <- as.character( formulaRep )
 #   ww <- grep('species *', form)
 #   if(length(ww) > 1){
 #     form <- .replaceString( form, 'species *', '')
 #     formulaRep <- as.formula(form)
 #   }
 # }
  
  tmp  <- .getDesign(formulaFec, tree)
  xfec <- tmp$x
  xfec <- xfec[,grep('species',colnames(xfec))]
  xfecMiss <- tmp$missx
  xfecCols <- tmp$specCols
  
  tmp  <- .getDesign(formulaRep, tree)
  xrep <- tmp$x
  xrep <- xrep[,grep('species',colnames(xrep))]
  xrepMiss <- tmp$missx
  xrepCols <- tmp$specCols
  
  rank <- qr(xfec)$rank
  if(rank < ncol(xfec))stop('fecundity design not full rank')
  rank <- qr(xrep)$rank
  if(rank < ncol(xrep))stop('maturation design not full rank')
  
  xfecU <- xfec
  xrepU <- xrep
  xfecT <- xrepT <- NULL
  
  if(length(xmean) > 0){   # unstandardized
    
    tmp <- .unstandBeta(xstandNames = names(xmean), formula = formulaFec, 
                        xdata = tree, xfec)
    xfecU <- tmp$x
    xfecT <- tmp$trans
    
    tmp <- .unstandBeta(xstandNames = names(xmean), formula = formulaRep, 
                        xdata = tree, xrep)
    xrepU <- tmp$x
    xrepT <- tmp$trans
  }
    
  
  distall <- numeric(0)
  distTree <- distTrap <- numeric(0)
  
  treeid <- trapid <- plotRm <- character(0)
  
  for(j in plotNames){
    
    tj <- which(xytree$plot == j)
    sj <- which(xytrap$plot == j)
    
    if(length(tj) == 0){
      plotRm <- c(plotRm,j)
      warning(paste('plot ',j,' is absent from xytree'))
      next
    }
    if(length(sj) == 0)stop( paste('plot', j ,'has no traps in xytrap') )
    
    xy1     <- xytree[tj,]
    xy2     <- xytrap[sj,]
    treeid  <- c(treeid,xytree$treeID[tj])
    trapid  <- c(trapid,xytrap$trapID[sj])
    da      <- .distmat(xy1[,'x'],xy1[,'y'],xy2[,'x'],xy2[,'y']) 
    distall <- .blockDiag(distall,da)
    distTree <- append(distTree, list(tj) )
    distTrap <- append(distTrap, list(sj) )
  }
  
  if(length(plotRm) > 0){
    plots <- plots[!plots %in% plotRm]
    plotNames <- plotNames[!plotNames %in% plotRm]
    wr <- which(seedData$plot %in% plotRm)
    seedData <- seedData[-wr,]
  }
  names(distTree) <- names(distTrap) <- plotNames
  distall[distall == 0] <- 10000
  rownames(distall) <- trapid
  colnames(distall) <- treeid
  
  dcol <- match(tree$treeID, treeid)
  drow <- match(seedData$trapID, trapid)
  
  tree$dcol <- dcol
  seedData$drow <- drow
  
  pall <- sort(unique(tree$plotYr))
  tree$plotyr <- match(tree$plotYr,pall)
  
  pall <- sort(unique(seedData$plotYr))
  seedData$plotyr <- match(seedData$plotYr,pall)
  
 # plots <- sort(unique(seedData$plot))
  
  
  keepCol <- c('plot','year','trap','trapID','plotyr','plotYr','drow',
               'area','active',seedNames)
  seedData <- seedData[,keepCol]
  
  list(treeData = tree, seedData = seedData, distall = distall,
       specNames = specNames,
       xytree = xytree, xytrap = xytrap, plotNames = plotNames,
       plots = plots, years = years, xfec = xfec, xrep = xrep, scode = scode,
       distTree = distTree, distTrap = distTrap, xfecMiss = xfecMiss, 
       xrepMiss = xrepMiss, xfecCols = xfecCols, xrepCols = xrepCols,
       xmean = xmean, xsd = xsd, xfecU = xfecU, xfecT = xfecT,
       xrepU = xrepU, xrepT = xrepT)
}
 
.unstandBeta <- function(xstandNames, formula, xdata, xnow){
  
  xterm <- names( model.frame(formula, xdata, na.action=NULL) )
  
  st <- grep('species',xterm)
  if(length(st) > 0)xterm <- xterm[-st]
  
  xterm <- xterm[xterm %in% xstandNames]
  
  
  if(length(xterm) == 0)return(list(x = xnow, trans = NULL) )
                               
    xun <- as.matrix(xdata[, xterm, drop=F])
    xun <- t( (t(xun) - colMeans(xun,na.rm=T))/apply(xun,2,sd,na.rm=T ) )
    xdata[,xterm] <- xun
    
    xfu  <- .getDesign(formula, xdata)$x
    xfu  <- xfu[,grep('species',colnames(xfu))]
    
    XX <- crossprod(xfu)
    diag(XX) <- diag(XX) + .0001
  
   trans <- solve(XX)%*%crossprod(xfu,xnow) 
  
    list(x = xfu, trans = trans)
}

.blockDiag <- function(mat1,mat2){
  
  #creates block diagional
  
  if(length(mat1) == 0)return(mat2)
  
  namesc <- c(colnames(mat1),colnames(mat2))
  namesr <- c(rownames(mat1),rownames(mat2))
  
  nr1 <- nrow(mat1)
  nr2 <- nrow(mat2)
  nc1 <- ncol(mat1)
  nc2 <- ncol(mat2)
  nr  <- nr1 + nr2
  nc  <- nc1 + nc2
  
  new <- matrix(0,nr,nc)
  new[ 1:nr1, 1:nc1 ] <- mat1
  new[ (nr1+1):nr, (nc1+1):nc ] <- mat2
  colnames(new) <- namesc
  rownames(new) <- namesr
  new
}
.getLambda <- function(ug, fg, z, M, SAMPM, seedData, 
                       tdata, distall, years, PERAREA=F){
  
  # PERAREA - from per-trap to per-area
  
  if(SAMPM){
    fg <- fg*M[drop=F,tdata[,'species'],]*z
  }else{
    fg <- matrix(fg*z,ncol=1)
  }
  
  lindex <- c(1:ncol(fg)) - 1
  
  dmat <- ug/pi/(ug + distall^2)^2
  
  lambda <- kernYrRcpp(dmat, fg, years, seedyear = seedData$year,
                    treeyear = tdata$year,seedrow = seedData$drow,
                    treecol = tdata$dcol, lindex)
  
  if(PERAREA) return(lambda)                               # per area
  
  lambda*matrix( seedData$active*seedData$area, 
                            nrow(lambda), ncol(lambda) )   # per trap
}


.tnorm <- function(n,lo,hi,mu,sig, tiny=0){   
  
  #normal truncated lo and hi
  
  if(length(lo) == 1 & length(mu) > 1)lo <- rep(lo,length(mu))
  if(length(hi) == 1 & length(mu) > 1)hi <- rep(hi,length(mu))
  
  q1 <- pnorm(lo,mu,sig)
  q2 <- pnorm(hi,mu,sig) 
  
  z <- runif(n,q1,q2)
  z <- qnorm(z,mu,sig)
  
  z[z == Inf]  <- lo[z == Inf] + tiny
  z[z == -Inf] <- hi[z == -Inf] + tiny
  z
}

.getPlotLayout <- function(np){
  
  # np - no. plots
  
  if(np == 1)return( c(1,1) )
  if(np == 2)return( c(1,2) )
  if(np == 3)return( c(1,3) )
  if(np <= 4)return( c(2,2) )
  if(np <= 6)return( c(2,3) )
  if(np <= 9)return( c(3,3) )
  if(np <= 12)return( c(3,4) )
  if(np <= 16)return( c(4,4) )
  if(np <= 20)return( c(4,5) )
  if(np <= 25)return( c(5,5) )
  if(np <= 25)return( c(5,6) )
  return( c(6,6) )
}

.seedProb <- function(ug, fg, distall, seedData, tdata, seedNames,
                      z, M, SAMPM, years){
  
  lambda <- .getLambda(ug, fg, z, M, SAMPM, seedData, tdata, 
                       distall, years, PERAREA=F)
  ss     <- as.matrix(seedData[,seedNames])
  dpois(ss, lambda, log=T)
}

.myBy <- function(x, i, j, summat=matrix(0,max(i),max(j)), 
                    totmat=summat, fun='mean'){  
  
  nn <- length(x)
  if( nn != length(i) | nn != length(j) )
    stop('vectors unequal in byFunctionRcpp')
  if( nrow(summat) < max(i) | ncol(summat) < max(j) )
    stop('matrix too small')
  
  ww <- which(is.na(x))
  if(length(ww) > 0){
    x <- x[-ww]
    i <- i[-ww]
    j <- j[-ww]
  }
  
  frommat <- cbind(i,j,x)
  
  nr  <- nrow(frommat)
  
  maxmat <- summat*0 - Inf
  minmat <- summat*0 + Inf
  
  tmp <- byRcpp(nr, frommat, totmat, summat, minmat, maxmat)
  
  if(fun == 'sum')return(tmp$sum)
  if(fun == 'mean'){
    mu <- tmp$sum/tmp$total
    mu[is.na(mu)] <- 0
    return(mu)
  }
  if(fun == 'min'){
    return( tmp$min )
  }
  tmp$max
}

.tnormMVNmatrix <- function(avec, muvec, smat, 
                            lo=matrix(-1000,nrow(muvec),ncol(muvec)), 
                            hi=matrix(1000,nrow(muvec),ncol(muvec)),
                            whichSample = c(1:nrow(smat))){
  
  # lo, hi must be same dimensions as muvec,avec
  # each sample is a row
  
  lo[lo < -1000] <- -1000
  hi[hi > 1000]  <- 1000
  
  if(max(whichSample) > length(muvec))
    stop('whichSample outside length(muvec)')
  
  nd <- dim(avec)
  
  r <- avec
  a <- trMVNmatrixRcpp(avec, muvec, smat, 
                       lo, hi, whichSample, 
                       idxALL = c(0:(nrow(smat)-1)) ) 
  r[,whichSample] <- a[,whichSample]
  r
}


.initEM <- function(distall, priorU, minDiam, maxF, minU, maxU, treeData, seedData,
                    specNames, seedNames, M, SAMPM, years, plotYears,
                    z, xfec){
  
  #close, large trees
  nclose <- Inf
  mind <- minDiam
  matr  <- sort(unique( treeData$dcol[z == 1] ))
  maxdis <- 18
  
  close <- 1:max(treeData$dcol)
  nn    <- nrow(treeData)
  allRows <- 1:nn

  small <- sort(unique( treeData$dcol[treeData$diam <= mind]  ) )
  keep  <- which(treeData$dcol %in% small)
  nn    <- length(keep)
  
  while(nn > 5000){
    
    small <- sort(unique( treeData$dcol[treeData$diam <= mind]  ) )
    
    small <- small[!small %in% matr]
    dtmp <- distall
    dtmp[dtmp > 1000] <- NA
    dtmp[,small] <- NA
    tmp <- t( apply(dtmp, 1, rank))
    close <- which(tmp < 8 & distall < maxdis,arr.ind=T)
    close <- sort(unique(close[,2]))                   # this is dcol
    nclose <- length(close)
    keep   <- which(treeData$dcol %in% close)
    nn     <- length(keep)
    mind <- mind + 4
    if(maxdis > 5)maxdis <- maxdis - 4
    if(mind > 38)break
  }
  
  
  wtree <- which( treeData$dcol %in% close )
  
  tdata <- treeData[wtree,]
  nn    <- nrow(tdata)
  fg    <- rep(0,nn)
  
  ss   <- seedData[,seedNames,drop=F]
  ff <- sapply(ss,is.factor)
  if(!all(!ff))ss <- .fac2num( ss )
  ss <- rowSums(ss, na.rm=T)
  
  for(j in 1:length(plotYears)){
    
    i <- which(tdata$plotYr == plotYears[j])
    if(length(i) == 0)next 
    k <- which(seedData$plotYr == plotYears[j])
    dk <- distall[ seedData[k,'drow'], tdata[i,'dcol'], drop=F ]
    
    kern  <- .getKern(priorU, dk)
    fg[i] <- .getF( kern, g = ss[k]/seedData$area[k]/
                      (.1 + seedData$active[k]) )
  }
  fg[!is.finite(fg)] <- 1
  fg <- fg + .tnorm(length(fg), fg*.1, fg, fg/4, .1)
  wf <- which(fg > maxF)
  if(length(wf) > 0)fg[wf] <- .tnorm(length(wf), 0, .5*maxF, .75*maxF, .2*maxF)
  fg[fg < 1] <- 1
  
  nsim <- 1000
  propF <- fg/20
  propU <- 1
  ug <- priorU
  zf <- fg*0 + 1
  au <- 0
  
  # by plot-yr
  ii <- treeData[,'plotyr']     #consider bnow[znow == 0] = 0
  sm <- matrix(0, max(c(treeData$plotyr, seedData$plotyr)), 1)
  
  pcheck <- c(10, 30, 50, 100, 200)
  
  print('initializing')
  
  pbar <- txtProgressBar(min=1,max=nsim,style=1)
  
  for(g in 1:nsim){
    
    fnew <- .tnorm(nn, 0, maxF, fg, rexp(nn,1/propF))
    unew <- .tnorm(1,minU,maxU,ug,propU)
    
    pnow <- .seedProb(ug, fg, distall, seedData, tdata, 
                      seedNames, zf, M, SAMPM, years)
    pnew <- .seedProb(unew, fnew, distall, seedData, tdata, 
                      seedNames, zf, M, SAMPM, years)
    
    pnow[!is.finite(pnow)] <- min(pnow[is.finite(pnow)],na.rm=T)
    pnew[!is.finite(pnow)] <- min(pnew[is.finite(pnew)],na.rm=T)
    
    # by plot-yr
    ii <- seedData[,'plotyr']
    ii <- rep(ii, length(seedNames))
    
    pnow <- .myBy(as.vector(pnow), ii, ii*0 + 1, summat = sm*0, fun='sum')
    pnew <- .myBy(as.vector(pnew), ii, ii*0 + 1, summat = sm*0, fun='sum')
    
    if(g == 1)accept <- pnow*0
    
    a  <- exp(pnew - pnow)        #wt on seed data
    az  <- runif(length(a),0,1)
    aw  <- which(az < a)
    
    if(length(aw) > 0){
      wa <- which(tdata[,'plotyr'] %in% aw)
      fg[ wa ] <- fnew[ wa ]
      accept[aw] <- accept[aw] + 1
    }
    
    a <- exp(sum(pnew) - sum(pnow))
    if(a > runif(1,0,1)){
      ug <- unew
      au <- au + 1
    }
    if(g %in% pcheck){
      whi <- which(accept > g/2)
      if(length(whi) > 0)propF[whi] <- propF[whi]*2
      wlo <- which(accept < g/5)
      if(length(wlo) > 0)propF[wlo] <- propF[wlo]/2
      if(au > g/2)propU <- propU*2
      if(au < g/5)propU <- propU/2
    }
    setTxtProgressBar(pbar,g)
  }
  
  fstart <- rep(1,nrow(treeData))
  fstart[wtree] <- fg
  
  XX <- crossprod(xfec[wtree,])
  diag(XX) <- diag(XX) + .000001
  
  bf <- solve(XX)%*%crossprod(xfec[wtree,],log(fg))
  mu <- xfec%*%bf
  
  lo <- mu*0
  hi <- lo + maxF
  lo[z == 1] <- 1
  hi[z == 0] <- 1
  lo[z == 0] <- .0001
  fstart <- .tnorm(nrow(treeData),lo,hi,exp(mu),.1)
  fstart[wtree] <- fg
  fstart
}


.ranEffVar <- function(yy, xf, Arand, sg, xrandCols){   # rewrite in cpp
  
  # marginalized variance from random effects
  # xr = xfec[,xrandCols]
  
  xx    <- xf[,xrandCols]%*%Arand           # w'A
  revar <- sg + rowSums(xx*xf[,xrandCols])  # sigma + w'Aw
  XR    <- t(xf/revar)                      
  VI    <- XR%*%xf                          # Q x Q
  V     <- solve(VI)
  v     <- XR%*%yy
  XX    <- XR*t(xf)                         # (x'x/s)_it
  XY    <- XR*yy                            # (x'y/s)_it
  u     <- rowSums(1/XX*XY)
  list(v = v, V = V)
}

.wrapperBeta <- function( priorB, priorIVB, minU, maxU, maxF,
                          priorU, priorVU, SAMPM,
                          seedData, treeData, seedNames, xfecCols,
                          xrepCols, last0first1, ntree, nyr, tyindex,
                          betaPrior, years, distall, YR, yrindex, 
                          RANDOM, reIndex, xrandCols){
  
  function(pars, bgFec, bgRep, xfec, xrep, M, propU, propF, w, 
           z, zmat, matYr){
    
    fg        <- pars$fg
    ug        <- pars$ug
    sg        <- pars$sg
    bgFec     <- pars$bgFec
    bgRep     <- pars$bgRep
    betaYr    <- pars$betaYr
    alphaRand <- pars$alphaRand
    Arand     <- pars$Arand
    
    accept <- 0
    nspec  <- nrow(M)
    nxx    <- nrow(xfec)
    
    yg <- log(fg)
    
    yeffect <- reffect <- 0
    
    xfz <- xfec
    bgf <- bgFec 
    
    w0  <- which( colSums(xfz) == 0 )  
    if(length(w0) > 0){
      xfz <- xfz[,-w0]
      bgf <- bgf[drop=F,-w0,]
    }
    
    if(YR){                            # yeffect in mean
      yeffect <- betaYr[yrindex]
      yg <- yg - yeffect
    }
    
    if(RANDOM){                        # marginalize random effect
      
      reffect <- rowSums( xfec[,xrandCols]*alphaRand[reIndex,] ) 
      yg <- yg - reffect
  #    tmp <- .ranEffVar(yg[z == 1], xfz[z == 1,], Arand, sg, xrandCols)   
  #    V   <- tmp$V
  #    v   <- tmp$v
      
 #   }else{
    }
    
    XX    <- 1/sg*crossprod(xfz[z == 1,])  
    testv <- try( chol(XX) ,T)
    
    if( inherits(testv,'try-error') ){
      diag(XX)  <- diag(XX) + .001
      testv <- try(chol(XX),T)
    }
    V  <- chol2inv(testv)
    v  <- 1/sg*crossprod(xfz[z == 1,],yg[z == 1]) 
 #   }
    
  #  mu    <- V%*%v
    if(is.null(betaPrior)){
      bgf  <- t( rmvnormRcpp(1, V%*%v, V) )
    }else{
      diag(V) <- diag(V) + .001
      lims <- betaPrior$fec
      bgf  <- t(.tnormMVNmatrix( avec=t(V%*%v), muvec=t(V%*%v), smat=V,
                                 lo=matrix(lims[,1],1), hi=matrix(lims[,2],1)))
    }
    
    if(length(w0) > 0){      # no mature individuals
      bgFec <- bgFec*0
      bgFec[-w0,] <- bgf
      bgf <- bgFec
    }
    
    bgFec <- bgf
    
    # maturation
    V  <- solve(1/sg*crossprod(xrep) )
    v  <- 1/sg*crossprod(xrep,w) 
    if(is.null(betaPrior)){
      bgRep <-t( rmvnormRcpp(1, V%*%v, V) )
    }else{
      lims <- betaPrior$rep
      bgRep <- t(.tnormMVNmatrix( avec=matrix(bgRep,1), muvec=t(V%*%v), 
                                  smat=V,
                                  lo=matrix(lims[,1],1), 
                                  hi=matrix(lims[,2],1)))
    }
    rownames(bgFec) <- colnames(xfec) 
    rownames(bgRep) <- colnames(xrep) 
    
    

    # propose z
    tmp <- .propZ(zmat, last0first1, matYr)
    zmatNew  <- tmp$zmat
    znew     <- zmatNew[ tyindex ] 
    matYrNew <- tmp$matYr 
    
    # fg - linear scale
    yg <- log(fg)
    
    lmu  <- xfec%*%bgFec
    if(YR)lmu <- lmu + yeffect
    if(RANDOM)lmu <- lmu + reffect
    
    lo <- hi <- znew        # not log scale
    lo[lo < 1e-6] <- 1e-6
    hi[hi == 1] <- maxF
    hi[hi < 1] <- 1

    fnew <- .tnorm(nxx, lo, hi, fg, rexp(nxx,1/propF), .1)
    ynew <- log(fnew)
    
    # fecundity
    bnow <- bnew <- fg*0
    bnow[z == 1]    <- dnorm(yg[z == 1], lmu[z == 1], sqrt(sg), log=T) 
    bnew[znew == 1] <- dnorm(ynew[znew == 1], lmu[znew == 1], sqrt(sg), log=T) 
    
    # seed
    pnow <- .seedProb(ug, fg, distall, seedData, treeData, 
                      seedNames, z, M, SAMPM, years)
    pnew <- .seedProb(ug, fnew, distall, seedData, treeData, 
                      seedNames, znew, M, SAMPM, years)
    
    # maturation
    pr   <- pnorm( xrep%*%bgRep )
    mnow <- z*log(pr) + (1 - z)*log(1 - pr)
    mnew <- znew*log(pr) + (1 - znew)*log(1 - pr)
    
    # by plot-yr
    ii <- treeData[,'plotyr']     #consider bnow[znow == 0] = 0
    sm <- matrix(0, max(c(treeData$plotyr, seedData$plotyr)), 1)
    
    mnow <- .myBy(mnow, ii, ii*0+1,summat = sm, fun='sum')
    mnew <- .myBy(mnew, ii, ii*0+1,summat = sm, fun='sum')

    bnow <- .myBy(bnow, i = ii, j = ii*0 + 1, summat = sm*0, fun='sum')
    bnew <- .myBy(bnew, i = ii, j = ii*0 + 1, summat = sm*0, fun='sum')
    
    ii <- seedData[,'plotyr']
    ii <- rep(ii, length(seedNames))
    
    pnow <- .myBy(as.vector(pnow), ii, ii*0 + 1, summat = sm*0, fun='sum')
    pnew <- .myBy(as.vector(pnew), ii, ii*0 + 1, summat = sm*0, fun='sum')
    
    accept <- rep(0,length(pnow))
    
    p <- pnew - pnow
    b <- bnew - bnow
    m <- mnew - mnow
    
    a  <- exp( p + b + m )        #wt on seed data
    az  <- runif(length(a),0,1)
    aw  <- which(az < a)
    
    if(length(aw) > 0){
      
      wa <- which(treeData[,'plotyr'] %in% aw)
      
      fg[ wa ] <- fnew[ wa ]
      z[ wa ]  <- znew[ wa ]
      zmat[tyindex] <- z  
      
      tmp <- apply(zmat,1,which.max)
      tmp[rowSums(zmat) == 0] <- ncol(zmat)
      matYr <- tmp
      
    #  matYr[wp] <- matYrNew[wp]
      
      accept[aw] <- 1
    }
    
    unew <- .tnorm(1,minU,maxU,ug,rexp(1,1/propU))
    pnow <- .seedProb(ug, fg, distall, seedData, treeData, seedNames, 
                      z, M, SAMPM, years) 
    pnew <- .seedProb(unew, fg, distall, seedData, treeData, seedNames, 
                      z, M, SAMPM, years) 
    pnow <- sum(pnow[is.finite(pnow)]) + 
            dnorm(ug, priorU, sqrt(priorVU),log=T)
    pnew <- sum(pnew[is.finite(pnew)]) + 
            dnorm(unew, priorU, sqrt(priorVU),log=T)
      
    a <- exp(pnew - pnow)
    if(is.finite(a)){
      if( runif(1,0,1) < a)ug   <- unew
    }
    list(fg = fg, z = z, zmat = zmat, matYr = matYr, ug = ug, 
         bgFec = bgFec, bgRep = bgRep, accept = accept)
  }
}



.getF <- function(kern, g ){
  
  tiny <- .0001
  
  fec <- rep(0, ncol(kern))
  
    kk <- kern
    K   <- crossprod(kk)
    K   <- K + diag(tiny, nrow(K), nrow(K))
    fec <- solve(K)%*%crossprod(kk, g)
  
  fec[fec < tiny] <- tiny
  fec
}

.getM <- function(specNames, seedNames, unknown = 'UNKN', unFraction = .8){
  
  # unknown    - indicates seedNames for unknowns
  # unFraction - prior fraction of seed to unknown
  
  #  tiny <- 1e-6
  
  if(length(specNames) > 1 | length(seedNames) > 1){
    
    M <- matrix(0, length(specNames), length(seedNames), 
                dimnames=list(specNames, seedNames))
    notun  <- rep(1 - unFraction, nrow(M))
    wu     <- grep(unknown, seedNames)
    M[,wu] <- unFraction
    
    wm <- which(rownames(M) %in% colnames(M))
    M[ cbind( match(rownames(M)[wm], colnames(M)), wm) ] <- notun[wm]
    M <- sweep(M, 1, rowSums(M), '/')
    return(M)
  }
  matrix(1)
}

.specFormula <- function(formula){
  
  form <- paste0( as.character(formula), collapse=' ')
  form <- .replaceString(form, '~', '~ species*')
  form <- .replaceString(form, ' + ', '+ species*')
  as.formula(form)
}


.getBetaPrior <- function(betaPrior, bgFec, bgRep, specNames){
  
  fecHi <- bgFec*0 + 10
  fecLo <- bgFec*0 - 10
  repHi <- bgRep*0 + 10
  repLo <- bgRep*0 - 10
  
  if('pos' %in% names(betaPrior)){
    for(j in 1:length(betaPrior$pos)){
      jn <- paste('species',specNames,sep='')
      if(betaPrior$pos[j] != 'intercept')jn <- paste(jn,':',betaPrior$pos[j],sep='')
      fecLo[rownames(fecLo) %in% jn] <- 0
      repLo[rownames(repLo) %in% jn] <- 0
    }
  }
  if('neg' %in% names(betaPrior)){
    for(j in 1:length(betaPrior$neg)){
      jn <- paste('species',specNames,sep='')
      if(betaPrior$neg[j] != 'intercept')jn <- paste(jn,':',betaPrior$neg[j],sep='')
      fecHi[rownames(fecHi) %in% jn] <- 0
      repHi[rownames(repHi) %in% jn] <- 0
    }
  }
  list(fec = cbind(fecLo, fecHi), rep = cbind(repLo, repHi) )
}

.updateBetaYr <- function(yg, z, sg, yrindex, yeGr){
  
  yk <- yrindex[z == 1,]  # year groups, years
  nk <- max(yrindex[,2])  # max no. years
  
  ygroup <- .myBy(yg[z == 1], yk[,1], yk[,2], 
                  summat=matrix(0, length(yeGr), nk), fun='sum')
  ngroup <- .myBy(yg[z == 1]*0+1, yk[,1], yk[,2], 
                  summat=matrix(0, length(yeGr), nk), fun='sum')
  
  wn <- which(ngroup <= 5)
  v <- ygroup/sg
  V <- 1/(ngroup/sg + 1)
  bf <- matrix( rnorm(length(v), V*v, sqrt(V)), nrow(ngroup), 
                ncol(ngroup) )
  bf[wn] <- NA
  bf[bf < -3] <- -3
  bf[bf > 3] <- 3
  wfinite <- which(is.finite(bf))
  bf      <- sweep(bf, 1, rowMeans(bf,na.rm=T), '-')
  bf[wn] <- 0
  list(beta = bf, wfinite = wfinite)
}

.multivarChainNames <- function(rowNames,colNames){
  as.vector( t(outer(colNames,rowNames,paste,sep='_')) )
}


.rdirichlet <- function(n = nrow(pmat), pmat){
  
  # pmat - rows are parameter vectors
  # if pmat is a vector, then n is the number of random vectors
  
  if(!is.matrix(pmat)){
    pmat <- matrix(pmat,1)
    pmat <- pmat[rep(1,n),]
  }
  pmat <- matrix( rgamma(n*ncol(pmat),pmat,1), n, ncol(pmat))
  sweep(pmat, 1, rowSums(pmat), '/')
}

.updateM <- function(ug, fg, z, SAMPM, distall, seedData, seedNames, 
                     treeData, M, priorM, priorMwt, years){
  
  nwt  <- rpois(1, nrow(seedData))
  mnew <- .rdirichlet(pmat=M*nwt)
  
  qnow <- sum( priorM*priorMwt*log(M), na.rm=T)
  qnew <- sum( priorM*priorMwt*log(mnew), na.rm=T)
  
  la1 <- .getLambda(ug, fg, z, M, SAMPM, seedData, treeData, 
                    distall, years, PERAREA=F)
  la2 <- .getLambda(ug, fg, z, mnew, SAMPM, seedData, treeData, 
                    distall, years, PERAREA=F)
  
  tnow <- dpois(as.matrix(seedData[,seedNames]), la1, log=T)
  tnew <- dpois(as.matrix(seedData[,seedNames]), la2, log=T)
  
  ww <- which(is.finite(tnow) & is.finite(tnew))
  
  pnow <- sum(tnow[ww])
  pnew <- sum(tnew[ww])
  
  a <- exp(pnew + qnew - pnow - qnow) 
  if(a > runif(1,0,1))M <- mnew
  M
}

.distmat <- function(x1,y1,x2,y2){
    xd <- outer(x1,x2,function(x1,x2) (x1 - x2)^2)
    yd <- outer(y1,y2,function(y1,y2) (y1 - y2)^2)
    t(sqrt(xd + yd)) 
}

.myrmvnorm <- function (n, mu, sigma){

    sigsvd <- svd(sigma)
    retval <- t(sigsvd$v %*% (t(sigsvd$u) * sqrt(sigsvd$d)))
    retval <- matrix(rnorm(n * ncol(sigma)), nrow = n) %*% retval
    retval + mu
}

.updateVariance <- function(y,mu,s1=1,s2=1){
  
  u1 <- s1 + length(y)/2
  u2 <- s2 + .5*sum( (y - mu)^2 )
  1/rgamma(1,u1,u2) 
  
}

.processPars <- function(xgb,xtrue=numeric(0),CPLOT=F,DPLOT=F,
                        sigOnly = F,burnin=1,xlimits = NULL){  

  #xg      - matrix of gibbs chains
  #xtrue   - true values (simulated data)
  #CPLOT   - if T, plot chains
  #DPLOT   - if T, plot density
  #burnin  - analyze chains > burnin
  #xlimits - xlimits for plot
  #sigOnly - plot only parameters that 95% CI does not include 0
  

  
  if(!is.matrix(xgb))xgb <- matrix(xgb,ncol=1)
  if(is.null(colnames(xgb)))colnames(xgb) <- paste('V',c(1:ncol(xgb)),sep='-')
  
  if(sigOnly){
    wi   <- grep('intercept',colnames(xgb))      #extract covariates for plotting
    btmp <- xgb
    if(length(wi) > 0){
    	btmp <- xgb[,-wi]
      if(length(xtrue) > 0)xtrue <- xtrue[-wi]
    }

    wq   <- apply(btmp,2,quantile,c(.025,.975),na.rm=T)  #extract parameters != 0
    wq   <- which(wq[1,] < 0 & wq[2,] > 0)
    if(length(wq) > 0){
      xgb  <- btmp[,-wq]
      if(length(xtrue) > 0)xtrue <- xtrue[-wq]
    }
   }

  if(!is.matrix(xgb))xgb <- as.matrix(xgb)
  if(burnin > 1){
  	     if(burnin > (nrow(xgb) + 100))stop("burnin too large")
  	     xgb <- xgb[-c(1:burnin),]
  }
  if(!is.matrix(xgb))xgb <- as.matrix(xgb)
  nc <- ncol(xgb)
  nf <- round(sqrt(nc),0)

  out <- t(rbind(apply(xgb,2,mean,na.rm=T),apply(xgb,2,sd,na.rm=T),
                 apply(xgb,2,quantile,c(.025,.975),na.rm=T)))
  if(!is.null(colnames(xgb)))rownames(out) <- colnames(xgb)
  colnames(out) <- c('estimate','se','0.025','0.975')
  if(length(xtrue) > 0){
    out <- cbind(out,xtrue)
    colnames(out) <- c('estimate','se','0.025','0.975','true value')
  }

  mfrow <- .getPlotLayout(ncol(xgb))
  par(mfrow=mfrow, bty='n', mar=c(1,3,3,1))
  
  if(CPLOT){
      for(j in 1:nc){
       plot(xgb[,j],type='l')
       abline(h=out[j,],lty=2)
       if(length(xtrue) > 0)abline(h=xtrue[j],col='red')
       title(colnames(xgb)[j])
     }
  }
  xlims <- xlimits
  if(DPLOT){
      for(j in 1:nc){
        xj <- density(xgb[,j])
        if(is.null(xlimits))xlims <- range(xj$x)
        plot(xj$x,xj$y,type='l',xlim=xlims)
        abline(v=out[j,],lty=2)
        if(length(xtrue) > 0)abline(v=xtrue[j],col='red')
        title(colnames(xgb)[j])
     }
  }
  invisible( list(summary = signif(out,4) )
)

}

.plotObsPred <- function(obs,yMean,ySE=NULL,nbin=NULL,nPerBin=NULL,log=F,
                        ylimit=NULL, xlabel='Observed', ylabel='Predicted',
                        trans = .5, col='black'){

   if(is.null(ylimit)){
     if(!log)plot(obs,yMean,col=.getColor('black',.2),cex=.3,xlab=xlabel,ylab=ylabel)
     if(log) suppressWarnings( plot(obs,yMean,col=.getColor('black',.2),cex=.3,
                                   xlab=xlabel,ylab=ylabel,log='xy') )
   }
   if(!is.null(ylimit)){
     if(!log)plot(obs,yMean,col=.getColor('black',trans),cex=.3,
                  xlab=xlabel,ylab=ylabel,ylim=ylimit)
     if(log) plot(obs,yMean,col=.getColor('black',trans),cex=.3,
                  xlab=xlabel,ylab=ylabel,log='xy',ylim=ylimit)
   }
   if(!is.null(ySE)){
     ylo <- yMean - 1.96*ySE
     yhi <- yMean + 1.96*ySE
     for(i in 1:length(obs))lines(c(obs[i],obs[i]),c(ylo[i],yhi[i]),col='grey',lwd=2)
   }

   if( !is.null(nbin) | !is.null(nPerBin) ){

     if(is.null(nbin))nbin <- 20
     bins <- seq(min(obs,na.rm=T),max(obs,na.rm=T),length=nbin)

     if(!is.null(nPerBin)){
         nbb <- nPerBin/length(obs)
         nbb <- seq(0,1,by=nbb)
         if(max(nbb) < 1)nbb <- c(nbb,1)
         bins <- quantile(obs,nbb,na.rm=T)
         nbin <- length(bins)
     }

     wide <- diff(bins)/2
     for(k in 1:(nbin-1)){
        qk <- which(is.finite(yMean) & obs >= bins[k] & obs <= bins[k+1])
        q  <- quantile(yMean[qk],c(.5,.025,.158,.841,.975),na.rm=T)
        ym <- mean(yMean[qk])
        xx <- mean(bins[k:(k+1)])
        lines(c(xx,xx),q[c(2,5)],lwd=2, col=.getColor(col,.8))
        lines(c(xx-.5*wide[k],xx+.5*wide[k]),q[c(1,1)],lwd=2, col=.getColor(col,.8))
        rect(xx-.4*wide[k],q[3],xx+.4*wide[k],q[4], col=.getColor(col,.5))
      }
   }
}

.getKern <- function(u,dij){
  kk <- u/pi/(u + dij^2)^2
  kk[is.na(kk)] <- 0
  kk
}

.mapSpec <- function(x, y, z, mapx=range(x), mapy=range(y), scale=0,
                     add=F, sym='circles',
                     colVec=rep(1,length(x)), fill=F){
	
   fillCol <- NA
   if(is.logical(fill))fillCol <- colVec
   if(is.character(fill))fillCol <- fill
  
   if(scale > 0).mapSetup(mapx,mapy,scale)
   if(sym == 'circles')symbols(x,y,circles=z/10,inches=F,
                               xlim=mapx,ylim=mapy,fg=colVec,bg=fillCol,
                               lwd=2,add=add)
   if(sym == 'squares')symbols(x,y,squares=z/10,inches=F,
                               xlim=mapx,ylim=mapy,fg=colVec,bg=fillCol,
                               lwd=2,add=add)
   if(sym == 'stars')  symbols(x,y,stars=z/10,inches=F,
                               xlim=mapx,ylim=mapy,fg=colVec,bg=fillCol,
                               lwd=2,add=add)
}

.mapSetup<- function(xlim,ylim,scale){  #scale is m per inch

  px   <- diff(xlim)/scale
  py   <- diff(ylim)/scale
  par(pin=c(px,py))

}

.getColor <- function(col,trans){
  
  # trans - transparency fraction [0, 1]
  
  tmp <- col2rgb(col)
  rgb(tmp[1,], tmp[2,], tmp[3,], maxColorValue = 255, 
      alpha = 255*trans, names = paste(col,trans,sep='_'))
}

.interp <- function(y,INCREASING=F,minVal=-Inf,maxVal=Inf,defaultValue=NULL,
                   tinySlope=NULL){  #interpolate vector x
  
  if(is.null(defaultValue))defaultValue <- NA
  
  tiny <- .00001
  if(!is.null(tinySlope))tiny <- tinySlope
  
  y[y < minVal] <- minVal
  y[y > maxVal] <- maxVal
  
  n  <- length(y)
  wi <- which(is.finite(y))
  
  if(length(wi) == 0)return(rep(defaultValue,n))
  if(length(wi) == 1)ss <- tiny
  
  xx  <- c(1:n)
  z  <- y
  
  if(wi[1] != 1) wi <- c(1,wi)
  if(max(wi) < n)wi <- c(wi,n)
  
  ss <- diff(z[wi])/diff(xx[wi])
  
  ss[is.na(ss)] <- 0
  
  if(length(ss) > 1){
    if(length(ss) > 2)ss[1] <- ss[2]
    ss[length(ss)] <- ss[length(ss)-1]
  }
  if(INCREASING)ss[ss < tiny] <- tiny
  
  if(is.na(y[1]))  z[1] <- z[wi[2]] - xx[wi[2]]*ss[1]
  if(z[1] < minVal)z[1] <- minVal
  if(z[1] > maxVal)z[1] <- maxVal
  
  for(k in 2:length(wi)){
    
    ki <- c(wi[k-1]:wi[k])
    yk <- z[wi[k-1]] + (xx[ki] - xx[wi[k-1]])*ss[k-1]
    yk[yk < minVal] <- minVal
    yk[yk > maxVal] <- maxVal
    z[ki] <- yk
  }
  z
}

.interpRows <- function(x,startIndex=rep(1,nrow(x)),endIndex=rep(ncol(x),nrow(x)),
                       INCREASING=F,minVal=-Inf,maxVal=Inf,
                       defaultValue=NULL,tinySlope=.001){  
  #interpolate rows of x subject to increasing
  
  nn  <- nrow(x)
  p  <- ncol(x)
  xx <- c(1:p)
  
  if(length(minVal) == 1)minVal <- rep(minVal,nn)
  if(length(maxVal) == 1)maxVal <- rep(maxVal,nn)
  
  ni   <- rep(NA,nn)
  flag <- numeric(0)
  
  z <- x
  
  for(i in 1:nn){
    if(startIndex[i] == endIndex[i]){
      z[i,-startIndex[i]] <- NA
      next
    }
    z[i,startIndex[i]:endIndex[i]] <- .interp(x[i,startIndex[i]:endIndex[i]],
                                             INCREASING,minVal[i],maxVal[i],
                                             defaultValue,tinySlope)
  }
  
  z
}

.shadeInterval <- function(xvalues,loHi,col='grey',PLOT=T,add=T,
                           xlab=' ',ylab=' ', trans = .5){
  
  #draw shaded interval
  
  tmp <- smooth.na(xvalues,loHi)
  xvalues <- tmp[,1]
  loHi <- tmp[,-1]
  
  xbound <- c(xvalues,rev(xvalues))
  ybound <- c(loHi[,1],rev(loHi[,2]))
  if(!add)plot(xvalues,loHi[,1]*0,cex=.01,ylim=c(range(loHi,na.rm=T)),
               xlab=xlab,ylab=ylab)
  if(PLOT)polygon(xbound,ybound,border=NA,col=.getColor(col, trans))
  
  invisible(cbind(xbound,ybound))
  
}


smooth.na <- function(x,y){   
  
  #remove missing values
  #x is the index
  #y is a matrix with rows indexed by x
  
  if(!is.matrix(y))y <- matrix(y,ncol=1)
  
  wy <- which(!is.finite(y),arr.ind =T)
  if(length(wy) == 0)return(cbind(x,y))
  wy <- unique(wy[,1])
  ynew <- y[-wy,]
  xnew <- x[-wy]
  
  return(cbind(xnew,ynew))
}


.appendMatrix <- function(m1,m2,fill=NA,SORT=F,asNumbers=F){  
  
  # matches matrices by column names
  # asNumbers: if column heads are numbers and SORT, then sort numerically
  
  if(length(m1) == 0){
    if(is.matrix(m2)){
      m3 <- m2
    } else {
      m3 <- matrix(m2,nrow=1)
    }
    if( !is.null(names(m2)) )colnames(m3) <- names(m2)
    return(m3)
  }
  if(length(m2) == 0){
    if(!is.matrix(m1))m1 <- matrix(m1,nrow=1)
    return(m1)
  }
  if( is.vector(m1) | (length(m1) > 0 & !is.matrix(m1)) ){
    nn <- names(m1)
    if(is.null(nn))warning('cannot append matrix without names')
    m1 <- matrix(m1,1)
    colnames(m1) <- nn
  }  
  if( is.vector(m2) | (length(m2) > 0 & !is.matrix(m2)) ){
    nn <- names(m2)
    if(is.null(nn))warning('cannot append matrix without names')
    m2 <- matrix(m2,1)
    colnames(m2) <- nn
  }
  
  c1 <- colnames(m1)
  c2 <- colnames(m2)
  r1 <- rownames(m1)
  r2 <- rownames(m2)
  n1 <- nrow(m1)
  n2 <- nrow(m2)
  
  allc <-  unique( c(c1,c2) ) 
  if(SORT & !asNumbers)allc <- sort(allc)
  if(SORT & asNumbers){
    ac <- as.numeric(allc)
    allc <- as.character( sort(ac) )
  }
  
  nr <- n1 + n2
  nc <- length(allc)
  
  if(is.null(r1))r1 <- paste('r',c(1:n1),sep='-')
  if(is.null(r2))r2 <- paste('r',c((n1+1):nr),sep='-')
  new <- c(r1,r2)
  
  mat1 <- match(c1,allc)
  mat2 <- match(c2,allc)
  
  out <- matrix(fill,nr,nc)
  colnames(out) <- allc
  rownames(out) <- new
  
  out[1:n1,mat1] <- m1
  out[(n1+1):nr,mat2] <- m2
  out
}

.myBoxPlot <- function(mat, tnam, snames, specColor, label){
  
  # tnam is columns of mat, with values of snames used to match specColor
  
  ord <- order(colMeans(mat),decreasing=F)
  mat  <- mat[,ord]
  tnam <- tnam[ord]
  bb   <- specColor[ match(tnam, snames) ]
  ry   <- range(mat)
  ymin <- min(mat) - diff(ry)*.15
  ymax <- max(mat) + diff(ry)*.15
  bx   <- .getColor(bb,.4)
  
  tmp <- .boxplotQuant( mat,xaxt='n',outline=F,ylim=c(ymin,ymax),
                        col=bx, border=bb, xaxt='n',lty=1)
  abline(h=0,lwd=2,col='grey',lty=2)
  
  dy <- .05*diff(par()$yaxp[1:2])
  
  cext <- .fitText2Fig(tnam,fraction=1)
  text((1:length(ord)) - .1,dy + tmp$stats[5,],tnam,srt=70,pos=4,
       col=bb, cex=cext)
  
  pl    <- par('usr')
  xtext <- pl[1]
  ytext <- pl[3] + diff(pl[3:4])*.85
  .plotLabel(label,location='topleft', cex=1.0)
}


.boxplotQuant <- function( xx, ..., boxfill=NULL ){
  
  tmp <- boxplot( xx, ..., plot=F)
  ss  <- apply( xx, 2, quantile, pnorm(c(-1.96,-1,0,1,1.96)) ) 
  tmp$stats <- ss
  
  pars <- list(...)
  if( 'col' %in% names(pars) )boxfill <- pars$col
  
  bxp( tmp, ..., boxfill = boxfill )
  
  tmp
}


.fitText2Fig <- function(xx, width=T, fraction=1, cex.max=1){
  
  # returns cex to fit xx within fraction of the current plotting device
  # width - horizontal labels stacked vertically
  #!width - vertical labels plotted horizontally
  
  px <- par('pin')[1]
  py <- par('pin')[2]
  cl <- max( strwidth(xx, units='inches') )
  ch <- strheight(xx, units='inches')[1]*length(xx)  # ht of stacked vector
  
  if(width){              #horizontal labels stacked vertically
    xf <- fraction*px/cl
    yf <- fraction*py/ch
  } else {                #vertical labels plotted horizontally
    xf <- fraction*px/ch
    yf <- fraction*py/cl
  }
  
  cexx <- min(c(xf,yf))
  if(cexx > cex.max)cexx <- cex.max
  cexx
}

